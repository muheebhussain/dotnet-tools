﻿using DurableTask.Core;
using DurableTask.SqlServer;
using Microsoft.Extensions.Logging;

var loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole();
});

var logger = loggerFactory.CreateLogger<Program>();

var connectionString = "YourSqlServerConnectionString";
var taskHubName = "YourTaskHubName";

var sqlOrchestrationService = new SqlOrchestrationService(new SqlOrchestrationServiceSettings(connectionString, taskHubName));

var taskHubClient = new TaskHubClient(sqlOrchestrationService);
var taskHubWorker = new TaskHubWorker(sqlOrchestrationService);

taskHubWorker.AddTaskOrchestrations(typeof(SampleOrchestration));
taskHubWorker.AddTaskActivities(typeof(SampleActivity));

await taskHubWorker.StartAsync();

var instanceId = await taskHubClient.CreateOrchestrationInstanceAsync(typeof(SampleOrchestration), null);

logger.LogInformation($"Orchestration started with instance ID = '{instanceId}'");

Console.ReadLine();

public class SampleOrchestration : TaskOrchestration<string, string>
{
    public override async Task<string> RunTask(OrchestrationContext context, string input)
    {
        var result = await context.ScheduleTask<string>(typeof(SampleActivity), input);
        return result;
    }
}

public class SampleActivity : TaskActivity<string, string>
{
    protected override string Execute(TaskContext context, string input)
    {
        return $"Hello, {input}!";
    }
}