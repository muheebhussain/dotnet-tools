﻿using DurableTask.Core;
using DurableTask.AzureStorage;
using Microsoft.Extensions.Logging;

var loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole();
});

var logger = loggerFactory.CreateLogger<Program>();

var storageAccountConnectionString = "YourAzureStorageConnectionString";
var taskHubName = "YourTaskHubName";

var storageOrchestrationService = new AzureStorageOrchestrationService(new AzureStorageOrchestrationServiceSettings
{
    TaskHubName = taskHubName,
    
    LoggerFactory = loggerFactory
});

var taskHubClient = new TaskHubClient(storageOrchestrationService);
var taskHubWorker = new TaskHubWorker(storageOrchestrationService);

taskHubWorker.AddTaskOrchestrations(typeof(SampleOrchestration));
taskHubWorker.AddTaskActivities(typeof(SampleActivity));

await taskHubWorker.StartAsync();

var instanceId = await taskHubClient.CreateOrchestrationInstanceAsync(typeof(SampleOrchestration), null);

logger.LogInformation($"Orchestration started with instance ID = '{instanceId}'");

Console.ReadLine();

public class SampleOrchestration : TaskOrchestration<string, string>
{
    public override async Task<string> RunTask(OrchestrationContext context, string input)
    {
        var result = await context.ScheduleTask<string>(typeof(SampleActivity), input);
        return result;
    }
}

public class SampleActivity : TaskActivity<string, string>
{
    protected override string Execute(TaskContext context, string input)
    {
        return $"Hello, {input}!";
    }
}