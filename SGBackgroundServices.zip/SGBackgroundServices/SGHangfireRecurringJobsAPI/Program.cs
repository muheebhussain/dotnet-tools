using Hangfire;
using Hangfire.MemoryStorage;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHangfire(config => config.UseMemoryStorage());
builder.Services.AddHangfireServer();

var app = builder.Build();

app.UseHangfireDashboard();

app.MapGet("/", () => "Recurring Jobs API is running");

app.MapPost("/schedule-jobs", () =>
{
    RecurringJob.AddOrUpdate("job1", () => Console.WriteLine("Recurring Job 1 executed."), Cron.Minutely);
    RecurringJob.AddOrUpdate("job2", () => Console.WriteLine("Recurring Job 2 executed."), Cron.Hourly);
    return Results.Ok("Jobs scheduled.");
});

app.Run();