namespace SGBackgroundServiceAPI;

public class SGBackgroundWorker : BackgroundService
{
    private readonly ILogger<SGBackgroundWorker> _logger;

    public SGBackgroundWorker(ILogger<SGBackgroundWorker> logger)
    {
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            _logger.LogInformation("SGBackgroundWorker running at: {time}", DateTimeOffset.Now);
            await Task.Delay(1000, stoppingToken);
        }
    }
}