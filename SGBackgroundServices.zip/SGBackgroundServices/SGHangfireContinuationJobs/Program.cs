﻿using Hangfire;
using Hangfire.MemoryStorage;

GlobalConfiguration.Configuration.UseMemoryStorage();
using var server = new BackgroundJobServer();
var parentJobId = BackgroundJob.Enqueue(() => Console.WriteLine("Parent job executed."));
BackgroundJob.ContinueJobWith(parentJobId, () => Console.WriteLine("Continuation job executed."));

Console.WriteLine($"Parent Job ID: {parentJobId}");
Console.ReadLine();
