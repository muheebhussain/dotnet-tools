﻿// See https://aka.ms/new-console-template for more information
using Hangfire;
using Hangfire.MemoryStorage;

GlobalConfiguration.Configuration.UseMemoryStorage();
using var server = new BackgroundJobServer();
Console.WriteLine("Recurring Jobs Processor is running...");
Console.ReadLine();
