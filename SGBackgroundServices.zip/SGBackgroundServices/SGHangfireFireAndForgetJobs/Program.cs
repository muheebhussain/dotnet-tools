﻿
using Hangfire;
using Hangfire.MemoryStorage;

GlobalConfiguration.Configuration.UseMemoryStorage();
using var server = new BackgroundJobServer();
var jobId = BackgroundJob.Enqueue(() => Console.WriteLine("Fire-and-Forget Job executed."));
Console.WriteLine($"Job ID: {jobId}");
Console.ReadLine();