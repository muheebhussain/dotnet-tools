﻿# Production Deployment Guide

**Document Version**: 1.0  
**Date**: February 17, 2026  
**Audience**: DevOps Engineers, SREs, Database Administrators

---

## Table of Contents
1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Pre-Deployment Checklist](#pre-deployment-checklist)
4. [Database Setup](#database-setup)
5. [Application Deployment](#application-deployment)
6. [Post-Deployment Verification](#post-deployment-verification)
7. [Rollback Procedures](#rollback-procedures)
8. [Monitoring Setup](#monitoring-setup)
9. [Troubleshooting](#troubleshooting)

---

## Overview

This guide provides step-by-step instructions for deploying the Archival solution to production environments.

### Deployment Timeline
- **Estimated Duration**: 2-4 hours (first-time deployment)
- **Downtime Required**: None (new deployment)
- **Rollback Time**: < 30 minutes

### Deployment Phases
1. **Database Setup** (1 hour) - Create metadata DB, run migrations
2. **Application Deployment** (30 minutes) - Deploy binaries, configure secrets
3. **Verification** (1 hour) - Test runs, validate data
4. **Monitoring** (30 minutes) - Configure alerts, dashboards

---

## Prerequisites

### Infrastructure Requirements

#### SQL Server
- **Version**: SQL Server 2019+ or Azure SQL Database
- **Sizing**: 
  - CPU: 2 cores minimum
  - RAM: 4 GB minimum
  - Storage: 50 GB minimum (for metadata database)
- **Access**: `db_owner` or equivalent for schema creation

#### Azure Blob Storage
- **Account Type**: General Purpose V2 (StorageV2)
- **Access Tier**: Hot (for archival destination)
- **Replication**: LRS, GRS, or RA-GRS (per your DR requirements)
- **Features**: 
  - Hierarchical Namespace (ADLS Gen2) - Optional but recommended
  - Archive Tier support - Required if using archive lifecycle

#### Compute Environment
**Option A: Kubernetes**
- Kubernetes 1.24+
- kubectl configured
- Helm 3+ (if using Helm charts)

**Option B: Linux VM**
- Ubuntu 20.04+ or RHEL 8+
- .NET 10.0 Runtime installed
- Cron daemon running

**Option C: Azure Container Instance**
- Azure subscription
- Azure CLI installed

### Access Requirements
- [ ] SQL Server admin credentials
- [ ] Azure Storage account key or SAS token
- [ ] Source database read permissions
- [ ] Kubernetes cluster access (if using K8s)
- [ ] Secrets management access (Key Vault, etc.)

### Software Requirements
- [ ] .NET 10.0 Runtime
- [ ] SQL Server client tools (sqlcmd or Azure Data Studio)
- [ ] kubectl (for Kubernetes deployments)
- [ ] Azure CLI (for ACI or storage setup)

---

## Pre-Deployment Checklist

### 1. Environment Validation

```bash
# Verify .NET Runtime
dotnet --version
# Expected: 10.0.x

# Verify SQL Server connectivity
sqlcmd -S your-server -U your-user -P your-password -Q "SELECT @@VERSION"

# Verify Azure Storage connectivity
az storage account show --name your-storage-account --resource-group your-rg
```

### 2. Backup Existing Data

⚠️ **CRITICAL**: Backup all source databases before archival operations.

```sql
-- SQL Server backup
BACKUP DATABASE [YourDatabase]
TO DISK = 'C:\Backups\YourDatabase_PreArchival.bak'
WITH FORMAT, COMPRESSION;
```

### 3. Prepare Secrets

#### Metadata Database Connection String

The application reads the metadata database connection string from:
1. **appsettings.json** - `ConnectionStrings:ArchivalMetadataDb` (recommended for development)
2. **Environment Variable** - `ARCHIVAL_METADATA_DB` (recommended for production)
3. **Kubernetes Secret** - Via environment variable injection

**Priority**: appsettings.json takes precedence over environment variable if both are set.

#### Option A: File-Based (Development/Testing)
Create secrets directory structure:
```bash
mkdir -p /opt/archival/secrets
chmod 700 /opt/archival/secrets
```

Configure `appsettings.Production.json`:
```json
{
  "ConnectionStrings": {
    "ArchivalMetadataDb": "Server=your-server;Database=ArchivalMetadata;User ID=archival_service;Password=YourPassword;"
  }
}
```

#### Option B: Kubernetes Secrets (Production)
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: archival-secrets
type: Opaque
stringData:
  metadata-db: "Server=...;Database=ArchivalMetadata;..."
```

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: archival-connection-strings
type: Opaque
stringData:
  archival-db-connections.json: |
    {
      "reporting_db": "Server=...;Database=ReportingDB;...",
      "analytics_db": "Server=...;Database=AnalyticsDB;..."
    }
  archival-storage-connections.json: |
    {
      "prodarchive": "DefaultEndpointsProtocol=https;AccountName=prodarchive;AccountKey=...;EndpointSuffix=core.windows.net"
    }
```

Apply secrets:
```bash
kubectl apply -f archival-secrets.yaml
kubectl apply -f archival-connection-strings.yaml
```

### 4. Network Connectivity

Verify connectivity from deployment environment:
```bash
# Test SQL Server connectivity
telnet your-sql-server 1433

# Test Azure Storage connectivity
curl https://your-storage-account.blob.core.windows.net/

# If using private endpoints, verify DNS resolution
nslookup your-sql-server
nslookup your-storage-account.blob.core.windows.net
```

---

## Database Setup

### Step 1: Create Metadata Database

```sql
-- Connect to master database
USE master;
GO

-- Create database
CREATE DATABASE ArchivalMetadata
ON PRIMARY 
(
    NAME = ArchivalMetadata_Data,
    FILENAME = 'C:\Data\ArchivalMetadata.mdf',
    SIZE = 100MB,
    MAXSIZE = 10GB,
    FILEGROWTH = 50MB
)
LOG ON 
(
    NAME = ArchivalMetadata_Log,
    FILENAME = 'C:\Logs\ArchivalMetadata_log.ldf',
    SIZE = 50MB,
    MAXSIZE = 5GB,
    FILEGROWTH = 25MB
);
GO

-- Set recovery model (SIMPLE for metadata DB)
ALTER DATABASE ArchivalMetadata SET RECOVERY SIMPLE;
GO
```

### Step 2: Run Schema Creation

```bash
# Download schema file
cd /opt/archival

# Apply base schema
sqlcmd -S your-server -d ArchivalMetadata -U your-user -P your-password \
  -i db/metadata_schema.sql

# Verify tables created
sqlcmd -S your-server -d ArchivalMetadata -U your-user -P your-password \
  -Q "SELECT name FROM sys.tables ORDER BY name"
```

**Expected Output**:
```
archival_blob_configuration
archival_blob_dataset
archival_blob_exemption
archival_blob_policy
archival_dataset
archival_run
archival_run_item
archival_table_configuration
archival_table_exemption
archival_table_policy
```

### Step 3: Run Migrations (In Order)

⚠️ **IMPORTANT**: Run migrations in numerical order.

```bash
# Migration 007: Blob dataset idempotency and execution status
sqlcmd -S your-server -d ArchivalMetadata -U your-user -P your-password \
  -i db/migrations/007_blob_dataset_idempotency_and_execution_status.sql

# Migration 008: Add exemption unique constraints
sqlcmd -S your-server -d ArchivalMetadata -U your-user -P your-password \
  -i db/migrations/008_add_exemption_unique_constraints.sql

# ⚠️ SKIP Migration 009 (blob run locking - references deprecated code)
# This migration is not required for v1.0

# Verify migrations applied
sqlcmd -S your-server -d ArchivalMetadata -U your-user -P your-password \
  -Q "SELECT * FROM sys.indexes WHERE name LIKE 'uq_archival%'"
```

**Expected Unique Indexes**:
- `uq_archival_blob_dataset_config_date`
- `uq_archival_blob_exemption_config_prefix_date`
- `uq_archival_table_exemption_config_date`
- `uq_archival_table_configuration_table`

### Step 4: Create Service Account (Recommended)

```sql
USE ArchivalMetadata;
GO

-- Create login and user
CREATE LOGIN archival_service WITH PASSWORD = 'StrongPassword123!';
CREATE USER archival_service FOR LOGIN archival_service;

-- Grant permissions
ALTER ROLE db_datareader ADD MEMBER archival_service;
ALTER ROLE db_datawriter ADD MEMBER archival_service;

-- Grant execute on stored procedures (if any added in future)
GRANT EXECUTE TO archival_service;
GO
```

### Step 5: Configure Initial Policies

```sql
-- Insert sample table retention policy
INSERT INTO archival_table_policy 
(name, is_active, keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy, created_at, created_by)
VALUES 
('retention_90_days', 1, 90, NULL, NULL, NULL, GETUTCDATE(), 'admin'),
('retention_1_year', 1, NULL, NULL, NULL, 1, GETUTCDATE(), 'admin');

-- Insert sample blob lifecycle policy
INSERT INTO archival_blob_policy 
(name, is_active, cold_min_age_days, archive_min_age_days, delete_min_age_days, created_at, created_by)
VALUES 
('lifecycle_standard', 1, 30, 90, 365, GETUTCDATE(), 'admin'),
('lifecycle_aggressive', 1, 7, 30, 180, GETUTCDATE(), 'admin');

-- Verify policies created
SELECT * FROM archival_table_policy;
SELECT * FROM archival_blob_policy;
```

---

## Application Deployment

### Option A: Kubernetes CronJob

#### 1. Build Docker Image

Create `Dockerfile`:
```dockerfile
FROM mcr.microsoft.com/dotnet/runtime:10.0
WORKDIR /app

# Copy published artifacts
COPY publish/ .

# Set entrypoint
ENTRYPOINT ["dotnet", "Archival.App.dll"]
```

Build and push:
```bash
# Build application
dotnet publish src/Archival.App/Archival.App.csproj \
  --configuration Release \
  --output publish

# Build Docker image
docker build -t your-registry/archival:1.0 .

# Push to registry
docker push your-registry/archival:1.0
```

#### 2. Deploy CronJob

Create `archival-cronjob.yaml`:
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: archival-table-nightly
  namespace: data-platform
spec:
  schedule: "0 2 * * *"  # 2 AM daily
  concurrencyPolicy: Forbid  # Prevent overlapping runs
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 5
  jobTemplate:
    spec:
      backoffLimit: 2  # Retry twice on failure
      template:
        metadata:
          labels:
            app: archival
            job-type: table-archival
        spec:
          restartPolicy: OnFailure
          containers:
          - name: archival
            image: your-registry/archival:1.0
            command: ["dotnet", "/app/Archival.App.dll"]
            args: ["table", "--all-active"]
            env:
            - name: ARCHIVAL_METADATA_DB
              valueFrom:
                secretKeyRef:
                  name: archival-secrets
                  key: metadata-db
            - name: ARCHIVAL_SECRETS_PATH
              value: "/secrets"
            volumeMounts:
            - name: secrets
              mountPath: /secrets
              readOnly: true
            resources:
              requests:
                memory: "512Mi"
                cpu: "500m"
              limits:
                memory: "2Gi"
                cpu: "2"
          volumes:
          - name: secrets
            secret:
              secretName: archival-connection-strings
```

Create `archival-blob-cronjob.yaml`:
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: archival-blob-lifecycle-nightly
  namespace: data-platform
spec:
  schedule: "0 3 * * *"  # 3 AM daily
  concurrencyPolicy: Forbid
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 5
  jobTemplate:
    spec:
      backoffLimit: 2
      template:
        metadata:
          labels:
            app: archival
            job-type: blob-lifecycle
        spec:
          restartPolicy: OnFailure
          containers:
          - name: archival
            image: your-registry/archival:1.0
            command: ["dotnet", "/app/Archival.App.dll"]
            args: ["blob", "--all-targets"]
            env:
            - name: ARCHIVAL_METADATA_DB
              valueFrom:
                secretKeyRef:
                  name: archival-secrets
                  key: metadata-db
            - name: ARCHIVAL_SECRETS_PATH
              value: "/secrets"
            volumeMounts:
            - name: secrets
              mountPath: /secrets
              readOnly: true
            resources:
              requests:
                memory: "512Mi"
                cpu: "500m"
              limits:
                memory: "2Gi"
                cpu: "2"
          volumes:
          - name: secrets
            secret:
              secretName: archival-connection-strings
```

Deploy:
```bash
kubectl apply -f archival-cronjob.yaml
kubectl apply -f archival-blob-cronjob.yaml

# Verify deployment
kubectl get cronjobs -n data-platform
```

### Option B: Linux VM with Cron

#### 1. Deploy Application

```bash
# Create application directory
sudo mkdir -p /opt/archival
sudo chown $(whoami):$(whoami) /opt/archival

# Copy published binaries
cd /path/to/source
dotnet publish src/Archival.App/Archival.App.csproj \
  --configuration Release \
  --output /opt/archival/app

# Create secrets directory
sudo mkdir -p /opt/archival/secrets
sudo chmod 700 /opt/archival/secrets

# Copy secret files
sudo cp archival-db-connections.json /opt/archival/secrets/
sudo cp archival-storage-connections.json /opt/archival/secrets/
sudo chmod 600 /opt/archival/secrets/*.json

# Verify files
ls -la /opt/archival/app
ls -la /opt/archival/secrets
```

#### 2. Create Run Script

Create `/opt/archival/run-table-archival.sh`:
```bash
#!/bin/bash
set -e

# Configuration (can also be set in appsettings.json under ConnectionStrings:ArchivalMetadataDb)
export ARCHIVAL_METADATA_DB="Server=your-server;Database=ArchivalMetadata;User ID=archival_service;Password=YourPassword;"
export ARCHIVAL_SECRETS_PATH="/opt/archival/secrets"

# Logging
LOG_DIR="/var/log/archival"
mkdir -p $LOG_DIR
LOG_FILE="$LOG_DIR/table-archival-$(date +%Y%m%d-%H%M%S).log"

# Run archival
cd /opt/archival/app
dotnet Archival.App.dll table --all-active 2>&1 | tee $LOG_FILE

# Capture exit code
EXIT_CODE=${PIPESTATUS[0]}

# Cleanup old logs (keep 30 days)
find $LOG_DIR -name "table-archival-*.log" -mtime +30 -delete

exit $EXIT_CODE
```

Create `/opt/archival/run-blob-lifecycle.sh`:
```bash
#!/bin/bash
set -e

# Configuration (can also be set in appsettings.json under ConnectionStrings:ArchivalMetadataDb)
export ARCHIVAL_METADATA_DB="Server=your-server;Database=ArchivalMetadata;User ID=archival_service;Password=YourPassword;"
export ARCHIVAL_SECRETS_PATH="/opt/archival/secrets"

# Logging
LOG_DIR="/var/log/archival"
mkdir -p $LOG_DIR
LOG_FILE="$LOG_DIR/blob-lifecycle-$(date +%Y%m%d-%H%M%S).log"

# Run lifecycle
cd /opt/archival/app
dotnet Archival.App.dll blob --all-targets 2>&1 | tee $LOG_FILE

# Capture exit code
EXIT_CODE=${PIPESTATUS[0]}

# Cleanup old logs
find $LOG_DIR -name "blob-lifecycle-*.log" -mtime +30 -delete

exit $EXIT_CODE
```

Make executable:
```bash
chmod +x /opt/archival/run-table-archival.sh
chmod +x /opt/archival/run-blob-lifecycle.sh
```

#### 3. Configure Cron

```bash
# Edit crontab
crontab -e

# Add entries
0 2 * * * /opt/archival/run-table-archival.sh
0 3 * * * /opt/archival/run-blob-lifecycle.sh

# Verify cron entries
crontab -l
```

---

## Post-Deployment Verification

### Step 1: Manual Test Run

```bash
# Run table archival (one table, dry-run mode)
# First, configure one test table in database

# Manual run
dotnet Archival.App.dll table --table-config-id 1

# Check exit code
echo $?
# Expected: 0 (success)
```

### Step 2: Verify Database Records

```sql
-- Check run was created
SELECT TOP 5 * FROM archival_run 
ORDER BY id DESC;

-- Check run items
SELECT TOP 10 * FROM archival_run_item 
WHERE run_id = (SELECT MAX(id) FROM archival_run)
ORDER BY id DESC;

-- Check datasets created
SELECT TOP 10 * FROM archival_dataset 
ORDER BY id DESC;

-- Check blob datasets (if table archival pushed internal datasets)
SELECT TOP 10 * FROM archival_blob_dataset 
WHERE source_type = 1  -- Internal
ORDER BY id DESC;
```

**Expected**:
- `archival_run` has entry with `status = 'Succeeded'`
- `archival_run_item` has entries for each processed table/date
- `archival_dataset` has entries with `status = 'Succeeded'`
- `archival_blob_dataset` has entries if blob lifecycle is configured

### Step 3: Verify Blob Storage

```bash
# Using Azure CLI
az storage blob list \
  --account-name your-storage-account \
  --container-name archive \
  --prefix "your-prefix/" \
  --output table

# Using Azure Storage Explorer (GUI)
# Navigate to: Storage Account > Containers > archive > your-prefix/
```

**Expected**:
- Parquet files exist with correct naming: `{prefix}/part-0000.parquet`, `part-0001.parquet`, etc.
- Files have non-zero size
- Metadata includes creation timestamp

### Step 4: Verify Logs

```bash
# Check logs for errors
grep -i error /var/log/archival/table-archival-*.log

# Check for warnings
grep -i warning /var/log/archival/table-archival-*.log

# Verify success messages
grep "Archive run completed" /var/log/archival/table-archival-*.log
```

**Expected**:
- No ERROR level messages (unless expected transient retries)
- "Archive run completed: Status=Succeeded"
- Run summary with counts (e.g., "Processed 5 table(s), 50 successful archive(s)")

### Step 5: Validate Data Integrity

```sql
-- Compare source row count to archived row count
SELECT 
    d.id AS dataset_id,
    d.table_configuration_id,
    d.as_of_date,
    d.row_count AS archived_rows,
    d.status
FROM archival_dataset d
WHERE d.status = 'Succeeded'
ORDER BY d.id DESC;

-- For specific table, verify row counts match
-- (Run this against source database)
SELECT 
    CAST(transaction_date AS DATE) AS as_of_date,
    COUNT(*) AS source_rows
FROM dbo.sales_transactions
WHERE transaction_date >= '2024-01-01'
GROUP BY CAST(transaction_date AS DATE)
ORDER BY as_of_date;
```

**Expected**: Archived row counts match source row counts

---

## Rollback Procedures

### Scenario 1: Rollback Database Migrations

```sql
-- If migration 008 needs rollback (unique constraints)
USE ArchivalMetadata;
GO

-- Drop unique constraints
DROP INDEX IF EXISTS uq_archival_blob_exemption_config_prefix_date 
  ON archival_blob_exemption;

DROP INDEX IF EXISTS uq_archival_table_exemption_config_date 
  ON archival_table_exemption;
GO

-- Restore from backup if needed
RESTORE DATABASE ArchivalMetadata 
FROM DISK = 'C:\Backups\ArchivalMetadata_PreMigration.bak'
WITH REPLACE;
```

### Scenario 2: Rollback Application Deployment

#### Kubernetes
```bash
# Rollback to previous version
kubectl set image cronjob/archival-table-nightly \
  archival=your-registry/archival:previous-version \
  -n data-platform

# Or delete CronJob entirely
kubectl delete cronjob archival-table-nightly -n data-platform
```

#### Linux VM
```bash
# Stop cron jobs
crontab -e
# Comment out archival entries

# Restore previous version
cp -r /opt/archival/app.backup /opt/archival/app
```

### Scenario 3: Undo Archival (Data Restore)

⚠️ **CRITICAL**: Archival with `delete_after_export = 1` is destructive.

If data was deleted from source:
1. Restore source database from backup
2. Disable archival configuration
3. Investigate root cause

```sql
-- Disable table configuration to prevent further archival
UPDATE archival_table_configuration 
SET is_active = 0 
WHERE id = X;
```

---

## Monitoring Setup

### Key Metrics

| Metric | Source | Threshold | Alert |
|--------|--------|-----------|-------|
| Job Exit Code | Kubernetes Job / Cron | != 0 | Critical |
| Run Duration | Database (`archival_run.ended_at - started_at`) | > 4 hours | Warning |
| Failed Run Count | Database (`archival_run.status = 'Failed'`) | > 0 in 24h | High |
| Error Log Count | Log aggregation | > 10 per run | Medium |
| Archived Bytes | Database (`archival_dataset.total_bytes`) | < expected | Info |

### Monitoring Queries

```sql
-- Failed runs in last 24 hours
SELECT 
    id AS run_id,
    run_type,
    started_at,
    ended_at,
    status,
    note
FROM archival_run
WHERE started_at >= DATEADD(hour, -24, GETUTCDATE())
  AND status = 'Failed'
ORDER BY started_at DESC;

-- Long-running jobs (> 4 hours)
SELECT 
    id AS run_id,
    run_type,
    started_at,
    DATEDIFF(minute, started_at, COALESCE(ended_at, GETUTCDATE())) AS duration_minutes,
    status
FROM archival_run
WHERE started_at >= DATEADD(hour, -24, GETUTCDATE())
  AND DATEDIFF(minute, started_at, COALESCE(ended_at, GETUTCDATE())) > 240
ORDER BY duration_minutes DESC;

-- Recent archival statistics
SELECT 
    run_type,
    status,
    COUNT(*) AS run_count,
    AVG(DATEDIFF(minute, started_at, ended_at)) AS avg_duration_minutes
FROM archival_run
WHERE started_at >= DATEADD(day, -7, GETUTCDATE())
GROUP BY run_type, status;
```

### Log Aggregation

**Splunk Query**:
```spl
index=archival sourcetype=json Level=Error
| stats count by MessageTemplate
| sort -count
```

**ELK Query**:
```json
{
  "query": {
    "bool": {
      "must": [
        { "match": { "Level": "Error" }},
        { "range": { "@timestamp": { "gte": "now-24h" }}}
      ]
    }
  }
}
```

### Dashboard Recommendations

**Grafana Dashboard Panels**:
1. Run Success Rate (gauge)
2. Average Run Duration (time series)
3. Failed Runs (table)
4. Archived Data Volume (bar chart)
5. Error Log Count (counter)

---

## Troubleshooting

### Issue: CronJob Not Running

**Symptoms**: No jobs appear in Kubernetes  
**Diagnosis**:
```bash
kubectl get cronjobs -n data-platform
kubectl describe cronjob archival-table-nightly -n data-platform
```

**Common Causes**:
- Invalid cron schedule syntax
- Namespace doesn't exist
- Image pull failures

**Solutions**:
- Verify schedule: https://crontab.guru
- Check image availability: `docker pull your-registry/archival:1.0`
- Check namespace: `kubectl get ns`

### Issue: Database Connection Failures

**Symptoms**: "Cannot open database" errors in logs  
**Diagnosis**:
```bash
# Test connection from pod
kubectl run -it --rm debug --image=mcr.microsoft.com/mssql-tools \
  --restart=Never -- /bin/bash

sqlcmd -S your-server -U your-user -P your-password -Q "SELECT @@VERSION"
```

**Solutions**:
- Verify connection string format
- Check firewall rules
- Verify credentials not expired
- Check network policies (if using Kubernetes)

### Issue: Azure Storage 403 Forbidden

**Symptoms**: "AuthorizationFailure" in logs  
**Diagnosis**:
```bash
# Test storage access
az storage blob list \
  --account-name your-storage-account \
  --container-name archive \
  --connection-string "your-connection-string"
```

**Solutions**:
- Verify SAS token not expired
- Check account key is correct
- Verify firewall allows source IP
- Check RBAC permissions (if using Managed Identity)

---

## Success Criteria

Before marking deployment as complete:

- [ ] Database created and migrations applied
- [ ] All unique constraints verified
- [ ] Application deployed (Kubernetes or VM)
- [ ] Secrets configured correctly
- [ ] Manual test run succeeded (exit code 0)
- [ ] Database records created (run, run_item, dataset)
- [ ] Blob storage contains Parquet files
- [ ] Logs show no ERROR level messages
- [ ] Cron/CronJob scheduled correctly
- [ ] Monitoring queries return expected data
- [ ] Alert rules configured
- [ ] Documentation updated with environment-specific details

---

## Next Steps

After successful deployment:

1. **Monitor for 1 Week** - Watch for unexpected failures
2. **Gradually Increase Scope** - Add more tables incrementally
3. **Tune Performance** - Adjust parallelism based on observed performance
4. **Implement Alerts** - Configure PagerDuty/Slack notifications
5. **Document Runbooks** - Create incident response procedures
6. **Schedule Reviews** - Weekly review of run statistics

---

## Support Contacts

- **Database Issues**: [dba-team@example.com]
- **Kubernetes Issues**: [platform-team@example.com]
- **Application Issues**: [data-engineering@example.com]
- **After-Hours Emergency**: [oncall-pager@example.com]

---

**Deployment Guide Version**: 1.0  
**Last Updated**: February 17, 2026  
**Maintained By**: Data Platform Team

