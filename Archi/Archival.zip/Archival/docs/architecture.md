﻿# Architecture

This document explains how the Archival solution is structured and how the two main workflows execute.

> Source of truth: code under `src/` (especially `src/Archival.App`, `src/Archival.Application`, `src/Archival.Data`, `src/Archival.Infrastructure`) and metadata DB schema in `src/Archival.Data/ArchivalDbContext.cs`.

## System context

Archival integrates with:

- **SQL Server (metadata DB)**: stores configuration (what to archive, policies), run history, and dataset tracking.
- **SQL Server (source DBs)**: the business tables being archived. Connection strings are loaded from the secrets files.
- **Azure Blob Storage**: destination for Parquet exports and target for lifecycle actions (tier changes, deletions).

## Projects / boundaries

- `src/Archival.App` (CLI host)
  - Responsible for argument parsing, wiring DI, and routing commands.
  - Entry point: `src/Archival.App/Program.cs`.
- `src/Archival.Application` (use cases)
  - Orchestrators and workers (“Run*” vs “Execute*” handlers) plus shared models/results.
  - Reads configuration via `IConfigurationStore` and writes run/dataset tracking via persistence stores.
- `src/Archival.Data` (persistence)
  - EF Core `ArchivalDbContext` + stores (`ConfigurationStore`, `DatasetStore`, `RunsStore`, …).
  - The EF model is the authoritative schema definition for docs.
- `src/Archival.Infrastructure` (external adapters)
  - Azure Blob SDK adapters, resiliency policies, SQL Server helpers, Parquet writer.

## High-level architecture (components + dependencies)

```mermaid
flowchart LR
  subgraph CLI[Archival.App CLI]
    Program[Program.cs]
    Startup[Startup.BuildHost]
    TableCmd[TableCommandHandler]
    BlobCmd[BlobCommandHandler]
  end

  subgraph App[Archival.Application]
    RunTable[RunTableArchivalHandler]
    ExecTable[ExecuteTableArchivalHandler]
    Discover[DiscoverBlobDatasetsHandler]
    ExecBlob[ExecuteBlobDatasetsHandler]

    CfgStore[IConfigurationStore]
    RunsStore[IRunsStore]
    RunItemsStore[IRunItemsStore]
    DsStore[IDatasetStore]
    BlobDsStore[IBlobDatasetStore]
  end

  subgraph Data[Archival.Data]
    Db[(ArchivalDbContext / SQL Server)]
    Stores[Stores and Repositories]
  end

  subgraph Infra[Archival.Infrastructure]
    TableArch[ITableArchiver]
    Cal[IBusinessCalendar]
    BlobList[IBlobLister and IBlobPrefixLister]
    BlobLife[IBlobLifecycleExecutor]
    Secrets[IConnectionStringResolver\nreads secrets JSON]
    Parquet[Parquet writer]
  end

  subgraph Ext[External Systems]
    MetaDB[(SQL Server Metadata DB)]
    SrcDB[(SQL Server Source DBs)]
    Blob[(Azure Blob Storage)]
  end

  Program --> Startup
  Program --> TableCmd
  Program --> BlobCmd

  TableCmd --> RunTable
  RunTable --> ExecTable

  BlobCmd --> Discover
  BlobCmd --> ExecBlob

  RunTable --> CfgStore
  RunTable --> RunsStore
  RunTable --> RunItemsStore
  RunTable --> DsStore

  ExecTable --> DsStore
  ExecTable --> TableArch
  ExecTable --> Parquet
  ExecTable --> Cal

  Discover --> CfgStore
  Discover --> BlobDsStore
  Discover --> BlobList

  ExecBlob --> CfgStore
  ExecBlob --> BlobDsStore
  ExecBlob --> BlobList
  ExecBlob --> BlobLife

  CfgStore --> Stores --> Db --> MetaDB
  RunsStore --> Stores --> Db
  RunItemsStore --> Stores --> Db
  DsStore --> Stores --> Db
  BlobDsStore --> Stores --> Db

  Secrets --> SrcDB
  TableArch --> SrcDB
  Parquet --> Blob
  BlobList --> Blob
  BlobLife --> Blob
```

## Main workflow: table archival

This is initiated by the CLI command `table`.

Key implementation files:
- CLI routing: `src/Archival.App/TableCommandHandler.cs`
- Orchestrator: `src/Archival.Application/Features/TableArchival/RunTableArchival/RunTableArchivalHandler.cs`
- Worker: `src/Archival.Application/Features/TableArchival/ExecuteTableArchival/ExecuteTableArchivalHandler.cs`

```mermaid
sequenceDiagram
  autonumber
  participant CLI as Archival.App CLI
  participant Run as RunTableArchivalHandler
  participant Cfg as IConfigurationStore
  participant Runs as IRunsStore
  participant Ds as IDatasetStore
  participant Tbl as ITableArchiver
  participant Blob as Azure Blob Storage

  CLI->>Run: HandleAsync
  Run->>Runs: StartRunAsync RunType.Archive
  Run->>Cfg: GetActiveTableConfigurationsAsync

  loop each active table configuration
    Run->>Tbl: GetPresentDatesAsync
    Run->>Ds: GetDatasetsByTableAndDatesAsync

    loop each candidate business date
      Run->>Tbl: ExportToParquetAsync
      Tbl-->>Blob: write parquet parts
      Run->>Ds: MarkDatasetSucceededAndPushBlobDatasetAsync
      opt delete_after_export
        Run->>Tbl: DeleteRowsAsync
      end
    end
  end

  Run->>Runs: CompleteRunAsync
```

Operational notes (as implemented):
- **Idempotency**: an `archival_dataset` row is unique per `(table_configuration_id, as_of_date)`; succeeded datasets are skipped.
- **Retry**: previously failed datasets are retried.
- **Run tracking**: a run is created in `archival_run`, and per-date results are written to `archival_run_item` (batch insert).

## Main workflow: blob lifecycle (discover + execute)

This is initiated by the CLI command `blob` with subcommands:
- `blob discover` → populates/updates `archival_blob_dataset`
- `blob execute` → performs actions for due datasets
- `blob lifecycle` → runs discover, then execute

Key implementation files:
- CLI routing: `src/Archival.App/BlobCommandHandler.cs`
- Discover handler: `src/Archival.Application/Features/BlobLifecycle/DiscoverBlobDatasets/DiscoverBlobDatasetsHandler.cs`
- Execute handler: `src/Archival.Application/Features/BlobLifecycle/ExecuteBlobDatasets/ExecuteBlobDatasetsHandler.cs`

```mermaid
flowchart TD
  A[CLI: blob lifecycle\nmode internal/external/all] --> B[DiscoverBlobDatasetsHandler]
  B -->|external configs only\nIsExternal equals true| C[List date-folder prefixes under config.Prefix]
  C --> D[Parse AsOfDate from folder name\nuses BusinessDateFolderFormat and Depth]
  D --> E[Upsert archival_blob_dataset\nunique by BlobConfigurationId plus AsOfDate]
  E --> F[ExecuteBlobDatasetsHandler]
  F --> G[Query due datasets by NextActionAt]
  G --> H[List blobs under dataset prefix]
  H --> I[Apply exemptions by container prefix date]
  I --> J{NextAction}
  J -->|SetCold| K[Set tier Cold]
  J -->|SetArchive| L[Set tier Archive\nfallback if unsupported]
  J -->|Delete| M[Delete blobs and optional HNS cleanup]
  K --> N[Batch mark results back to DB]
  L --> N
  M --> N
```

## Observability & operational notes

- **Logging**: Serilog console logging is configured in `src/Archival.App/Startup.cs`.
- **Run tracking**:
  - Table archival uses `IRunsStore` + `IRunItemsStore` inside `RunTableArchivalHandler`.
  - Blob commands start/complete a run in `src/Archival.App/BlobCommandHandler.cs`.
- **Crash safety**: blob lifecycle uses `archival_blob_dataset.execution_status`, attempt counters, and timestamps to allow re-runs.

## How to verify a claim in these docs

- Trace entrypoints: `src/Archival.App/Program.cs`, `src/Archival.App/Startup.cs`
- Trace CLI routing: `src/Archival.App/Cli/CliParser.cs`, `src/Archival.App/*CommandHandler.cs`
- Trace handler implementations: `src/Archival.Application/Features/**`
- Confirm schema: `src/Archival.Data/ArchivalDbContext.cs`
- Confirm infrastructure adapters: `src/Archival.Infrastructure/**`
