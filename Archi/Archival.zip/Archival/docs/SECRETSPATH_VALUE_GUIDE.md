﻿# SecretsPath Configuration - Correct Value for Project Root Secrets

**Date**: February 17, 2026  
**Project Structure**: Archival (Root) → secrets/ folder at root level

---

## Project Structure

```
C:\Users\muhee\Downloads\Archival\Archival/
├── secrets/                          ← Secrets folder (at root)
│   ├── archival-db-connections.template.json
│   └── archival-storage-connections.template.json
├── src/
│   └── Archival.App/                 ← Application location
│       ├── appsettings.json
│       └── Program.cs
├── db/
├── tests/
├── docs/
└── (other files)
```

---

## Correct SecretsPath Values

### Option 1: Relative Path (RECOMMENDED)
```json
{
  "SecretsPath": "./secrets/"
}
```

**Why**: 
- ✅ Relative to working directory when app starts
- ✅ Works in both local development and Docker
- ✅ Most flexible and portable
- ✅ Standard convention

**When**: Use this in `appsettings.json` (applies everywhere)

---

### Option 2: Relative Path (Alternative)
```json
{
  "SecretsPath": "secrets/"
}
```

**Why**:
- ✅ Same as Option 1, just without the `./`
- ✅ Works the same way
- ✅ Slightly shorter syntax

**When**: Use if you prefer without `./` prefix

---

### Option 3: Absolute Path (Development Only)
```json
{
  "SecretsPath": "C:\\Users\\muhee\\Downloads\\Archival\\Archival\\secrets\\"
}
```

**Why**:
- ❌ NOT RECOMMENDED
- ❌ Only works on this specific machine
- ❌ Won't work in production/Docker
- ❌ Won't work on other developers' machines

**When**: Never use in production (only for troubleshooting)

---

### Option 4: Docker/Linux Path (Container Deployment)
```json
{
  "SecretsPath": "/app/secrets/"
}
```

**Why**:
- ✅ Used when running in Docker container
- ✅ Matches typical container structure
- ✅ Standard for Kubernetes deployments

**When**: Use `appsettings.Production.json` or override via environment variable

---

## Current Configuration

Your current appsettings.json has:
```json
{
  "SecretsPath": "/secrets/"
}
```

This is **correct for Linux/Docker** but should be changed to relative path for better portability.

---

## Recommended Update

### Update appsettings.json (Development & Local)
```json
{
  "ConnectionStrings": {
    "ArchivalMetadataDb": "Server=FARISHSURFACE;Database=ArchivalDb;Trusted_Connection=True;MultipleActiveResultSets=true"
  },
  "SecretsPath": "./secrets/",
  "BlobLifecycle": {
    "DatasetsParallelism": 4
  },
  "ParquetExport": {
    "RowsPerPart": 50000,
    "RowGroupTargetBytes": 67108864,
    "SpillThresholdBytes": 16777216
  }
}
```

### For Docker/Production (if needed)
```json
{
  "ConnectionStrings": {
    "ArchivalMetadataDb": "Server=sql-server;Database=ArchivalDb;User Id=sa;Password=..."
  },
  "SecretsPath": "/app/secrets/",
  "BlobLifecycle": {
    "DatasetsParallelism": 4
  },
  "ParquetExport": {
    "RowsPerPart": 50000,
    "RowGroupTargetBytes": 67108864,
    "SpillThresholdBytes": 16777216
  }
}
```

---

## How Relative Paths Work

When you use `./secrets/`, the application resolves it relative to the **current working directory** when the process starts.

### Local Development
```
Working Directory: C:\Users\muhee\Downloads\Archival\Archival\
"./secrets/" → C:\Users\muhee\Downloads\Archival\Archival\secrets\
✅ WORKS
```

### Docker Container
```
Working Directory: /app/
"./secrets/" → /app/secrets/
(You mount volume: docker run -v /host/secrets:/app/secrets ...)
✅ WORKS
```

### CI/CD Pipeline
```
Working Directory: /build/
"./secrets/" → /build/secrets/
(Build process places secrets in build directory)
✅ WORKS
```

---

## Best Practices

### Development Environment
```json
// appsettings.Development.json
{
  "SecretsPath": "./secrets/"
}
```
✅ Relative path works perfectly

### Production Environment (On-Premise Server)
```json
// appsettings.Production.json
{
  "SecretsPath": "/opt/archival/secrets/"
}
```
✅ Absolute path to production location (on server)

### Docker Container
```bash
# Dockerfile or docker-compose.yml override via environment variable
ENV ARCHIVAL_SECRETS_PATH=/app/secrets/
```
✅ Environment variable override

### Kubernetes
```yaml
# ConfigMap or Secret
env:
  - name: ARCHIVAL_SECRETS_PATH
    value: /app/secrets/
```
✅ Environment variable in pod spec

---

## What to Update

Update your `appsettings.json` from:
```json
"SecretsPath": "/secrets/"
```

To:
```json
"SecretsPath": "./secrets/"
```

This single change makes your configuration portable across:
- ✅ Local development machines
- ✅ Docker containers
- ✅ CI/CD pipelines
- ✅ Production servers

---

## How It Works

The application starts and looks for secrets folder:

```
1. App starts (working directory = project root)
2. Reads appsettings.json
3. Finds "SecretsPath": "./secrets/"
4. Resolves ./secrets/ relative to current working directory
5. Finds archival-db-connections.template.json ✅
6. Finds archival-storage-connections.template.json ✅
```

---

## Summary

| Path | Use Case | Notes |
|------|----------|-------|
| `./secrets/` | Development & Production | **RECOMMENDED** - Portable |
| `secrets/` | Development & Production | Same as above (no ./ prefix) |
| `C:\Users\...\secrets\` | Local troubleshooting only | Machine-specific, not portable |
| `/app/secrets/` | Docker/Kubernetes | Container-specific path |

---

## Recommendation

**Update appsettings.json to use relative path**:
```json
"SecretsPath": "./secrets/"
```

This is the best choice because it works everywhere:
- ✅ Local development
- ✅ Docker containers
- ✅ Production servers
- ✅ CI/CD pipelines
- ✅ Different machines

---

**Status**: Ready to update  
**Recommendation**: Change to `./secrets/` for portability

