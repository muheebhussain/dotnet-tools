﻿# Database Configuration Guide

**Version:** 1.0  
**Last Updated:** February 15, 2026  
**Audience:** Engineers and operators configuring archival via database records  

---

## Table of Contents

1. [Overview](#overview)
2. [General Concepts](#general-concepts)
3. [Table Archival Configuration](#table-archival-configuration)
4. [Blob Lifecycle Configuration](#blob-lifecycle-configuration)
5. [End-to-End Walkthrough](#end-to-end-walkthrough)
6. [Warnings, Logs, and Troubleshooting](#warnings-logs-and-troubleshooting)
7. [Quick Reference](#quick-reference)

---

## Overview

This guide explains how to configure the Archival system by **inserting and updating records directly in the metadata database**. The system is DB-driven: all table archival rules, blob lifecycle policies, retention settings, and exemptions are stored as database records.

**What This Guide Covers:**
- Database table schemas and column definitions
- Required vs. optional configuration fields
- Archive path template syntax and token expansion
- Lifecycle policies and age-based thresholds
- Exemption rules for skipping specific data
- SQL examples for common scenarios
- Validation rules and troubleshooting

**What This Guide Does NOT Cover:**
- Application configuration via `appsettings.json`
- Infrastructure setup (connection strings, secrets)
- Deployment and operations

---

## General Concepts

### What is DB-Driven Configuration?

The Archival system loads its configuration from database tables at runtime:

1. **Configuration records** define what to archive/manage (tables, blobs)
2. **Policy records** define retention rules and lifecycle thresholds
3. **Exemption records** protect specific data from archival/deletion
4. **Run history** tracks execution and references configurations

### Configuration Lifecycle

```
┌──────────────┐
│ Create Config│  INSERT INTO archival_table_configuration...
│   in DB      │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Validate   │  On load: ConfigurationValidator checks rules
│              │  If invalid: Run fails fast with error
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Use in Run   │  Handler reads config, executes archival
│              │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Run History  │  archival_run, archival_run_item, archival_dataset
│   Records    │  Reference config_id for audit trail
└──────────────┘
```

### Key Principles

**Configuration Changes Apply to Future Runs Only**
- Changing a config does NOT re-process past data
- Historical runs remain linked to the config version that was active at the time

**Disabling vs. Deleting**
- **Disable:** Set `is_active = 0` or `is_enabled = 0` (config retained, not used)
- **Delete:** Not recommended if historical runs exist (foreign key constraints)
- Use `is_active = 0` to "soft delete" configurations

**Validation Happens at Load Time**
- Invalid configurations cause runs to fail immediately
- Validation errors include config ID for easy identification
- See [Validation Rules](#validation-rules) sections for details

---

## Table Archival Configuration

### Overview

**Table archival** exports SQL Server table data to Parquet files in Azure Blob Storage and optionally deletes the source rows. Configuration controls:

- Which table to archive
- How data is exported (batch size, date range)
- Where Parquet files are stored (blob path templates)
- Retention rules (how many days/months/years to keep)
- Deletion behavior after export

### Database Tables

Table archival uses three related tables:

1. **`archival_table_configuration`** - Defines which tables to archive
2. **`archival_table_policy`** - Defines retention rules
3. **`archival_table_exemption`** - Protects specific dates from archival

---

### Table: `archival_table_configuration`

This is the primary configuration table for table archival.

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key (auto-increment) |
| `is_active` | bit | Yes | - | 0 | Enable/disable this config (1=active, 0=inactive) |
| `database_name` | nvarchar | Yes | 128 | - | Source database name |
| `schema_name` | nvarchar | Yes | 128 | - | Source schema name (e.g., `dbo`) |
| `table_name` | nvarchar | Yes | 128 | - | Source table name |
| `as_of_date_column` | nvarchar | Yes | 128 | - | Column containing business date (must be datetime/date type) |
| `archive_path_template` | nvarchar | Yes | 400 | - | Blob path template with tokens (see below) |
| `table_policy_id` | int | Yes | - | - | Foreign key to `archival_table_policy` |
| `blob_policy_id` | int | Yes | - | - | Foreign key to `archival_blob_policy` (for lifecycle after archival) |
| `delete_after_export` | bit | Yes | - | 1 | Delete rows from source after successful export (1=yes, 0=no) |
| `batch_delete_size` | int | Yes | - | 10000 | Batch size for DELETE operations |
| `created_at` | datetime2 | Yes | - | - | Timestamp when record was created |
| `created_by` | nvarchar | No | 100 | NULL | Who created the record |
| `updated_at` | datetime2 | No | - | NULL | Timestamp when record was last updated |
| `updated_by` | nvarchar | No | 100 | NULL | Who updated the record |

#### Unique Constraints

- **Unique index on:** `(database_name, schema_name, table_name)`
  - Only one configuration per table allowed
  - Attempting to insert duplicate returns error

---

### Archive Path Template (Critical)

The `archive_path_template` column defines **where Parquet files are stored** in blob storage. Templates support **tokens** that are expanded at runtime.

#### Supported Tokens

| Token | Description | Example Value |
|-------|-------------|---------------|
| `{database}` | Database name (lowercase) | `adventureworks` |
| `{schema}` | Schema name (lowercase) | `dbo` |
| `{table}` | Table name (lowercase) | `orders` |
| `{yyyy}` | 4-digit year | `2026` |
| `{MM}` | 2-digit month (zero-padded) | `02` |
| `{dd}` | 2-digit day (zero-padded) | `15` |
| `{date}` | Full date in yyyy-MM-dd format | `2026-02-15` |
| `{date_type}` | Date type (EOD, EOM, EOQ, EOY) | `EOD` |

**Token Matching:**
- Tokens are **case-insensitive**
- Both `{YYYY}` and `{yyyy}` work
- Unknown tokens cause validation failure

#### Path Normalization Rules

1. **Backslashes converted to forward slashes:** `archive\data\` → `archive/data/`
2. **Leading slashes trimmed:** `/archive/data/` → `archive/data/`
3. **Trailing slashes preserved:** If you want directory-style paths, include trailing `/`

#### Template Examples

**Example 1: Simple date-partitioned path**
```sql
archive_path_template = 'archive/{database}/{schema}/{table}/{yyyy}/{MM}/{dd}/'
```
**Runtime expansion for date 2026-02-15:**
```
archive/adventureworks/dbo/orders/2026/02/15/
```
**Resulting files:**
```
archive/adventureworks/dbo/orders/2026/02/15/orders-part-00001.parquet
archive/adventureworks/dbo/orders/2026/02/15/orders-part-00002.parquet
archive/adventureworks/dbo/orders/2026/02/15/_SUCCESS
```

**Example 2: Compact date format**
```sql
archive_path_template = 'exports/{table}/{date}/'
```
**Runtime expansion for date 2026-02-15:**
```
exports/orders/2026-02-15/
```

**Example 3: No date tokens (fixed path)**
```sql
archive_path_template = 'archive/mydata/'
```
**Runtime expansion (always same):**
```
archive/mydata/
```
**Note:** Without date tokens, all dates export to the same prefix. Not recommended for partitioned data.

**Example 4: Year/month partitioning only**
```sql
archive_path_template = 'warehouse/{database}/{schema}/{table}/{yyyy}/{MM}/'
```
**Runtime expansion for date 2026-02-15:**
```
warehouse/adventureworks/dbo/orders/2026/02/
```
**Note:** Multiple days will export to the same folder (month-level granularity).

---

### Table: `archival_table_policy`

Defines **retention rules** for table data. Determines how many of each date type (EOD, EOM, EOQ, EOY) to keep.

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key |
| `name` | nvarchar | Yes | 200 | - | Policy name (descriptive) |
| `is_active` | bit | Yes | - | 1 | Enable/disable policy |
| `keep_last_eod` | int | No | - | NULL | Keep last N end-of-day dates |
| `keep_last_eom` | int | No | - | NULL | Keep last N end-of-month dates |
| `keep_last_eoq` | int | No | - | NULL | Keep last N end-of-quarter dates |
| `keep_last_eoy` | int | No | - | NULL | Keep last N end-of-year dates |
| `created_at` | datetime2 | Yes | - | - | Creation timestamp |
| `created_by` | nvarchar | No | 100 | NULL | Creator |
| `updated_at` | datetime2 | No | - | NULL | Last update timestamp |
| `updated_by` | nvarchar | No | 100 | NULL | Last updater |

#### Retention Logic

The system classifies business dates using `dbo.v_business_date_classification` view:
- **EOD** (End of Day): Every business day
- **EOM** (End of Month): Last business day of each month
- **EOQ** (End of Quarter): Last business day of each quarter
- **EOY** (End of Year): Last business day of each year

**Retention Calculation:**
1. Query all distinct dates present in the table
2. Classify each date (EOD, EOM, EOQ, EOY) using business calendar
3. For each type, keep the **most recent N** dates (as specified in policy)
4. Dates to archive = Present dates - Keep set - Exemptions

**Example:**
```sql
keep_last_eod = 5   -- Keep last 5 daily snapshots
keep_last_eom = 12  -- Keep last 12 month-ends
keep_last_eoq = 8   -- Keep last 8 quarter-ends
keep_last_eoy = 7   -- Keep last 7 year-ends
```

**If a date qualifies for multiple types:**
- A date that is both EOM and EOQ will be kept if **either** threshold is met
- Example: 2025-12-31 is EOD, EOM, EOQ, and EOY
  - If any of the four "keep last" values would include it, the date is kept

**NULL values mean "keep nothing of that type":**
- `keep_last_eod = NULL` → archive ALL EOD dates (except other types)
- All NULL → archive everything (no retention)

---

### Table: `archival_table_exemption`

Exempts specific business dates from archival. Use this to protect data that should **never** be archived (e.g., legal holds, audit requirements).

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key |
| `table_configuration_id` | int | Yes | - | - | Foreign key to `archival_table_configuration` |
| `as_of_date` | date | Yes | - | - | Business date to exempt |
| `reason` | nvarchar | No | 4000 | NULL | Why this date is exempted (for audit) |
| `created_at` | datetime2 | Yes | - | - | Creation timestamp |
| `created_by` | nvarchar | No | 100 | NULL | Creator |

#### Matching Logic

An exemption matches when:
- `table_configuration_id` matches the config being processed
- `as_of_date` matches the candidate business date

**Effect:** Matching dates are skipped entirely (not archived, not deleted).

---

### Validation Rules (Table Config)

The system validates table configurations at load time using `ConfigurationValidator.ValidateTableConfiguration()`:

#### ❌ Validation Failures (Cause Run to Fail)

1. **`batch_delete_size <= 0`**
   - Error: `"BatchDeleteSize must be positive, got {value}"`
   - Fix: Set to a positive integer (recommended: 10000)

2. **`archive_path_template` is empty or whitespace**
   - Error: `"ArchivePathTemplate is required and cannot be empty"`
   - Fix: Provide a valid template

3. **`archive_path_template` contains invalid blob path characters**
   - Invalid characters: `\ " < > | ? *`
   - Error: `"ArchivePathTemplate contains invalid blob path characters. Invalid chars: ..."`
   - Fix: Remove invalid characters (use `/` for paths, not `\`)

4. **Unknown tokens in template**
   - Error: `"Unknown tokens in archive path template: {token}. Known tokens: ..."`
   - Fix: Use only supported tokens or remove invalid ones

---

### SQL Examples: Table Configuration

#### Example 1: Basic Daily Table Archival

Archive `dbo.Orders` table with daily date partitioning:

```sql
-- Step 1: Create a retention policy
INSERT INTO dbo.archival_table_policy (
    name, is_active, 
    keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy,
    created_at, created_by
) VALUES (
    'Daily_7_Monthly_12_Quarterly_8_Yearly_7', 1,
    7, 12, 8, 7,
    GETUTCDATE(), 'admin'
);
-- Result: id = 1

-- Step 2: Get/create a blob lifecycle policy (for archived data)
-- Assuming a policy already exists with id=1

-- Step 3: Create table configuration
INSERT INTO dbo.archival_table_configuration (
    is_active,
    database_name,
    schema_name,
    table_name,
    as_of_date_column,
    archive_path_template,
    table_policy_id,
    blob_policy_id,
    delete_after_export,
    batch_delete_size,
    created_at,
    created_by
) VALUES (
    1,                                -- is_active: enabled
    'AdventureWorks',                 -- database_name
    'dbo',                            -- schema_name
    'Orders',                         -- table_name
    'OrderDate',                      -- as_of_date_column (must exist in table)
    'archive/{database}/{schema}/{table}/{yyyy}/{MM}/{dd}/',  -- archive_path_template
    1,                                -- table_policy_id (references policy above)
    1,                                -- blob_policy_id (lifecycle after archival)
    1,                                -- delete_after_export: yes
    10000,                            -- batch_delete_size
    GETUTCDATE(),
    'admin'
);
```

**Resulting blob paths (example for 2026-02-15):**
```
archive/adventureworks/dbo/orders/2026/02/15/orders-part-00001.parquet
archive/adventureworks/dbo/orders/2026/02/15/orders-part-00002.parquet
archive/adventureworks/dbo/orders/2026/02/15/_SUCCESS
```

---

#### Example 2: Month-Level Partitioning (No Day Tokens)

Archive `staging.ProductInventory` with month-level granularity:

```sql
INSERT INTO dbo.archival_table_configuration (
    is_active,
    database_name,
    schema_name,
    table_name,
    as_of_date_column,
    archive_path_template,
    table_policy_id,
    blob_policy_id,
    delete_after_export,
    batch_delete_size,
    created_at,
    created_by
) VALUES (
    1,
    'Inventory',
    'staging',
    'ProductInventory',
    'SnapshotDate',
    'warehouse/inventory/{table}/{yyyy}/{MM}/',  -- Month-level only
    1,
    1,
    1,
    5000,                             -- Smaller batch for large table
    GETUTCDATE(),
    'admin'
);
```

**Resulting blob paths (all days in Feb 2026):**
```
warehouse/inventory/productinventory/2026/02/productinventory-part-00001.parquet
warehouse/inventory/productinventory/2026/02/productinventory-part-00002.parquet
warehouse/inventory/productinventory/2026/02/_SUCCESS
```

**Note:** All dates in February 2026 export to the same folder.

---

#### Example 3: Multi-Database Configuration

Archive tables from multiple databases:

```sql
-- Database 1: Sales
INSERT INTO dbo.archival_table_configuration (
    is_active, database_name, schema_name, table_name, as_of_date_column,
    archive_path_template,
    table_policy_id, blob_policy_id, delete_after_export, batch_delete_size,
    created_at, created_by
) VALUES (
    1, 'SalesDB', 'dbo', 'Transactions', 'TransactionDate',
    'archive/{database}/{table}/{yyyy}-{MM}-{dd}/',  -- Using full date token
    1, 1, 1, 10000,
    GETUTCDATE(), 'admin'
);

-- Database 2: Marketing
INSERT INTO dbo.archival_table_configuration (
    is_active, database_name, schema_name, table_name, as_of_date_column,
    archive_path_template,
    table_policy_id, blob_policy_id, delete_after_export, batch_delete_size,
    created_at, created_by
) VALUES (
    1, 'MarketingDB', 'dbo', 'Campaigns', 'StartDate',
    'archive/{database}/{table}/{yyyy}-{MM}-{dd}/',
    1, 1, 1, 10000,
    GETUTCDATE(), 'admin'
);
```

**Resulting blob paths (example for 2026-02-15):**
```
archive/salesdb/transactions/2026-02-15/transactions-part-00001.parquet
archive/marketingdb/campaigns/2026-02-15/campaigns-part-00001.parquet
```

---

#### Example 4: Exempt Specific Dates

Exempt January 1, 2026 from archival (e.g., regulatory hold):

```sql
-- Assuming table_configuration_id = 1 for dbo.Orders
INSERT INTO dbo.archival_table_exemption (
    table_configuration_id,
    as_of_date,
    reason,
    created_at,
    created_by
) VALUES (
    1,
    '2026-01-01',
    'Regulatory hold - Q4 2025 audit in progress',
    GETUTCDATE(),
    'compliance-team'
);
```

**Effect:** The date `2026-01-01` will be skipped during archival runs, even if retention policy says it should be archived.

---

## Blob Lifecycle Configuration

### Overview

**Blob lifecycle management** applies age-based tier changes and deletions to blobs in Azure Storage. This is used for:

- Archived Parquet files (after table archival)
- Other blob data needing lifecycle management

Configuration controls:
- Which containers and prefixes to manage
- Age thresholds for cold/archive/delete actions
- Exemptions for specific blobs

### Database Tables

Blob lifecycle uses three related tables:

1. **`archival_blob_configuration`** - Defines which blob prefixes to manage
2. **`archival_blob_policy`** - Defines age-based lifecycle thresholds
3. **`archival_blob_exemption`** - Protects specific blobs from lifecycle actions

---

### Table: `archival_blob_configuration`

Defines which blob prefixes to apply lifecycle policies to.

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key |
| `is_enabled` | bit | Yes | - | 1 | Enable/disable this config |
| `storage_account_name` | nvarchar | Yes | 128 | - | Azure storage account name |
| `container_name` | nvarchar | Yes | 128 | - | Container name (must follow Azure naming rules) |
| `prefix` | nvarchar | Yes | 1024 | - | Blob prefix (StartsWith match) |
| `include_pattern` | nvarchar | No | 2000 | NULL | Optional regex pattern to include blobs |
| `exclude_pattern` | nvarchar | No | 2000 | NULL | Optional regex pattern to exclude blobs |
| `supports_archive_tier` | bit | Yes | - | 1 | Whether container supports Archive tier (0=no, use Cold instead) |
| `business_date_source` | nvarchar | Yes | 20 | `FromFileName` | How to determine blob age (enum: see below) |
| `blob_policy_id` | int | Yes | - | - | Foreign key to `archival_blob_policy` |
| `created_at` | datetime2 | Yes | - | - | Creation timestamp |
| `created_by` | nvarchar | No | 100 | NULL | Creator |
| `updated_at` | datetime2 | No | - | NULL | Last update timestamp |
| `updated_by` | nvarchar | No | 100 | NULL | Last updater |

#### BusinessDateSource Enum Values

| Value | Description | When to Use |
|-------|-------------|-------------|
| `FromFileName` | Extract date from blob name/path | Default; works with partitioned paths like `archive/data/2026/02/15/` |
| `CreatedOn` | Use blob creation timestamp | When blob names don't contain dates |
| `LastModified` | Use blob last modified timestamp | When modification time represents data currency |

**Default:** `FromFileName`

---

### Blob Targeting Rules

#### Container Matching

- **Exact match:** `container_name` must match the blob's container exactly
- Case-sensitive (Azure container names are lowercase)

#### Prefix Matching

- **StartsWith behavior:** Blob name must start with the configured `prefix`
- Example: `prefix = 'archive/orders/'` matches:
  - ✅ `archive/orders/2026/02/15/file.parquet`
  - ✅ `archive/orders/data.parquet`
  - ❌ `archive/products/file.parquet` (different prefix)

#### Date Extraction (FromFileName)

When `business_date_source = FromFileName`, the system extracts dates from blob paths:
- Looks for `YYYY/MM/DD` segments in the path
- Example: `archive/orders/2026/02/15/file.parquet` → date = 2026-02-15
- If extraction fails, falls back to blob `CreatedAtUtc`

---

### Table: `archival_blob_policy`

Defines age-based lifecycle thresholds.

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key |
| `name` | nvarchar | Yes | 200 | - | Policy name |
| `is_active` | bit | Yes | - | 1 | Enable/disable policy |
| `cold_min_age_days` | int | No | - | NULL | Move to Cold tier after N days |
| `archive_min_age_days` | int | No | - | NULL | Move to Archive tier after N days |
| `delete_min_age_days` | int | No | - | NULL | Delete after N days |
| `created_at` | datetime2 | Yes | - | - | Creation timestamp |
| `created_by` | nvarchar | No | 100 | NULL | Creator |
| `updated_at` | datetime2 | No | - | NULL | Last update timestamp |
| `updated_by` | nvarchar | No | 100 | NULL | Last updater |

#### Lifecycle Action Logic

For each blob, the system calculates `ageDays = Today - BlobDate`:

```
IF ageDays >= delete_min_age_days THEN
    Action = Delete
ELSEIF ageDays >= archive_min_age_days THEN
    Action = SetArchive (or SetCold if !supports_archive_tier)
ELSEIF ageDays >= cold_min_age_days THEN
    Action = SetCold
ELSE
    Action = Skip
END IF
```

**Ordering Constraint:**
- `cold_min_age_days <= archive_min_age_days <= delete_min_age_days`
- Violating this ordering causes validation failure

**NULL values:**
- `cold_min_age_days = NULL` → Never move to Cold
- `archive_min_age_days = NULL` → Never move to Archive
- `delete_min_age_days = NULL` → Never delete
- All NULL → No actions taken (Skip all blobs)

---

### Table: `archival_blob_exemption`

Exempts specific blobs from lifecycle actions.

#### Schema

| Column Name | Type | Required | Max Length | Default | Description |
|-------------|------|----------|-----------|---------|-------------|
| `id` | int | Yes | - | Auto | Primary key |
| `blob_configuration_id` | int | Yes | - | - | Foreign key to `archival_blob_configuration` |
| `as_of_date` | date | Yes | - | - | Business date to exempt |
| `container_name` | nvarchar | Yes | 128 | - | Container name (must match blob config) |
| `prefix` | nvarchar | Yes | 1024 | - | Blob prefix to exempt |
| `reason` | nvarchar | No | 4000 | NULL | Why this is exempted (audit trail) |
| `created_at` | datetime2 | Yes | - | - | Creation timestamp |
| `created_by` | nvarchar | No | 100 | NULL | Creator |

#### Matching Logic

A blob is exempted when **all** of the following match:
1. `blob_configuration_id` matches the config being processed
2. `container_name` matches the blob's container
3. Blob name starts with `prefix`
4. `as_of_date` matches the blob's extracted/assigned date

**Effect:** Matching blobs are skipped (no tier changes, no deletion).

---

### Validation Rules (Blob Config)

The system validates blob configurations at load time using `ConfigurationValidator.ValidateBlobConfiguration()`:

#### ❌ Validation Failures (Cause Run to Fail)

1. **`storage_account_name` is empty**
   - Error: `"StorageAccountName is required"`
   - Fix: Provide a valid storage account name

2. **`container_name` is empty**
   - Error: `"ContainerName is required"`
   - Fix: Provide a valid container name

3. **`container_name` violates Azure naming rules**
   - Rules: 3-63 characters, lowercase alphanumeric and hyphens only, cannot start/end with hyphen
   - Error: `"ContainerName '{name}' does not follow Azure container naming rules..."`
   - Fix: Use a valid container name (e.g., `archive`, `my-data`, `container123`)

4. **`prefix` starts with forward slash**
   - Error: `"Prefix should not start with a forward slash"`
   - Fix: Use `archive/data/` not `/archive/data/`

---

### SQL Examples: Blob Configuration

#### Example 1: Basic 3-Tier Lifecycle Policy

Move archived data through Cold → Archive → Delete tiers:

```sql
-- Step 1: Create lifecycle policy
INSERT INTO dbo.archival_blob_policy (
    name, is_active,
    cold_min_age_days, archive_min_age_days, delete_min_age_days,
    created_at, created_by
) VALUES (
    '30d_Cold_90d_Archive_365d_Delete', 1,
    30,    -- Cold after 30 days
    90,    -- Archive after 90 days
    365,   -- Delete after 1 year
    GETUTCDATE(), 'admin'
);
-- Result: id = 1

-- Step 2: Create blob configuration for archived orders
INSERT INTO dbo.archival_blob_configuration (
    is_enabled,
    storage_account_name,
    container_name,
    prefix,
    include_pattern,
    exclude_pattern,
    supports_archive_tier,
    business_date_source,
    blob_policy_id,
    created_at,
    created_by
) VALUES (
    1,                              -- is_enabled
    'archivalstorage01',            -- storage_account_name
    'archive',                      -- container_name
    'archive/adventureworks/dbo/orders/',  -- prefix
    NULL,                           -- include_pattern (optional)
    NULL,                           -- exclude_pattern (optional)
    1,                              -- supports_archive_tier: yes
    'FromFileName',                 -- business_date_source
    1,                              -- blob_policy_id
    GETUTCDATE(),
    'admin'
);
```

**Effect:**
- All blobs under `archive/adventureworks/dbo/orders/` will be managed
- Day 30: Move to Cold tier
- Day 90: Move to Archive tier
- Day 365: Delete

---

#### Example 2: Cold-Only Policy (No Archive Tier)

For storage accounts that don't support Archive tier:

```sql
INSERT INTO dbo.archival_blob_policy (
    name, is_active,
    cold_min_age_days, archive_min_age_days, delete_min_age_days,
    created_at, created_by
) VALUES (
    '60d_Cold_180d_Delete', 1,
    60,    -- Cold after 60 days
    NULL,  -- No Archive tier
    180,   -- Delete after 180 days
    GETUTCDATE(), 'admin'
);
-- Result: id = 2

INSERT INTO dbo.archival_blob_configuration (
    is_enabled, storage_account_name, container_name, prefix,
    include_pattern, exclude_pattern,
    supports_archive_tier,  -- Important: set to 0
    business_date_source, blob_policy_id,
    created_at, created_by
) VALUES (
    1, 'legacystorage', 'data', 'exports/',
    NULL, NULL,
    0,                      -- supports_archive_tier: no (skip Archive tier)
    'CreatedOn',            -- Use blob creation date
    2,
    GETUTCDATE(), 'admin'
);
```

**Effect:**
- Blobs under `exports/` in `legacystorage/data` container
- Day 60: Move to Cold tier
- Day 180: Delete
- Archive tier skipped (not supported)

---

#### Example 3: Exempt Specific Date Range

Exempt February 2026 from lifecycle actions (e.g., active audit):

```sql
-- Assuming blob_configuration_id = 1 for archived orders
INSERT INTO dbo.archival_blob_exemption (
    blob_configuration_id,
    as_of_date,
    container_name,
    prefix,
    reason,
    created_at,
    created_by
) VALUES
    (1, '2026-02-01', 'archive', 'archive/adventureworks/dbo/orders/2026/02/01/', 'Audit in progress', GETUTCDATE(), 'compliance'),
    (1, '2026-02-02', 'archive', 'archive/adventureworks/dbo/orders/2026/02/02/', 'Audit in progress', GETUTCDATE(), 'compliance'),
    (1, '2026-02-03', 'archive', 'archive/adventureworks/dbo/orders/2026/02/03/', 'Audit in progress', GETUTCDATE(), 'compliance');
    -- ... continue for all dates in February
```

**Effect:** Blobs under the specified prefixes will never be tiered or deleted.

---

#### Example 4: Delete-Only Policy (No Tiering)

Just delete old data without tiering:

```sql
INSERT INTO dbo.archival_blob_policy (
    name, is_active,
    cold_min_age_days, archive_min_age_days, delete_min_age_days,
    created_at, created_by
) VALUES (
    '90d_Delete_Only', 1,
    NULL,  -- No Cold
    NULL,  -- No Archive
    90,    -- Delete after 90 days
    GETUTCDATE(), 'admin'
);
-- Result: id = 3

INSERT INTO dbo.archival_blob_configuration (
    is_enabled, storage_account_name, container_name, prefix,
    include_pattern, exclude_pattern, supports_archive_tier,
    business_date_source, blob_policy_id,
    created_at, created_by
) VALUES (
    1, 'tempstorage', 'temp', 'staging/',
    NULL, NULL, 1,
    'CreatedOn',
    3,
    GETUTCDATE(), 'admin'
);
```

**Effect:**
- Blobs under `staging/` in `tempstorage/temp` container
- Day 90: Deleted
- No tiering (goes straight from Hot to Deleted)

---

## End-to-End Walkthrough

Let's walk through a complete example from configuration to execution.

### Scenario

**Goal:** Archive `AdventureWorks.dbo.Orders` table daily, keep last 7 days + 12 month-ends, then apply lifecycle management to the archived Parquet files.

---

### Step 1: Create Retention Policy

```sql
INSERT INTO dbo.archival_table_policy (
    name, is_active,
    keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy,
    created_at, created_by
) VALUES (
    'Orders_Daily7_Monthly12', 1,
    7,     -- Keep last 7 daily snapshots
    12,    -- Keep last 12 month-ends
    NULL,  -- Don't keep quarter-ends separately
    NULL,  -- Don't keep year-ends separately
    GETUTCDATE(), 'data-engineer'
);
-- Result: id = 10
```

---

### Step 2: Create Lifecycle Policy

```sql
INSERT INTO dbo.archival_blob_policy (
    name, is_active,
    cold_min_age_days, archive_min_age_days, delete_min_age_days,
    created_at, created_by
) VALUES (
    'Orders_Lifecycle', 1,
    30,    -- Cold after 30 days
    180,   -- Archive after 180 days
    730,   -- Delete after 2 years
    GETUTCDATE(), 'data-engineer'
);
-- Result: id = 5
```

---

### Step 3: Create Table Configuration

```sql
INSERT INTO dbo.archival_table_configuration (
    is_active,
    database_name,
    schema_name,
    table_name,
    as_of_date_column,
    archive_path_template,
    table_policy_id,
    blob_policy_id,
    delete_after_export,
    batch_delete_size,
    created_at,
    created_by
) VALUES (
    1,
    'AdventureWorks',
    'dbo',
    'Orders',
    'OrderDate',
    'archive/adventureworks/orders/{yyyy}/{MM}/{dd}/',
    10,   -- table_policy_id from Step 1
    5,    -- blob_policy_id from Step 2 (used later)
    1,    -- delete_after_export: yes
    10000,
    GETUTCDATE(),
    'data-engineer'
);
-- Result: id = 20
```

---

### Step 4: Create Blob Configuration (for Lifecycle)

```sql
INSERT INTO dbo.archival_blob_configuration (
    is_enabled,
    storage_account_name,
    container_name,
    prefix,
    include_pattern,
    exclude_pattern,
    supports_archive_tier,
    business_date_source,
    blob_policy_id,
    created_at,
    created_by
) VALUES (
    1,
    'prodarchival',
    'archive',
    'archive/adventureworks/orders/',  -- Matches table's archive path
    NULL,
    NULL,
    1,
    'FromFileName',
    5,    -- blob_policy_id from Step 2
    GETUTCDATE(),
    'data-engineer'
);
-- Result: id = 15
```

---

### Step 5: (Optional) Add Exemption

Exempt a specific date (e.g., end-of-year that's under audit):

```sql
INSERT INTO dbo.archival_table_exemption (
    table_configuration_id,
    as_of_date,
    reason,
    created_at,
    created_by
) VALUES (
    20,            -- table_configuration_id from Step 3
    '2025-12-31',  -- New Year's Eve
    'Year-end close - keep permanently',
    GETUTCDATE(),
    'finance-dept'
);
```

---

### Step 6: Run Archival

Execute the archival CLI command:

```bash
./Archival.App table --all-active
```

**What Happens (Runtime Flow):**

1. **Load Configuration**
   - Read `archival_table_configuration` where `is_active = 1`
   - Find table config id=20 (AdventureWorks.dbo.Orders)
   - Validate configuration (passes all rules)

2. **Discover Dates**
   - Query source table: `SELECT DISTINCT CAST(OrderDate AS date) FROM AdventureWorks.dbo.Orders`
   - Find dates: [2026-02-01, 2026-02-08, 2026-02-09, ..., 2026-02-15]

3. **Calculate Retention**
   - Load retention policy id=10
   - Classify dates using business calendar
   - Keep set: Last 7 EOD + Last 12 EOM
   - Archive candidates: Present dates - Keep set - Exemptions

4. **For Each Candidate Date (e.g., 2026-02-01):**
   - **Check exemptions:** 2026-02-01 not exempted → proceed
   - **Check if already archived:** Query `archival_dataset` → not found → proceed
   - **Expand template:** `archive/adventureworks/orders/{yyyy}/{MM}/{dd}/` → `archive/adventureworks/orders/2026/02/01/`
   - **Export to Parquet:**
     - Query: `SELECT * FROM AdventureWorks.dbo.Orders WHERE OrderDate >= '2026-02-01' AND OrderDate < '2026-02-02'`
     - Write to: `archive/adventureworks/orders/2026/02/01/orders-part-00001.parquet`
     - Write marker: `archive/adventureworks/orders/2026/02/01/_SUCCESS`
   - **Validate row count:**
     - Query: `SELECT COUNT(*) FROM AdventureWorks.dbo.Orders WHERE OrderDate >= '2026-02-01' AND OrderDate < '2026-02-02'`
     - Compare to exported rows → match → proceed
   - **Delete from source:**
     - Execute: `DELETE TOP (10000) FROM AdventureWorks.dbo.Orders WHERE OrderDate >= '2026-02-01' AND OrderDate < '2026-02-02'`
     - Repeat until all rows deleted
   - **Mark dataset successful:** Update `archival_dataset` status = 'Succeeded'

5. **Record Run History**
   - Create record in `archival_run` (run_type='Archive', status='Succeeded')
   - Create records in `archival_run_item` (one per date archived)

---

### Step 7: Run Blob Lifecycle (Later)

Execute lifecycle management:

```bash
./Archival.App blob --all-active
```

**What Happens:**

1. **Load Blob Configuration**
   - Read `archival_blob_configuration` where `is_enabled = 1`
   - Find blob config id=15 (prodarchival/archive/orders/)
   - Load blob policy id=5

2. **List Blobs**
   - Azure SDK: List blobs in `prodarchival/archive` starting with `archive/adventureworks/orders/`

3. **For Each Blob:**
   - **Extract date:** From path `archive/adventureworks/orders/2026/02/01/orders-part-00001.parquet` → date = 2026-02-01
   - **Check exemptions:** No blob exemptions for 2026-02-01 → proceed
   - **Calculate age:** `ageDays = Today - 2026-02-01` = 14 days
   - **Determine action:**
     - `ageDays < 30` → Action = Skip (too new for Cold tier)
   - **Skip blob** (no action taken yet)

4. **30 Days Later:**
   - Same blob, age = 44 days
   - `ageDays >= 30` → Action = SetCold
   - **Execute:** Azure SDK: Set blob tier to Cold

5. **180 Days Later:**
   - Same blob, age = 194 days
   - `ageDays >= 180` → Action = SetArchive
   - **Execute:** Azure SDK: Set blob tier to Archive

6. **730 Days Later:**
   - Same blob, age = 744 days
   - `ageDays >= 730` → Action = Delete
   - **Execute:** Azure SDK: Delete blob

---

## Warnings, Logs, and Troubleshooting

### Common Warnings

#### 1. Unknown date_type Fallback

**Warning Message:**
```
[WRN] Unknown date_type: {DateType}, defaulting to EOD
```

**Cause:**
- The `dbo.v_business_date_classification` view returned a `date_type` value not in `['EOD', 'EOM', 'EOQ', 'EOY']`

**Fix:**
- Verify business calendar view data
- Ensure date_type column contains only valid values
- Update view if necessary

**Impact:** System defaults to EOD (safe fallback)

---

#### 2. Future-Dated Blob

**Warning Message:**
```
[WRN] Blob has future date: {BlobName}, Date={Date}
```

**Cause:**
- Blob path extraction or date assignment resulted in a date > today
- Examples:
  - Blob path: `archive/data/2027/01/01/file.parquet` (future date in path)
  - System clock issue

**Fix:**
- Verify blob paths are correct
- Check system clock
- If intentional (e.g., scheduled data), blob is skipped safely

**Impact:** Blob is skipped (no lifecycle action)

---

#### 3. Unusually Large Date Set

**Warning Message:**
```
[WRN] Unusually large number of distinct dates found: {Count} for table {Schema}.{Table}. This may impact performance.
```

**Cause:**
- Table has > 10,000 distinct business dates
- Possible after removing 10-year window (MED-3 fix)

**Fix:**
- Expected for long-lived tables (no action needed)
- Consider partitioning config if performance degrades
- Review retention policy to keep fewer dates

**Impact:** Performance may degrade for very large date sets

---

### Common Errors

#### 1. Configuration Validation Failure

**Error Message:**
```
[ERR] Invalid table configuration (ID={Id}): {ValidationError}
```

**Examples:**
- `"BatchDeleteSize must be positive, got 0"`
- `"ArchivePathTemplate is required and cannot be empty"`
- `"ArchivePathTemplate contains invalid blob path characters. Invalid chars: \, ", <, >, |, ?, *"`

**Fix:**
- Correct the configuration in the database
- See [Validation Rules](#validation-rules-table-config) section

**Impact:** Run fails immediately (no data processed)

---

#### 2. Row Count Mismatch

**Error Message:**
```
[ERR] Row count mismatch: exported {ExportedRows}, expected {ExpectedRows}
```

**Cause:**
- Exported row count doesn't match source `COUNT(*)`
- Indicates partial export or data change during export

**Fix:**
- **If data changed during export:** Retry (this is expected for active tables)
- **If persistent:** Check for:
  - SQL timeout issues
  - Blob upload failures
  - Network issues during export

**Impact:** Export marked as failed, retry on next run

---

#### 3. Container Naming Validation

**Error Message:**
```
[ERR] Invalid blob configuration (ID={Id}): ContainerName '{Name}' does not follow Azure container naming rules (3-63 chars, lowercase alphanumeric and hyphens only)
```

**Cause:**
- Container name violates Azure naming rules
- Examples: `MyContainer` (uppercase), `my_container` (underscore), `ab` (too short)

**Fix:**
- Use lowercase letters, numbers, and hyphens only
- 3-63 characters
- Cannot start or end with hyphen

**Impact:** Run fails immediately

---

### Troubleshooting Checklist

#### Problem: Table Not Being Archived

**Check:**
1. `is_active = 1` in `archival_table_configuration`?
2. Table has data in the configured `as_of_date_column`?
3. Dates are within scope (not all in "keep set")?
4. Dates not exempted in `archival_table_exemption`?
5. `table_policy_id` references valid policy?

**Query to Debug:**
```sql
-- Check config
SELECT * FROM dbo.archival_table_configuration WHERE id = {YourConfigId};

-- Check policy
SELECT * FROM dbo.archival_table_policy WHERE id = {YourPolicyId};

-- Check exemptions
SELECT * FROM dbo.archival_table_exemption WHERE table_configuration_id = {YourConfigId};

-- Check already archived dates
SELECT * FROM dbo.archival_dataset WHERE table_configuration_id = {YourConfigId} ORDER BY as_of_date DESC;
```

---

#### Problem: Blobs Not Being Lifecycled

**Check:**
1. `is_enabled = 1` in `archival_blob_configuration`?
2. `container_name` and `prefix` match blob location?
3. Blobs old enough to meet age threshold?
4. Blobs not exempted in `archival_blob_exemption`?
5. `blob_policy_id` references valid policy?

**Query to Debug:**
```sql
-- Check config
SELECT * FROM dbo.archival_blob_configuration WHERE id = {YourConfigId};

-- Check policy
SELECT * FROM dbo.archival_blob_policy WHERE id = {YourPolicyId};

-- Check exemptions
SELECT * FROM dbo.archival_blob_exemption WHERE blob_configuration_id = {YourConfigId};

-- Check run history
SELECT TOP 10 * FROM dbo.archival_run WHERE run_type = 'Lifecycle' ORDER BY started_at DESC;
SELECT TOP 100 * FROM dbo.archival_run_item WHERE run_id = {YourRunId};
```

---

## Quick Reference

### Table Names

| Purpose | Table Name |
|---------|-----------|
| Table archival config | `dbo.archival_table_configuration` |
| Table retention policy | `dbo.archival_table_policy` |
| Table exemptions | `dbo.archival_table_exemption` |
| Blob lifecycle config | `dbo.archival_blob_configuration` |
| Blob lifecycle policy | `dbo.archival_blob_policy` |
| Blob exemptions | `dbo.archival_blob_exemption` |
| Run history | `dbo.archival_run` |
| Run item details | `dbo.archival_run_item` |
| Dataset tracking | `dbo.archival_dataset` |

---

### Archive Path Template Tokens

| Token | Example Output |
|-------|----------------|
| `{database}` | `adventureworks` |
| `{schema}` | `dbo` |
| `{table}` | `orders` |
| `{yyyy}` | `2026` |
| `{MM}` | `02` |
| `{dd}` | `15` |
| `{date}` | `2026-02-15` |
| `{date_type}` | `EOD` |

---

### Enum Values

**BusinessDateSource:**
- `FromFileName` (default)
- `CreatedOn`
- `LastModified`

**DateType (business calendar):**
- `EOD` - End of Day
- `EOM` - End of Month
- `EOQ` - End of Quarter
- `EOY` - End of Year

**RunStatus:**
- `Running`
- `Succeeded`
- `Failed`
- `PartiallySucceeded`

**DatasetStatus:**
- `Pending`
- `Succeeded`
- `Failed`
- `Partial`

**LifecycleAction:**
- `None`
- `SetCold`
- `SetArchive`
- `Delete`
- `Skip`

---

### Useful Queries

**List all active table configs:**
```sql
SELECT id, database_name, schema_name, table_name, archive_path_template
FROM dbo.archival_table_configuration
WHERE is_active = 1;
```

**List all enabled blob configs:**
```sql
SELECT id, storage_account_name, container_name, prefix
FROM dbo.archival_blob_configuration
WHERE is_enabled = 1;
```

**Recent runs:**
```sql
SELECT TOP 10 id, run_type, started_at, ended_at, status, note
FROM dbo.archival_run
ORDER BY started_at DESC;
```

**Datasets archived today:**
```sql
SELECT table_configuration_id, as_of_date, status, row_count, total_bytes
FROM dbo.archival_dataset
WHERE CAST(created_at AS date) = CAST(GETUTCDATE() AS date)
ORDER BY created_at DESC;
```

---

## Summary

This guide covered:
- ✅ Database-driven configuration model
- ✅ Table archival setup (configs, policies, exemptions)
- ✅ Archive path templates with token expansion
- ✅ Blob lifecycle setup (configs, policies, exemptions)
- ✅ Age-based tiering and deletion
- ✅ End-to-end walkthrough
- ✅ Validation rules and error handling
- ✅ Troubleshooting common issues

**Next Steps:**
1. Insert your configurations using the SQL examples
2. Run the archival CLI to process data
3. Monitor logs for warnings and errors
4. Review run history in database tables

For operational guidance (CLI commands, environment variables), see the main README.md.

---

**Document Version:** 1.0  
**Last Updated:** February 15, 2026

