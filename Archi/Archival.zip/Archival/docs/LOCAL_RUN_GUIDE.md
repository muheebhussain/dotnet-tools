﻿# How to Run Archival App Locally - Table Command Guide

**Date**: February 17, 2026  
**Environment**: Windows Development  
**Command**: Table Archival

---

## Prerequisites

### 1. Database Setup
Your appsettings.json already has:
```json
"ConnectionStrings": {
  "ArchivalMetadataDb": "Server=FARISHSURFACE;Database=ArchivalDb;Trusted_Connection=True;MultipleActiveResultSets=true"
}
```
✅ Database: `ArchivalDb` on server `FARISHSURFACE`  
✅ Auth: Windows Integrated Authentication (Trusted_Connection)

### 2. Secrets Folder
Your appsettings.json has:
```json
"SecretsPath": "./secrets/"
```
✅ Secrets folder location: `./secrets/` (relative to project root)

### 3. Required Files in secrets/
Ensure these files exist in `C:\Users\muhee\Downloads\Archival\Archival\secrets\`:
```
secrets/
├── archival-db-connections.json (or .template.json)
└── archival-storage-connections.json (or .template.json)
```

---

## Running the App Locally

### Method 1: Using dotnet run (RECOMMENDED FOR DEVELOPMENT)

**Step 1: Open Terminal/PowerShell**
```powershell
# Navigate to the app project directory
cd C:\Users\muhee\Downloads\Archival\Archival\src\Archival.App
```

**Step 2: Run with dotnet run**
```powershell
# Run table archival with all active configurations
dotnet run -- table --all-active

# OR run for a specific table configuration
dotnet run -- table --table-config-id 1
```

---

### Method 2: Using dotnet build + execute

**Step 1: Build the application**
```powershell
cd C:\Users\muhee\Downloads\Archival\Archival\src\Archival.App
dotnet build
```

**Step 2: Find the executable**
```powershell
# Debug build
cd .\bin\Debug\net8.0\  # (or latest .NET version)

# OR Release build
cd .\bin\Release\net8.0\
```

**Step 3: Run the executable**
```powershell
# All active configurations
.\Archival.App.exe table --all-active

# OR specific configuration
.\Archival.App.exe table --table-config-id 1
```

---

### Method 3: Using Visual Studio

**Step 1: Open Solution**
```
Open: C:\Users\muhee\Downloads\Archival\Archival\Archival.sln
```

**Step 2: Set Archival.App as Startup Project**
- Right-click `Archival.App` project
- Select "Set as Startup Project"

**Step 3: Set Debug Arguments**
- Right-click `Archival.App` project
- Select "Properties"
- Go to "Debug" → "General"
- Set "Command line arguments" to: `table --all-active`

**Step 4: Run**
- Press `F5` (Debug) or `Ctrl+F5` (Release)

---

## Common Table Command Scenarios

### Scenario 1: Run All Active Table Configurations
```powershell
dotnet run -- table --all-active
```

**What it does**:
- Finds all active table configurations from database
- Archives each table's data by business date
- Exports to Parquet format
- Pushes to blob storage via configured blob configuration

**Output**: Progress logs showing:
```
[2026-02-17 14:30:00] [INF] Table archival started
[2026-02-17 14:30:01] [INF] Processing table: dbo.tbl_reporting_comb_stock_record
[2026-02-17 14:30:02] [INF] Exporting data to Parquet...
[2026-02-17 14:30:15] [INF] Data exported to blob storage
```

---

### Scenario 2: Run Specific Table Configuration
```powershell
# Get ID from database first
dotnet run -- table --table-config-id 1
```

**What it does**:
- Processes only the table configuration with ID = 1
- Same workflow as above (export → push to blob)

---

## Running Blob Commands

### Overview: Blob Lifecycle Management

The blob commands manage the lifecycle of archived datasets in blob storage:
- **Discover**: Find datasets in blob storage (internal and external)
- **Execute**: Apply lifecycle actions (SetCold, SetArchive, Delete)

---

## Blob Discover Command

### Purpose
Discovers datasets in blob storage and updates their status in the metadata database.

---

### Discover Internal Blob Datasets (Auto-Discovered from Archival)

**Command**:
```powershell
dotnet run -- blob discover --internal
```

**What it does**:
- Scans the `archival_blob_configuration` table for `is_external = 0`
- Discovers datasets that were created by the archival process
- Updates dataset metadata with blob tier information
- Tracks current tier state (Hot, Cool, Archive)

**Output**: Progress logs showing:
```
[2026-02-17 14:35:00] [INF] Blob discovery started: Type=Internal
[2026-02-17 14:35:01] [INF] Discovering datasets from storage account: myarchivalstorage
[2026-02-17 14:35:05] [INF] Discovered 42 datasets
[2026-02-17 14:35:10] [INF] Updated metadata for 42 datasets
[2026-02-17 14:35:15] [INF] Blob discovery completed successfully
```

**Example with specific blob config**:
```powershell
# Discover for specific blob configuration (ID=1)
dotnet run -- blob discover --internal --blob-config-id 1
```

---

### Discover External Blob Datasets (From Partner/External Sources)

**Command**:
```powershell
dotnet run -- blob discover --external
```

**What it does**:
- Scans the `archival_blob_configuration` table for `is_external = 1`
- Discovers datasets provided by external partners/sources
- Tracks external dataset locations and metadata
- Updates blob dataset metadata with external source information

**Output**: Progress logs showing:
```
[2026-02-17 14:40:00] [INF] Blob discovery started: Type=External
[2026-02-17 14:40:01] [INF] Discovering external datasets from storage account: partnerstorage
[2026-02-17 14:40:05] [INF] Discovered 15 external datasets
[2026-02-17 14:40:10] [INF] Updated metadata for 15 external datasets
[2026-02-17 14:40:15] [INF] Blob discovery completed successfully
```

**Example with specific blob config**:
```powershell
# Discover external datasets for specific configuration (ID=2)
dotnet run -- blob discover --external --blob-config-id 2
```

---

### Discover All Datasets (Internal + External)

**Command**:
```powershell
dotnet run -- blob discover --all
```

**What it does**:
- Runs discovery for both internal and external blob configurations
- Processes all blob configurations in sequence
- Updates all dataset metadata

---

## Blob Execute Command

### Purpose
Applies lifecycle actions to discovered datasets (tier transitions, deletion, etc.)

---

### Execute Internal Blob Lifecycle Actions

**Command**:
```powershell
dotnet run -- blob execute --internal
```

**What it does**:
- Finds datasets from internal archival that are ready for lifecycle actions
- Checks blob policies for scheduling (when to move to Cool, Archive, Delete)
- Applies tier transitions:
  - Hot → Cool (after X days)
  - Cool → Archive (after Y days)
  - Archive → Delete (after Z days)
- Updates dataset status and tier information

**Output**: Progress logs showing:
```
[2026-02-17 14:45:00] [INF] Blob execution started: Type=Internal
[2026-02-17 14:45:01] [INF] Checking 42 internal datasets for lifecycle actions
[2026-02-17 14:45:05] [INF] Applying action SetCold to 8 datasets (moving to Cool tier)
[2026-02-17 14:45:10] [INF] Applying action SetArchive to 3 datasets (moving to Archive tier)
[2026-02-17 14:45:15] [INF] Applying action Delete to 1 dataset
[2026-02-17 14:45:20] [INF] Blob execution completed: 12 actions applied
```

**Example with specific blob config**:
```powershell
# Execute lifecycle for specific internal config (ID=1)
dotnet run -- blob execute --internal --blob-config-id 1
```

---

### Execute External Blob Lifecycle Actions

**Command**:
```powershell
dotnet run -- blob execute --external
```

**What it does**:
- Applies lifecycle actions to external/partner datasets
- Follows external blob policies for tier transitions
- Handles external datasets that may have different policies/constraints
- Updates external dataset status

**Output**: Progress logs showing:
```
[2026-02-17 14:50:00] [INF] Blob execution started: Type=External
[2026-02-17 14:50:01] [INF] Checking 15 external datasets for lifecycle actions
[2026-02-17 14:50:05] [INF] Applying action SetCold to 2 external datasets
[2026-02-17 14:50:10] [INF] Blob execution completed: 2 actions applied
```

**Example with specific blob config**:
```powershell
# Execute lifecycle for specific external config (ID=2)
dotnet run -- blob execute --external --blob-config-id 2
```

---

### Execute All Blob Lifecycle Actions (Internal + External)

**Command**:
```powershell
dotnet run -- blob execute --all
```

**What it does**:
- Runs lifecycle execution for both internal and external configurations
- Processes all blob configurations in sequence
- Applies all pending lifecycle actions

---

## Blob Lifecycle Command (Advanced)

The `blob lifecycle` command is an advanced alternative to `blob execute` that provides additional lifecycle management capabilities.

### Execute Internal Blob Lifecycle (Advanced)

**Command**:
```powershell
dotnet run -- blob lifecycle --internal
```

**What it does**:
- Similar to `blob execute --internal` but with additional lifecycle management options
- Applies complex lifecycle policies with custom scheduling
- Handles advanced tier transitions and retention policies
- Updates detailed lifecycle tracking information

**Example with specific config**:
```powershell
dotnet run -- blob lifecycle --internal --blob-config-id 1
```

---

### Execute External Blob Lifecycle (Advanced)

**Command**:
```powershell
dotnet run -- blob lifecycle --external
```

**What it does**:
- Advanced lifecycle management for external/partner datasets
- Applies custom external lifecycle policies
- Handles external dataset-specific retention rules
- Manages third-party dataset lifecycle

**Example with specific config**:
```powershell
dotnet run -- blob lifecycle --external --blob-config-id 2
```

---

### Execute All Blob Lifecycle Actions (Advanced)

**Command**:
```powershell
dotnet run -- blob lifecycle --all
```

**What it does**:
- Runs advanced lifecycle management for both internal and external
- Applies all complex lifecycle policies
- Comprehensive lifecycle tracking across all blob configurations

---

## Blob Command Comparison

| Feature | discover | execute | lifecycle |
|---------|----------|---------|-----------|
| **Purpose** | Find datasets in blob | Apply tier transitions | Advanced lifecycle mgmt |
| **Internal** | ✅ discover --internal | ✅ execute --internal | ✅ lifecycle --internal |
| **External** | ✅ discover --external | ✅ execute --external | ✅ lifecycle --external |
| **Both** | ✅ discover --all | ✅ execute --all | ✅ lifecycle --all |
| **Specific Config** | ✅ --blob-config-id | ✅ --blob-config-id | ✅ --blob-config-id |

---



Here's a complete workflow for managing archived data lifecycle:

**Step 1: Archive table data**
```powershell
# Archive tables to blob storage
dotnet run -- table --all-active
```

**Step 2: Discover archived datasets (Internal)**
```powershell
# Find the archived datasets in blob storage
dotnet run -- blob discover --internal
```

**Step 3: Discover external datasets (if applicable)**
```powershell
# Discover partner datasets
dotnet run -- blob discover --external
```

**Step 4: Apply lifecycle actions**
```powershell
# Move data to cheaper storage tiers based on age
dotnet run -- blob execute --internal

# Apply external dataset policies
dotnet run -- blob execute --external
```

---

## Blob Command Reference

| Command | Purpose |
|---------|---------|
| `dotnet run -- blob discover --internal` | Discover internal datasets |
| `dotnet run -- blob discover --external` | Discover external datasets |
| `dotnet run -- blob discover --all` | Discover all datasets |
| `dotnet run -- blob discover --internal --blob-config-id 1` | Discover specific internal config |
| `dotnet run -- blob discover --external --blob-config-id 2` | Discover specific external config |
| `dotnet run -- blob execute --internal` | Apply internal lifecycle actions |
| `dotnet run -- blob execute --external` | Apply external lifecycle actions |
| `dotnet run -- blob execute --all` | Apply all lifecycle actions |
| `dotnet run -- blob execute --internal --blob-config-id 1` | Execute for specific config |

---

## Blob Lifecycle Tiers (Example Policy)

Typical lifecycle progression:

```
Day 0:   Dataset archived to blob storage
         Status: HOT (immediately accessible)

Day 30:  Automatic transition to COOL tier
         Action: SetCold
         Effect: Lower access cost, slightly slower retrieval

Day 90:  Automatic transition to ARCHIVE tier
         Action: SetArchive
         Effect: Lowest cost, requires rehydration for access

Day 365: Automatic deletion
         Action: Delete
         Effect: Data permanently removed from storage
```

---



### Issue 1: "Secrets folder not found"
**Error Message**:
```
Fatal error: Could not find secrets directory at ./secrets/
```

**Solution**:
```powershell
# Check if secrets folder exists
ls C:\Users\muhee\Downloads\Archival\Archival\secrets\

# If not found, create and copy template files
mkdir secrets
copy secrets\archival-db-connections.template.json secrets\archival-db-connections.json
copy secrets\archival-storage-connections.template.json secrets\archival-storage-connections.json
```

---

### Issue 2: "Database connection failed"
**Error Message**:
```
Fatal error: Connection to FARISHSURFACE failed
```

**Solution**:
```powershell
# Verify database server is accessible
sqlcmd -S FARISHSURFACE -E -Q "SELECT @@VERSION"

# If fails, check:
# 1. Server name is correct (FARISHSURFACE)
# 2. SQL Server service is running
# 3. Windows authentication is enabled
```

---

### Issue 3: "ArchivalDb database not found"
**Error Message**:
```
Fatal error: Database 'ArchivalDb' does not exist
```

**Solution**:
```powershell
# Create database from schema
sqlcmd -S FARISHSURFACE -E -i db\metadata_schema.sql

# Or use EF migrations
dotnet ef database update --project src/Archival.Data --startup-project src/Archival.App
```

---

## Development Environment Setup (One-Time)

### Step 1: Install .NET
```powershell
# Check if installed
dotnet --version

# If not, install from https://dotnet.microsoft.com/download
```

### Step 2: Restore NuGet Packages
```powershell
cd C:\Users\muhee\Downloads\Archival\Archival
dotnet restore
```

### Step 3: Create Database
```powershell
# From solution root
sqlcmd -S FARISHSURFACE -E -i db\metadata_schema.sql
```

### Step 4: Configure Secrets
```powershell
# Copy template files
cd secrets
copy archival-db-connections.template.json archival-db-connections.json
copy archival-storage-connections.template.json archival-storage-connections.json

# Edit with actual values
notepad archival-db-connections.json
notepad archival-storage-connections.json
```

---

## Configuration Files (What Gets Loaded)

When you run the app, it loads in this order:

1. **appsettings.json** (base configuration)
   ```json
   {
     "ConnectionStrings": {...},
     "SecretsPath": "./secrets/",
     "BlobLifecycle": {...},
     "ParquetExport": {...}
   }
   ```

2. **appsettings.Development.json** (development overrides, if DOTNET_ENVIRONMENT=Development)

3. **Environment Variables** (if set)

4. **Secrets Files** (from `./secrets/`)
   - archival-db-connections.json
   - archival-storage-connections.json

---

## Monitoring & Logs

### View Application Logs
The app logs to console. You'll see:
```
[HH:mm:ss] [Level] Message
```

Levels:
- `[INF]` - Information (normal operation)
- `[WRN]` - Warning (recoverable issues)
- `[ERR]` - Error (execution problem)

### Save Logs to File
```powershell
# Redirect to file
dotnet run -- table --all-active > archival.log 2>&1

# View log
Get-Content archival.log -Tail 50  # Last 50 lines
```

---

## Performance Tips

### For Large Tables
If archiving large tables (millions of rows):

1. **Check Parquet Settings** in appsettings.json:
   ```json
   "ParquetExport": {
     "RowsPerPart": 50000,           // Adjust based on row size
     "RowGroupTargetBytes": 67108864, // ~64MB per group
     "SpillThresholdBytes": 16777216  // ~16MB spill threshold
   }
   ```

2. **Adjust DatasetsParallelism**:
   ```json
   "BlobLifecycle": {
     "DatasetsParallelism": 4  // Increase for more parallel jobs
   }
   ```

3. **Run with higher resource allocation**:
   ```powershell
   dotnet run --configuration Release -- table --all-active
   ```

---

## Quick Command Reference

### Table Commands
| Command | Purpose |
|---------|---------|
| `dotnet run -- table --all-active` | Process all active table configs |
| `dotnet run -- table --table-config-id 1` | Process specific config |

### Blob Discover Commands
| Command | Purpose |
|---------|---------|
| `dotnet run -- blob discover --internal` | Discover internal archived datasets |
| `dotnet run -- blob discover --external` | Discover external/partner datasets |
| `dotnet run -- blob discover --all` | Discover all datasets (internal + external) |
| `dotnet run -- blob discover --internal --blob-config-id 1` | Discover specific internal config |
| `dotnet run -- blob discover --external --blob-config-id 2` | Discover specific external config |

### Blob Execute Commands
| Command | Purpose |
|---------|---------|
| `dotnet run -- blob execute --internal` | Apply lifecycle actions to internal datasets |
| `dotnet run -- blob execute --external` | Apply lifecycle actions to external datasets |
| `dotnet run -- blob execute --all` | Apply all lifecycle actions (internal + external) |
| `dotnet run -- blob execute --internal --blob-config-id 1` | Execute for specific internal config |
| `dotnet run -- blob execute --external --blob-config-id 2` | Execute for specific external config |

### Blob Lifecycle Commands (Advanced)
| Command | Purpose |
|---------|---------|
| `dotnet run -- blob lifecycle --internal` | Advanced internal lifecycle management |
| `dotnet run -- blob lifecycle --external` | Advanced external lifecycle management |
| `dotnet run -- blob lifecycle --all` | Advanced lifecycle for all datasets |
| `dotnet run -- blob lifecycle --internal --blob-config-id 1` | Advanced lifecycle for specific internal config |
| `dotnet run -- blob lifecycle --external --blob-config-id 2` | Advanced lifecycle for specific external config |

### General Commands
| Command | Purpose |
|---------|---------|
| `dotnet build` | Build without running |
| `dotnet run -- help` | Show help text |
| `dotnet test` | Run unit tests |

---

## Stopping the Application

To stop a running application:
- Press `Ctrl+C` in the terminal
- Application will gracefully shut down

---

## Summary

### To run table command locally:

1. **Navigate to project**:
   ```powershell
   cd C:\Users\muhee\Downloads\Archival\Archival\src\Archival.App
   ```

2. **Run command**:
   ```powershell
   dotnet run -- table --all-active
   ```

3. **Monitor logs** for success/errors

4. **Verify in database** that configurations were processed

---

### To run blob discover and execute commands locally:

#### 1. Discover Internal Datasets
```powershell
cd C:\Users\muhee\Downloads\Archival\Archival\src\Archival.App
dotnet run -- blob discover --internal
```
- Discovers archived datasets created by table archival
- Updates metadata with current storage tier (Hot/Cool/Archive)

#### 2. Discover External Datasets
```powershell
dotnet run -- blob discover --external
```
- Discovers external/partner datasets in blob storage
- Tracks external source information

#### 3. Execute Internal Lifecycle Actions
```powershell
dotnet run -- blob execute --internal
```
- Applies lifecycle actions to internal datasets (SetCold, SetArchive, Delete)
- Follows internal blob policies for tier transitions

#### 4. Execute External Lifecycle Actions
```powershell
dotnet run -- blob execute --external
```
- Applies lifecycle actions to external datasets
- Follows external blob policies

#### 5. Discover All Datasets (Both Types)
```powershell
dotnet run -- blob discover --all
```
- Runs discovery for both internal and external configurations

#### 6. Execute All Lifecycle Actions (Both Types)
```powershell
dotnet run -- blob execute --all
```
- Applies lifecycle actions for both internal and external datasets

---

### Complete Workflow Example

**Step 1: Archive all table data**
```powershell
dotnet run -- table --all-active
```

**Step 2: Discover internal archived datasets**
```powershell
dotnet run -- blob discover --internal
```

**Step 3: Discover external partner datasets**
```powershell
dotnet run -- blob discover --external
```

**Step 4: Apply lifecycle actions to internal datasets**
```powershell
dotnet run -- blob execute --internal
```

**Step 5: Apply lifecycle actions to external datasets**
```powershell
dotnet run -- blob execute --external
```

**Step 6 (Optional): Advanced lifecycle management**
```powershell
# For advanced internal lifecycle management
dotnet run -- blob lifecycle --internal

# For advanced external lifecycle management
dotnet run -- blob lifecycle --external
```

---

### Quick Workflow (Minimal Steps)

If you just need to archive and manage lifecycle:

```powershell
# 1. Archive tables
dotnet run -- table --all-active

# 2. Discover all datasets
dotnet run -- blob discover --all

# 3. Apply lifecycle
dotnet run -- blob execute --all
```

---

**Status**: Ready to run ✅  
**Next**: Execute the command and monitor logs

