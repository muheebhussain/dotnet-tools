﻿using System.Text;
using Azure.Storage.Blobs;

namespace ConsoleApp1;

internal static class Program
{
    // Hardcoded values (as requested)
    private static readonly string Container = "archival";
    private static readonly string Table = "AllocationSummary";

    // Example date range
    private static readonly DateOnly StartDate = new DateOnly(2023, 01, 01);
    private static readonly DateOnly EndDate   = new DateOnly(2023, 01, 31);

    public static async Task Main()
    {
        // Use connection string from environment variable for simplicity.
        // Set this before running:
        //   Windows PowerShell:
        //     $env:AZURE_STORAGE_CONNECTION_STRING="DefaultEndpointsProtocol=...;"
        //   CMD:
        //     set AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=...;
        //
        var connectionString = "UseDevelopmentStorage=true";//Environment.GetEnvironmentVariable("AZURE_STORAGE_CONNECTION_STRING");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            Console.Error.WriteLine("Missing environment variable: AZURE_STORAGE_CONNECTION_STRING");
            Console.Error.WriteLine("Set it to your Azure Storage account connection string and re-run.");
            Environment.Exit(1);
            return;
        }

        // BlobServiceClient expects a connection string (simple + works locally)
        var serviceClient = new BlobServiceClient(connectionString);

        // NOTE: This creates/uses a container named "archival"
        var containerClient = serviceClient.GetBlobContainerClient(Container);
        await containerClient.CreateIfNotExistsAsync();

        Console.WriteLine($"Uploading blobs to container: {Container}");

        for (var date = StartDate; date <= EndDate; date = date.AddDays(1))
        {
            var currentDate = date.ToString("yyyy-MM-dd"); // folder name in your path
            var yyyy = date.ToString("yyyy");
            var MM   = date.ToString("MM");
            var dd   = date.ToString("dd");

            // This is the "table_{yyyy}{MM}{dd}.text" folder segment
            var tableDateSegment = $"{Table}_{yyyy}{MM}{dd}.text";

            // Base prefix (WITHOUT the leading /{container}/ because container is handled by Blob container)
            // Your requested path:
            // /{container}/file-output/modules/sgas/15c3-3/output/{table}/{currentDate}/{table}_{yyyy}{MM}{dd}.text/...
            //
            var basePrefix =
                $"file-output/modules/sgas/15c3-3/output/{Table}/{currentDate}/{tableDateSegment}";

            // Create two parts per day
            for (var partIndex = 0; partIndex < 2; partIndex++)
            {
                var partNumber = partIndex.ToString("D5"); // 00000, 00001
                var guid = Guid.NewGuid().ToString();

                var blobName =
                    $"{basePrefix}/part-{partNumber}-{guid}-c000.snappy.txt";

                // Dummy content (whatever you like)
                var content =
                    $"Dummy data for {Table}\n" +
                    $"BusinessDate: {currentDate}\n" +
                    $"Part: {partNumber}\n" +
                    $"GeneratedAtUtc: {DateTime.UtcNow:O}\n";

                var blobClient = containerClient.GetBlobClient(blobName);

                // Upload from memory
                var bytes = Encoding.UTF8.GetBytes(content);
                using var ms = new MemoryStream(bytes);

                await blobClient.UploadAsync(ms, overwrite: true);

                Console.WriteLine($"Uploaded: /{Container}/{blobName}");
            }
        }

        Console.WriteLine("Done.");
    }
}