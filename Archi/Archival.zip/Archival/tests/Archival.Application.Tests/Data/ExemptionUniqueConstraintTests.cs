﻿using Archival.Application.Contracts.Persistence;
using Archival.Infrastructure.Time;
using Archival.Data;
using Archival.Data.Stores;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.Data;

/// <summary>
/// Unit tests for unique constraint enforcement in exemption stores.
/// Verifies that duplicate exemptions are rejected gracefully.
/// </summary>
public class ExemptionUniqueConstraintTests : IAsyncLifetime
{
    private ArchivalDbContext _dbContext = null!;
    private ExemptionsStore _store = null!;
    private Mock<IConfigurationRepository> _mockConfigRepo = null!;
    private Mock<ILogger<ExemptionsStore>> _mockLogger = null!;

    public async Task InitializeAsync()
    {
        // Create in-memory database for testing
        var options = new DbContextOptionsBuilder<ArchivalDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ArchivalDbContext(options);
        await _dbContext.Database.EnsureCreatedAsync();

        _mockConfigRepo = new Mock<IConfigurationRepository>();
        _mockLogger = new Mock<ILogger<ExemptionsStore>>();

        var clock = new SystemClock();
        _store = new ExemptionsStore(_dbContext, _mockConfigRepo.Object, _mockLogger.Object, clock);
    }

    public async Task DisposeAsync()
    {
        await _dbContext.Database.EnsureDeletedAsync();
        _dbContext.Dispose();
    }

    #region Table Exemption Tests

    /// <summary>
    /// Test: Add table exemption successfully when no duplicate exists.
    /// </summary>
    [Fact]
    public async Task AddTableExemptionAsync_ValidNewExemption_Succeeds()
    {
        // Arrange
        int tableConfigId = 1;
        var asOfDate = new DateOnly(2026, 2, 15);
        string reason = "Data retention exception";
        string createdBy = "test-user";

        // Act
        var result = await _store.AddTableExemptionAsync(tableConfigId, asOfDate, reason, createdBy, CancellationToken.None);

        // Assert
        Assert.True(result.Ok, "Add should succeed for new exemption");
        Assert.Null(result.Error);

        // Verify stored in database
        var stored = await _dbContext.TableExemptions
            .FirstOrDefaultAsync(x => x.TableConfigurationId == tableConfigId && x.AsOfDate == asOfDate);
        Assert.NotNull(stored);
        Assert.Equal(reason, stored.Reason);
        Assert.Equal(createdBy, stored.CreatedBy);
    }

    /// <summary>
    /// Test: Reject duplicate table exemption with graceful error.
    /// </summary>
    [Fact]
    public async Task AddTableExemptionAsync_DuplicateExemption_ReturnsFailure()
    {
        // Arrange
        int tableConfigId = 1;
        var asOfDate = new DateOnly(2026, 2, 15);
        string reason = "First exemption";

        // Add first exemption (should succeed)
        var firstResult = await _store.AddTableExemptionAsync(tableConfigId, asOfDate, reason, "user1", CancellationToken.None);
        Assert.True(firstResult.Ok, "First exemption should succeed");

        // Act - Try to add duplicate
        var secondResult = await _store.AddTableExemptionAsync(tableConfigId, asOfDate, "Second exemption", "user2", CancellationToken.None);

        // Assert
        Assert.False(secondResult.Ok, "Duplicate exemption should fail");
        Assert.NotNull(secondResult.Error);
        Assert.Contains("already exists", secondResult.Error, StringComparison.OrdinalIgnoreCase);

        // Verify only one record in database
        var count = await _dbContext.TableExemptions
            .CountAsync(x => x.TableConfigurationId == tableConfigId && x.AsOfDate == asOfDate);
        Assert.Equal(1, count);
    }

    /// <summary>
    /// Test: Allow exemptions for same config but different dates.
    /// </summary>
    [Fact]
    public async Task AddTableExemptionAsync_SameConfigDifferentDates_Succeeds()
    {
        // Arrange
        int tableConfigId = 1;
        var date1 = new DateOnly(2026, 2, 15);
        var date2 = new DateOnly(2026, 2, 16);

        // Act
        var result1 = await _store.AddTableExemptionAsync(tableConfigId, date1, "Reason 1", "user1", CancellationToken.None);
        var result2 = await _store.AddTableExemptionAsync(tableConfigId, date2, "Reason 2", "user2", CancellationToken.None);

        // Assert
        Assert.True(result1.Ok, "First exemption should succeed");
        Assert.True(result2.Ok, "Second exemption should succeed (different date)");

        // Verify both records in database
        var count = await _dbContext.TableExemptions
            .CountAsync(x => x.TableConfigurationId == tableConfigId);
        Assert.Equal(2, count);
    }

    /// <summary>
    /// Test: Allow exemptions for different configs but same date.
    /// </summary>
    [Fact]
    public async Task AddTableExemptionAsync_DifferentConfigSameDate_Succeeds()
    {
        // Arrange
        int configId1 = 1;
        int configId2 = 2;
        var asOfDate = new DateOnly(2026, 2, 15);

        // Act
        var result1 = await _store.AddTableExemptionAsync(configId1, asOfDate, "Reason 1", "user1", CancellationToken.None);
        var result2 = await _store.AddTableExemptionAsync(configId2, asOfDate, "Reason 2", "user2", CancellationToken.None);

        // Assert
        Assert.True(result1.Ok, "First exemption should succeed");
        Assert.True(result2.Ok, "Second exemption should succeed (different config)");

        // Verify both records in database
        var count = await _dbContext.TableExemptions.CountAsync();
        Assert.Equal(2, count);
    }

    #endregion

    #region Blob Exemption Tests

    /// <summary>
    /// Test: Add blob exemption successfully when no duplicate exists.
    /// </summary>
    [Fact]
    public async Task AddBlobExemptionAsync_ValidNewExemption_Succeeds()
    {
        // Arrange
        int blobConfigId = 1;
        string prefix = "data/archive/2026/02/";
        string containerName = "archive";
        var asOfDate = new DateOnly(2026, 2, 15);
        string reason = "Blob exemption reason";
        string createdBy = "test-user";

        // Act
        var result = await _store.AddBlobExemptionAsync(blobConfigId, prefix, containerName, asOfDate, reason, createdBy, CancellationToken.None);

        // Assert
        Assert.True(result.Ok, "Add should succeed for new exemption");
        Assert.Null(result.Error);

        // Verify stored in database
        var stored = await _dbContext.BlobExemptions
            .FirstOrDefaultAsync(x =>
                x.BlobConfigurationId == blobConfigId &&
                x.Prefix == prefix.Trim('/') &&
                x.AsOfDate == asOfDate);
        Assert.NotNull(stored);
        Assert.Equal(reason, stored.Reason);
        Assert.Equal(createdBy, stored.CreatedBy);
    }

    /// <summary>
    /// Test: Reject duplicate blob exemption with graceful error.
    /// </summary>
    [Fact]
    public async Task AddBlobExemptionAsync_DuplicateExemption_ReturnsFailure()
    {
        // Arrange
        int blobConfigId = 1;
        string prefix = "data/archive/2026/02/";
        string containerName = "archive";
        var asOfDate = new DateOnly(2026, 2, 15);

        // Add first exemption (should succeed)
        var firstResult = await _store.AddBlobExemptionAsync(blobConfigId, prefix, containerName, asOfDate, "First reason", "user1", CancellationToken.None);
        Assert.True(firstResult.Ok, "First exemption should succeed");

        // Act - Try to add duplicate (with trailing slash variation)
        var secondResult = await _store.AddBlobExemptionAsync(blobConfigId, "data/archive/2026/02/", containerName, asOfDate, "Second reason", "user2", CancellationToken.None);

        // Assert
        Assert.False(secondResult.Ok, "Duplicate exemption should fail");
        Assert.NotNull(secondResult.Error);
        Assert.Contains("already exists", secondResult.Error, StringComparison.OrdinalIgnoreCase);

        // Verify only one record in database
        var count = await _dbContext.BlobExemptions
            .CountAsync(x =>
                x.BlobConfigurationId == blobConfigId &&
                x.AsOfDate == asOfDate);
        Assert.Equal(1, count);
    }

    /// <summary>
    /// Test: Allow exemptions for same config but different prefixes.
    /// </summary>
    [Fact]
    public async Task AddBlobExemptionAsync_SameConfigDifferentPrefixes_Succeeds()
    {
        // Arrange
        int blobConfigId = 1;
        string containerName = "archive";
        var asOfDate = new DateOnly(2026, 2, 15);

        // Act
        var result1 = await _store.AddBlobExemptionAsync(blobConfigId, "prefix1/", containerName, asOfDate, "Reason 1", "user1", CancellationToken.None);
        var result2 = await _store.AddBlobExemptionAsync(blobConfigId, "prefix2/", containerName, asOfDate, "Reason 2", "user2", CancellationToken.None);

        // Assert
        Assert.True(result1.Ok, "First exemption should succeed");
        Assert.True(result2.Ok, "Second exemption should succeed (different prefix)");

        // Verify both records in database
        var count = await _dbContext.BlobExemptions
            .CountAsync(x => x.BlobConfigurationId == blobConfigId && x.AsOfDate == asOfDate);
        Assert.Equal(2, count);
    }

    /// <summary>
    /// Test: Allow exemptions for same config/prefix but different dates.
    /// </summary>
    [Fact]
    public async Task AddBlobExemptionAsync_SameConfigPrefixDifferentDates_Succeeds()
    {
        // Arrange
        int blobConfigId = 1;
        string prefix = "data/archive/";
        string containerName = "archive";
        var date1 = new DateOnly(2026, 2, 15);
        var date2 = new DateOnly(2026, 2, 16);

        // Act
        var result1 = await _store.AddBlobExemptionAsync(blobConfigId, prefix, containerName, date1, "Reason 1", "user1", CancellationToken.None);
        var result2 = await _store.AddBlobExemptionAsync(blobConfigId, prefix, containerName, date2, "Reason 2", "user2", CancellationToken.None);

        // Assert
        Assert.True(result1.Ok, "First exemption should succeed");
        Assert.True(result2.Ok, "Second exemption should succeed (different date)");

        // Verify both records in database
        var count = await _dbContext.BlobExemptions
            .CountAsync(x => x.BlobConfigurationId == blobConfigId && x.Prefix == prefix.Trim('/'));
        Assert.Equal(2, count);
    }

    /// <summary>
    /// Test: Normalize prefixes with varying slashes.
    /// </summary>
    [Fact]
    public async Task AddBlobExemptionAsync_PrefixNormalization_Succeeds()
    {
        // Arrange
        int blobConfigId = 1;
        string containerName = "archive";
        var asOfDate = new DateOnly(2026, 2, 15);

        // Add with trailing slashes
        var result1 = await _store.AddBlobExemptionAsync(blobConfigId, "/data/archive/", containerName, asOfDate, "First", "user1", CancellationToken.None);
        Assert.True(result1.Ok);

        // Try to add with same path but different slash pattern - should fail (duplicate)
        var result2 = await _store.AddBlobExemptionAsync(blobConfigId, "data/archive", containerName, asOfDate, "Second", "user2", CancellationToken.None);

        // Assert - Should fail because normalized form is the same
        Assert.False(result2.Ok, "Normalized duplicate should fail");
        Assert.Contains("already exists", result2.Error);
    }

    #endregion

    #region Error Handling Tests

    /// <summary>
    /// Test: Handle database exceptions gracefully.
    /// </summary>
    [Fact]
    public async Task AddTableExemptionAsync_DatabaseError_ReturnsFailure()
    {
        // Arrange - Create a corrupt database context
        var options = new DbContextOptionsBuilder<ArchivalDbContext>()
            .UseInMemoryDatabase(databaseName: "invalid")
            .Options;

        using var corruptContext = new ArchivalDbContext(options);
        // Don't ensure created - this will cause issues

        var store = new ExemptionsStore(corruptContext, _mockConfigRepo.Object, _mockLogger.Object, new SystemClock());

        // Act - Try to add (will fail due to corrupt context)
        var result = await store.AddTableExemptionAsync(1, DateOnly.FromDateTime(DateTime.UtcNow), "Test", "user", CancellationToken.None);

        // Assert
        Assert.False(result.Ok, "Should fail gracefully on database error");
        Assert.NotNull(result.Error);
    }

    #endregion
}

