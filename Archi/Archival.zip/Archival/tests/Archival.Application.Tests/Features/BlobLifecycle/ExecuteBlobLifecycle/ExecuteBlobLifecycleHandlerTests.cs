using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Contracts.Time;
using Archival.Application.Features.BlobLifecycle.ExecuteBlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Application.Tests.TestUtilities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.Features.BlobLifecycle.ExecuteBlobLifecycle;

/// <summary>
/// Unit tests for ExecuteBlobLifecycleHandler.
/// Tests lifecycle action selection, exemption matching, future date handling, and age calculations.
/// </summary>
public class ExecuteBlobLifecycleHandlerTests
{
    private readonly Mock<IBlobConfigurationStore> _mockBlobConfigStore;
    private readonly Mock<IBlobPolicyStore> _mockBlobPolicyStore;
    private readonly Mock<IExemptionsStore> _mockExemptionsStore;
    private readonly Mock<IConnectionStringResolver> _mockConnectionResolver;
    private readonly Mock<IBlobInventory> _mockBlobInventory;
    private readonly Mock<IBlobLifecycleExecutor> _mockBlobLifecycleExecutor;
    private readonly FakeClock _clock;
    private readonly Mock<ILogger<ExecuteBlobLifecycleHandler>> _mockLogger;

    private readonly ExecuteBlobLifecycleHandler _sut;

    public ExecuteBlobLifecycleHandlerTests()
    {
        _mockBlobConfigStore = new Mock<IBlobConfigurationStore>();
        _mockBlobPolicyStore = new Mock<IBlobPolicyStore>();
        _mockExemptionsStore = new Mock<IExemptionsStore>();
        _mockConnectionResolver = new Mock<IConnectionStringResolver>();
        _mockBlobInventory = new Mock<IBlobInventory>();
        _mockBlobLifecycleExecutor = new Mock<IBlobLifecycleExecutor>();
        _clock = FakeClock.CreateDefault(); // Feb 15, 2026
        _mockLogger = new Mock<ILogger<ExecuteBlobLifecycleHandler>>();

        _sut = new ExecuteBlobLifecycleHandler(
            _mockBlobConfigStore.Object,
            _mockBlobPolicyStore.Object,
            _mockExemptionsStore.Object,
            _mockConnectionResolver.Object,
            _mockBlobInventory.Object,
            _mockBlobLifecycleExecutor.Object,
            _clock,
            _mockLogger.Object);
    }

    [Fact]
    public async Task HandleAsync_DeleteThresholdMet_SelectsDeleteAction()
    {
        // Arrange: Blob is 400 days old, delete threshold is 365
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var blobDate = _clock.Today.AddDays(-400); // 400 days old
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob
        var blob = new BlobInventoryItem("archive/data/file.parquet", blobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = blobDate;
                return true;
            });

        // Setup: Delete succeeds
        _mockBlobLifecycleExecutor
            .Setup(x => x.TryDeleteAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(1, result.Value.DeleteCount);
        Assert.Equal(0, result.Value.ArchiveCount);
        Assert.Equal(0, result.Value.ColdCount);

        // Verify Delete was called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TryDeleteAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_ArchiveThresholdMet_SelectsArchiveAction()
    {
        // Arrange: Blob is 100 days old, archive threshold is 90
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var blobDate = _clock.Today.AddDays(-100); // 100 days old
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob
        var blob = new BlobInventoryItem("archive/data/file.parquet", blobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = blobDate;
                return true;
            });

        // Setup: SetArchive succeeds
        _mockBlobLifecycleExecutor
            .Setup(x => x.TrySetArchiveAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(1, result.Value.ArchiveCount);
        Assert.Equal(0, result.Value.DeleteCount);
        Assert.Equal(0, result.Value.ColdCount);

        // Verify SetArchive was called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetArchiveAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_ColdThresholdMet_SelectsColdAction()
    {
        // Arrange: Blob is 40 days old, cold threshold is 30
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var blobDate = _clock.Today.AddDays(-40); // 40 days old
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob
        var blob = new BlobInventoryItem("archive/data/file.parquet", blobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = blobDate;
                return true;
            });

        // Setup: SetCold succeeds
        _mockBlobLifecycleExecutor
            .Setup(x => x.TrySetColdAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(1, result.Value.ColdCount);
        Assert.Equal(0, result.Value.ArchiveCount);
        Assert.Equal(0, result.Value.DeleteCount);

        // Verify SetCold was called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetColdAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_NoThresholdMet_SkipsBlob()
    {
        // Arrange: Blob is 10 days old, cold threshold is 30 (too new)
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var blobDate = _clock.Today.AddDays(-10); // Only 10 days old
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob
        var blob = new BlobInventoryItem("archive/data/file.parquet", blobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = blobDate;
                return true;
            });

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(0, result.Value.ColdCount);
        Assert.Equal(0, result.Value.ArchiveCount);
        Assert.Equal(0, result.Value.DeleteCount);
        Assert.Equal(1, result.Value.BlobsScanned); // Blob was scanned but skipped

        // Verify NO lifecycle actions were called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetColdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetArchiveAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockBlobLifecycleExecutor.Verify(
            x => x.TryDeleteAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_FutureDatedBlob_SkipsAndLogsWarning()
    {
        // Arrange: Blob dated in the future (tomorrow)
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var futureBlobDate = _clock.Today.AddDays(1); // Tomorrow!
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob with future date
        var blob = new BlobInventoryItem("archive/data/future-file.parquet", futureBlobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction returns future date
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = futureBlobDate;
                return true;
            });

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(0, result.Value.ColdCount);
        Assert.Equal(0, result.Value.ArchiveCount);
        Assert.Equal(0, result.Value.DeleteCount);
        Assert.Equal(1, result.Value.BlobsScanned);

        // Verify warning was logged
        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("future date")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        // Verify NO lifecycle actions were called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetColdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetArchiveAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockBlobLifecycleExecutor.Verify(
            x => x.TryDeleteAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_ConfigNotFound_ReturnsFailure()
    {
        // Arrange
        var blobConfigId = 999;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        // Setup: Config NOT found
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync((BlobConfigurationDto?)null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Blob configuration 999 not found", result.Error);

        // Verify no further processing happened
        _mockBlobInventory.Verify(
            x => x.ListBlobsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_NoArchiveTierSupport_UsesColdInsteadOfArchive()
    {
        // Arrange: Blob is 100 days old, archive threshold is 90, but no Archive tier support
        var blobConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var blobDate = _clock.Today.AddDays(-100);
        var command = new ExecuteBlobLifecycleCommand(blobConfigId, businessDate);

        var blobConfig = new BlobConfigBuilder()
            .WithId(blobConfigId)
            .WithContainerName("archive")
            .WithPrefix("archive/data/")
            .Build();

        var policy = new LifecyclePolicyBuilder()
            .WithColdMinAgeDays(30)
            .WithArchiveMinAgeDays(90)
            .WithDeleteMinAgeDays(365)
            .Build();

        // Setup: Config and policy
        _mockBlobConfigStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        _mockBlobPolicyStore
            .Setup(x => x.GetBlobPolicyAsync(blobConfig.BlobPolicyId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetBlobExemptionsAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobExemptionDto>());

        // Setup: One blob
        var blob = new BlobInventoryItem("archive/data/file.parquet", blobDate.ToDateTime(TimeOnly.MinValue), 1024);
        _mockBlobInventory
            .Setup(x => x.ListBlobsAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blobConfig.Prefix,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobInventoryItem> { blob });

        // Setup: Date extraction
        _mockBlobInventory
            .Setup(x => x.TryExtractDateFromPathSegment(blob.Name, blobConfig.Prefix, out It.Ref<DateOnly>.IsAny))
            .Returns((string name, string prefix, out DateOnly date) =>
            {
                date = blobDate;
                return true;
            });

        // Setup: SetCold succeeds (should be called instead of Archive)
        _mockBlobLifecycleExecutor
            .Setup(x => x.TrySetColdAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.Equal(1, result.Value.ColdCount);
        Assert.Equal(0, result.Value.ArchiveCount); // Archive tier not used

        // Verify SetCold was called instead of SetArchive
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetColdAsync(
                It.IsAny<string>(),
                blobConfig.ContainerName,
                blob.Name,
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Verify SetArchive was NOT called
        _mockBlobLifecycleExecutor.Verify(
            x => x.TrySetArchiveAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }
}


