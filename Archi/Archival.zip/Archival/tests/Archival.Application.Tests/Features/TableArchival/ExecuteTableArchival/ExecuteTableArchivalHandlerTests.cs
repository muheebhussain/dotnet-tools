﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Tables;
using Archival.Application.Features.TableArchival.BuildTableArchivalPlan;
using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Application.Tests.TestUtilities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.Features.TableArchival.ExecuteTableArchival;

/// <summary>
/// Unit tests for ExecuteTableArchivalHandler.
/// Tests execution logic, row count validation, dataset status transitions, and plan building.
/// </summary>
public class ExecuteTableArchivalHandlerTests
{
    private readonly Mock<IDatasetStore> _mockDatasetStore;
    private readonly Mock<IConnectionStringResolver> _mockConnectionResolver;
    private readonly Mock<ITableArchiver> _mockTableArchiver;
    private readonly Mock<IArchivePathTemplateExpander> _mockTemplateExpander;
    private readonly Mock<BuildTableArchivalPlanHandler> _mockBuildPlanHandler;
    private readonly Mock<IBlobConfigurationStore> _mockBlobConfigurationStore;
    private readonly Mock<IBlobPolicyStore> _mockBlobPolicyStore;
    private readonly Mock<IBlobDatasetStore> _mockBlobDatasetStore;
    private readonly Mock<ILogger<ExecuteTableArchivalHandler>> _mockLogger;

    private readonly ExecuteTableArchivalHandler _sut;

    public ExecuteTableArchivalHandlerTests()
    {
        _mockDatasetStore = new Mock<IDatasetStore>();
        _mockConnectionResolver = new Mock<IConnectionStringResolver>();
        _mockTableArchiver = new Mock<ITableArchiver>();
        _mockTemplateExpander = new Mock<IArchivePathTemplateExpander>();
        _mockBuildPlanHandler = new Mock<BuildTableArchivalPlanHandler>();
        _mockBlobConfigurationStore = new Mock<IBlobConfigurationStore>();
        _mockBlobPolicyStore = new Mock<IBlobPolicyStore>();
        _mockBlobDatasetStore = new Mock<IBlobDatasetStore>();
        _mockLogger = new Mock<ILogger<ExecuteTableArchivalHandler>>();

        // Setup default template expander behavior: return template as-is with trailing slash
        _mockTemplateExpander
            .Setup(x => x.ExpandTemplate(It.IsAny<string>(), It.IsAny<ArchivePathTemplateContext>()))
            .Returns<string, ArchivePathTemplateContext>((template, _) => template.TrimEnd('/') + "/");

        _sut = new ExecuteTableArchivalHandler(
            _mockDatasetStore.Object,
            _mockConnectionResolver.Object,
            _mockTableArchiver.Object,
            _mockTemplateExpander.Object,
            _mockBuildPlanHandler.Object,
            _mockBlobConfigurationStore.Object,
            _mockBlobPolicyStore.Object,
            _mockBlobDatasetStore.Object,
            _mockLogger.Object);

    }

    [Fact]
    public async Task HandleAsync_SucceededDataset_SkipsExport()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(
                It.Is<BuildTableArchivalPlanQuery>(q => q.TableConfigurationId == tableConfigId),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Dataset already succeeded
        var succeededDataset = new DatasetDetailBuilder()
            .WithStatus(DatasetStatus.Succeeded)
            .WithAsOfDate(businessDate)
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(succeededDataset);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.False(result.Value.ExportSucceeded); // Should indicate skip
        Assert.False(result.Value.DeleteSucceeded);

        // Archiver should NOT be called (dataset already succeeded)
        _mockTableArchiver.Verify(
            x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_FailedDataset_ReusesDatasetRecord()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var existingDatasetId = 42L;
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Connection strings
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: Dataset previously failed (should reuse this record)
        var failedDataset = new DatasetDetailBuilder()
            .WithDatasetId(existingDatasetId)
            .WithStatus(DatasetStatus.Failed)
            .WithAsOfDate(businessDate)
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(failedDataset);

        // Setup: Export succeeds on retry
        _mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResult>.Success(new ExportResult(100, 5, 1024, "archive", "archive/orders/2026-02-15/")));

        // Setup: Mark dataset succeeded
        _mockDatasetStore
            .Setup(x => x.MarkDatasetSucceededAsync(
                existingDatasetId,
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Delete succeeds
        _mockTableArchiver
            .Setup(x => x.DeleteRowsAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<int>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.True(result.Value.ExportSucceeded);
        Assert.True(result.Value.DeleteSucceeded);

        // Should reuse existing dataset record (not create new)
        _mockDatasetStore.Verify(
            x => x.CreateDatasetAsync(
                It.IsAny<int>(),
                It.IsAny<DateOnly>(),
                It.IsAny<DateType>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);

        // Should mark existing dataset as succeeded
        _mockDatasetStore.Verify(
            x => x.MarkDatasetSucceededAsync(
                existingDatasetId,
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_NewDataset_CreatesDatasetRecord()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var newDatasetId = 99L;
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Connection strings
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No existing dataset (first run)
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: Create dataset returns new ID
        _mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                tableConfigId,
                businessDate,
                DateType.EOD,
                "teststorage",
                "archive",
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(newDatasetId);

        // Setup: Export succeeds
        _mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResult>.Success(new ExportResult(100, 5, 1024, "archive", "archive/orders/2026-02-15/")));

        // Setup: Mark dataset succeeded
        _mockDatasetStore
            .Setup(x => x.MarkDatasetSucceededAsync(
                newDatasetId,
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Delete succeeds
        _mockTableArchiver
            .Setup(x => x.DeleteRowsAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<int>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // Should create new dataset record
        _mockDatasetStore.Verify(
            x => x.CreateDatasetAsync(
                tableConfigId,
                businessDate,
                DateType.EOD,
                "teststorage",
                "archive",
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Should mark new dataset as succeeded
        _mockDatasetStore.Verify(
            x => x.MarkDatasetSucceededAsync(
                newDatasetId,
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_ExportFailure_MarksDatasetFailed()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var datasetId = 42L;
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Connection strings
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No existing dataset
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: Create dataset
        _mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                It.IsAny<int>(),
                It.IsAny<DateOnly>(),
                It.IsAny<DateType>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(datasetId);

        // Setup: Export FAILS
        _mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResult>.Fail("Connection timeout"));

        // Setup: Mark dataset failed
        _mockDatasetStore
            .Setup(x => x.MarkDatasetFailedAsync(
                datasetId,
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Export failed", result.Error);

        // Should mark dataset as failed
        _mockDatasetStore.Verify(
            x => x.MarkDatasetFailedAsync(
                datasetId,
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Should NOT mark as succeeded
        _mockDatasetStore.Verify(
            x => x.MarkDatasetSucceededAsync(
                It.IsAny<long>(),
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_InvalidPlan_ReturnsFailure()
    {
        // Arrange
        var tableConfigId = 999;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        // Setup: Build plan FAILS (config not found)
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(
                It.Is<BuildTableArchivalPlanQuery>(q => q.TableConfigurationId == tableConfigId),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Fail("Table configuration 999 not found"));

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Failed to build archival plan", result.Error);

        // Should NOT call archiver (no valid plan)
        _mockTableArchiver.Verify(
            x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_DeleteAfterExportFalse_SkipsDelete()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: false, // ← Key: do NOT delete
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Connection strings
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");
        _mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection(It.IsAny<string>()))
            .Returns("DefaultEndpointsProtocol=https;");

        // Setup: No existing dataset
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: Create dataset
        _mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                It.IsAny<int>(),
                It.IsAny<DateOnly>(),
                It.IsAny<DateType>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(42L);

        // Setup: Export succeeds
        _mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResult>.Success(new ExportResult(100, 5, 1024, "archive", "archive/orders/2026-02-15/")));

        // Setup: Mark dataset succeeded
        _mockDatasetStore
            .Setup(x => x.MarkDatasetSucceededAsync(
                It.IsAny<long>(),
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.True(result.Value.ExportSucceeded);
        Assert.False(result.Value.DeleteSucceeded); // Delete NOT performed

        // Should NOT call DeleteRowsAsync (DeleteAfterExport = false)
        _mockTableArchiver.Verify(
            x => x.DeleteRowsAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly>(),
                It.IsAny<int>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleAsync_CancellationRequested_PropagatesToken()
    {
        // Arrange
        var tableConfigId = 1;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);
        var cts = new CancellationTokenSource();

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: GetDatasetAsync throws OperationCanceledException when called
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new OperationCanceledException());

        cts.Cancel(); // Cancel immediately

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            async () => await _sut.HandleAsync(command, cts.Token));

        // Verify cancellation token was passed to GetDatasetAsync
        _mockDatasetStore.Verify(
            x => x.GetDatasetAsync(
                It.IsAny<int>(),
                It.IsAny<DateOnly>(),
                It.Is<CancellationToken>(ct => ct.IsCancellationRequested)),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_SucceededDataset_AttemptsBlobDatasetPush()
    {
        // Arrange
        var tableConfigId = 1;
        var blobConfigId = 10;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: false,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(
                It.Is<BuildTableArchivalPlanQuery>(q => q.TableConfigurationId == tableConfigId),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Table configuration with blob config
        var tableConfig = new TableConfigurationDto(
            Id: tableConfigId,
            IsActive: true,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            TablePolicyId: 1,
            BlobConfigurationId: blobConfigId,
            ArchivePathTemplate: "archive/{yyyy}/{MM}/{dd}/",
            DeleteAfterExport: false,
            BatchDeleteSize: 10000);

        _mockBuildPlanHandler
            .Setup(x => x.GetTableConfigurationAsync(tableConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(tableConfig);

        // Setup: Blob configuration exists
        var blobConfig = new BlobConfigurationDto(
            Id: blobConfigId,
            IsEnabled: true,
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            Prefix: "archive/",
            IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: "AsOfDate",
            BlobPolicyId: 1,
            IsExternal: false,
            DatasetPathTemplate: null,
            BusinessDateFolderFormat: null,
            BusinessDateFolderDepth: 1);

        _mockBlobConfigurationStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        // Setup: Blob policy exists
        var blobPolicy = new BlobPolicyDto(
            Id: 1,
            IsActive: true,
            ColdMinAgeDays: 30,
            ArchiveMinAgeDays: 90,
            DeleteMinAgeDays: 365);

        _mockBlobPolicyStore
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobPolicy);

        // Setup: Blob dataset upsert succeeds
        _mockBlobDatasetStore
            .Setup(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Dataset already succeeded
        var succeededDataset = new DatasetDetailBuilder()
            .WithStatus(DatasetStatus.Succeeded)
            .WithAsOfDate(businessDate)
            .WithStorageAccountName("teststorage")
            .WithContainerName("archive")
            .WithBlobPrefix("archive/orders/")
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(succeededDataset);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.False(result.Value.ExportSucceeded); // Should indicate skip (no new export)

        // Verify blob dataset push was attempted
        _mockBlobDatasetStore.Verify(
            x => x.UpsertAsync(
                It.Is<BlobDatasetUpsertDto>(dto =>
                    dto.BlobConfigurationId == blobConfigId &&
                    dto.SourceType == BlobDatasetSourceType.Internal &&
                    dto.AsOfDate == businessDate &&
                    dto.ArchivalDatasetId == succeededDataset.DatasetId),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_SucceededDataset_PushFailureReturnsSuccess()
    {
        // Arrange
        var tableConfigId = 1;
        var blobConfigId = 10;
        var businessDate = new DateOnly(2026, 2, 15);
        var command = new ExecuteTableArchivalCommand(tableConfigId, businessDate);

        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfigId,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            BaseBlobPrefix: "archive/orders/",
            DateType: DateType.EOD,
            DeleteAfterExport: false,
            BatchDeleteSize: 10000);

        // Setup: Build plan succeeds
        _mockBuildPlanHandler
            .Setup(x => x.HandleAsync(
                It.Is<BuildTableArchivalPlanQuery>(q => q.TableConfigurationId == tableConfigId),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Setup: Table configuration with blob config
        var tableConfig = new TableConfigurationDto(
            Id: tableConfigId,
            IsActive: true,
            DatabaseName: "TestDB",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            TablePolicyId: 1,
            BlobConfigurationId: blobConfigId,
            ArchivePathTemplate: "archive/{yyyy}/{MM}/{dd}/",
            DeleteAfterExport: false,
            BatchDeleteSize: 10000);

        _mockBuildPlanHandler
            .Setup(x => x.GetTableConfigurationAsync(tableConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(tableConfig);

        // Setup: Blob configuration exists
        var blobConfig = new BlobConfigurationDto(
            Id: blobConfigId,
            IsEnabled: true,
            StorageAccountName: "teststorage",
            ContainerName: "archive",
            Prefix: "archive/",
            IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: "AsOfDate",
            BlobPolicyId: 1,
            IsExternal: false,
            DatasetPathTemplate: null,
            BusinessDateFolderFormat: null,
            BusinessDateFolderDepth: 1);

        _mockBlobConfigurationStore
            .Setup(x => x.GetBlobConfigurationAsync(blobConfigId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobConfig);

        // Setup: Blob policy exists
        var blobPolicy = new BlobPolicyDto(
            Id: 1,
            IsActive: true,
            ColdMinAgeDays: 30,
            ArchiveMinAgeDays: 90,
            DeleteMinAgeDays: 365);

        _mockBlobPolicyStore
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(blobPolicy);

        // Setup: Blob dataset upsert FAILS
        _mockBlobDatasetStore
            .Setup(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("Database connection failed"));

        // Setup: Dataset already succeeded
        var succeededDataset = new DatasetDetailBuilder()
            .WithStatus(DatasetStatus.Succeeded)
            .WithAsOfDate(businessDate)
            .WithStorageAccountName("teststorage")
            .WithContainerName("archive")
            .WithBlobPrefix("archive/orders/")
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfigId, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(succeededDataset);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        // Even though push failed, overall success should be returned (archival succeeded)
        Assert.True(result.Ok);
        Assert.NotNull(result.Value);
        Assert.False(result.Value.ExportSucceeded); // Should indicate skip (no new export)

        // Verify push was attempted
        _mockBlobDatasetStore.Verify(
            x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }
}


