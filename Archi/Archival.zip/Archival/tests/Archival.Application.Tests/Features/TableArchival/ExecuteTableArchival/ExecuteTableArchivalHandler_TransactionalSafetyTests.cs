﻿using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Data;
using Archival.Data.Entities;
using Archival.Infrastructure.Time;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace Archival.Application.Tests.Features.TableArchival.ExecuteTableArchival;

/// <summary>
/// Unit tests for transactional safety in ExecuteTableArchivalHandler.
/// Validates that dataset + blob dataset push are atomic.
/// </summary>
public class ExecuteTableArchivalHandler_TransactionalSafetyTests
{
    private readonly DbContextOptions<ArchivalDbContext> _dbOptions;

    public ExecuteTableArchivalHandler_TransactionalSafetyTests()
    {
        _dbOptions = new DbContextOptionsBuilder<ArchivalDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestDb_{Guid.NewGuid()}")
            .Options;
    }

    /// <summary>
    /// Test: Export succeeds, push fails → transaction rolls back → dataset remains Failed
    /// </summary>
    [Fact]
    public async Task HandleAsync_ExportSucceeds_PushFails_TransactionRollback_DatasetRemainsFailed()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var mockDatasetStore = new Mock<IDatasetStore>();
        var mockConnectionResolver = new Mock<IConnectionStringResolver>();
        var mockTableArchiver = new Mock<ITableArchiver>();
        var mockTemplateExpander = new Mock<IArchivePathTemplateExpander>();
        var mockBuildPlanHandler = new Mock<BuildTableArchivalPlanHandler>(
            new Mock<ITableConfigurationStore>().Object,
            new Mock<IBlobConfigurationStore>().Object,
            new Mock<ILogger<BuildTableArchivalPlanHandler>>().Object);
        var mockBlobConfigStore = new Mock<IBlobConfigurationStore>();
        var mockBlobPolicyStore = new Mock<IBlobPolicyStore>();
        var mockBlobDatasetStore = new Mock<IBlobDatasetStore>();
        var mockLogger = new Mock<ILogger<ExecuteTableArchivalHandler>>();
        var clock = new SystemClock();

        // Setup: Export succeeds
        var exportResult = new ExportResultDto(PartCount: 5, RowCount: 1000, TotalBytes: 5_000_000);
        mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateOnly>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResultDto>.Success(exportResult));

        // Setup: Blob push fails with exception
        mockBlobDatasetStore
            .Setup(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("Blob dataset push failed"));

        // Setup: Plan building succeeds
        var plan = new TableArchivalPlan(
            TableConfigurationId: 1,
            DatabaseName: "TestDb",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "data",
            BaseBlobPrefix: "archive/",
            DeleteAfterExport: false,
            BatchDeleteSize: 1000,
            DateType: DateType.EOD);

        mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        // Dataset creation
        long createdDatasetId = 999;
        var existingDataset = new DatasetDetailDto(
            DatasetId: createdDatasetId,
            AsOfDate: new DateOnly(2026, 2, 15),
            DateType: DateType.EOD,
            StorageAccountName: "teststorage",
            ContainerName: "data",
            BlobPrefix: "archive/2026/02/15/",
            Status: DatasetStatus.InProgress);

        mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<DateType>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(createdDatasetId);

        var command = new ExecuteTableArchivalCommand(
            TableConfigurationId: 1,
            BusinessDate: new DateOnly(2026, 2, 15));

        mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection("TestDb"))
            .Returns("source_conn");
        mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection("teststorage"))
            .Returns("storage_conn");

        mockTemplateExpander
            .Setup(x => x.ExpandTemplate(It.IsAny<string>(), It.IsAny<ArchivePathTemplateContext>()))
            .Returns("archive/2026/02/15/");

        var handler = new ExecuteTableArchivalHandler(
            mockDatasetStore.Object,
            mockConnectionResolver.Object,
            mockTableArchiver.Object,
            mockTemplateExpander.Object,
            mockBuildPlanHandler.Object,
            mockBlobConfigStore.Object,
            mockBlobPolicyStore.Object,
            mockBlobDatasetStore.Object,
            mockLogger.Object,
            clock,
            dbContext);

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.False(result.Ok, "Result should fail when push fails");
        Assert.Contains("Internal blob dataset push failed", result.Error);
        Assert.Contains("transaction rolled back", result.Error);

        // Verify: Export succeeded
        mockTableArchiver.Verify(
            x => x.ExportToParquetAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateOnly>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Verify: MarkDatasetSucceededAsync NOT called (prevented by transaction rollback)
        // Mock doesn't track this since it's actually called but transaction rolls back
        // So we verify that MarkDatasetFailedAsync was called instead
        mockDatasetStore.Verify(
            x => x.MarkDatasetFailedAsync(
                It.Is<long>(id => id == createdDatasetId),
                It.Is<string>(msg => msg.Contains("Failed to push internal blob dataset")),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// Test: Export succeeds, push succeeds → transaction commits → dataset marked Succeeded
    /// </summary>
    [Fact]
    public async Task HandleAsync_ExportAndPushSucceed_TransactionCommits_DatasetSucceeded()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var mockDatasetStore = new Mock<IDatasetStore>();
        var mockConnectionResolver = new Mock<IConnectionStringResolver>();
        var mockTableArchiver = new Mock<ITableArchiver>();
        var mockTemplateExpander = new Mock<IArchivePathTemplateExpander>();
        var mockBuildPlanHandler = new Mock<BuildTableArchivalPlanHandler>(
            new Mock<ITableConfigurationStore>().Object,
            new Mock<IBlobConfigurationStore>().Object,
            new Mock<ILogger<BuildTableArchivalPlanHandler>>().Object);
        var mockBlobConfigStore = new Mock<IBlobConfigurationStore>();
        var mockBlobPolicyStore = new Mock<IBlobPolicyStore>();
        var mockBlobDatasetStore = new Mock<IBlobDatasetStore>();
        var mockLogger = new Mock<ILogger<ExecuteTableArchivalHandler>>();
        var clock = new SystemClock();

        // Setup: Export succeeds
        var exportResult = new ExportResultDto(PartCount: 5, RowCount: 1000, TotalBytes: 5_000_000);
        mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateOnly>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResultDto>.Success(exportResult));

        // Setup: Blob push succeeds (idempotent upsert)
        mockBlobDatasetStore
            .Setup(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Plan building succeeds
        var plan = new TableArchivalPlan(
            TableConfigurationId: 1,
            DatabaseName: "TestDb",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "data",
            BaseBlobPrefix: "archive/",
            DeleteAfterExport: false,
            BatchDeleteSize: 1000,
            DateType: DateType.EOD);

        mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        long createdDatasetId = 999;
        mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<DateType>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(createdDatasetId);

        var command = new ExecuteTableArchivalCommand(
            TableConfigurationId: 1,
            BusinessDate: new DateOnly(2026, 2, 15));

        mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection("TestDb"))
            .Returns("source_conn");
        mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection("teststorage"))
            .Returns("storage_conn");

        mockTemplateExpander
            .Setup(x => x.ExpandTemplate(It.IsAny<string>(), It.IsAny<ArchivePathTemplateContext>()))
            .Returns("archive/2026/02/15/");

        var handler = new ExecuteTableArchivalHandler(
            mockDatasetStore.Object,
            mockConnectionResolver.Object,
            mockTableArchiver.Object,
            mockTemplateExpander.Object,
            mockBuildPlanHandler.Object,
            mockBlobConfigStore.Object,
            mockBlobPolicyStore.Object,
            mockBlobDatasetStore.Object,
            mockLogger.Object,
            clock,
            dbContext);

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok, "Result should succeed when export and push both succeed");

        // Verify: MarkDatasetSucceededAsync called (transaction committed)
        mockDatasetStore.Verify(
            x => x.MarkDatasetSucceededAsync(
                It.Is<long>(id => id == createdDatasetId),
                It.Is<int>(p => p == 5),
                It.Is<long>(r => r == 1000),
                It.Is<long>(b => b == 5_000_000),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Verify: Blob dataset upsert called (transaction committed)
        mockBlobDatasetStore.Verify(
            x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()),
            Times.Once);

        // Verify: MarkDatasetFailedAsync NOT called (successful path)
        mockDatasetStore.Verify(
            x => x.MarkDatasetFailedAsync(
                It.IsAny<long>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// Test: Retry after push failure → export+push+commit succeeds → dataset finally marked Succeeded
    /// </summary>
    [Fact]
    public async Task HandleAsync_RetryAfterPushFailure_SucceedsSecondTime()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var mockDatasetStore = new Mock<IDatasetStore>();
        var mockConnectionResolver = new Mock<IConnectionStringResolver>();
        var mockTableArchiver = new Mock<ITableArchiver>();
        var mockTemplateExpander = new Mock<IArchivePathTemplateExpander>();
        var mockBuildPlanHandler = new Mock<BuildTableArchivalPlanHandler>(
            new Mock<ITableConfigurationStore>().Object,
            new Mock<IBlobConfigurationStore>().Object,
            new Mock<ILogger<BuildTableArchivalPlanHandler>>().Object);
        var mockBlobConfigStore = new Mock<IBlobConfigurationStore>();
        var mockBlobPolicyStore = new Mock<IBlobPolicyStore>();
        var mockBlobDatasetStore = new Mock<IBlobDatasetStore>();
        var mockLogger = new Mock<ILogger<ExecuteTableArchivalHandler>>();
        var clock = new SystemClock();

        // Setup: Export succeeds
        var exportResult = new ExportResultDto(PartCount: 5, RowCount: 1000, TotalBytes: 5_000_000);
        mockTableArchiver
            .Setup(x => x.ExportToParquetAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateOnly>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExportResultDto>.Success(exportResult));

        // Setup: Plan building succeeds
        var plan = new TableArchivalPlan(
            TableConfigurationId: 1,
            DatabaseName: "TestDb",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            StorageAccountName: "teststorage",
            ContainerName: "data",
            BaseBlobPrefix: "archive/",
            DeleteAfterExport: false,
            BatchDeleteSize: 1000,
            DateType: DateType.EOD);

        mockBuildPlanHandler
            .Setup(x => x.HandleAsync(It.IsAny<BuildTableArchivalPlanQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<TableArchivalPlan>.Success(plan));

        long createdDatasetId = 999;

        // Scenario 1: First attempt fails
        var failedDataset = new DatasetDetailDto(
            DatasetId: createdDatasetId,
            AsOfDate: new DateOnly(2026, 2, 15),
            DateType: DateType.EOD,
            StorageAccountName: "teststorage",
            ContainerName: "data",
            BlobPrefix: "archive/2026/02/15/",
            Status: DatasetStatus.Failed);

        var setupCallCount = 0;
        mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                setupCallCount++;
                // First call returns null (fresh), second call returns failed dataset
                return setupCallCount == 1 ? null : failedDataset;
            });

        mockDatasetStore
            .Setup(x => x.CreateDatasetAsync(
                It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<DateType>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(createdDatasetId);

        // First attempt: push fails
        var callCount = 0;
        mockBlobDatasetStore
            .Setup(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()))
            .Returns(() =>
            {
                callCount++;
                if (callCount == 1)
                    throw new InvalidOperationException("Push failed temporarily");
                return Task.CompletedTask;
            });

        var command = new ExecuteTableArchivalCommand(
            TableConfigurationId: 1,
            BusinessDate: new DateOnly(2026, 2, 15));

        mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection("TestDb"))
            .Returns("source_conn");
        mockConnectionResolver
            .Setup(x => x.ResolveStorageConnection("teststorage"))
            .Returns("storage_conn");

        mockTemplateExpander
            .Setup(x => x.ExpandTemplate(It.IsAny<string>(), It.IsAny<ArchivePathTemplateContext>()))
            .Returns("archive/2026/02/15/");

        var handler = new ExecuteTableArchivalHandler(
            mockDatasetStore.Object,
            mockConnectionResolver.Object,
            mockTableArchiver.Object,
            mockTemplateExpander.Object,
            mockBuildPlanHandler.Object,
            mockBlobConfigStore.Object,
            mockBlobPolicyStore.Object,
            mockBlobDatasetStore.Object,
            mockLogger.Object,
            clock,
            dbContext);

        // Act - First attempt (fails)
        var result1 = await handler.HandleAsync(command, CancellationToken.None);

        // Assert - First attempt should fail
        Assert.False(result1.Ok, "First attempt should fail");

        // Act - Second attempt (retry, succeeds)
        var result2 = await handler.HandleAsync(command, CancellationToken.None);

        // Assert - Second attempt should succeed
        Assert.True(result2.Ok, "Second attempt should succeed");

        // Verify: MarkDatasetSucceededAsync called on second attempt (transaction committed)
        mockDatasetStore.Verify(
            x => x.MarkDatasetSucceededAsync(
                It.Is<long>(id => id == createdDatasetId),
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}

