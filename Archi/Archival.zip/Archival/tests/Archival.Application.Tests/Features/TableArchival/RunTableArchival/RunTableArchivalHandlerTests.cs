﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Retention;
using Archival.Application.Contracts.Tables;
using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Features.TableArchival.RunTableArchival;
using Archival.Application.Features.Runs.CompleteRun;
using Archival.Application.Features.Runs.StartRun;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Application.Tests.TestUtilities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.Features.TableArchival.RunTableArchival;

/// <summary>
/// Unit tests for RunTableArchivalHandler.
/// Tests orchestration logic, retry behavior, run status transitions, and cancellation handling.
/// </summary>
public class RunTableArchivalHandlerTests
{
    private readonly Mock<IRunItemsStore> _mockRunItemsStore;
    private readonly Mock<ITableConfigurationStore> _mockTableConfigStore;
    private readonly Mock<IExemptionsStore> _mockExemptionsStore;
    private readonly Mock<IDatasetStore> _mockDatasetStore;
    private readonly Mock<IRetentionCalculator> _mockRetentionCalculator;
    private readonly Mock<ITableArchiver> _mockTableArchiver;
    private readonly Mock<IConnectionStringResolver> _mockConnectionResolver;
    private readonly Mock<StartRunHandler> _mockStartRunHandler;
    private readonly Mock<CompleteRunHandler> _mockCompleteRunHandler;
    private readonly Mock<ExecuteTableArchivalHandler> _mockExecuteHandler;
    private readonly Mock<ILogger<RunTableArchivalHandler>> _mockLogger;

    private readonly RunTableArchivalHandler _sut;

    public RunTableArchivalHandlerTests()
    {
        _mockRunItemsStore = new Mock<IRunItemsStore>();
        _mockTableConfigStore = new Mock<ITableConfigurationStore>();
        _mockExemptionsStore = new Mock<IExemptionsStore>();
        _mockDatasetStore = new Mock<IDatasetStore>();
        _mockRetentionCalculator = new Mock<IRetentionCalculator>();
        _mockTableArchiver = new Mock<ITableArchiver>();
        _mockConnectionResolver = new Mock<IConnectionStringResolver>();
        _mockStartRunHandler = new Mock<StartRunHandler>();
        _mockCompleteRunHandler = new Mock<CompleteRunHandler>();
        _mockExecuteHandler = new Mock<ExecuteTableArchivalHandler>();
        _mockLogger = new Mock<ILogger<RunTableArchivalHandler>>();

        _sut = new RunTableArchivalHandler(
            _mockRunItemsStore.Object,
            _mockTableConfigStore.Object,
            _mockExemptionsStore.Object,
            _mockDatasetStore.Object,
            _mockRetentionCalculator.Object,
            _mockTableArchiver.Object,
            _mockConnectionResolver.Object,
            _mockStartRunHandler.Object,
            _mockCompleteRunHandler.Object,
            _mockExecuteHandler.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task HandleAsync_SucceededDataset_SkipsExport()
    {
        // Arrange
        var tableConfig = new TableConfigBuilder()
            .WithId(1)
            .WithDatabaseName("TestDB")
            .WithSchemaName("dbo")
            .WithTableName("Orders")
            .Build();

        var businessDate = new DateOnly(2026, 2, 15);
        var runId = 42L;

        // Setup: Run started successfully
        _mockStartRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<StartRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<long>.Success(runId));

        // Setup: One active table config
        _mockTableConfigStore
            .Setup(x => x.GetActiveTableConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { tableConfig });

        // Setup: Connection string
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");

        // Setup: Present dates
        _mockTableArchiver
            .Setup(x => x.GetPresentDatesAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BusinessDate> { new BusinessDate(businessDate) });

        // Setup: Retention calculator (archive candidates)
        _mockRetentionCalculator
            .Setup(x => x.CalculateKeepDatesAsync(It.IsAny<int>(), It.IsAny<IReadOnlyList<BusinessDate>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<DateOnly>());

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetTableExemptionsAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<(int, DateOnly)>());

        // Setup: Dataset ALREADY SUCCEEDED (key for this test)
        var succeededDataset = new DatasetDetailBuilder()
            .WithStatus(DatasetStatus.Succeeded)
            .WithAsOfDate(businessDate)
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfig.Id, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(succeededDataset);

        // Setup: Complete run
        _mockCompleteRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<CompleteRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        var command = new RunTableArchivalCommand(AllActive: true, TableConfigId: null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // ExecuteTableArchivalHandler should NOT be called (dataset already succeeded)
        _mockExecuteHandler.Verify(
            x => x.HandleAsync(It.IsAny<ExecuteTableArchivalCommand>(), It.IsAny<CancellationToken>()),
            Times.Never);

        // Run should complete successfully
        _mockCompleteRunHandler.Verify(
            x => x.HandleAsync(
                It.Is<CompleteRunCommand>(c => c.RunId == runId && c.Status == RunStatus.Succeeded),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_FailedDataset_RetriesExport()
    {
        // Arrange
        var tableConfig = new TableConfigBuilder()
            .WithId(1)
            .WithDatabaseName("TestDB")
            .WithSchemaName("dbo")
            .WithTableName("Orders")
            .Build();

        var businessDate = new DateOnly(2026, 2, 15);
        var runId = 42L;

        // Setup: Run started successfully
        _mockStartRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<StartRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<long>.Success(runId));

        // Setup: One active table config
        _mockTableConfigStore
            .Setup(x => x.GetActiveTableConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { tableConfig });

        // Setup: Connection string
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");

        // Setup: Present dates
        _mockTableArchiver
            .Setup(x => x.GetPresentDatesAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BusinessDate> { new BusinessDate(businessDate) });

        // Setup: Retention calculator
        _mockRetentionCalculator
            .Setup(x => x.CalculateKeepDatesAsync(It.IsAny<int>(), It.IsAny<IReadOnlyList<BusinessDate>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<DateOnly>());

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetTableExemptionsAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<(int, DateOnly)>());

        // Setup: Dataset FAILED (key for this test - should retry)
        var failedDataset = new DatasetDetailBuilder()
            .WithStatus(DatasetStatus.Failed)
            .WithAsOfDate(businessDate)
            .Build();

        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfig.Id, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync(failedDataset);

        // Setup: Execute handler succeeds on retry
        _mockExecuteHandler
            .Setup(x => x.HandleAsync(It.IsAny<ExecuteTableArchivalCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExecuteTableArchivalResponse>.Success(
                new ExecuteTableArchivalResponse(true, true, 100, 5)));

        // Setup: AddRunItem
        _mockRunItemsStore
            .Setup(x => x.AddRunItemAsync(
                It.IsAny<long>(),
                It.IsAny<RunItemType>(),
                It.IsAny<RunItemStatus>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<string?>(),
                It.IsAny<long?>(),
                It.IsAny<long?>(),
                It.IsAny<string?>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Complete run
        _mockCompleteRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<CompleteRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        var command = new RunTableArchivalCommand(AllActive: true, TableConfigId: null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // ExecuteTableArchivalHandler SHOULD be called (retry failed dataset)
        _mockExecuteHandler.Verify(
            x => x.HandleAsync(
                It.Is<ExecuteTableArchivalCommand>(c => c.TableConfigurationId == tableConfig.Id && c.BusinessDate == businessDate),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Run should complete successfully
        _mockCompleteRunHandler.Verify(
            x => x.HandleAsync(
                It.Is<CompleteRunCommand>(c => c.RunId == runId && c.Status == RunStatus.Succeeded),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_PendingDataset_ProcessesExport()
    {
        // Arrange
        var tableConfig = new TableConfigBuilder()
            .WithId(1)
            .Build();

        var businessDate = new DateOnly(2026, 2, 15);
        var runId = 42L;

        // Setup: Run started
        _mockStartRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<StartRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<long>.Success(runId));

        // Setup: Active config
        _mockTableConfigStore
            .Setup(x => x.GetActiveTableConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { tableConfig });

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");

        // Setup: Present dates
        _mockTableArchiver
            .Setup(x => x.GetPresentDatesAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BusinessDate> { new BusinessDate(businessDate) });

        // Setup: Retention
        _mockRetentionCalculator
            .Setup(x => x.CalculateKeepDatesAsync(It.IsAny<int>(), It.IsAny<IReadOnlyList<BusinessDate>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<DateOnly>());

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetTableExemptionsAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<(int, DateOnly)>());

        // Setup: No existing dataset (null = first run, should process)
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(tableConfig.Id, businessDate, It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: Execute succeeds
        _mockExecuteHandler
            .Setup(x => x.HandleAsync(It.IsAny<ExecuteTableArchivalCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExecuteTableArchivalResponse>.Success(
                new ExecuteTableArchivalResponse(true, true, 100, 5)));

        // Setup: AddRunItem
        _mockRunItemsStore
            .Setup(x => x.AddRunItemAsync(
                It.IsAny<long>(),
                It.IsAny<RunItemType>(),
                It.IsAny<RunItemStatus>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<string?>(),
                It.IsAny<long?>(),
                It.IsAny<long?>(),
                It.IsAny<string?>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Complete run
        _mockCompleteRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<CompleteRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        var command = new RunTableArchivalCommand(AllActive: true, TableConfigId: null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // ExecuteTableArchivalHandler SHOULD be called (new dataset)
        _mockExecuteHandler.Verify(
            x => x.HandleAsync(
                It.Is<ExecuteTableArchivalCommand>(c => c.TableConfigurationId == tableConfig.Id && c.BusinessDate == businessDate),
                It.IsAny<CancellationToken>()),
            Times.Once);

        // Run should complete successfully
        _mockCompleteRunHandler.Verify(
            x => x.HandleAsync(
                It.Is<CompleteRunCommand>(c => c.RunId == runId && c.Status == RunStatus.Succeeded),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_SomeItemsFail_MarksRunPartiallySucceeded()
    {
        // Arrange
        var tableConfig = new TableConfigBuilder().WithId(1).Build();
        var date1 = new DateOnly(2026, 2, 15);
        var date2 = new DateOnly(2026, 2, 16);
        var runId = 42L;

        // Setup: Run started
        _mockStartRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<StartRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<long>.Success(runId));

        // Setup: Config
        _mockTableConfigStore
            .Setup(x => x.GetActiveTableConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { tableConfig });

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");

        // Setup: Two dates
        _mockTableArchiver
            .Setup(x => x.GetPresentDatesAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BusinessDate> { new BusinessDate(date1), new BusinessDate(date2) });

        // Setup: Retention
        _mockRetentionCalculator
            .Setup(x => x.CalculateKeepDatesAsync(It.IsAny<int>(), It.IsAny<IReadOnlyList<BusinessDate>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<DateOnly>());

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetTableExemptionsAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<(int, DateOnly)>());

        // Setup: No existing datasets
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: First date succeeds, second date fails
        _mockExecuteHandler
            .Setup(x => x.HandleAsync(
                It.Is<ExecuteTableArchivalCommand>(c => c.BusinessDate == date1),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExecuteTableArchivalResponse>.Success(
                new ExecuteTableArchivalResponse(true, true, 100, 5)));

        _mockExecuteHandler
            .Setup(x => x.HandleAsync(
                It.Is<ExecuteTableArchivalCommand>(c => c.BusinessDate == date2),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExecuteTableArchivalResponse>.Fail("Export failed"));

        // Setup: AddRunItem
        _mockRunItemsStore
            .Setup(x => x.AddRunItemAsync(
                It.IsAny<long>(),
                It.IsAny<RunItemType>(),
                It.IsAny<RunItemStatus>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<string?>(),
                It.IsAny<long?>(),
                It.IsAny<long?>(),
                It.IsAny<string?>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Complete run
        _mockCompleteRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<CompleteRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        var command = new RunTableArchivalCommand(AllActive: true, TableConfigId: null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // Run should be marked PartiallySucceeded (some items failed)
        _mockCompleteRunHandler.Verify(
            x => x.HandleAsync(
                It.Is<CompleteRunCommand>(c => c.RunId == runId && c.Status == RunStatus.PartiallySucceeded),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_RecordsRunItemForEachDataset()
    {
        // Arrange
        var tableConfig = new TableConfigBuilder().WithId(1).Build();
        var date1 = new DateOnly(2026, 2, 15);
        var date2 = new DateOnly(2026, 2, 16);
        var runId = 42L;

        // Setup: Run started
        _mockStartRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<StartRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<long>.Success(runId));

        // Setup: Config
        _mockTableConfigStore
            .Setup(x => x.GetActiveTableConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { tableConfig });

        // Setup: Connection
        _mockConnectionResolver
            .Setup(x => x.ResolveSourceConnection(It.IsAny<string>()))
            .Returns("Server=test;");

        // Setup: Two dates
        _mockTableArchiver
            .Setup(x => x.GetPresentDatesAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BusinessDate> { new BusinessDate(date1), new BusinessDate(date2) });

        // Setup: Retention
        _mockRetentionCalculator
            .Setup(x => x.CalculateKeepDatesAsync(It.IsAny<int>(), It.IsAny<IReadOnlyList<BusinessDate>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<DateOnly>());

        // Setup: No exemptions
        _mockExemptionsStore
            .Setup(x => x.GetTableExemptionsAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new HashSet<(int, DateOnly)>());

        // Setup: No existing datasets
        _mockDatasetStore
            .Setup(x => x.GetDatasetAsync(It.IsAny<int>(), It.IsAny<DateOnly>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((DatasetDetailDto?)null);

        // Setup: Both succeed
        _mockExecuteHandler
            .Setup(x => x.HandleAsync(It.IsAny<ExecuteTableArchivalCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<ExecuteTableArchivalResponse>.Success(
                new ExecuteTableArchivalResponse(true, true, 100, 5)));

        // Setup: AddRunItem
        _mockRunItemsStore
            .Setup(x => x.AddRunItemAsync(
                It.IsAny<long>(),
                It.IsAny<RunItemType>(),
                It.IsAny<RunItemStatus>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<int?>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<string?>(),
                It.IsAny<long?>(),
                It.IsAny<long?>(),
                It.IsAny<string?>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Setup: Complete run
        _mockCompleteRunHandler
            .Setup(x => x.HandleAsync(It.IsAny<CompleteRunCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success());

        var command = new RunTableArchivalCommand(AllActive: true, TableConfigId: null);

        // Act
        var result = await _sut.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // Should record 2 run items (one for each date)
        _mockRunItemsStore.Verify(
            x => x.AddRunItemAsync(
                runId,
                RunItemType.Dataset,
                RunItemStatus.Succeeded,
                tableConfig.Id,
                It.IsAny<DateOnly>(),
                null,
                null,
                It.IsAny<string>(),
                It.IsAny<long>(),
                It.IsAny<long>(),
                null,
                It.IsAny<CancellationToken>()),
            Times.Exactly(2));
    }
}

