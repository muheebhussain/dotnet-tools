﻿using Archival.Application.Contracts.BlobLifecycle;
using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Features.BlobLifecycle.DiscoverBlobDatasets;
using Archival.Application.Shared.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.BlobLifecycle;

/// <summary>
/// Tests for DiscoverBlobDatasetsHandler external dataset discovery.
/// </summary>
public class DiscoverBlobDatasetsHandlerTests
{
    private readonly Mock<IBlobConfigurationStore> _configStoreMock = new();
    private readonly Mock<IBlobPolicyStore> _policyStoreMock = new();
    private readonly Mock<IBlobPrefixLister> _prefixListerMock = new();
    private readonly Mock<IDatasetPathTemplateExpander> _expanderMock = new();
    private readonly Mock<IBlobDatasetStore> _datasetStoreMock = new();
    private readonly Mock<IConnectionStringResolver> _connectionResolverMock = new();
    private readonly Mock<ILogger<DiscoverBlobDatasetsHandler>> _loggerMock = new();

    private DiscoverBlobDatasetsHandler CreateHandler()
    {
        return new DiscoverBlobDatasetsHandler(
            _configStoreMock.Object,
            _policyStoreMock.Object,
            _prefixListerMock.Object,
            _expanderMock.Object,
            _datasetStoreMock.Object,
            _connectionResolverMock.Object,
            _loggerMock.Object);
    }

    [Fact]
    public async Task HandleAsync_NoConfigurations_ReturnsEmptyResult()
    {
        // Arrange
        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto>());

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(0, result.Value.DatasetsDiscovered);
    }

    [Fact]
    public async Task HandleAsync_SkipsInternalConfigurations()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);
        // Note: IsExternal is false (internal configuration)

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(1, result.Value.ConfigurationsProcessed);
        Assert.Equal(0, result.Value.DatasetsDiscovered);
        // Verify UpsertAsync was never called for internal config
        _datasetStoreMock.Verify(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleAsync_ValidatesExternalConfigTemplate()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);
        // IsExternal = true but templates are null

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(0, result.Value.DatasetsDiscovered);
    }

    [Fact]
    public async Task HandleAsync_UpsertsDatesWithoutTemplateTokens()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1)
        { IsExternal = true, DatasetPathTemplate = "dataset/", BusinessDateFolderFormat = "yyyy-MM-dd" };

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _policyStoreMock
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _connectionResolverMock
            .Setup(x => x.ResolveStorageConnection("acc"))
            .Returns("connection-string");

        var prefixes = new List<string> { "prefix/2023-11-08/" };
        _prefixListerMock
            .Setup(x => x.ListPrefixesAsync("connection-string", "cont", "prefix", It.IsAny<CancellationToken>()))
            .ReturnsAsync(prefixes);

        _expanderMock
            .Setup(x => x.ExpandTemplate("dataset/", It.IsAny<DatasetPathTemplateContext>()))
            .Returns("dataset/");

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(1, result.Value.DatasetsDiscovered);
        Assert.Equal(1, result.Value.DatasetsUpserted);
        _datasetStoreMock.Verify(x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task HandleAsync_FiltersByMode_External()
    {
        // Arrange
        var externalConfig = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1)
        { IsExternal = true, DatasetPathTemplate = "d/", BusinessDateFolderFormat = "yyyy-MM-dd" };

        var internalConfig = new BlobConfigurationDto(
            Id: 2, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);
        // IsExternal = false (default)

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { externalConfig, internalConfig });

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "external");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        // Should process both configs, but only external one produces datasets
        Assert.Equal(2, result.Value.ConfigurationsProcessed);
    }

    [Fact]
    public async Task HandleAsync_SkipsNewerThanThreshold()
    {
        // Arrange
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var veryOldDate = today.AddDays(-50);  // Definitely older than thresholds
        var recentDate = today.AddDays(-2);    // Newer than all thresholds

        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1)
        { IsExternal = true, DatasetPathTemplate = "d/", BusinessDateFolderFormat = "yyyy-MM-dd" };

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Min threshold = 30 days

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _policyStoreMock
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _connectionResolverMock
            .Setup(x => x.ResolveStorageConnection("acc"))
            .Returns("connection-string");

        var prefixes = new List<string>
        {
            $"prefix/{veryOldDate:yyyy-MM-dd}/",
            $"prefix/{recentDate:yyyy-MM-dd}/"
        };
        _prefixListerMock
            .Setup(x => x.ListPrefixesAsync("connection-string", "cont", "prefix", It.IsAny<CancellationToken>()))
            .ReturnsAsync(prefixes);

        _expanderMock
            .Setup(x => x.ExpandTemplate("d/", It.IsAny<DatasetPathTemplateContext>()))
            .Returns("d/");

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        // Should only upsert the old date, not the recent one
        Assert.Equal(1, result.Value.DatasetsDiscovered);
    }

    [Fact]
    public async Task HandleAsync_CallsExpanderWithCorrectContext()
    {
        // Arrange
        var asOfDate = new DateOnly(2023, 11, 8);
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1)
        { IsExternal = true, DatasetPathTemplate = "data/{yyyy}/{MM}/", BusinessDateFolderFormat = "yyyy-MM-dd" };

        var policy = new LifecyclePolicyDto(1, true, null, null, null);

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _policyStoreMock
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _connectionResolverMock
            .Setup(x => x.ResolveStorageConnection("acc"))
            .Returns("connection-string");

        _prefixListerMock
            .Setup(x => x.ListPrefixesAsync("connection-string", "cont", "prefix", It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<string> { $"prefix/{asOfDate:yyyy-MM-dd}/" });

        _expanderMock
            .Setup(x => x.ExpandTemplate("data/{yyyy}/{MM}/", It.IsAny<DatasetPathTemplateContext>()))
            .Returns("data/2023/11/");

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        _expanderMock.Verify(x => x.ExpandTemplate(
            "data/{yyyy}/{MM}/",
            It.Is<DatasetPathTemplateContext>(ctx => ctx.AsOfDate == asOfDate)),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_LogsWarning_WhenDateParsingFails()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "prefix/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1)
        {
            IsExternal = true,
            DatasetPathTemplate = "data/",
            BusinessDateFolderFormat = "yyyy-MM-dd",
            BusinessDateFolderDepth = 1
        };

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        _configStoreMock
            .Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _policyStoreMock
            .Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _connectionResolverMock
            .Setup(x => x.ResolveStorageConnection("acc"))
            .Returns("connection-string");

        // Invalid prefixes that won't parse with yyyy-MM-dd format
        var invalidPrefixes = new List<string>
        {
            "prefix/invalid-date/",      // Not a valid date
            "prefix/2023-13-45/",        // Invalid month/day
            "prefix/not-a-date-folder/"  // Completely invalid
        };

        _prefixListerMock
            .Setup(x => x.ListPrefixesAsync("connection-string", "cont", "prefix/", It.IsAny<CancellationToken>()))
            .ReturnsAsync(invalidPrefixes);

        var handler = CreateHandler();
        var command = new DiscoverBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(0, result.Value.DatasetsDiscovered); // No datasets should be discovered

        // Verify WARNING was logged for each invalid prefix with correct details
        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Could not parse business date from prefix") &&
                                               v.ToString()!.Contains("BlobConfigId=1") &&
                                               v.ToString()!.Contains("Prefix=prefix/invalid-date/") &&
                                               v.ToString()!.Contains("ExpectedFormat=yyyy-MM-dd") &&
                                               v.ToString()!.Contains("FolderDepth=1")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Could not parse business date from prefix") &&
                                               v.ToString()!.Contains("Prefix=prefix/2023-13-45/")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Could not parse business date from prefix") &&
                                               v.ToString()!.Contains("Prefix=prefix/not-a-date-folder/")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        // Verify no datasets were upserted
        _datasetStoreMock.Verify(
            x => x.UpsertAsync(It.IsAny<BlobDatasetUpsertDto>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }
}

