using Archival.Application.Configuration;
using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Contracts.Time;
using Archival.Application.Features.BlobLifecycle.ExecuteBlobDatasets;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Application.Tests.TestUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;

namespace Archival.Application.Tests.BlobLifecycle;

/// <summary>
/// Tests for ExecuteBlobDatasetsHandler.
/// Verifies dataset-level lifecycle execution with bounded concurrency and parent cleanup.
/// </summary>
public class ExecuteBlobDatasetsHandlerTests
{
    private readonly Mock<IConfigurationStore> _configStoreMock = new();
    private readonly Mock<IBlobDatasetStore> _datasetStoreMock = new();
    private readonly Mock<IExemptionsStore> _exemptionsStoreMock = new();
    private readonly Mock<IConnectionStringResolver> _connectionResolverMock = new();
    private readonly Mock<IBlobLister> _blobListerMock = new();
    private readonly Mock<IBlobLifecycleExecutor> _executorMock = new();
    private readonly Mock<ILogger<ExecuteBlobDatasetsHandler>> _loggerMock = new();
    private readonly IClock _clock = FakeClock.CreateDefault();

    private ExecuteBlobDatasetsHandler CreateHandler(int datasetsParallelism = 4)
    {
        var options = Options.Create(new BlobLifecycleOptions { DatasetsParallelism = datasetsParallelism });

        return new ExecuteBlobDatasetsHandler(
            _configStoreMock.Object,
            _datasetStoreMock.Object,
            _exemptionsStoreMock.Object,
            _connectionResolverMock.Object,
            _blobListerMock.Object,
            _executorMock.Object,
            options,
            _loggerMock.Object,
            _clock);
    }

    [Fact]
    public async Task HandleAsync_ProcessesDueRowsOnly()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "root/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        var dataset = new BlobDatasetDto(
            Id: 1, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: new DateOnly(2026, 2, 10), StorageAccountName: "acc", ContainerName: "cont",
            BlobPrefix: "root/data/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
            NextAction: BlobDatasetNextAction.SetCold, NextActionAt: DateTime.UtcNow.AddHours(-1),
            AttemptCount: 0, LastError: null,
            ExecutionStatus: BlobDatasetExecutionStatus.Pending, ExecutedAt: null);

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobDatasetDto> { dataset });

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        _blobListerMock.Setup(x => x.ListBlobsAsync("connstr", "cont", "root/data/", It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        _executorMock.Setup(x => x.TrySetColdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var handler = CreateHandler();
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(1, result.Value.ConfigurationsProcessed);
        Assert.Equal(1, result.Value.ActionsExecuted);

        // Verify GetDueAsync was called
        _datasetStoreMock.Verify(
            x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()),
            Times.Once);

        // Verify MarkActionResultAsync was called
        _datasetStoreMock.Verify(
            x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_DeleteActionTriggersCleanup()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "root/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        var dataset = new BlobDatasetDto(
            Id: 1, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: new DateOnly(2026, 2, 10), StorageAccountName: "acc", ContainerName: "cont",
            BlobPrefix: "root/data/2026/02/10/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
            NextAction: BlobDatasetNextAction.Delete, NextActionAt: DateTime.UtcNow.AddHours(-1),
            AttemptCount: 0, LastError: null,
            ExecutionStatus: BlobDatasetExecutionStatus.Pending, ExecutedAt: null);

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobDatasetDto> { dataset });

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        _blobListerMock.Setup(x => x.ListBlobsAsync("connstr", "cont", "root/data/2026/02/10/", It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        var deleteResult = new PrefixDeletionResultDto(0, false, false, 2, true);
        _executorMock.Setup(x => x.DeletePrefixAndCleanupParentsAsync(
            "connstr", "cont", "root/data/2026/02/10/", "root/", It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<PrefixDeletionResultDto>.Success(deleteResult));

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var handler = CreateHandler();
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // Verify DeletePrefixAndCleanupParentsAsync was called with root prefix boundary
        _executorMock.Verify(
            x => x.DeletePrefixAndCleanupParentsAsync("connstr", "cont", "root/data/2026/02/10/", "root/", It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_IdempotentOnAlreadyDeletedDataset()
    {
        // Arrange: Dataset already deleted (IsDeleted=true), attempt re-execution
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "root/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        var dataset = new BlobDatasetDto(
            Id: 1, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: new DateOnly(2026, 2, 10), StorageAccountName: "acc", ContainerName: "cont",
            BlobPrefix: "root/data/2026/02/10/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
            NextAction: BlobDatasetNextAction.Delete, NextActionAt: DateTime.UtcNow.AddHours(-1),
            AttemptCount: 1, LastError: null,
            ExecutionStatus: BlobDatasetExecutionStatus.Pending, ExecutedAt: null);

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobDatasetDto> { dataset });

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        // No blobs found (already deleted)
        _blobListerMock.Setup(x => x.ListBlobsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        var deleteResult = new PrefixDeletionResultDto(0, false, false, 0, true);
        _executorMock.Setup(x => x.DeletePrefixAndCleanupParentsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<PrefixDeletionResultDto>.Success(deleteResult));

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var handler = CreateHandler();
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert - Should succeed even though nothing was deleted
        Assert.True(result.Ok);
        Assert.Equal(1, result.Value.ActionsExecuted);
    }

    [Fact]
    public async Task HandleAsync_BoundedConcurrencyLimitedToFourDatasetsInParallel()
    {
        // Arrange: Create multiple datasets to verify concurrency
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "root/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        var datasets = Enumerable.Range(1, 8)
            .Select(i => new BlobDatasetDto(
                Id: i, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
                AsOfDate: new DateOnly(2026, 2, 10 + i), StorageAccountName: "acc", ContainerName: "cont",
                BlobPrefix: $"root/data/{i}/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
                NextAction: BlobDatasetNextAction.SetCold, NextActionAt: DateTime.UtcNow.AddHours(-1),
                AttemptCount: 0, LastError: null))
            .ToList();

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(datasets);

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        _blobListerMock.Setup(x => x.ListBlobsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        _executorMock.Setup(x => x.TrySetColdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var handler = CreateHandler();
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert - All datasets should be processed (concurrency is transparent)
        Assert.True(result.Ok);
        Assert.Equal(8, result.Value.ActionsExecuted);

        // Verify batch update was called
        _datasetStoreMock.Verify(
            x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_RespectsRootPrefixBoundaryInCleanup()
    {
        // Arrange: Verify cleanup respects root prefix boundary
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "data/2026/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        var dataset = new BlobDatasetDto(
            Id: 1, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: new DateOnly(2026, 2, 10), StorageAccountName: "acc", ContainerName: "cont",
            BlobPrefix: "data/2026/02/10/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
            NextAction: BlobDatasetNextAction.Delete, NextActionAt: DateTime.UtcNow.AddHours(-1),
            AttemptCount: 0, LastError: null,
            ExecutionStatus: BlobDatasetExecutionStatus.Pending, ExecutedAt: null);

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobDatasetDto> { dataset });

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        _blobListerMock.Setup(x => x.ListBlobsAsync("connstr", "cont", "data/2026/02/10/", It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        var deleteResult = new PrefixDeletionResultDto(0, false, false, 2, true);
        _executorMock.Setup(x => x.DeletePrefixAndCleanupParentsAsync(
            "connstr", "cont", "data/2026/02/10/", "data/2026/", It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<PrefixDeletionResultDto>.Success(deleteResult));

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var handler = CreateHandler();
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);

        // Verify cleanup was called with correct root prefix boundary
        _executorMock.Verify(
            x => x.DeletePrefixAndCleanupParentsAsync("connstr", "cont", "data/2026/02/10/", "data/2026/", It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task HandleAsync_UsesConfiguredParallelism()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "acc", ContainerName: "cont", Prefix: "root/",
            IncludePattern: null, ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        // Create multiple datasets to test parallelism
        var datasets = Enumerable.Range(1, 10).Select(i => new BlobDatasetDto(
            Id: i, BlobConfigurationId: 1, SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: new DateOnly(2026, 2, i), StorageAccountName: "acc", ContainerName: "cont",
            BlobPrefix: $"root/data{i}/", ArchivalDatasetId: null, CurrentTier: BlobTierState.Hot,
            NextAction: BlobDatasetNextAction.SetCold, NextActionAt: DateTime.UtcNow.AddHours(-1),
            AttemptCount: 0, LastError: null)).ToList();

        _configStoreMock.Setup(x => x.GetEnabledBlobConfigurationsAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<BlobConfigurationDto> { config });

        _configStoreMock.Setup(x => x.GetLifecyclePolicyAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(policy);

        var callCount = 0;
        _datasetStoreMock.Setup(x => x.GetDueAsync(1, It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                callCount++;
                return callCount == 1 ? datasets : new List<BlobDatasetDto>();
            });

        _connectionResolverMock.Setup(x => x.ResolveStorageConnection("acc")).Returns("connstr");

        _exemptionsStoreMock.Setup(x => x.GetBlobExemptionMatcherAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Archival.Application.BlobLifecycle.BlobExemptionMatcher.Create(Array.Empty<(string, string, DateOnly)>()));

        _blobListerMock.Setup(x => x.ListBlobsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .Returns(AsyncEnumerable.Empty<BlobItem>());

        _executorMock.Setup(x => x.TrySetColdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        _datasetStoreMock.Setup(x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Create handler with custom parallelism
        var customParallelism = 8;
        var handler = CreateHandler(customParallelism);
        var command = new ExecuteBlobDatasetsCommand(true, null, "all");

        // Act
        var result = await handler.HandleAsync(command, CancellationToken.None);

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(10, result.Value.ActionsExecuted);

        // Verify batch update called once for the batch
        _datasetStoreMock.Verify(
            x => x.MarkActionResultsBatchAsync(It.IsAny<IReadOnlyList<BlobDatasetMarkBatchItem>>(), It.IsAny<CancellationToken>()),
            Times.Once);

        // The test verifies that the handler completes successfully with the configured parallelism
        // The SemaphoreSlim internally uses the configured value (8) instead of hardcoded 4
        // This ensures that the configuration is properly injected and used
    }
}

