﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Features.BlobLifecycle.DiscoverBlobDatasets;
using Archival.Application.Features.BlobLifecycle.ExecuteBlobDatasets;
using Archival.Application.Shared.Models;
using Archival.Data;
using Archival.Data.Entities;
using Archival.Data.Stores;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Application.Tests.BlobLifecycle;

/// <summary>
/// Integration-style unit tests for crash-safe, idempotent blob dataset discovery and execution.
/// Validates that re-running discover-execute stages doesn't create duplicates or lose state.
/// </summary>
public class BlobDatasetIdempotencyTests
{
    private readonly DbContextOptions<ArchivalDbContext> _dbOptions;

    public BlobDatasetIdempotencyTests()
    {
        // Use in-memory database for testing
        _dbOptions = new DbContextOptionsBuilder<ArchivalDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestDb_{Guid.NewGuid()}")
            .Options;
    }

    /// <summary>
    /// Test: Discover creates dataset with ExecutionStatus=Pending.
    /// Re-discover should NOT create duplicate; existing should remain Pending.
    /// </summary>
    [Fact]
    public async Task Discover_ThenDiscoverAgain_NoDuplicatesCreated()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());
        var configId = 1;
        var date = new DateOnly(2026, 2, 15);

        var upsertDto = new BlobDatasetUpsertDto(
            BlobConfigurationId: configId,
            SourceType: BlobDatasetSourceType.External,
            AsOfDate: date,
            StorageAccountName: "account",
            ContainerName: "container",
            BlobPrefix: "data/2026/02/15/",
            ArchivalDatasetId: null,
            CurrentTier: BlobTierState.Unknown,
            NextAction: BlobDatasetNextAction.SetCold,
            NextActionAt: DateTime.UtcNow.AddHours(-1));

        // Act - First discover
        await store.UpsertAsync(upsertDto, CancellationToken.None);

        // Count records
        using var dbContext2 = new ArchivalDbContext(_dbOptions);
        var countAfterFirstDiscover = await dbContext2.BlobDatasets.CountAsync();
        var firstRecord = await dbContext2.BlobDatasets
            .FirstAsync(x => x.BlobConfigurationId == configId && x.AsOfDate == date);
        var firstStatus = firstRecord.ExecutionStatus;

        // Act - Second discover (should be idempotent)
        await store.UpsertAsync(upsertDto, CancellationToken.None);

        // Count again
        var countAfterSecondDiscover = await dbContext2.BlobDatasets.CountAsync();
        var secondRecord = await dbContext2.BlobDatasets
            .FirstAsync(x => x.BlobConfigurationId == configId && x.AsOfDate == date);
        var secondStatus = secondRecord.ExecutionStatus;

        // Assert
        Assert.Equal(1, countAfterFirstDiscover);
        Assert.Equal(1, countAfterSecondDiscover);
        Assert.Equal(BlobDatasetExecutionStatus.Pending, firstStatus);
        Assert.Equal(BlobDatasetExecutionStatus.Pending, secondStatus);
    }

    /// <summary>
    /// Test: Discover → Execute half of batch → Crash → Restart Execute.
    /// Should only process remaining Pending datasets, not re-process Succeeded ones.
    /// </summary>
    [Fact]
    public async Task Discover_ExecuteHalf_CrashAndRestart_OnlyProcessesRemaining()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());
        var configId = 1;

        // Create 4 datasets
        var datasets = new[]
        {
            new BlobDatasetUpsertDto(configId, BlobDatasetSourceType.External, new DateOnly(2026, 2, 10), "acc", "cont", "data/2026/02/10/", null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow),
            new BlobDatasetUpsertDto(configId, BlobDatasetSourceType.External, new DateOnly(2026, 2, 11), "acc", "cont", "data/2026/02/11/", null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow),
            new BlobDatasetUpsertDto(configId, BlobDatasetSourceType.External, new DateOnly(2026, 2, 12), "acc", "cont", "data/2026/02/12/", null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow),
            new BlobDatasetUpsertDto(configId, BlobDatasetSourceType.External, new DateOnly(2026, 2, 13), "acc", "cont", "data/2026/02/13/", null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow),
        };

        // Act - Discover all datasets
        foreach (var dto in datasets)
        {
            await store.UpsertAsync(dto, CancellationToken.None);
        }

        // Get all datasets and mark first 2 as Succeeded (simulate first batch execution)
        using var dbContext2 = new ArchivalDbContext(_dbOptions);
        var allDatasets = await dbContext2.BlobDatasets.OrderBy(x => x.AsOfDate).ToListAsync();
        Assert.Equal(4, allDatasets.Count);

        // Simulate execution: mark first 2 as Succeeded
        var ds1 = allDatasets[0];
        var ds2 = allDatasets[1];
        ds1.ExecutionStatus = BlobDatasetExecutionStatus.Succeeded;
        ds1.ExecutedAt = DateTime.UtcNow;
        ds1.LastAction = BlobDatasetLastAction.SetCold;
        ds1.LastActionAt = DateTime.UtcNow;

        ds2.ExecutionStatus = BlobDatasetExecutionStatus.Succeeded;
        ds2.ExecutedAt = DateTime.UtcNow;
        ds2.LastAction = BlobDatasetLastAction.SetCold;
        ds2.LastActionAt = DateTime.UtcNow;

        await dbContext2.SaveChangesAsync();

        // Act - Crash, restart discover (should not create duplicates)
        var store2 = new BlobDatasetStore(dbContext2, CreateMockLogger());
        foreach (var dto in datasets)
        {
            await store2.UpsertAsync(dto, CancellationToken.None);
        }

        // Act - Query for due (Pending) datasets
        var dueDatasets = await store2.GetDueAsync(configId, DateTime.UtcNow, 100, CancellationToken.None);

        // Assert - Only 2 should be due (the 2 that are still Pending)
        Assert.Equal(2, dueDatasets.Count);
        Assert.All(dueDatasets, dto => Assert.Equal(BlobDatasetExecutionStatus.Pending, dto.ExecutionStatus));
        Assert.Contains(dueDatasets, dto => dto.AsOfDate == new DateOnly(2026, 2, 12));
        Assert.Contains(dueDatasets, dto => dto.AsOfDate == new DateOnly(2026, 2, 13));
    }

    /// <summary>
    /// Test: Discover → Execute batch → Some fail → MarkActionResult sets Succeeded/Failed status.
    /// </summary>
    [Fact]
    public async Task ExecuteAndMark_SuccessfulExecution_SetsSucceededStatus()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());
        var configId = 1;
        var date = new DateOnly(2026, 2, 15);

        // Create dataset
        var upsertDto = new BlobDatasetUpsertDto(
            configId, BlobDatasetSourceType.External, date, "acc", "cont", "data/2026/02/15/",
            null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow);
        await store.UpsertAsync(upsertDto, CancellationToken.None);

        // Get dataset ID
        using var dbContext2 = new ArchivalDbContext(_dbOptions);
        var dataset = await dbContext2.BlobDatasets
            .FirstAsync(x => x.BlobConfigurationId == configId && x.AsOfDate == date);
        var datasetId = dataset.Id;

        // Act - Mark successful execution
        var markDto = new BlobDatasetMarkResultDto(
            LastAction: BlobDatasetLastAction.SetCold,
            LastActionAt: DateTime.UtcNow,
            LastError: null,
            NextAttemptAfterMinutes: null);
        await store.MarkActionResultAsync(datasetId, markDto, CancellationToken.None);

        // Assert
        using var dbContext3 = new ArchivalDbContext(_dbOptions);
        var updatedDataset = await dbContext3.BlobDatasets.FindAsync(datasetId);
        Assert.NotNull(updatedDataset);
        Assert.Equal(BlobDatasetExecutionStatus.Succeeded, updatedDataset.ExecutionStatus);
        Assert.NotNull(updatedDataset.ExecutedAt);
        Assert.Equal(BlobDatasetLastAction.SetCold, updatedDataset.LastAction);
    }

    /// <summary>
    /// Test: Execute action fails → MarkActionResult sets Failed status.
    /// </summary>
    [Fact]
    public async Task ExecuteAndMark_FailedExecution_SetsFailedStatus()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());
        var configId = 1;
        var date = new DateOnly(2026, 2, 15);

        // Create dataset
        var upsertDto = new BlobDatasetUpsertDto(
            configId, BlobDatasetSourceType.External, date, "acc", "cont", "data/2026/02/15/",
            null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow);
        await store.UpsertAsync(upsertDto, CancellationToken.None);

        // Get dataset ID
        using var dbContext2 = new ArchivalDbContext(_dbOptions);
        var dataset = await dbContext2.BlobDatasets
            .FirstAsync(x => x.BlobConfigurationId == configId && x.AsOfDate == date);
        var datasetId = dataset.Id;

        // Act - Mark failed execution (LastAction=None indicates failure)
        var markDto = new BlobDatasetMarkResultDto(
            LastAction: BlobDatasetLastAction.None,
            LastActionAt: DateTime.UtcNow,
            LastError: "Blob tiering failed: 429 Too Many Requests",
            NextAttemptAfterMinutes: null);
        await store.MarkActionResultAsync(datasetId, markDto, CancellationToken.None);

        // Assert
        using var dbContext3 = new ArchivalDbContext(_dbOptions);
        var updatedDataset = await dbContext3.BlobDatasets.FindAsync(datasetId);
        Assert.NotNull(updatedDataset);
        Assert.Equal(BlobDatasetExecutionStatus.Failed, updatedDataset.ExecutionStatus);
        Assert.NotNull(updatedDataset.ExecutedAt);
        Assert.Contains("429", updatedDataset.LastError);
    }

    /// <summary>
    /// Test: Unique constraint on (BlobConfigurationId, AsOfDate) prevents inserts.
    /// </summary>
    [Fact]
    public async Task UpsertAsync_DuplicateKeys_DoesNotThrow()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());
        var configId = 1;
        var date = new DateOnly(2026, 2, 15);

        var dto1 = new BlobDatasetUpsertDto(
            configId, BlobDatasetSourceType.External, date, "acc", "cont", "data/2026/02/15/",
            null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow);

        // Act - Insert first
        await store.UpsertAsync(dto1, CancellationToken.None);

        // Act - Attempt duplicate key (different blob_prefix)
        var dto2 = new BlobDatasetUpsertDto(
            configId, BlobDatasetSourceType.External, date, "acc", "cont", "different/prefix/",
            null, BlobTierState.Unknown, BlobDatasetNextAction.SetCold, DateTime.UtcNow);

        // Should NOT throw; upsert should be idempotent
        await store.UpsertAsync(dto2, CancellationToken.None);

        // Assert - Only 1 record should exist (not 2)
        using var dbContext2 = new ArchivalDbContext(_dbOptions);
        var count = await dbContext2.BlobDatasets
            .Where(x => x.BlobConfigurationId == configId && x.AsOfDate == date)
            .CountAsync();
        Assert.Equal(1, count);
    }

    /// <summary>
    /// Test: GetDueAsync filters Pending datasets only (excludes Succeeded/Failed).
    /// </summary>
    [Fact]
    public async Task GetDueAsync_FiltersOnlyPendingDatasets()
    {
        // Arrange
        using var dbContext = new ArchivalDbContext(_dbOptions);
        await dbContext.Database.EnsureCreatedAsync();

        var configId = 1;
        var now = DateTime.UtcNow;

        // Manually create datasets with different statuses
        dbContext.BlobDatasets.AddRange(
            new ArchivalBlobDatasetEntity
            {
                BlobConfigurationId = configId,
                SourceType = BlobDatasetSourceType.External,
                AsOfDate = new DateOnly(2026, 2, 10),
                StorageAccountName = "acc",
                ContainerName = "cont",
                BlobPrefix = "prefix1/",
                ArchivalDatasetId = null,
                CurrentTier = BlobTierState.Unknown,
                NextAction = BlobDatasetNextAction.SetCold,
                NextActionAt = now.AddHours(-1),
                ExecutionStatus = BlobDatasetExecutionStatus.Pending,  // Should be included
                DiscoveredAt = now,
                IsDeleted = false,
                CreatedAt = now,
            },
            new ArchivalBlobDatasetEntity
            {
                BlobConfigurationId = configId,
                SourceType = BlobDatasetSourceType.External,
                AsOfDate = new DateOnly(2026, 2, 11),
                StorageAccountName = "acc",
                ContainerName = "cont",
                BlobPrefix = "prefix2/",
                ArchivalDatasetId = null,
                CurrentTier = BlobTierState.Unknown,
                NextAction = BlobDatasetNextAction.SetCold,
                NextActionAt = now.AddHours(-1),
                ExecutionStatus = BlobDatasetExecutionStatus.Succeeded,  // Should NOT be included
                DiscoveredAt = now,
                ExecutedAt = now,
                IsDeleted = false,
                CreatedAt = now,
            },
            new ArchivalBlobDatasetEntity
            {
                BlobConfigurationId = configId,
                SourceType = BlobDatasetSourceType.External,
                AsOfDate = new DateOnly(2026, 2, 12),
                StorageAccountName = "acc",
                ContainerName = "cont",
                BlobPrefix = "prefix3/",
                ArchivalDatasetId = null,
                CurrentTier = BlobTierState.Unknown,
                NextAction = BlobDatasetNextAction.SetCold,
                NextActionAt = now.AddHours(-1),
                ExecutionStatus = BlobDatasetExecutionStatus.Failed,  // Should NOT be included
                DiscoveredAt = now,
                ExecutedAt = now,
                IsDeleted = false,
                CreatedAt = now,
            }
        );
        await dbContext.SaveChangesAsync();

        var store = new BlobDatasetStore(dbContext, CreateMockLogger());

        // Act
        var dueDatasets = await store.GetDueAsync(configId, now, 100, CancellationToken.None);

        // Assert - Only 1 (Pending)
        Assert.Single(dueDatasets);
        Assert.Equal(new DateOnly(2026, 2, 10), dueDatasets[0].AsOfDate);
        Assert.Equal(BlobDatasetExecutionStatus.Pending, dueDatasets[0].ExecutionStatus);
    }

    // Helper to create mock logger
    private static ILogger<BlobDatasetStore> CreateMockLogger()
    {
        return new Mock<ILogger<BlobDatasetStore>>().Object;
    }
}

