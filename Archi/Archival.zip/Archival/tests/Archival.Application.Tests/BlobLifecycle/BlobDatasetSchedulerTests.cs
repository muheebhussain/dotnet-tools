﻿using Archival.Application.Shared.BlobLifecycle;
using Archival.Application.Shared.Models;
using Xunit;

namespace Archival.Application.Tests.BlobLifecycle;

/// <summary>
/// Tests for BlobDatasetScheduler lifecycle action computation.
/// </summary>
public class BlobDatasetSchedulerTests
{
    [Fact]
    public void ComputeNext_DeleteThreshold_ReturnsDelete()
    {
        // Arrange
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-31);  // 31 days old
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Delete at 30 days

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert
        Assert.Equal(BlobDatasetNextAction.Delete, action);
        Assert.Null(actionAt);
    }

    [Fact]
    public void ComputeNext_ArchiveThreshold_ReturnsArchive()
    {
        // Arrange
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-21);  // 21 days old
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Archive at 20 days

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert
        Assert.Equal(BlobDatasetNextAction.SetArchive, action);
        Assert.Null(actionAt);
    }

    [Fact]
    public void ComputeNext_ColdThreshold_ReturnsCold()
    {
        // Arrange
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-11);  // 11 days old
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Cold at 10 days

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert
        Assert.Equal(BlobDatasetNextAction.SetCold, action);
        Assert.Null(actionAt);
    }

    [Fact]
    public void ComputeNext_NoThreshold_ReturnsNone()
    {
        // Arrange
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-5);  // 5 days old
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Cold at 10 days

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert
        Assert.Equal(BlobDatasetNextAction.None, action);
        Assert.Null(actionAt);
    }

    [Fact]
    public void ComputeNext_DeletePrecedence_IgnoresArchiveAndCold()
    {
        // Arrange: Dataset is 31 days old, all thresholds met
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-31);
        var policy = new LifecyclePolicyDto(1, true, 5, 10, 30);  // Cold 5d, Archive 10d, Delete 30d

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert - Should return Delete, not Cold or Archive
        Assert.Equal(BlobDatasetNextAction.Delete, action);
    }

    [Fact]
    public void ComputeNext_ArchiveTierNotSupported_SkipsArchive()
    {
        // Arrange: Dataset is 21 days old, archive threshold met, but not supported
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-21);
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, supportsArchiveTier: false, asOfDate, DateTime.UtcNow);

        // Assert - Should skip Archive and return Cold instead
        Assert.Equal(BlobDatasetNextAction.SetCold, action);
    }

    [Fact]
    public void ComputeNext_NullArchiveThreshold_SkipsArchive()
    {
        // Arrange: Dataset is 21 days old, but no archive threshold configured
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var asOfDate = today.AddDays(-21);
        var policy = new LifecyclePolicyDto(1, true, 10, archiveMinAgeDays: null, deleteMinAgeDays: 30);

        // Act
        var (action, actionAt) = BlobDatasetScheduler.ComputeNext(policy, true, asOfDate, DateTime.UtcNow);

        // Assert - Should skip Archive and go to Cold
        Assert.Equal(BlobDatasetNextAction.SetCold, action);
    }

    [Fact]
    public void ComputeMinThresholdDate_MultipleThresholds_ReturnsEarliest()
    {
        // Arrange
        var utcNow = DateTime.UtcNow;
        var today = DateOnly.FromDateTime(utcNow);
        var policy = new LifecyclePolicyDto(1, true, 10, 20, 30);  // Cold 10d, Archive 20d, Delete 30d

        // Act
        var threshold = BlobDatasetScheduler.ComputeMinThresholdDate(policy, true, utcNow);

        // Assert - Should be 30 days ago (delete threshold)
        Assert.NotNull(threshold);
        Assert.Equal(today.AddDays(-30), threshold);
    }

    [Fact]
    public void ComputeMinThresholdDate_NoThresholds_ReturnsNull()
    {
        // Arrange
        var utcNow = DateTime.UtcNow;
        var policy = new LifecyclePolicyDto(1, true,
            coldMinAgeDays: null,
            archiveMinAgeDays: null,
            deleteMinAgeDays: null);

        // Act
        var threshold = BlobDatasetScheduler.ComputeMinThresholdDate(policy, true, utcNow);

        // Assert
        Assert.Null(threshold);
    }

    [Fact]
    public void ComputeMinThresholdDate_OnlyDeleteConfigured_ReturnsDeleteThreshold()
    {
        // Arrange
        var utcNow = DateTime.UtcNow;
        var today = DateOnly.FromDateTime(utcNow);
        var policy = new LifecyclePolicyDto(1, true,
            coldMinAgeDays: null,
            archiveMinAgeDays: null,
            deleteMinAgeDays: 30);

        // Act
        var threshold = BlobDatasetScheduler.ComputeMinThresholdDate(policy, true, utcNow);

        // Assert
        Assert.NotNull(threshold);
        Assert.Equal(today.AddDays(-30), threshold);
    }
}

