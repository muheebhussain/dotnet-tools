﻿using Archival.App.Cli;
using Xunit;

namespace Archival.Application.Tests.Cli;

/// <summary>
/// Tests for CLI argument parsing, including blob stage and mode flags.
/// </summary>
public class CliParserTests
{
    [Fact]
    public void ParseArgs_NoArgs_ReturnsOkWithNoCommand()
    {
        // Act
        var result = CliParser.ParseArgs(Array.Empty<string>());

        // Assert
        Assert.True(result.Ok);
        Assert.Null(result.Command);
    }

    [Fact]
    public void ParseArgs_HelpCommand_ReturnsHelpCommand()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "help" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("help", result.Command);
    }

    [Theory]
    [InlineData("-h")]
    [InlineData("--help")]
    public void ParseArgs_HelpFlags_ReturnsHelpCommand(string helpFlag)
    {
        // Act
        var result = CliParser.ParseArgs(new[] { helpFlag });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("help", result.Command);
    }

    [Theory]
    [InlineData("table")]
    [InlineData("blob")]
    public void ParseArgs_ValidCommand_ReturnsCommand(string cmd)
    {
        // Act
        var result = CliParser.ParseArgs(new[] { cmd });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal(cmd, result.Command);
    }

    [Fact]
    public void ParseArgs_InvalidCommand_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "invalid" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Unknown command", result.Error);
    }

    [Fact]
    public void ParseArgs_TableWithAllActive_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "table", "--all-active" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("table", result.Command);
        Assert.True(result.AllActive);
    }

    [Fact]
    public void ParseArgs_TableWithTableConfigId_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "table", "--table-config-id", "5" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("table", result.Command);
        Assert.Equal(5, result.TableConfigId);
    }

    [Fact]
    public void ParseArgs_TableWithInvalidConfigId_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "table", "--table-config-id", "notanumber" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Invalid --table-config-id", result.Error);
    }

    [Fact]
    public void ParseArgs_BlobWithAllTargets_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.True(result.AllTargets);
    }

    [Fact]
    public void ParseArgs_BlobWithTargetId_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--target-id", "3" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal(3, result.TargetId);
    }

    [Fact]
    public void ParseArgs_BlobWithStageDiscover_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--stage", "discover" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.True(result.AllTargets);
        Assert.Equal("discover", result.BlobStage);
    }

    [Fact]
    public void ParseArgs_BlobWithStageExecute_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--target-id", "1", "--stage", "execute" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal(1, result.TargetId);
        Assert.Equal("execute", result.BlobStage);
    }

    [Fact]
    public void ParseArgs_BlobWithStageLifecycle_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--stage", "lifecycle" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal("lifecycle", result.BlobStage);
    }

    [Fact]
    public void ParseArgs_BlobWithInvalidStage_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--stage", "invalid" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Invalid --stage", result.Error);
    }

    [Fact]
    public void ParseArgs_BlobWithModeInternal_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--mode", "internal" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal("internal", result.BlobMode);
    }

    [Fact]
    public void ParseArgs_BlobWithModeExternal_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--target-id", "2", "--mode", "external" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal(2, result.TargetId);
        Assert.Equal("external", result.BlobMode);
    }

    [Fact]
    public void ParseArgs_BlobWithModeAll_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--mode", "all" });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal("all", result.BlobMode);
    }

    [Fact]
    public void ParseArgs_BlobWithInvalidMode_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--mode", "invalid" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Invalid --mode", result.Error);
    }

    [Fact]
    public void ParseArgs_BlobWithStageModeAndSecrets_ParsesCorrectly()
    {
        // Act
        var result = CliParser.ParseArgs(new[] {
            "blob",
            "--target-id", "5",
            "--secrets-path", "/secrets",
            "--stage", "lifecycle",
            "--mode", "external"
        });

        // Assert
        Assert.True(result.Ok);
        Assert.Equal("blob", result.Command);
        Assert.Equal(5, result.TargetId);
        Assert.Equal("/secrets", result.SecretsPath);
        Assert.Equal("lifecycle", result.BlobStage);
        Assert.Equal("external", result.BlobMode);
    }

    [Fact]
    public void ParseArgs_MissingStageValue_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--stage" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Missing value for --stage", result.Error);
    }

    [Fact]
    public void ParseArgs_MissingModeValue_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "blob", "--all-targets", "--mode" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Missing value for --mode", result.Error);
    }

    [Fact]
    public void ParseArgs_UnknownOption_ReturnsFail()
    {
        // Act
        var result = CliParser.ParseArgs(new[] { "table", "--unknown-option" });

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("Unknown option", result.Error);
    }
}

