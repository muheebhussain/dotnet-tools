﻿using Archival.Application.Contracts.Tables;
using Archival.Application.Shared.Models;
using Archival.Infrastructure.Parquet;
using Xunit;

namespace Archival.Infrastructure.Tests.Parquet;

/// <summary>
/// Tests for HIGH-2: Archive path template expansion.
/// Verifies that the ArchivePathTemplateExpander correctly expands tokens.
/// </summary>
public class ArchivePathTemplateExpanderTests
{
    private readonly ArchivePathTemplateExpander _expander = new();

    /// <summary>
    /// Tests that a template with all supported tokens expands correctly.
    /// </summary>
    [Fact]
    public void ExpandTemplate_AllTokens_ExpandsCorrectly()
    {
        // Arrange
        var template = "{database}/{schema}/{table}/{yyyy}/{MM}/{dd}/";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "AdventureWorks",
            SchemaName: "dbo",
            TableName: "Orders",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("AdventureWorks/dbo/Orders/2025/01/15/", result);
    }

    /// <summary>
    /// Tests that template with no tokens remains unchanged.
    /// This ensures backward compatibility with non-tokenized paths.
    /// </summary>
    [Fact]
    public void ExpandTemplate_NoTokens_RemainsUnchanged()
    {
        // Arrange
        var template = "archive/fixed-path/";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "db",
            SchemaName: "schema",
            TableName: "table",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("archive/fixed-path/", result);
    }

    /// <summary>
    /// Tests that individual date tokens expand correctly.
    /// </summary>
    [Theory]
    [InlineData("{yyyy}", "2025")]
    [InlineData("{MM}", "01")]
    [InlineData("{dd}", "15")]
    [InlineData("{date}", "2025-01-15")]
    public void ExpandTemplate_DateTokens_ExpandCorrectly(string template, string expected)
    {
        // Arrange
        var context = new ArchivePathTemplateContext(
            DatabaseName: "db",
            SchemaName: "schema",
            TableName: "table",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that entity name tokens expand correctly.
    /// </summary>
    [Theory]
    [InlineData("{database}", "mydb")]
    [InlineData("{schema}", "dbo")]
    [InlineData("{table}", "orders")]
    public void ExpandTemplate_EntityTokens_ExpandCorrectly(string template, string expected)
    {
        // Arrange
        var context = new ArchivePathTemplateContext(
            DatabaseName: "mydb",
            SchemaName: "dbo",
            TableName: "orders",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that date type token expands correctly.
    /// </summary>
    [Theory]
    [InlineData(DateType.EOD, "EOD")]
    [InlineData(DateType.EOM, "EOM")]
    [InlineData(DateType.EOQ, "EOQ")]
    [InlineData(DateType.EOY, "EOY")]
    public void ExpandTemplate_DateTypeToken_ExpandsCorrectly(DateType dateType, string expected)
    {
        // Arrange
        var template = "{date_type}";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "db",
            SchemaName: "schema",
            TableName: "table",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: dateType);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that tokens are expanded case-insensitively.
    /// </summary>
    [Fact]
    public void ExpandTemplate_MixedCaseTokens_ExpandsCorrectly()
    {
        // Arrange
        var template = "{DATABASE}/{SCHEMA}/{TABLE}/{YYYY}/{MM}/{DD}/";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "MyDB",
            SchemaName: "dbo",
            TableName: "Orders",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("MyDB/dbo/Orders/2025/01/15/", result);
    }

    /// <summary>
    /// Tests that backslashes are converted to forward slashes.
    /// This ensures blob storage compatibility (forward slash paths).
    /// </summary>
    [Fact]
    public void ExpandTemplate_BackslashesConverted_ToForwardSlashes()
    {
        // Arrange
        var template = "archive\\{schema}\\{table}\\{yyyy}\\{MM}\\{dd}\\";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "db",
            SchemaName: "dbo",
            TableName: "orders",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("archive/dbo/orders/2025/01/15/", result);
    }

    /// <summary>
    /// Tests that leading slashes are trimmed (blob paths are relative).
    /// </summary>
    [Fact]
    public void ExpandTemplate_LeadingSlash_IsTrimmed()
    {
        // Arrange
        var template = "/{schema}/{table}/";
        var context = new ArchivePathTemplateContext(
            DatabaseName: "db",
            SchemaName: "dbo",
            TableName: "orders",
            AsOfDate: new DateOnly(2025, 1, 15),
            DateType: DateType.EOD);

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("dbo/orders/", result);
    }
}

