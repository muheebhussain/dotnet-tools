﻿using Archival.Infrastructure.BlobStorage.Resilience;
using Azure;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Infrastructure.Tests.BlobStorage.Resilience;

/// <summary>
/// Unit tests for AzureStorageResilience resilience policy.
/// Validates retry behavior, cancellation handling, and transient vs non-transient error classification.
/// </summary>
public class AzureStorageResilienceTests
{
    private readonly Mock<ILogger<AzureStorageResilience>> _mockLogger;
    private readonly AzureStorageResilience _resilience;

    public AzureStorageResilienceTests()
    {
        _mockLogger = new Mock<ILogger<AzureStorageResilience>>();
        _resilience = new AzureStorageResilience(_mockLogger.Object);
    }

    [Fact]
    public async Task ExecuteAsync_SucceedsOnFirstAttempt()
    {
        // Arrange
        var operationName = "TestOperation";
        var expectedResult = "success";
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            await Task.CompletedTask;
            return expectedResult;
        };

        // Act
        var result = await _resilience.ExecuteAsync(operation, operationName, CancellationToken.None);

        // Assert
        Assert.Equal(expectedResult, result);
    }

    [Fact]
    public async Task ExecuteAsync_RetriesOn429ThrottleError()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;

            // Fail on first attempt with 429 (throttle), succeed on second
            if (attemptCount == 1)
            {
                throw new RequestFailedException(429, "Too many requests");
            }

            return "success";
        };

        // Act
        var result = await _resilience.ExecuteAsync(operation, operationName, CancellationToken.None);

        // Assert
        Assert.Equal("success", result);
        Assert.Equal(2, attemptCount); // Should have retried
    }

    [Fact]
    public async Task ExecuteAsync_RetriesOn503ServiceUnavailable()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;

            if (attemptCount == 1)
            {
                throw new RequestFailedException(503, "Service unavailable");
            }

            return "success";
        };

        // Act
        var result = await _resilience.ExecuteAsync(operation, operationName, CancellationToken.None);

        // Assert
        Assert.Equal("success", result);
        Assert.Equal(2, attemptCount);
    }

    [Fact]
    public async Task ExecuteAsync_RetriesOn408RequestTimeout()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;

            if (attemptCount == 1)
            {
                throw new RequestFailedException(408, "Request timeout");
            }

            return "success";
        };

        // Act
        var result = await _resilience.ExecuteAsync(operation, operationName, CancellationToken.None);

        // Assert
        Assert.Equal("success", result);
        Assert.Equal(2, attemptCount);
    }

    [Fact]
    public async Task ExecuteAsync_DoesNotRetryOn404NotFound()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;
            throw new RequestFailedException(404, "Not found");
        };

        // Act
        var exception = await Assert.ThrowsAsync<RequestFailedException>(
            () => _resilience.ExecuteAsync(operation, operationName, CancellationToken.None));

        // Assert
        Assert.Equal(404, exception.Status);
        Assert.Equal(1, attemptCount); // Should NOT have retried
    }

    [Fact]
    public async Task ExecuteAsync_DoesNotRetryOn401Unauthorized()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;
            throw new RequestFailedException(401, "Unauthorized");
        };

        // Act
        var exception = await Assert.ThrowsAsync<RequestFailedException>(
            () => _resilience.ExecuteAsync(operation, operationName, CancellationToken.None));

        // Assert
        Assert.Equal(401, exception.Status);
        Assert.Equal(1, attemptCount);
    }

    [Fact]
    public async Task ExecuteAsync_ThrowsOnCancellation()
    {
        // Arrange
        var operationName = "TestOperation";
        var cts = new CancellationTokenSource();
        cts.Cancel();

        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            await Task.CompletedTask;
            return "success";
        };

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _resilience.ExecuteAsync(operation, operationName, cts.Token));
    }

    [Fact]
    public async Task ExecuteAsync_StopsRetryingOnCancellation()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        var cts = new CancellationTokenSource();

        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;

            // Cancel on second attempt
            if (attemptCount == 2)
            {
                cts.Cancel();
            }

            // Always throw transient error to force retry
            throw new RequestFailedException(429, "Too many requests");
        };

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _resilience.ExecuteAsync(operation, operationName, cts.Token));

        // Should have attempted twice (first failed with 429, on retry we canceled)
        Assert.True(attemptCount <= 3, "Should stop retrying after cancellation");
    }

    [Fact]
    public async Task ExecuteAsync_PropagatesNonTransientExceptions()
    {
        // Arrange
        var operationName = "TestOperation";
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            await Task.CompletedTask;
            throw new InvalidOperationException("Custom error");
        };

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _resilience.ExecuteAsync(operation, operationName, CancellationToken.None));

        Assert.Equal("Custom error", exception.Message);
    }

    [Fact]
    public async Task ExecuteAsync_EventuallyFailsAfterMaxRetries()
    {
        // Arrange
        var operationName = "TestOperation";
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            await Task.CompletedTask;
            // Always throw transient error
            throw new RequestFailedException(429, "Too many requests");
        };

        // Act & Assert
        var exception = await Assert.ThrowsAsync<RequestFailedException>(
            () => _resilience.ExecuteAsync(operation, operationName, CancellationToken.None));

        Assert.Equal(429, exception.Status);
    }

    [Fact]
    public async Task ExecuteAsync_HandlesHttpRequestException()
    {
        // Arrange
        var operationName = "TestOperation";
        int attemptCount = 0;
        Func<CancellationToken, Task<string>> operation = async (ct) =>
        {
            attemptCount++;
            await Task.CompletedTask;

            if (attemptCount == 1)
            {
                throw new HttpRequestException("Connection timeout");
            }

            return "success";
        };

        // Act
        var result = await _resilience.ExecuteAsync(operation, operationName, CancellationToken.None);

        // Assert
        Assert.Equal("success", result);
        Assert.Equal(2, attemptCount);
    }

    [Fact]
    public async Task ExecuteAsync_ReturnsGenericTypeCorrectly()
    {
        // Arrange
        var operationName = "TestOperation";
        var expectedValue = new { Name = "Test", Count = 42 };

        Func<CancellationToken, Task<dynamic>> operation = async (ct) =>
        {
            await Task.CompletedTask;
            return expectedValue;
        };

        // Act
        dynamic result = await _resilience.ExecuteAsync<dynamic>(operation, operationName, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
    }
}

