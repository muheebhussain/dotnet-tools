﻿using Archival.Infrastructure.BlobStorage;
using Archival.Infrastructure.BlobStorage.Resilience;
using Azure;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Infrastructure.Tests.BlobStorage;

/// <summary>
/// Unit tests for AzureBlobTierManager with resilience layer.
/// Verifies that tier changes and deletions properly use the resilience policy.
/// </summary>
public class AzureBlobTierManagerResilienceTests
{
    private readonly Mock<IAzureStorageResilience> _mockResilience;
    private readonly Mock<ILogger<AzureBlobTierManager>> _mockLogger;
    private readonly AzureBlobTierManager _tierManager;

    public AzureBlobTierManagerResilienceTests()
    {
        _mockResilience = new Mock<IAzureStorageResilience>();
        _mockLogger = new Mock<ILogger<AzureBlobTierManager>>();
        _tierManager = new AzureBlobTierManager(_mockResilience.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task TrySetColdAsync_ReturnsTrueOnSuccess()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _tierManager.TrySetColdAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.True(result);
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.Is<string>(s => s.Contains("SetBlobCold")),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TrySetColdAsync_HandleTransientFailuresViaResilience()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        // Simulate resilience layer retrying and eventually succeeding
        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _tierManager.TrySetColdAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.True(result);
        // Resilience layer should have been called
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TrySetColdAsync_ReturnsFalseOnBlobNotFound()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "missing-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(404, "Blob not found"));

        // Act
        var result = await _tierManager.TrySetColdAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task TrySetColdAsync_ReturnsFalseOnOtherErrors()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(500, "Internal server error"));

        // Act
        var result = await _tierManager.TrySetColdAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task TrySetArchiveAsync_ReturnsTrueOnSuccess()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _tierManager.TrySetArchiveAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.True(result);
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.Is<string>(s => s.Contains("SetBlobArchive")),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TryDeleteAsync_ReturnsTrueOnSuccess()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _tierManager.TryDeleteAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.True(result);
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.Is<string>(s => s.Contains("DeleteBlob")),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TryDeleteAsync_ReturnsFalseOnBlobNotFound()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "missing-blob";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(404, "Blob not found"));

        // Act
        var result = await _tierManager.TryDeleteAsync(storageConn, containerName, blobName, CancellationToken.None);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task TryOperations_UseUniqueOperationNames()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";

        var capturedOperationNames = new List<string>();
        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Callback<Func<CancellationToken, Task<bool>>, string, CancellationToken>(
                (_, opName, _) => capturedOperationNames.Add(opName))
            .ReturnsAsync(true);

        // Act
        await _tierManager.TrySetColdAsync(storageConn, containerName, "blob1", CancellationToken.None);
        await _tierManager.TrySetColdAsync(storageConn, containerName, "blob2", CancellationToken.None);

        // Assert
        Assert.Equal(2, capturedOperationNames.Count);
        Assert.NotEqual(capturedOperationNames[0], capturedOperationNames[1]);
        Assert.True(capturedOperationNames[0].Contains("blob1"));
        Assert.True(capturedOperationNames[1].Contains("blob2"));
    }

    [Fact]
    public async Task TryOperations_RespectCancellationToken()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var blobName = "test-blob";
        var cts = new CancellationTokenSource();
        cts.Cancel();

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                cts.Token))
            .ThrowsAsync(new OperationCanceledException());

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _tierManager.TrySetColdAsync(storageConn, containerName, blobName, cts.Token));

        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.IsAny<string>(),
            It.Is<CancellationToken>(ct => ct == cts.Token)), Times.Once);
    }
}

