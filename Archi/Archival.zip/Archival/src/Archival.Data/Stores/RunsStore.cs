﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Models;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Stores;

public sealed class RunsStore(ArchivalDbContext db, IClock clock) : IRunsStore
{
    public async Task<RunDto> StartRunAsync(RunType runType, CancellationToken ct)
    {
        var entity = new ArchivalRunEntity
        {
            RunType = runType,
            StartedAt = clock.UtcNow,
            Status = RunStatus.Running
        };

        db.Runs.Add(entity);
        await db.SaveChangesAsync(ct);

        return new RunDto(
            entity.Id,
            runType,
            entity.StartedAt,
            entity.EndedAt,
            entity.Status,
            entity.Note);
    }

    public async Task CompleteRunAsync(long runId, RunStatus status, string? note, CancellationToken ct)
    {
        // Verify run exists
        var exists = await db.Runs.AnyAsync(x => x.Id == runId, ct);
        if (!exists)
            throw new InvalidOperationException($"Run with ID {runId} not found");

        // EF Core 7.0+: ExecuteUpdateAsync for efficient bulk update
        // No entity loading, no change tracking, direct SQL execution
        await db.Runs
            .Where(x => x.Id == runId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(x => x.Status, status)
                .SetProperty(x => x.Note, note)
                .SetProperty(x => x.EndedAt, clock.UtcNow),
                cancellationToken: ct);
    }
}

