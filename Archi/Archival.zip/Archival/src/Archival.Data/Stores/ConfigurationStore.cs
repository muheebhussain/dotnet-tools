﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Validators;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Unified store for all configuration operations (tables, blobs, policies).
/// Consolidates previously separate stores to reduce interface explosion.
/// </summary>
public sealed class ConfigurationStore(IConfigurationRepository configRepo) : IConfigurationStore
{
    // Table Configuration Methods
    public async Task<IReadOnlyList<TableConfigurationDto>> GetActiveTableConfigurationsAsync(CancellationToken ct)
    {
        var configs = await configRepo.GetActiveTableConfigurationsAsync(ct);
        var dtos = configs.Select(c => new TableConfigurationDto(
            c.Id, c.IsActive, c.DatabaseName, c.SchemaName, c.TableName, c.BusinessDateColumnName,
            c.TablePolicyId, c.BlobConfigurationId, c.ArchivePathTemplate, c.DeleteAfterExport, c.BatchDeleteSize))
            .ToList();

        // Validate each configuration
        foreach (var dto in dtos)
        {
            var validationResult = ConfigurationValidator.ValidateTableConfiguration(dto);
            if (!validationResult.Ok)
                throw new InvalidOperationException($"Invalid table configuration (ID={dto.Id}): {validationResult.Error}");
        }

        return dtos;
    }

    public async Task<TableConfigurationDto?> GetTableConfigurationAsync(int id, CancellationToken ct)
    {
        var config = await configRepo.GetTableConfigurationAsync(id, ct);
        if (config is null)
            return null;

        var dto = new TableConfigurationDto(
            config.Id, config.IsActive, config.DatabaseName, config.SchemaName, config.TableName,
            config.BusinessDateColumnName, config.TablePolicyId, config.BlobConfigurationId,
            config.ArchivePathTemplate, config.DeleteAfterExport, config.BatchDeleteSize);

        var validationResult = ConfigurationValidator.ValidateTableConfiguration(dto);
        if (!validationResult.Ok)
            throw new InvalidOperationException($"Invalid table configuration (ID={dto.Id}): {validationResult.Error}");

        return dto;
    }

    // Table Policy Methods
    public async Task<TableRetentionPolicyDto?> GetTableRetentionPolicyAsync(int id, CancellationToken ct)
    {
        var policy = await configRepo.GetTableRetentionPolicyAsync(id, ct);
        return policy is null ? null : new TableRetentionPolicyDto(
            policy.Id, policy.IsActive, policy.KeepLastEod, policy.KeepLastEom, policy.KeepLastEoq, policy.KeepLastEoy);
    }

    // Blob Configuration Methods
    public async Task<IReadOnlyList<BlobConfigurationDto>> GetEnabledBlobConfigurationsAsync(CancellationToken ct)
    {
        var configs = await configRepo.GetEnabledBlobConfigurationsAsync(ct);
        var dtos = configs.Select(c => new BlobConfigurationDto(
            c.Id, c.IsEnabled, c.StorageAccountName, c.ContainerName, c.Prefix, c.IncludePattern, c.ExcludePattern,
            c.BusinessDateSource, c.BlobPolicyId,
            c.IsExternal, c.DatasetPathTemplate, c.BusinessDateFolderFormat, c.BusinessDateFolderDepth))
            .ToList();

        // Validate each configuration
        foreach (var dto in dtos)
        {
            var validationResult = ConfigurationValidator.ValidateBlobConfiguration(dto);
            if (!validationResult.Ok)
                throw new InvalidOperationException($"Invalid blob configuration (ID={dto.Id}): {validationResult.Error}");
        }

        return dtos;
    }

    public async Task<BlobConfigurationDto?> GetBlobConfigurationAsync(int id, CancellationToken ct)
    {
        var configs = await GetEnabledBlobConfigurationsAsync(ct);
        return configs.FirstOrDefault(c => c.Id == id);
    }

    // Blob Policy Methods
    public async Task<LifecyclePolicyDto?> GetLifecyclePolicyAsync(int id, CancellationToken ct)
    {
        var policy = await configRepo.GetLifecyclePolicyAsync(id, ct);
        return policy is null ? null : new LifecyclePolicyDto(
            policy.Id, policy.IsActive, policy.ColdMinAgeDays, policy.ArchiveMinAgeDays, policy.DeleteMinAgeDays);
    }
}

