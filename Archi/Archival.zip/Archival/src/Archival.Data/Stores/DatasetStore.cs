﻿﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.BlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Archival.Data.Stores;

/// <summary>
/// Store for dataset operations.
/// </summary>
public sealed class DatasetStore(
    IRunRepository runRepo,
    ArchivalDbContext db,
    IConfigurationStore configurationStore,
    IBlobDatasetStore blobDatasetStore,
    ILogger<DatasetStore> logger,
    IClock clock) : IDatasetStore
{
    public Task<bool> DatasetExistsAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct) =>
        runRepo.DatasetExistsAsync(tableConfigId, asOfDate, ct);

    public async Task<DatasetDetailDto?> GetDatasetAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct)
    {
        var result = await runRepo.GetDatasetAsync(tableConfigId, asOfDate, ct);
        if (result == null)
            return null;

        var (configId, date, status) = result.Value;
        // Fetch full dataset details including ID for retry scenarios
        var fullDataset = await db.Datasets.AsNoTracking()
            .Where(d => d.TableConfigurationId == tableConfigId && d.AsOfDate == asOfDate)
            .Select(d => new { d.Id, d.AsOfDate, d.StorageAccountName, d.ContainerName, d.BlobPrefix, d.Status })
            .FirstOrDefaultAsync(cancellationToken: ct);

        if (fullDataset is null)
            return null;

        return new DatasetDetailDto(
            fullDataset.Id,
            fullDataset.AsOfDate,
            DateType.EOD,
            fullDataset.StorageAccountName ?? "",
            fullDataset.ContainerName ?? "",
            fullDataset.BlobPrefix ?? "",
            fullDataset.Status);
    }

    /// <summary>
    /// Batch query datasets for multiple dates in one DB call instead of N individual calls.
    /// </summary>
    public async Task<IReadOnlyDictionary<(int TableConfigId, DateOnly AsOfDate), DatasetDetailDto>> GetDatasetsByTableAndDatesAsync(
        int tableConfigId,
        IReadOnlyList<DateOnly> asOfDates,
        CancellationToken ct)
    {
        if (asOfDates.Count == 0)
            return new Dictionary<(int, DateOnly), DatasetDetailDto>();

        var results = await db.Datasets.AsNoTracking()
            .Where(d => d.TableConfigurationId == tableConfigId && asOfDates.Contains(d.AsOfDate))
            .Select(d => new { d.Id, d.TableConfigurationId, d.AsOfDate, d.DateType, d.StorageAccountName, d.ContainerName, d.BlobPrefix, d.Status })
            .ToListAsync(ct);

        var dict = new Dictionary<(int, DateOnly), DatasetDetailDto>();
        foreach (var dataset in results)
        {
            var dto = new DatasetDetailDto(
                dataset.Id,
                dataset.AsOfDate,
                dataset.DateType,
                dataset.StorageAccountName ?? "",
                dataset.ContainerName ?? "",
                dataset.BlobPrefix ?? "",
                dataset.Status);
            dict[(dataset.TableConfigurationId, dataset.AsOfDate)] = dto;
        }

        return dict;
    }

    public Task<long> CreateDatasetAsync(int tableConfigId, DateOnly asOfDate, DateType dateType,
        string storageAccountName, string containerName, string blobPrefix, CancellationToken ct) =>
        runRepo.CreateDatasetAsync(tableConfigId, asOfDate, dateType, storageAccountName, containerName, blobPrefix, ct);

    public Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct) =>
        runRepo.MarkDatasetSucceededAsync(datasetId, partCount, rowCount, totalBytes, ct);

    public Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct) =>
        runRepo.MarkDatasetFailedAsync(datasetId, errorSummary, ct);

    /// <summary>
    /// Mark dataset as succeeded and push internal blob dataset atomically.
    /// Transaction is managed internally. If push fails, entire transaction is rolled back.
    /// </summary>
    public async Task<Result<bool>> MarkDatasetSucceededAndPushBlobDatasetAsync(
        long datasetId,
        int partCount,
        long rowCount,
        long totalBytes,
        int tableConfigurationId,
        DateOnly businessDate,
        string storageAccountName,
        string containerName,
        string blobPrefix,
        CancellationToken ct)
    {
        if (datasetId <= 0)
        {
            var message = $"Invalid datasetId '{datasetId}' for table configuration '{tableConfigurationId}'.";
            logger.LogError("{Message}", message);
            return Result<bool>.Fail(message);
        }

        var strategy = db.Database.CreateExecutionStrategy();
        try
        {
            return await strategy.ExecuteAsync(async () =>
            {
                await using var tx = await db.Database.BeginTransactionAsync(ct);
                try
                {
                    // Mark dataset succeeded (pending, not committed yet)
                    await runRepo.MarkDatasetSucceededAsync(datasetId, partCount, rowCount, totalBytes, ct);
                    logger.LogDebug("Dataset marked succeeded: DatasetId={DatasetId}, Parts={Parts}, Rows={Rows}, Bytes={Bytes}",
                        datasetId, partCount, rowCount, totalBytes);

                    // Push internal blob dataset for lifecycle tracking
                    await PushInternalBlobDatasetAsync(
                        tableConfigurationId,
                        businessDate,
                        storageAccountName,
                        containerName,
                        blobPrefix,
                        datasetId,
                        ct);

                    logger.LogDebug("Internal blob dataset pushed: DatasetId={DatasetId}, TableConfigId={TableConfigId}",
                        datasetId, tableConfigurationId);

                    // Commit transaction (both changes persisted atomically)
                    await tx.CommitAsync(ct);
                    logger.LogDebug("Transaction committed successfully: DatasetId={DatasetId}", datasetId);

                    return Result<bool>.Success(true);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Transaction failed, rolling back: DatasetId={DatasetId}, TableConfigId={TableConfigId}",
                        datasetId, tableConfigurationId);
                    await tx.RollbackAsync(ct);
                    throw;
                }
            });
        }
        catch (Exception ex)
        {
            // Mark dataset as failed due to blob push failure (separate transaction)
            try
            {
                await runRepo.MarkDatasetFailedAsync(
                    datasetId,
                    $"Failed to push internal blob dataset: {ex.Message}",
                    ct);
                logger.LogInformation("Dataset marked failed after transaction rollback: DatasetId={DatasetId}",
                    datasetId);
            }
            catch (Exception markFailedEx)
            {
                logger.LogError(markFailedEx, "Failed to mark dataset as failed after rollback: DatasetId={DatasetId}",
                    datasetId);
            }

            return Result<bool>.Fail($"Internal blob dataset push failed (transaction rolled back): {ex.Message}");
        }
    }

    private async Task PushInternalBlobDatasetAsync(
        int tableConfigurationId,
        DateOnly businessDate,
        string storageAccountName,
        string containerName,
        string blobPrefix,
        long datasetId,
        CancellationToken ct)
    {
        // Get table configuration to access blob configuration
        // This is a simple lookup, should be cached ideally
        var tableConfig = await db.TableConfigurations
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == tableConfigurationId, cancellationToken: ct);

        if (tableConfig?.BlobConfigurationId is null or <= 0)
        {
            logger.LogDebug("Table config {TableConfigId} has no blob configuration, skipping blob dataset push",
                tableConfigurationId);
            return;
        }

        // Load blob configuration
        var blobConfig = await configurationStore.GetBlobConfigurationAsync(tableConfig.BlobConfigurationId, ct);
        if (blobConfig is null)
        {
            logger.LogWarning("Blob configuration {BlobConfigId} not found, skipping blob dataset push",
                tableConfig.BlobConfigurationId);
            return;
        }

        // Load policy for scheduling
        var policy = await configurationStore.GetLifecyclePolicyAsync(blobConfig.BlobPolicyId, ct);
        if (policy is null || !policy.IsActive)
        {
            logger.LogWarning("Blob policy {PolicyId} not found or inactive, skipping blob dataset push",
                blobConfig.BlobPolicyId);
            return;
        }

        // Compute next action
        // Note: Archive support determined at runtime via fallback mechanism
        var (nextAction, nextActionAt) = BlobDatasetScheduler.ComputeNext(
            policy, supportsArchiveTier: true, businessDate, clock.UtcNow);

        // Upsert blob dataset (idempotent)
        var upsertDto = new BlobDatasetUpsertDto(
            BlobConfigurationId: blobConfig.Id,
            SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: businessDate,
            StorageAccountName: storageAccountName,
            ContainerName: containerName,
            BlobPrefix: blobPrefix,
            ArchivalDatasetId: datasetId,
            CurrentTier: BlobTierState.Hot,
            NextAction: nextAction,
            NextActionAt: nextActionAt);

        await blobDatasetStore.UpsertAsync(upsertDto, ct);

        logger.LogInformation("Pushed internal blob dataset: BlobConfigId={BlobConfigId}, DatasetId={DatasetId}, Prefix={Prefix}, NextAction={NextAction}",
            blobConfig.Id, datasetId, blobPrefix, nextAction);
    }
}
