﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Models;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Stores;

public sealed class RunItemsStore(ArchivalDbContext db, IClock clock) : IRunItemsStore
{
    public async Task AddRunItemAsync(
        long runId,
        RunItemType itemType,
        RunItemStatus status,
        int? tableConfigurationId = null,
        DateOnly? asOfDate = null,
        int? blobConfigurationId = null,
        LifecycleAction? action = null,
        long? rowsAffected = null,
        long? bytesAffected = null,
        string? itemKey = null,
        string? error = null,
        CancellationToken ct = default)
    {
        // Check for existing (idempotency)
        bool exists = false;

        if (tableConfigurationId.HasValue && asOfDate.HasValue)
        {
            exists = await db.RunItems.AnyAsync(ri =>
                ri.RunId == runId &&
                ri.ItemType == itemType &&
                ri.TableConfigurationId == tableConfigurationId.Value &&
                ri.AsOfDate == asOfDate.Value,
                ct);
        }
        else if (blobConfigurationId.HasValue && asOfDate.HasValue)
        {
            exists = await db.RunItems.AnyAsync(ri =>
                ri.RunId == runId &&
                ri.ItemType == itemType &&
                ri.BlobConfigurationId == blobConfigurationId.Value &&
                ri.AsOfDate == asOfDate.Value,
                ct);
        }

        if (exists)
            return; // Already exists

        db.RunItems.Add(new ArchivalRunItemEntity
        {
            RunId = runId,
            ItemType = itemType,
            TableConfigurationId = tableConfigurationId,
            AsOfDate = asOfDate,
            BlobConfigurationId = blobConfigurationId,
            ItemKey = itemKey,
            Action = action,
            Status = status,
            RowsAffected = rowsAffected,
            BytesAffected = bytesAffected,
            ErrorMessage = error,
            CreatedAt = clock.UtcNow
        });

        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Phase 5 Optimization: Batch insert multiple run items in one SaveChangesAsync call.
    /// This avoids N per-item database round-trips.
    /// </summary>
    public async Task AddRunItemsBatchAsync(
        long runId,
        IReadOnlyList<RunItemBatchDto> items,
        CancellationToken ct)
    {
        if (items.Count == 0)
            return;

        var entities = new List<ArchivalRunItemEntity>(items.Count);
        foreach (var item in items)
        {
            entities.Add(new ArchivalRunItemEntity
            {
                RunId = runId,
                ItemType = item.ItemType,
                TableConfigurationId = item.TableConfigurationId,
                AsOfDate = item.AsOfDate,
                BlobConfigurationId = item.BlobConfigurationId,
                ItemKey = item.ItemKey,
                Action = item.Action,
                Status = item.Status,
                RowsAffected = item.RowsAffected,
                BytesAffected = item.BytesAffected,
                ErrorMessage = item.Error,
                CreatedAt = clock.UtcNow
            });
        }

        db.RunItems.AddRange(entities);
        await db.SaveChangesAsync(ct);
    }
}
