﻿﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Models;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Archival.Data.Stores;

/// <summary>
/// Store for blob dataset lifecycle tracking and management.
/// Implements idempotent, crash-safe discover-execute pattern.
/// </summary>
public sealed class BlobDatasetStore(ArchivalDbContext db, ILogger<BlobDatasetStore> logger, IClock clock) : IBlobDatasetStore
{
    /// <summary>
    /// Upsert dataset by unique (BlobConfigurationId, AsOfDate).
    /// If dataset exists, it is NOT recreated (idempotent).
    /// DiscoveredAt is set only on first creation.
    /// </summary>
    public async Task UpsertAsync(BlobDatasetUpsertDto dto, CancellationToken ct)
    {
        // Check existence by (BlobConfigurationId, AsOfDate) unique key
        var existing = await db.BlobDatasets
            .FirstOrDefaultAsync(x =>
                x.BlobConfigurationId == dto.BlobConfigurationId &&
                x.AsOfDate == dto.AsOfDate,
                cancellationToken: ct);

        if (existing != null)
        {
            // Dataset already exists. Preserve crash-recovery state, but refresh scheduling for pending rows.
            if (existing.ExecutionStatus == BlobDatasetExecutionStatus.Pending)
            {
                // Only update scheduling fields when new values are available.
                var shouldUpdate = existing.NextAction == BlobDatasetNextAction.None
                    || existing.NextActionAt is null;

                if (shouldUpdate)
                {
                    existing.NextAction = dto.NextAction;
                    existing.NextActionAt = dto.NextActionAt;
                    existing.UpdatedAt = clock.UtcNow;
                    await db.SaveChangesAsync(ct);

                    logger.LogDebug(
                        "BlobDataset scheduling updated: ConfigId={ConfigId}, Date={Date}, NextAction={NextAction}",
                        dto.BlobConfigurationId, dto.AsOfDate, dto.NextAction);
                }
                else
                {
                    logger.LogDebug(
                        "BlobDataset already scheduled: ConfigId={ConfigId}, Date={Date}, NextAction={NextAction}",
                        dto.BlobConfigurationId, dto.AsOfDate, existing.NextAction);
                }
            }
            else
            {
                logger.LogDebug(
                    "BlobDataset already exists (idempotent upsert): ConfigId={ConfigId}, Date={Date}, Status={Status}",
                    dto.BlobConfigurationId, dto.AsOfDate, existing.ExecutionStatus);
            }

            return;
        }

        // Create new record with ExecutionStatus = Pending and DiscoveredAt = now
        var newRecord = new ArchivalBlobDatasetEntity
        {
            BlobConfigurationId = dto.BlobConfigurationId,
            SourceType = dto.SourceType,
            AsOfDate = dto.AsOfDate,
            StorageAccountName = dto.StorageAccountName,
            ContainerName = dto.ContainerName,
            BlobPrefix = dto.BlobPrefix,
            ArchivalDatasetId = dto.ArchivalDatasetId,
            CurrentTier = dto.CurrentTier,
            NextAction = dto.NextAction,
            NextActionAt = dto.NextActionAt,
            IsDeleted = false,
            AttemptCount = 0,
            DiscoveredAt = clock.UtcNow,
            ExecutedAt = null,
            ExecutionStatus = BlobDatasetExecutionStatus.Pending,
            CreatedAt = clock.UtcNow,
            UpdatedAt = clock.UtcNow,
        };
        db.BlobDatasets.Add(newRecord);
        await db.SaveChangesAsync(ct);

        logger.LogDebug(
            "BlobDataset created (idempotent upsert): ConfigId={ConfigId}, Date={Date}, Status=Pending",
            dto.BlobConfigurationId, dto.AsOfDate);
    }

    /// <summary>
    /// Get due datasets that are ready for lifecycle action (by NextActionAt).
    /// Filters to Pending datasets only (those not yet executed).
    /// </summary>
    public async Task<IReadOnlyList<BlobDatasetDto>> GetDueAsync(int blobConfigId, DateTime utcNow, int batchSize, CancellationToken ct)
    {
        var records = await db.BlobDatasets
            .AsNoTracking()
            .Where(x =>
                x.BlobConfigurationId == blobConfigId &&
                !x.IsDeleted &&
                x.ExecutionStatus == BlobDatasetExecutionStatus.Pending &&
                (x.NextActionAt == null || x.NextActionAt <= utcNow))
                // Note: Removed "x.NextAction != BlobDatasetNextAction.None" filter
                // because scheduled datasets with NextAction = None should be included
                // when their NextActionAt date is reached. The handler will recalculate
                // the action for today and execute it.
            .OrderBy(x => x.NextActionAt)
            .Take(batchSize)
            .ToListAsync(cancellationToken: ct);

        return records
            .Select(x => new BlobDatasetDto(
                x.Id,
                x.BlobConfigurationId,
                x.SourceType,
                x.AsOfDate,
                x.StorageAccountName,
                x.ContainerName,
                x.BlobPrefix,
                x.ArchivalDatasetId,
                x.CurrentTier,
                x.NextAction,
                x.NextActionAt,
                x.AttemptCount,
                x.LastError,
                x.ExecutionStatus,
                x.ExecutedAt))
            .ToList();
    }

    /// <summary>
    /// Mark dataset execution result and set ExecutionStatus atomically.
    /// Uses ExecuteUpdateAsync for efficient bulk update without loading entity.
    /// If action succeeded, status = Succeeded and ExecutedAt = now.
    /// If action failed, status = Failed and ExecutedAt = now.
    /// </summary>
    public async Task MarkActionResultAsync(long id, BlobDatasetMarkResultDto dto, CancellationToken ct)
    {
        // NOTE: No existence check needed because:
        // 1. Dataset DTOs come from GetDueAsync which already verified they exist
        // 2. Existence check + ExecuteUpdateAsync causes threading errors in parallel execution
        // 3. If record doesn't exist, ExecuteUpdateAsync safely does nothing
        // 4. Removing the check eliminates "second operation started" errors

        // Determine ExecutionStatus based on action result
        var executionStatus = dto.LastAction == BlobDatasetLastAction.None
            ? BlobDatasetExecutionStatus.Failed
            : BlobDatasetExecutionStatus.Succeeded;

        // Calculate NextActionAt before the update (these values don't depend on current entity state)
        var nextActionAt = dto.NextAttemptAfterMinutes.HasValue && dto.NextAttemptAfterMinutes > 0
            ? dto.LastActionAt.AddMinutes(dto.NextAttemptAfterMinutes.Value)
            : (DateTime?)null;

        // Calculate NextAction - mark complete (None) since we're done with this attempt
        var nextAction = BlobDatasetNextAction.None;

        // EF Core 7.0+: ExecuteUpdateAsync for efficient bulk update
        // No entity loading, no change tracking, direct SQL execution
        // This is thread-safe and eliminates concurrent DbContext issues
        // No AnyAsync check before - this prevents "second operation" threading errors
        await db.BlobDatasets
            .Where(x => x.Id == id)
            .ExecuteUpdateAsync(s => s
                .SetProperty(x => x.LastAction, dto.LastAction)
                .SetProperty(x => x.LastActionAt, dto.LastActionAt)
                .SetProperty(x => x.LastError, dto.LastError)
                .SetProperty(x => x.ExecutionStatus, executionStatus)
                .SetProperty(x => x.ExecutedAt, dto.LastActionAt)
                .SetProperty(x => x.AttemptCount, x => x.AttemptCount + 1)
                .SetProperty(x => x.UpdatedAt, dto.LastActionAt)
                .SetProperty(x => x.NextAction, nextAction)
                .SetProperty(x => x.NextActionAt, nextActionAt),
                cancellationToken: ct);
    }

    public async Task<(int Inserted, int Updated)> UpsertBatchAsync(
        IReadOnlyList<BlobDatasetUpsertDto> dtos,
        CancellationToken ct)
    {
        if (dtos.Count == 0)
            return (0, 0);

        var blobConfigId = dtos[0].BlobConfigurationId;
        var asOfDates = dtos.Select(d => d.AsOfDate).Distinct().ToList();

        // Load existing records for these dates
        var existingRecords = await db.BlobDatasets
            .Where(x => x.BlobConfigurationId == blobConfigId && asOfDates.Contains(x.AsOfDate))
            .ToListAsync(ct);

        var existingByDate = existingRecords
            .ToDictionary(x => x.AsOfDate, x => x);

        int updated = 0;
        int inserted = 0;

        foreach (var dto in dtos)
        {
            if (existingByDate.TryGetValue(dto.AsOfDate, out var existing))
            {
                // Preserve crash-recovery state, but refresh scheduling for pending rows.
                if (existing.ExecutionStatus == BlobDatasetExecutionStatus.Pending)
                {
                    var shouldUpdate = existing.NextAction == BlobDatasetNextAction.None
                        || existing.NextActionAt is null;

                    if (shouldUpdate)
                    {
                        existing.NextAction = dto.NextAction;
                        existing.NextActionAt = dto.NextActionAt;
                        existing.UpdatedAt = clock.UtcNow;
                        updated++;
                    }
                }

                continue;
            }

            var newRecord = new ArchivalBlobDatasetEntity
            {
                BlobConfigurationId = dto.BlobConfigurationId,
                SourceType = dto.SourceType,
                AsOfDate = dto.AsOfDate,
                StorageAccountName = dto.StorageAccountName,
                ContainerName = dto.ContainerName,
                BlobPrefix = dto.BlobPrefix,
                ArchivalDatasetId = dto.ArchivalDatasetId,
                CurrentTier = dto.CurrentTier,
                NextAction = dto.NextAction,
                NextActionAt = dto.NextActionAt,
                IsDeleted = false,
                AttemptCount = 0,
                DiscoveredAt = clock.UtcNow,
                ExecutedAt = null,
                ExecutionStatus = BlobDatasetExecutionStatus.Pending,
                CreatedAt = clock.UtcNow,
                UpdatedAt = clock.UtcNow,
            };

            db.BlobDatasets.Add(newRecord);
            inserted++;
        }

        if (inserted > 0 || updated > 0)
            await db.SaveChangesAsync(ct);

        return (inserted, updated);
    }

    public async Task<DateOnly?> GetMaxAsOfDateAsync(int blobConfigId, CancellationToken ct)
    {
        return await db.BlobDatasets
            .Where(x => x.BlobConfigurationId == blobConfigId)
            .Select(x => (DateOnly?)x.AsOfDate)
            .MaxAsync(ct);
    }

    public async Task MarkActionResultsBatchAsync(IReadOnlyList<BlobDatasetMarkBatchItem> items, CancellationToken ct)
    {
        if (items.Count == 0)
            return;

        var ids = items.Select(i => i.Id).Distinct().ToList();
        var records = await db.BlobDatasets
            .Where(x => ids.Contains(x.Id))
            .ToListAsync(ct);

        var byId = records.ToDictionary(x => x.Id);

        foreach (var item in items)
        {
            if (!byId.TryGetValue(item.Id, out var record))
                continue;

            var dto = item.Result;
            var executionStatus = dto.LastAction == BlobDatasetLastAction.None
                ? BlobDatasetExecutionStatus.Failed
                : BlobDatasetExecutionStatus.Succeeded;

            record.LastAction = dto.LastAction;
            record.LastActionAt = dto.LastActionAt;
            record.LastError = dto.LastError;
            record.ExecutionStatus = executionStatus;
            record.ExecutedAt = dto.LastActionAt;
            record.AttemptCount += 1;
            record.UpdatedAt = dto.LastActionAt;

            if (dto.NextAttemptAfterMinutes.HasValue && dto.NextAttemptAfterMinutes > 0)
            {
                record.NextActionAt = dto.LastActionAt.AddMinutes(dto.NextAttemptAfterMinutes.Value);
            }
            else
            {
                record.NextAction = BlobDatasetNextAction.None;
                record.NextActionAt = null;
            }
        }

        await db.SaveChangesAsync(ct);
    }
}
