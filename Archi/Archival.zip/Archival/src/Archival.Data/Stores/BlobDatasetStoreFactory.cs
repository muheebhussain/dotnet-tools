﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Archival.Data.Stores;

/// <summary>
/// Factory for creating isolated BlobDatasetStore instances with their own DbContext.
/// Ensures thread-safe concurrent operations by giving each thread its own store context.
/// </summary>
public sealed class BlobDatasetStoreFactory(
    IDbContextFactory<ArchivalDbContext> dbContextFactory,
    ILoggerFactory loggerFactory,
    IClock clock) : IBlobDatasetStoreFactory
{
    public IBlobDatasetStore CreateStore()
    {
        // Create a new DbContext for this store
        // This ensures each parallel task has its own isolated context
        var dbContext = dbContextFactory.CreateDbContext();
        var logger = loggerFactory.CreateLogger<BlobDatasetStore>();

        // Return new store with isolated context
        return new BlobDatasetStore(dbContext, logger, clock);
    }
}

