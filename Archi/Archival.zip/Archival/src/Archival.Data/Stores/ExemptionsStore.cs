﻿using Archival.Application.BlobLifecycle;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Results;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Archival.Data.Stores;

/// <summary>
/// Store for exemption operations.
/// Enforces unique constraints at application layer to provide graceful Result handling.
/// </summary>
public sealed class ExemptionsStore(
    ArchivalDbContext db,
    ILogger<ExemptionsStore> logger,
    IClock clock) : IExemptionsStore
{
    public async Task<IReadOnlySet<(int TableConfigurationId, DateOnly AsOfDate)>> GetTableExemptionsAsync(
        int tableConfigurationId, CancellationToken ct)
    {
        var exemptions = await db.TableExemptions
            .AsNoTracking()
            .Where(e => e.TableConfigurationId == tableConfigurationId)
            .Select(e => new { e.TableConfigurationId, e.AsOfDate })
            .ToListAsync(ct);
        return exemptions.Select(e => (e.TableConfigurationId, e.AsOfDate)).ToHashSet();
    }

    /// <summary>
    /// Phase 3 Optimization: Batch query exemptions for multiple tables in one DB call.
    /// Returns dictionary keyed by tableConfigurationId with set of exempted dates.
    /// </summary>
    public async Task<IReadOnlyDictionary<int, IReadOnlySet<DateOnly>>> GetTableExemptionsByTableIdsAsync(
        IReadOnlyList<int> tableConfigurationIds,
        CancellationToken ct)
    {
        if (tableConfigurationIds.Count == 0)
            return new Dictionary<int, IReadOnlySet<DateOnly>>();

        var exemptions = await db.TableExemptions
            .AsNoTracking()
            .Where(e => tableConfigurationIds.Contains(e.TableConfigurationId))
            .Select(e => new { e.TableConfigurationId, e.AsOfDate })
            .ToListAsync(ct);

        var result = new Dictionary<int, IReadOnlySet<DateOnly>>();
        foreach (var tableId in tableConfigurationIds)
        {
            result[tableId] = exemptions
                .Where(e => e.TableConfigurationId == tableId)
                .Select(e => e.AsOfDate)
                .ToHashSet();
        }

        logger.LogDebug("Batch loaded exemptions for {Count} tables: {TotalExemptions} total exemptions",
            tableConfigurationIds.Count, exemptions.Count);

        return result;
    }

    /// <summary>
    /// Get blob exemption matcher with materialized exemptions.
    /// Loads all exemptions for the configuration and builds matcher for efficient checking.
    /// </summary>
    public async Task<BlobExemptionMatcher> GetBlobExemptionMatcherAsync(
        int blobConfigurationId, CancellationToken ct)
    {
        var exemptions = await db.BlobExemptions
            .AsNoTracking()
            .Where(x => x.BlobConfigurationId == blobConfigurationId)
            .Select(x => new { x.ContainerName, x.Prefix, x.AsOfDate })
            .ToListAsync(ct);

        logger.LogDebug("Loaded {Count} blob exemptions for config {ConfigId}",
            exemptions.Count, blobConfigurationId);

        var tuples = exemptions.Select(e => (e.ContainerName, e.Prefix, e.AsOfDate));
        return BlobExemptionMatcher.Create(tuples);
    }

    /// <summary>
    /// Add a table exemption with unique constraint validation.
    /// Returns failure if duplicate already exists instead of throwing exception.
    /// </summary>
    public async Task<Result<bool>> AddTableExemptionAsync(
        int tableConfigurationId,
        DateOnly asOfDate,
        string reason,
        string? createdBy,
        CancellationToken ct)
    {
        try
        {
            // Check for duplicate before attempting insert
            var existing = await db.TableExemptions
                .FirstOrDefaultAsync(x =>
                    x.TableConfigurationId == tableConfigurationId &&
                    x.AsOfDate == asOfDate,
                cancellationToken: ct);

            if (existing != null)
            {
                logger.LogWarning(
                    "Duplicate table exemption attempted: TableConfigId={ConfigId}, AsOfDate={Date}",
                    tableConfigurationId, asOfDate.ToString("yyyy-MM-dd"));

                return Result<bool>.Fail(
                    $"Table exemption already exists for configuration {tableConfigurationId} on date {asOfDate:yyyy-MM-dd}");
            }

            // Insert new exemption
            var entity = new ArchivalTableExemptionEntity
            {
                TableConfigurationId = tableConfigurationId,
                AsOfDate = asOfDate,
                Reason = reason,
                CreatedAt = clock.UtcNow,
                CreatedBy = createdBy
            };

            db.TableExemptions.Add(entity);
            await db.SaveChangesAsync(ct);

            logger.LogInformation(
                "Table exemption created: TableConfigId={ConfigId}, AsOfDate={Date}, CreatedBy={CreatedBy}",
                tableConfigurationId, asOfDate.ToString("yyyy-MM-dd"), createdBy ?? "system");

            return Result<bool>.Success(true);
        }
        catch (DbUpdateException ex) when (ex.InnerException?.Message.Contains("unique") ?? false)
        {
            logger.LogWarning(
                "Unique constraint violation adding table exemption: TableConfigId={ConfigId}, AsOfDate={Date}",
                tableConfigurationId, asOfDate.ToString("yyyy-MM-dd"));

            return Result<bool>.Fail(
                $"Table exemption already exists for configuration {tableConfigurationId} on date {asOfDate:yyyy-MM-dd}");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error adding table exemption: TableConfigId={ConfigId}, AsOfDate={Date}",
                tableConfigurationId, asOfDate.ToString("yyyy-MM-dd"));

            return Result<bool>.Fail($"Failed to add table exemption: {ex.Message}");
        }
    }

    /// <summary>
    /// Add a blob exemption with unique constraint validation.
    /// Returns failure if duplicate already exists instead of throwing exception.
    /// </summary>
    public async Task<Result<bool>> AddBlobExemptionAsync(
        int blobConfigurationId,
        string prefix,
        string? containerName,
        DateOnly asOfDate,
        string reason,
        string? createdBy,
        CancellationToken ct)
    {
        try
        {
            // Normalize prefix for comparison
            var normalizedPrefix = NormalizePrefix(prefix);

            // Check for duplicate before attempting insert
            var existing = await db.BlobExemptions
                .FirstOrDefaultAsync(x =>
                    x.BlobConfigurationId == blobConfigurationId &&
                    x.Prefix == normalizedPrefix &&
                    x.AsOfDate == asOfDate,
                cancellationToken: ct);

            if (existing != null)
            {
                logger.LogWarning(
                    "Duplicate blob exemption attempted: BlobConfigId={ConfigId}, Prefix={Prefix}, AsOfDate={Date}",
                    blobConfigurationId, normalizedPrefix, asOfDate.ToString("yyyy-MM-dd"));

                return Result<bool>.Fail(
                    $"Blob exemption already exists for configuration {blobConfigurationId}, prefix '{normalizedPrefix}' on date {asOfDate:yyyy-MM-dd}");
            }

            // Insert new exemption
            var entity = new ArchivalBlobExemptionEntity
            {
                BlobConfigurationId = blobConfigurationId,
                Prefix = normalizedPrefix,
                ContainerName = containerName!,
                AsOfDate = asOfDate,
                Reason = reason,
                CreatedAt = clock.UtcNow,
                CreatedBy = createdBy
            };

            db.BlobExemptions.Add(entity);
            await db.SaveChangesAsync(ct);

            logger.LogInformation(
                "Blob exemption created: BlobConfigId={ConfigId}, Prefix={Prefix}, AsOfDate={Date}, CreatedBy={CreatedBy}",
                blobConfigurationId, normalizedPrefix, asOfDate.ToString("yyyy-MM-dd"), createdBy ?? "system");

            return Result<bool>.Success(true);
        }
        catch (DbUpdateException ex) when (ex.InnerException?.Message.Contains("unique") ?? false)
        {
            logger.LogWarning(
                "Unique constraint violation adding blob exemption: BlobConfigId={ConfigId}, Prefix={Prefix}, AsOfDate={Date}",
                blobConfigurationId, prefix, asOfDate.ToString("yyyy-MM-dd"));

            return Result<bool>.Fail(
                $"Blob exemption already exists for configuration {blobConfigurationId}, prefix '{prefix}' on date {asOfDate:yyyy-MM-dd}");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error adding blob exemption: BlobConfigId={ConfigId}, Prefix={Prefix}, AsOfDate={Date}",
                blobConfigurationId, prefix, asOfDate.ToString("yyyy-MM-dd"));

            return Result<bool>.Fail($"Failed to add blob exemption: {ex.Message}");
        }
    }

    /// <summary>
    /// Normalize blob prefix by trimming slashes for consistent storage.
    /// </summary>
    private static string NormalizePrefix(string prefix)
    {
        return prefix.Trim('/');
    }
}

