﻿using Archival.Application.Shared.Models;

namespace Archival.Data.Entities;

/// <summary>
/// Entity for tracking blob dataset-level lifecycle state and actions.
/// Supports both internal datasets (from table archives) and external datasets (from discovery).
/// </summary>
public sealed class ArchivalBlobDatasetEntity
{
    public long Id { get; set; }

    public int BlobConfigurationId { get; set; }
    public ArchivalBlobConfigurationEntity BlobConfiguration { get; set; } = null!;

    public BlobDatasetSourceType SourceType { get; set; }
    public DateOnly AsOfDate { get; set; }

    public string StorageAccountName { get; set; } = null!;
    public string ContainerName { get; set; } = null!;
    public string BlobPrefix { get; set; } = null!;

    public long? ArchivalDatasetId { get; set; }
    public ArchivalDatasetEntity? ArchivalDataset { get; set; }

    public BlobTierState CurrentTier { get; set; } = BlobTierState.Unknown;
    public BlobDatasetNextAction NextAction { get; set; } = BlobDatasetNextAction.None;
    public DateTime? NextActionAt { get; set; }

    public bool IsDeleted { get; set; }

    public BlobDatasetLastAction? LastAction { get; set; }
    public DateTime? LastActionAt { get; set; }

    public DateTime DiscoveredAt { get; set; }
    public DateTime? ExecutedAt { get; set; }

    public BlobDatasetExecutionStatus ExecutionStatus { get; set; }

    public int AttemptCount { get; set; }
    public string? LastError { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

