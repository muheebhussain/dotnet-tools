namespace Archival.Data.Entities;

public sealed class ArchivalTableConfigurationEntity
{
    public int Id { get; set; }
    public bool IsActive { get; set; }

    public string DatabaseName { get; set; } = null!;
    public string SchemaName { get; set; } = null!;
    public string TableName { get; set; } = null!;
    public string BusinessDateColumnName { get; set; } = null!;

    public string ArchivePathTemplate { get; set; } = null!;

    public int TablePolicyId { get; set; }
    public ArchivalTablePolicyEntity TablePolicy { get; set; } = null!;

    public int BlobConfigurationId { get; set; }
    public ArchivalBlobConfigurationEntity BlobConfiguration { get; set; } = null!;

    public bool DeleteAfterExport { get; set; } = true;
    public int BatchDeleteSize { get; set; } = 10000;

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    public ICollection<ArchivalTableExemptionEntity> TableExemptions { get; set; } = new List<ArchivalTableExemptionEntity>();
}
