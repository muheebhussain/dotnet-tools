using Archival.Application.Shared.Models;

namespace Archival.Data.Entities;

public sealed class ArchivalRunItemEntity
{
    public long Id { get; set; }
    public long RunId { get; set; }
    public ArchivalRunEntity Run { get; set; } = null!;

    public RunItemType ItemType { get; set; }

    // Structured identity fields (vNext-safe)
    public int? TableConfigurationId { get; set; }
    public DateOnly? AsOfDate { get; set; }
    public int? BlobConfigurationId { get; set; }

    // Optional display/debug field (not for identity)
    public string? ItemKey { get; set; }

    public LifecycleAction? Action { get; set; }  // Nullable (only for blob lifecycle items)
    public RunItemStatus Status { get; set; }
    public long? RowsAffected { get; set; }
    public long? BytesAffected { get; set; }
    public string? ErrorMessage { get; set; }

    public DateTime CreatedAt { get; set; }

    // Navigation properties
    public ArchivalTableConfigurationEntity? TableConfiguration { get; set; }
    public ArchivalBlobConfigurationEntity? BlobConfiguration { get; set; }
}
