using Archival.Application.Shared.Models;
using Archival.Application.Contracts.Time;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Repositories;

public interface IRunRepository
{
    Task<ArchivalRunEntity> StartRunAsync(RunType runType, CancellationToken ct);

    // vNext-safe: Structured identity for run items
    Task AddRunItemAsync(
        long runId,
        RunItemType itemType,
        RunItemStatus status,
        int? tableConfigurationId = null,
        DateOnly? asOfDate = null,
        int? blobConfigurationId = null,
        LifecycleAction? action = null,
        long? rowsAffected = null,
        long? bytesAffected = null,
        string? itemKey = null,
        string? error = null,
        CancellationToken ct = default);

    Task CompleteRunAsync(long runId, RunStatus status, string? note, CancellationToken ct);

    Task<bool> DatasetExistsAsync(int tableConfigurationId, DateOnly asOfDate, CancellationToken ct);
    Task<(int TableConfigId, DateOnly AsOfDate, DatasetStatus Status)?> GetDatasetAsync(int tableConfigurationId, DateOnly asOfDate, CancellationToken ct);
    Task<long> CreateDatasetAsync(int tableConfigurationId, DateOnly asOfDate, DateType dateType, string storageAccountName, string containerName, string blobPrefix, CancellationToken ct);
    Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct);
    Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct);
}

public sealed class RunRepository(ArchivalDbContext db, IClock clock) : IRunRepository
{
    public async Task<ArchivalRunEntity> StartRunAsync(RunType runType, CancellationToken ct)
    {
        var run = new ArchivalRunEntity
        {
            RunType = runType,
            StartedAt = clock.UtcNow,
            Status = RunStatus.Running
        };
        db.Runs.Add(run);
        await db.SaveChangesAsync(ct);
        return run;
    }

    public async Task AddRunItemAsync(
        long runId,
        RunItemType itemType,
        RunItemStatus status,
        int? tableConfigurationId = null,
        DateOnly? asOfDate = null,
        int? blobConfigurationId = null,
        LifecycleAction? action = null,
        long? rowsAffected = null,
        long? bytesAffected = null,
        string? itemKey = null,
        string? error = null,
        CancellationToken ct = default)
    {
        // Check for existing run item (idempotency)
        bool exists = false;

        if (tableConfigurationId.HasValue && asOfDate.HasValue)
        {
            exists = await db.RunItems.AnyAsync(ri =>
                ri.RunId == runId &&
                ri.ItemType == itemType &&
                ri.TableConfigurationId == tableConfigurationId.Value &&
                ri.AsOfDate == asOfDate.Value,
                ct);
        }
        else if (blobConfigurationId.HasValue && asOfDate.HasValue)
        {
            exists = await db.RunItems.AnyAsync(ri =>
                ri.RunId == runId &&
                ri.ItemType == itemType &&
                ri.BlobConfigurationId == blobConfigurationId.Value &&
                ri.AsOfDate == asOfDate.Value,
                ct);
        }

        if (exists)
            return; // Already exists, skip

        db.RunItems.Add(new ArchivalRunItemEntity
        {
            RunId = runId,
            ItemType = itemType,
            TableConfigurationId = tableConfigurationId,
            AsOfDate = asOfDate,
            BlobConfigurationId = blobConfigurationId,
            ItemKey = itemKey,
            Action = action,
            Status = status,
            RowsAffected = rowsAffected,
            BytesAffected = bytesAffected,
            ErrorMessage = error,
            CreatedAt = clock.UtcNow
        });
        await db.SaveChangesAsync(ct);
    }

    public async Task CompleteRunAsync(long runId, RunStatus status, string? note, CancellationToken ct)
    {
        var run = await db.Runs.SingleAsync(r => r.Id == runId, ct);
        run.Status = status;
        run.Note = note;
        run.EndedAt = clock.UtcNow;
        await db.SaveChangesAsync(ct);
    }

    public async Task<bool> DatasetExistsAsync(int tableConfigurationId, DateOnly asOfDate, CancellationToken ct) =>
        await db.Datasets.AsNoTracking().AnyAsync(d => d.TableConfigurationId == tableConfigurationId && d.AsOfDate == asOfDate, ct);

    public async Task<(int TableConfigId, DateOnly AsOfDate, DatasetStatus Status)?> GetDatasetAsync(int tableConfigurationId, DateOnly asOfDate, CancellationToken ct)
    {
        var dataset = await db.Datasets.AsNoTracking()
            .Where(d => d.TableConfigurationId == tableConfigurationId && d.AsOfDate == asOfDate)
            .Select(d => new { d.TableConfigurationId, d.AsOfDate, d.Status })
            .FirstOrDefaultAsync(ct);

        return dataset == null ? null : (dataset.TableConfigurationId, dataset.AsOfDate, dataset.Status);
    }

    public async Task<long> CreateDatasetAsync(int tableConfigurationId, DateOnly asOfDate, DateType dateType, string storageAccountName, string containerName, string blobPrefix, CancellationToken ct)
    {
        var ds = new ArchivalDatasetEntity
        {
            TableConfigurationId = tableConfigurationId,
            AsOfDate = asOfDate,
            DateType = dateType,
            StorageAccountName = storageAccountName,
            ContainerName = containerName,
            BlobPrefix = blobPrefix,
            PartCount = 0,
            Status = DatasetStatus.Pending,
            CreatedAt = clock.UtcNow
        };
        db.Datasets.Add(ds);
        await db.SaveChangesAsync(ct);
        return ds.Id;
    }

    public async Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct)
    {
        // Verify dataset exists
        var exists = await db.Datasets.AnyAsync(x => x.Id == datasetId, ct);
        if (!exists)
            throw new InvalidOperationException($"Dataset '{datasetId}' not found.");

        // EF Core 7.0+: ExecuteUpdateAsync for efficient bulk update
        // No entity loading, no change tracking, direct SQL execution
        await db.Datasets
            .Where(x => x.Id == datasetId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(x => x.PartCount, partCount)
                .SetProperty(x => x.RowCount, rowCount)
                .SetProperty(x => x.TotalBytes, totalBytes)
                .SetProperty(x => x.Status, DatasetStatus.Succeeded)
                .SetProperty(x => x.CompletedAt, clock.UtcNow),
                cancellationToken: ct);
    }

    public async Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct)
    {
        // Verify dataset exists
        var exists = await db.Datasets.AnyAsync(x => x.Id == datasetId, ct);
        if (!exists)
            throw new InvalidOperationException($"Dataset '{datasetId}' not found.");

        // EF Core 7.0+: ExecuteUpdateAsync for efficient bulk update
        // No entity loading, no change tracking, direct SQL execution
        await db.Datasets
            .Where(x => x.Id == datasetId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(x => x.Status, DatasetStatus.Failed)
                .SetProperty(x => x.ErrorSummary, errorSummary)
                .SetProperty(x => x.CompletedAt, clock.UtcNow),
                cancellationToken: ct);
    }
}
