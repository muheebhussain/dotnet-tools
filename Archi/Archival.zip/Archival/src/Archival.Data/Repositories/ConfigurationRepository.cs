using Archival.Application.Configuration;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Repositories;

public interface IConfigurationRepository
{
    Task<IReadOnlyList<TableConfiguration>> GetActiveTableConfigurationsAsync(CancellationToken ct);
    Task<TableConfiguration?> GetTableConfigurationAsync(int id, CancellationToken ct);
    Task<TablePolicy?> GetTableRetentionPolicyAsync(int id, CancellationToken ct);
    Task<BlobPolicy?> GetLifecyclePolicyAsync(int id, CancellationToken ct);
    Task<IReadOnlySet<DateOnly>> GetTableExemptDatesAsync(int tableConfigId, CancellationToken ct);
    Task<IReadOnlyList<BlobConfiguration>> GetEnabledBlobConfigurationsAsync(CancellationToken ct);
}

public sealed class ConfigurationRepository(ArchivalDbContext db) : IConfigurationRepository
{
    public async Task<IReadOnlyList<TableConfiguration>> GetActiveTableConfigurationsAsync(CancellationToken ct)
        => await db.TableConfigurations.AsNoTracking()
            .Where(t => t.IsActive)
            .Select(t => new TableConfiguration(
            t.Id, t.IsActive, t.DatabaseName, t.SchemaName, t.TableName, t.BusinessDateColumnName,
            t.TablePolicyId, t.BlobConfigurationId,
            t.ArchivePathTemplate, t.DeleteAfterExport, t.BatchDeleteSize))
        .ToListAsync(ct);

public async Task<TableConfiguration?> GetTableConfigurationAsync(int id, CancellationToken ct)
    => await db.TableConfigurations.AsNoTracking()
        .Where(t => t.Id == id)
        .Select(t => new TableConfiguration(
            t.Id, t.IsActive, t.DatabaseName, t.SchemaName, t.TableName, t.BusinessDateColumnName,
            t.TablePolicyId, t.BlobConfigurationId,
            t.ArchivePathTemplate, t.DeleteAfterExport, t.BatchDeleteSize))
        .SingleOrDefaultAsync(ct);

    public async Task<TablePolicy?> GetTableRetentionPolicyAsync(int id, CancellationToken ct)
        => await db.TablePolicies.AsNoTracking()
            .Where(p => p.Id == id)
            .Select(p => new TablePolicy(p.Id, p.IsActive, p.KeepLastEod, p.KeepLastEom, p.KeepLastEoq, p.KeepLastEoy))
            .SingleOrDefaultAsync(ct);

    public async Task<BlobPolicy?> GetLifecyclePolicyAsync(int id, CancellationToken ct)
        => await db.BlobPolicies.AsNoTracking()
            .Where(p => p.Id == id)
            .Select(p => new BlobPolicy(
                p.Id, p.IsActive,
                p.ColdMinAgeDays, p.ArchiveMinAgeDays, p.DeleteMinAgeDays))
            .SingleOrDefaultAsync(ct);

    public async Task<IReadOnlySet<DateOnly>> GetTableExemptDatesAsync(int tableConfigId, CancellationToken ct)
    {
        var dates = await db.TableExemptions.AsNoTracking()
            .Where(e => e.TableConfigurationId == tableConfigId)
            .Select(e => e.AsOfDate)
            .ToListAsync(ct);
        return dates.ToHashSet();
    }

    public async Task<IReadOnlyList<BlobConfiguration>> GetEnabledBlobConfigurationsAsync(CancellationToken ct)
        => await db.BlobConfigurations.AsNoTracking()
            .Where(t => t.IsEnabled)
            .Select(t => new BlobConfiguration(
                t.Id, t.IsEnabled, t.StorageAccountName, t.ContainerName, t.Prefix, t.IncludePattern, t.ExcludePattern,
                t.BusinessDateSource, t.BlobPolicyId,
                t.IsExternal, t.DatasetPathTemplate, t.BusinessDateFolderFormat, t.BusinessDateFolderDepth ?? 1))
            .ToListAsync(ct);
}
