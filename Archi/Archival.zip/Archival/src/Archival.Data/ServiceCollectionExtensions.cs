﻿using Archival.Application.Contracts.Persistence;
using Archival.Data.Repositories;
using Archival.Data.Stores;

namespace Archival.Data;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

/// <summary>
/// Extension methods for registering data layer services.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Adds data layer services to the dependency injection container.
    /// </summary>
    public static IServiceCollection AddDataServices(
        this IServiceCollection services,
        string metadataConnection,
        IServiceProvider configurationProvider)
    {
        services.AddDbContext<ArchivalDbContext>(options =>
        {
            options.UseSqlServer(metadataConnection, sqlOptions =>
            {
                sqlOptions.EnableRetryOnFailure(
                    maxRetryCount: 3,
                    maxRetryDelay: TimeSpan.FromSeconds(5),
                    errorNumbersToAdd: null);
            });
        });

        // Add DbContext factory for creating isolated contexts in parallel scenarios
        services.AddDbContextFactory<ArchivalDbContext>(options =>
        {
            options.UseSqlServer(metadataConnection, sqlOptions =>
            {
                sqlOptions.EnableRetryOnFailure(
                    maxRetryCount: 3,
                    maxRetryDelay: TimeSpan.FromSeconds(5),
                    errorNumbersToAdd: null);
            });
        });

        services.AddScoped<IConfigurationRepository, ConfigurationRepository>();
        services.AddScoped<IRunRepository, RunRepository>();

        // Persistence stores
        services.AddScoped<IRunsStore, RunsStore>();
        services.AddScoped<IRunItemsStore, RunItemsStore>();

        // Focused configuration stores (recommended)
        services.AddScoped<IConfigurationStore, ConfigurationStore>();
        services.AddScoped<IExemptionsStore, ExemptionsStore>();
        services.AddScoped<IDatasetStore, DatasetStore>();
        services.AddScoped<IBlobDatasetStore, BlobDatasetStore>();

        // Factory for creating isolated stores for concurrent operations
        services.AddScoped<IBlobDatasetStoreFactory, BlobDatasetStoreFactory>();

        return services;
    }
}

