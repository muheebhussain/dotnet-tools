using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data;

public sealed class ArchivalDbContext(DbContextOptions<ArchivalDbContext> options) : DbContext(options)
{
    public DbSet<ArchivalBlobExemptionEntity> BlobExemptions => Set<ArchivalBlobExemptionEntity>();
    public DbSet<ArchivalTableConfigurationEntity> TableConfigurations => Set<ArchivalTableConfigurationEntity>();
    public DbSet<ArchivalTablePolicyEntity> TablePolicies => Set<ArchivalTablePolicyEntity>();
    public DbSet<ArchivalBlobPolicyEntity> BlobPolicies => Set<ArchivalBlobPolicyEntity>();
    public DbSet<ArchivalBlobConfigurationEntity> BlobConfigurations => Set<ArchivalBlobConfigurationEntity>();
    public DbSet<ArchivalRunEntity> Runs => Set<ArchivalRunEntity>();
    public DbSet<ArchivalRunItemEntity> RunItems => Set<ArchivalRunItemEntity>();
    public DbSet<ArchivalDatasetEntity> Datasets => Set<ArchivalDatasetEntity>();
    public DbSet<ArchivalTableExemptionEntity> TableExemptions => Set<ArchivalTableExemptionEntity>();
    public DbSet<ArchivalBlobDatasetEntity> BlobDatasets => Set<ArchivalBlobDatasetEntity>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        // Table naming (snake_case + archival_ prefix) and keys
        b.Entity<ArchivalTableConfigurationEntity>(e =>
        {
            e.ToTable("archival_table_configuration");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.IsActive).HasColumnName("is_active");
            e.Property(x => x.DatabaseName).HasColumnName("database_name").HasMaxLength(128);
            e.Property(x => x.SchemaName).HasColumnName("schema_name").HasMaxLength(128);
            e.Property(x => x.TableName).HasColumnName("table_name").HasMaxLength(128);
            e.Property(x => x.BusinessDateColumnName).HasColumnName("as_of_date_column").HasMaxLength(128);
            e.Property(x => x.ArchivePathTemplate).HasColumnName("archive_path_template").HasMaxLength(400);
            e.Property(x => x.DeleteAfterExport).HasColumnName("delete_after_export");
            e.Property(x => x.BatchDeleteSize).HasColumnName("batch_delete_size");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by").HasMaxLength(100);

            e.Property(x => x.TablePolicyId).HasColumnName("table_policy_id");
            e.Property(x => x.BlobConfigurationId).HasColumnName("blob_configuration_id");

            e.HasIndex(x => new { x.DatabaseName, x.SchemaName, x.TableName }).IsUnique()
                .HasDatabaseName("uq_archival_table_configuration_table");
        });

        b.Entity<ArchivalTablePolicyEntity>(e =>
        {
            e.ToTable("archival_table_policy");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name").HasMaxLength(200);
            e.Property(x => x.IsActive).HasColumnName("is_active");
            e.Property(x => x.KeepLastEod).HasColumnName("keep_last_eod");
            e.Property(x => x.KeepLastEom).HasColumnName("keep_last_eom");
            e.Property(x => x.KeepLastEoq).HasColumnName("keep_last_eoq");
            e.Property(x => x.KeepLastEoy).HasColumnName("keep_last_eoy");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by").HasMaxLength(100);
        });

        b.Entity<ArchivalBlobPolicyEntity>(e =>
        {
            e.ToTable("archival_blob_policy");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name").HasMaxLength(200);
            e.Property(x => x.IsActive).HasColumnName("is_active");

            e.Property(x => x.ColdMinAgeDays).HasColumnName("cold_min_age_days");
            e.Property(x => x.ArchiveMinAgeDays).HasColumnName("archive_min_age_days");
            e.Property(x => x.DeleteMinAgeDays).HasColumnName("delete_min_age_days");

            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by").HasMaxLength(100);
        });

        b.Entity<ArchivalBlobConfigurationEntity>(e =>
        {
            e.ToTable("archival_blob_configuration");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.IsEnabled).HasColumnName("is_enabled");
            e.Property(x => x.StorageAccountName).HasColumnName("storage_account_name").HasMaxLength(128);
            e.Property(x => x.ContainerName).HasColumnName("container_name").HasMaxLength(128);
            e.Property(x => x.Prefix).HasColumnName("prefix").HasMaxLength(1024);
            e.Property(x => x.IncludePattern).HasColumnName("include_pattern").HasMaxLength(2000);
            e.Property(x => x.ExcludePattern).HasColumnName("exclude_pattern").HasMaxLength(2000);
            e.Property(x => x.BusinessDateSource).HasColumnName("business_date_source").HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.IsExternal).HasColumnName("is_external");
            e.Property(x => x.DatasetPathTemplate).HasColumnName("dataset_path_template").HasMaxLength(1024);
            e.Property(x => x.BusinessDateFolderFormat).HasColumnName("business_date_folder_format").HasMaxLength(50);
            e.Property(x => x.BusinessDateFolderDepth).HasColumnName("business_date_folder_depth").IsRequired(false);
            e.Property(x => x.BlobPolicyId).HasColumnName("blob_policy_id");

            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at");
            e.Property(x => x.UpdatedBy).HasColumnName("updated_by").HasMaxLength(100);
        });

        b.Entity<ArchivalTableExemptionEntity>(e =>
        {
            e.ToTable("archival_table_exemption");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.TableConfigurationId).HasColumnName("table_configuration_id");
            e.Property(x => x.AsOfDate).HasColumnName("as_of_date");
            e.Property(x => x.Reason).HasColumnName("reason").HasMaxLength(4000);
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);

            // Unique constraint: One exemption per (TableConfigId, AsOfDate)
            e.HasIndex(x => new { x.TableConfigurationId, x.AsOfDate }).IsUnique()
                .HasDatabaseName("uq_archival_table_exemption_config_date");
        });

        // Run entity with enum conversions
        b.Entity<ArchivalRunEntity>(e =>
        {
            e.ToTable("archival_run");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.RunType).HasColumnName("run_type").HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.StartedAt).HasColumnName("started_at");
            e.Property(x => x.EndedAt).HasColumnName("ended_at");
            e.Property(x => x.Status).HasColumnName("status").HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.Note).HasColumnName("note").HasMaxLength(4000);
        });

        // RunItem entity with enum conversions and structured identity
        b.Entity<ArchivalRunItemEntity>(e =>
        {
            e.ToTable("archival_run_item");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.RunId).HasColumnName("run_id");
            e.Property(x => x.ItemType).HasColumnName("item_type").HasConversion<string>().HasMaxLength(20);

            // Structured identity columns (vNext-safe)
            e.Property(x => x.TableConfigurationId).HasColumnName("table_configuration_id");
            e.Property(x => x.AsOfDate).HasColumnName("as_of_date");
            e.Property(x => x.BlobConfigurationId).HasColumnName("blob_configuration_id");

            // Optional display/debug field
            e.Property(x => x.ItemKey).HasColumnName("item_key").HasMaxLength(1200);

            e.Property(x => x.Action).HasColumnName("action").HasConversion<string>().HasMaxLength(40);
            e.Property(x => x.Status).HasColumnName("status").HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.RowsAffected).HasColumnName("rows_affected");
            e.Property(x => x.BytesAffected).HasColumnName("bytes_affected");
            e.Property(x => x.ErrorMessage).HasColumnName("error_message");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");

            // Relationships
            e.HasOne(x => x.TableConfiguration).WithMany().HasForeignKey(x => x.TableConfigurationId).OnDelete(DeleteBehavior.NoAction);
            e.HasOne(x => x.BlobConfiguration).WithMany().HasForeignKey(x => x.BlobConfigurationId).OnDelete(DeleteBehavior.NoAction);

            // Unique indexes for idempotency (filtered for non-null values)
            // Note: SQL Server requires filtered indexes for uniqueness with nullable columns
            e.HasIndex(x => new { x.RunId, x.ItemType, x.TableConfigurationId, x.AsOfDate })
                .HasDatabaseName("uq_run_item_table_dataset")
                .IsUnique()
                .HasFilter("[table_configuration_id] IS NOT NULL AND [as_of_date] IS NOT NULL");

            e.HasIndex(x => new { x.RunId, x.ItemType, x.BlobConfigurationId, x.AsOfDate })
                .HasDatabaseName("uq_run_item_blob_date_folder")
                .IsUnique()
                .HasFilter("[blob_configuration_id] IS NOT NULL AND [as_of_date] IS NOT NULL");
        });

        // Dataset entity with enum conversions
        b.Entity<ArchivalDatasetEntity>(e =>
        {
            e.ToTable("archival_dataset");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.TableConfigurationId).HasColumnName("table_configuration_id");
            e.Property(x => x.AsOfDate).HasColumnName("as_of_date");
            e.Property(x => x.DateType).HasColumnName("date_type").HasConversion<string>().HasMaxLength(4);
            e.Property(x => x.StorageAccountName).HasColumnName("storage_account_name").HasMaxLength(128);
            e.Property(x => x.ContainerName).HasColumnName("container_name").HasMaxLength(128);
            e.Property(x => x.BlobPrefix).HasColumnName("blob_prefix").HasMaxLength(1024);
            e.Property(x => x.PartCount).HasColumnName("part_count");
            e.Property(x => x.TotalBytes).HasColumnName("total_bytes");
            e.Property(x => x.RowCount).HasColumnName("row_count");
            e.Property(x => x.Status).HasColumnName("status").HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CompletedAt).HasColumnName("completed_at");
            e.Property(x => x.ErrorSummary).HasColumnName("error_summary");
            e.HasIndex(x => new { x.TableConfigurationId, x.AsOfDate }).IsUnique()
                .HasDatabaseName("uq_archival_dataset_table_date");
            e.HasOne(x => x.TableConfiguration).WithMany().HasForeignKey(x => x.TableConfigurationId);
        });

        b.Entity<ArchivalBlobExemptionEntity>(e =>
        {
            e.ToTable("archival_blob_exemption");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.BlobConfigurationId).HasColumnName("blob_configuration_id");
            e.Property(x => x.AsOfDate).HasColumnName("as_of_date");
            e.Property(x => x.ContainerName).HasColumnName("container_name").HasMaxLength(128);
            e.Property(x => x.Prefix).HasColumnName("prefix").HasMaxLength(1024);
            e.Property(x => x.Reason).HasColumnName("reason").HasMaxLength(4000);
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.CreatedBy).HasColumnName("created_by").HasMaxLength(100);

            // Unique constraint: One exemption per (BlobConfigId, Prefix, AsOfDate)
            e.HasIndex(x => new { x.BlobConfigurationId, x.Prefix, x.AsOfDate }).IsUnique()
                .HasDatabaseName("uq_archival_blob_exemption_config_prefix_date");
        });

        // Blob Dataset entity for tracking blob lifecycle at dataset level
        b.Entity<ArchivalBlobDatasetEntity>(e =>
        {
            e.ToTable("archival_blob_dataset");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.BlobConfigurationId).HasColumnName("blob_configuration_id");
            e.Property(x => x.SourceType).HasColumnName("source_type").HasConversion<int>();
            e.Property(x => x.AsOfDate).HasColumnName("as_of_date");
            e.Property(x => x.StorageAccountName).HasColumnName("storage_account_name").HasMaxLength(128);
            e.Property(x => x.ContainerName).HasColumnName("container_name").HasMaxLength(128);
            e.Property(x => x.BlobPrefix).HasColumnName("blob_prefix").HasMaxLength(2048);
            e.Property(x => x.ArchivalDatasetId).HasColumnName("archival_dataset_id");
            e.Property(x => x.CurrentTier).HasColumnName("current_tier").HasConversion<int>();
            e.Property(x => x.NextAction).HasColumnName("next_action").HasConversion<int>();
            e.Property(x => x.NextActionAt).HasColumnName("next_action_at");
            e.Property(x => x.IsDeleted).HasColumnName("is_deleted");
            e.Property(x => x.LastAction).HasColumnName("last_action").HasConversion<int?>();
            e.Property(x => x.LastActionAt).HasColumnName("last_action_at");
            e.Property(x => x.AttemptCount).HasColumnName("attempt_count");
            e.Property(x => x.LastError).HasColumnName("last_error").HasMaxLength(2000);
            e.Property(x => x.DiscoveredAt).HasColumnName("discovered_at");
            e.Property(x => x.ExecutedAt).HasColumnName("executed_at");
            e.Property(x => x.ExecutionStatus).HasColumnName("execution_status").HasConversion<int>();
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.UpdatedAt).HasColumnName("updated_at");

            // Relationships
            e.HasOne(x => x.BlobConfiguration).WithMany(c => c.BlobDatasets).HasForeignKey(x => x.BlobConfigurationId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ArchivalDataset).WithMany().HasForeignKey(x => x.ArchivalDatasetId).OnDelete(DeleteBehavior.SetNull);

            // UNIQUE index on (BlobConfigurationId, AsOfDate) prevents duplicates on re-discover
            e.HasIndex(x => new { x.BlobConfigurationId, x.AsOfDate }).IsUnique()
                .HasDatabaseName("uq_archival_blob_dataset_config_date");

            // Index on (BlobConfigurationId, ExecutionStatus) for querying pending items
            e.HasIndex(x => new { x.BlobConfigurationId, x.ExecutionStatus })
                .HasDatabaseName("ix_archival_blob_dataset_config_exec_status");

            // Index on (BlobConfigurationId, NextActionAt) for querying due items
            e.HasIndex(x => new { x.BlobConfigurationId, x.NextActionAt })
                .HasDatabaseName("ix_archival_blob_dataset_config_next_action_at");
        });

    }
}
