﻿using Archival.App.Cli;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Archival.App;

/// <summary>
/// Handles command execution for blob lifecycle.
/// Routes to discover/execute/lifecycle handlers based on BlobSubcommand.
/// Supports: discover, execute, lifecycle with --internal, --external, or --all modes.
/// </summary>
public static class BlobCommandHandler
{
    public static async Task<int> ExecuteBlobHandlerAsync(IServiceProvider services, ParsedArgs args, CancellationToken cancellationToken)
    {
        if (args.BlobSubcommand is null)
            return CliErrorHandler.Error("blob command requires subcommand: discover, execute, or lifecycle");

        var subcommand = args.BlobSubcommand;
        var mode = args.BlobMode ?? "all";

        var runsStore = services.GetRequiredService<IRunsStore>();
        long runId = -1;

        try
        {
            // Start a combined run for any blob subcommand
            var run = await runsStore.StartRunAsync(RunType.Lifecycle, cancellationToken);
            runId = run.Id;

            // Route by subcommand
            var result = subcommand switch
            {
                "discover" => await ExecuteDiscoverAsync(services, mode, args.BlobConfigId, cancellationToken),
                "execute" => await ExecuteAsync(services, mode, args.BlobConfigId, cancellationToken),
                "lifecycle" => await ExecuteLifecycleAsync(services, mode, args.BlobConfigId, cancellationToken),
                _ => CliErrorHandler.Error($"Unknown blob subcommand: {subcommand}"),
            };

            var finalStatus = result == ExitCode.Success ? RunStatus.Succeeded : RunStatus.Failed;
            var note = result == ExitCode.Success
                ? $"Blob {subcommand} completed ({mode})"
                : $"Blob {subcommand} failed ({mode})";

            await runsStore.CompleteRunAsync(runId, finalStatus, note, cancellationToken);
            return result;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            if (runId > 0)
                await runsStore.CompleteRunAsync(runId, RunStatus.Failed, "Blob operation cancelled", cancellationToken);

            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.blob")
                .LogInformation("Blob operation cancelled by user");
            return ExitCode.RuntimeError;
        }
        catch (Exception ex)
        {
            if (runId > 0)
            {
                try
                {
                    await runsStore.CompleteRunAsync(runId, RunStatus.Failed, ex.Message, cancellationToken);
                }
                catch
                {
                    // Swallow completion errors to preserve original exception
                }
            }

            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.blob")
                .LogError(ex, "Blob operation failed");
            return ExitCode.RuntimeError;
        }
    }

    private static async Task<int> ExecuteDiscoverAsync(IServiceProvider services, string mode, int? blobConfigId, CancellationToken ct)
    {
        var handler = services.GetRequiredService<Application.Features.BlobLifecycle.DiscoverBlobDatasets.DiscoverBlobDatasetsHandler>();

        // Map mode and blobConfigId to command parameters
        var allTargets = mode == "all" || blobConfigId is null;
        var targetId = blobConfigId;

        var command = new Application.Features.BlobLifecycle.DiscoverBlobDatasets.DiscoverBlobDatasetsCommand(
            AllTargets: allTargets,
            TargetId: targetId,
            BlobMode: mode);
        var result = await handler.HandleAsync(command, ct);
        return result.Ok ? ExitCode.Success : ExitCode.RuntimeError;
    }

    private static async Task<int> ExecuteAsync(IServiceProvider services, string mode, int? blobConfigId, CancellationToken ct)
    {
        var handler = services.GetRequiredService<Application.Features.BlobLifecycle.ExecuteBlobDatasets.ExecuteBlobDatasetsHandler>();

        // Map mode and blobConfigId to command parameters
        var allTargets = mode == "all" || blobConfigId is null;
        var targetId = blobConfigId;

        var command = new Application.Features.BlobLifecycle.ExecuteBlobDatasets.ExecuteBlobDatasetsCommand(
            AllTargets: allTargets,
            TargetId: targetId,
            BlobMode: mode);
        var result = await handler.HandleAsync(command, ct);
        return result.Ok ? ExitCode.Success : ExitCode.RuntimeError;
    }

    private static async Task<int> ExecuteLifecycleAsync(IServiceProvider services, string mode, int? blobConfigId, CancellationToken ct)
    {
        // Lifecycle = discover then execute
        var discoverResult = await ExecuteDiscoverAsync(services, mode, blobConfigId, ct);
        if (discoverResult != ExitCode.Success)
            return discoverResult;

        return await ExecuteAsync(services, mode, blobConfigId, ct);
    }
}
