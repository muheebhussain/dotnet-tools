﻿namespace Archival.App;

/// <summary>
/// Constants for CLI command names.
/// </summary>
public static class Commands
{
    public const string Table = "table";
    public const string Blob = "blob";
    public const string Help = "help";
}

