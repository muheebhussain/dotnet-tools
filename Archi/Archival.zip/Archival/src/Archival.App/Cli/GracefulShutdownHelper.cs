﻿using System.Threading;

namespace Archival.App.Cli;

/// <summary>
/// Helper class for managing graceful shutdown and signal handling.
/// Provides safe cancellation with proper exception handling for disposal edge cases.
/// </summary>
public static class GracefulShutdownHelper
{
    /// <summary>
    /// Registers signal handlers for graceful shutdown (Ctrl+C and SIGTERM).
    /// </summary>
    /// <param name="cancellationTokenSource">The cancellation token source to signal on shutdown.</param>
    public static void RegisterSignalHandlers(CancellationTokenSource cancellationTokenSource)
    {
        // Handle Ctrl+C
        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;  // Don't terminate immediately
            SafeCancel(cancellationTokenSource);
        };

        // Handle SIGTERM (Docker, Kubernetes)
        AppDomain.CurrentDomain.ProcessExit += (_, _) =>
        {
            SafeCancel(cancellationTokenSource);
        };
    }

    /// <summary>
    /// Safely cancels the token source, handling disposal edge cases.
    /// Suppresses ObjectDisposedException which can occur if shutdown is initiated after main completion.
    /// </summary>
    /// <param name="cancellationTokenSource">The cancellation token source to cancel.</param>
    private static void SafeCancel(CancellationTokenSource cancellationTokenSource)
    {
        try
        {
            if (!cancellationTokenSource.IsCancellationRequested)
            {
                cancellationTokenSource.Cancel();
            }
        }
        catch (ObjectDisposedException)
        {
            // Token source may be disposed if shutdown is initiated after main completion.
            // This is expected and safe to ignore.
        }
    }
}

