﻿namespace Archival.App.Cli;

/// <summary>
/// Parses command-line arguments into structured format.
/// Supports:
///   - table [--all-active | --table-config-id ID]
///   - blob discover [--internal | --external | --all] [--blob-config-id ID]
///   - blob execute [--internal | --external | --all] [--blob-config-id ID]
///   - blob lifecycle [--internal | --external | --all] [--blob-config-id ID]
/// </summary>
public static class CliParser
{
    public static ParsedArgs ParseArgs(string[] args)
    {
        if (args.Length == 0)
            return new ParsedArgs { Ok = true };

        var cmd = args[0];
        if (cmd is "help" or "--help" or "-h")
            return new ParsedArgs { Ok = true, Command = "help" };

        if (cmd is not ("table" or "blob"))
            return new ParsedArgs { Ok = false, Error = $"Unknown command: {cmd}" };

        switch (cmd)
        {
            // Table command: table [--all-active | --table-config-id ID]
            case "table":
            {
                string? secrets = null;
                bool allActive = false;
                int? tableId = null;

                for (var i = 1; i < args.Length; i++)
                {
                    var arg = args[i];

                    switch (arg)
                    {
                        case "--secrets-path" when ++i >= args.Length:
                            return new ParsedArgs { Ok = false, Error = "Missing value for --secrets-path" };
                        case "--secrets-path":
                            secrets = args[i];
                            break;
                        case "--all-active":
                            allActive = true;
                            break;
                        case "--table-config-id" when ++i >= args.Length:
                            return new ParsedArgs { Ok = false, Error = "Missing value for --table-config-id" };
                        case "--table-config-id":
                        {
                            if (!int.TryParse(args[i], out int id)) return new ParsedArgs { Ok = false, Error = "Invalid --table-config-id: must be integer" };
                            tableId = id;
                            break;
                        }
                        default:
                            return new ParsedArgs { Ok = false, Error = $"Unknown option for table command: {arg}" };
                    }
                }

                return new ParsedArgs
                {
                    Ok = true,
                    Command = "table",
                    SecretsPath = secrets,
                    AllActive = allActive,
                    TableConfigId = tableId,
                };
            }
            // Blob command: blob <subcommand> [--internal | --external | --all] [--blob-config-id ID]
            case "blob" when args.Length < 2:
                return new ParsedArgs { Ok = false, Error = "blob command requires subcommand: discover, execute, or lifecycle" };
            case "blob":
            {
                var subcommand = args[1];
                if (subcommand is not ("discover" or "execute" or "lifecycle"))
                    return new ParsedArgs { Ok = false, Error = $"Unknown blob subcommand: {subcommand}. Must be discover, execute, or lifecycle" };

                string? secrets = null;
                string? blobMode = null;
                int? blobConfigId = null;

                for (var i = 2; i < args.Length; i++)
                {
                    var arg = args[i];

                    switch (arg)
                    {
                        case "--secrets-path" when ++i >= args.Length:
                            return new ParsedArgs { Ok = false, Error = "Missing value for --secrets-path" };
                        case "--secrets-path":
                            secrets = args[i];
                            break;
                        case "--internal":
                            blobMode = "internal";
                            break;
                        case "--external":
                            blobMode = "external";
                            break;
                        case "--all":
                            blobMode = "all";
                            break;
                        case "--blob-config-id" when ++i >= args.Length:
                            return new ParsedArgs { Ok = false, Error = "Missing value for --blob-config-id" };
                        case "--blob-config-id":
                        {
                            if (!int.TryParse(args[i], out int id)) return new ParsedArgs { Ok = false, Error = "Invalid --blob-config-id: must be integer" };
                            blobConfigId = id;
                            break;
                        }
                        default:
                            return new ParsedArgs { Ok = false, Error = $"Unknown option for blob command: {arg}" };
                    }
                }

                // Default to "all" mode if no mode specified
                blobMode ??= "all";

                return new ParsedArgs
                {
                    Ok = true,
                    Command = "blob",
                    BlobSubcommand = subcommand,
                    BlobMode = blobMode,
                    BlobConfigId = blobConfigId,
                    SecretsPath = secrets,
                };
            }
            default:
                return new ParsedArgs { Ok = false, Error = $"Unknown command: {cmd}" };
        }
    }
}