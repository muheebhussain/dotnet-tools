﻿namespace Archival.App.Cli;

/// <summary>
/// Represents parsed command-line arguments.
/// </summary>
public record struct ParsedArgs
{
    public bool Ok { get; init; }
    public string? Error { get; init; }
    public string? Command { get; init; }
    public string? SecretsPath { get; init; }

    // Table command arguments
    public bool AllActive { get; init; }
    public int? TableConfigId { get; init; }

    // Blob command arguments
    public string? BlobSubcommand { get; init; }  // discover, execute, lifecycle
    public string? BlobMode { get; init; }        // internal, external, all
    public int? BlobConfigId { get; init; }
}