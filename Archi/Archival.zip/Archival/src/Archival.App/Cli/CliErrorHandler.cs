﻿namespace Archival.App.Cli;

/// <summary>
/// Handles CLI error display and validation error responses.
/// </summary>
public static class CliErrorHandler
{
    public static int Error(string message)
    {
        Console.Error.WriteLine($"Error: {message}");
        Console.Error.WriteLine();
        CliHelp.Print();
        return ExitCode.ValidationError;
    }
}

