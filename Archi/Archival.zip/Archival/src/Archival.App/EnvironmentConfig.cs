﻿namespace Archival.App;

/// <summary>
/// Environment configuration values.
/// </summary>
public record class EnvironmentConfig(string MetadataConnection, string SecretsDirectory);