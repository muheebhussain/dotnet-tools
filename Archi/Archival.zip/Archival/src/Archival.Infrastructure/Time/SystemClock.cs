﻿namespace Archival.Infrastructure.Time;

public sealed class SystemClock :
    Archival.Application.Contracts.Time.IClock
{
    public DateTime Now => DateTime.Now;
    public DateTime UtcNow => DateTime.UtcNow;
    public DateOnly Today => DateOnly.FromDateTime(DateTime.Today);
}