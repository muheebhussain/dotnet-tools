﻿using Microsoft.Extensions.Options;

namespace Archival.Infrastructure.Parquet;

/// <summary>
/// Validates ParquetExportOptions configuration on startup.
/// </summary>
public sealed class ParquetExportOptionsValidator : IValidateOptions<ParquetExportOptions>
{
    public ValidateOptionsResult Validate(string? name, ParquetExportOptions options)
    {
        if (options.RowsPerPart <= 0)
        {
            return ValidateOptionsResult.Fail(
                "ParquetExportOptions.RowsPerPart must be greater than 0. " +
                $"Current value: {options.RowsPerPart}");
        }

        if (options.RowGroupTargetBytes <= 0)
        {
            return ValidateOptionsResult.Fail(
                "ParquetExportOptions.RowGroupTargetBytes must be greater than 0. " +
                $"Current value: {options.RowGroupTargetBytes}");
        }

        if (options.SpillThresholdBytes < options.RowGroupTargetBytes)
        {
            return ValidateOptionsResult.Fail(
                "ParquetExportOptions.SpillThresholdBytes must be >= RowGroupTargetBytes. " +
                $"Current values: SpillThreshold={options.SpillThresholdBytes}, " +
                $"RowGroupTarget={options.RowGroupTargetBytes}");
        }

        return ValidateOptionsResult.Success;
    }
}

