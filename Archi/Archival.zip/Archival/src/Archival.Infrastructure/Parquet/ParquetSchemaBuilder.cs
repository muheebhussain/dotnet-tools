﻿using System.Data;
using Parquet.Schema;

namespace Archival.Infrastructure.Parquet;

public interface IParquetSchemaBuilder
{
    (List<DataField> Fields, ParquetSchema Schema) BuildSchema(IDataRecord reader);
}

public sealed class ParquetSchemaBuilder : IParquetSchemaBuilder
{
    public (List<DataField> Fields, ParquetSchema Schema) BuildSchema(IDataRecord reader)
    {
        var fields = new List<DataField>();

        for (var i = 0; i < reader.FieldCount; i++)
        {
            var name = reader.GetName(i);
            var t = reader.GetFieldType(i);

            // Parquet.Net DataField requires CLR type. We'll map common types.
            if (t == typeof(int)) fields.Add(new DataField<int?>(name));
            else if (t == typeof(long)) fields.Add(new DataField<long?>(name));
            else if (t == typeof(decimal)) fields.Add(new DataField<decimal?>(name));
            else if (t == typeof(double)) fields.Add(new DataField<double?>(name));
            else if (t == typeof(float)) fields.Add(new DataField<float?>(name));
            else if (t == typeof(bool)) fields.Add(new DataField<bool?>(name));
            else if (t == typeof(DateTime)) fields.Add(new DataField<DateTime?>(name));
            else if (t == typeof(Guid))
            {
                // Store GUIDs as strings for broad compatibility.
                fields.Add(new DataField<string>(name));
            }
            else if (t == typeof(byte[])) fields.Add(new DataField<byte[]>(name));
            else
            {
                // Default to string
                fields.Add(new DataField<string>(name));
            }
        }

        var schema = new ParquetSchema(fields.ToArray());
        return (fields, schema);
    }
}

