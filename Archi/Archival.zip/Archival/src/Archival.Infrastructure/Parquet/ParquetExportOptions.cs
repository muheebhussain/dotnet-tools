﻿namespace Archival.Infrastructure.Parquet;

public sealed class ParquetExportOptions
{
    public const string SectionName = "ParquetExport";

    public int RowsPerPart { get; init; } = 50_000;
    public long RowGroupTargetBytes { get; init; } = 64L * 1024 * 1024;    // 64 MB
    public long SpillThresholdBytes { get; init; } = 128L * 1024 * 1024;   // 128 MB (must be >= RowGroupTargetBytes)
}

