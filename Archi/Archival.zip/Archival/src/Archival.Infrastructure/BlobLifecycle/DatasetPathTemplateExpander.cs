﻿using Archival.Application.Contracts.BlobLifecycle;
using System.Text.RegularExpressions;

namespace Archival.Infrastructure.BlobLifecycle;

/// <summary>
/// Infrastructure implementation of dataset path template expansion.
/// Replaces tokens like {yyyy}, {MM}, {dd}, {date} with actual date values.
/// </summary>
public sealed class DatasetPathTemplateExpander : IDatasetPathTemplateExpander
{
    private static readonly string[] KnownTokens =
    {
        "{yyyy}", "{MM}", "{dd}", "{date}"
    };

    public void ValidateTemplate(string template)
    {
        if (string.IsNullOrWhiteSpace(template))
            throw new ArgumentException("Dataset path template cannot be empty", nameof(template));

        // Find all tokens in the template
        var tokens = Regex.Matches(template, @"\{([^}]+)\}")
            .Select(m => m.Value.ToLowerInvariant())
            .Distinct()
            .ToList();

        // Check for unknown tokens
        var unknownTokens = tokens.Where(t => !KnownTokens.Contains(t, StringComparer.OrdinalIgnoreCase)).ToList();
        if (unknownTokens.Any())
            throw new ArgumentException($"Unknown tokens in dataset path template: {string.Join(", ", unknownTokens)}. Known tokens: {string.Join(", ", KnownTokens)}");
    }

    public string ExpandTemplate(string template, DatasetPathTemplateContext context)
    {
        ValidateTemplate(template);

        var expanded = template
            .Replace("{yyyy}", context.AsOfDate.Year.ToString("D4"), StringComparison.OrdinalIgnoreCase)
            .Replace("{MM}", context.AsOfDate.Month.ToString("D2"), StringComparison.OrdinalIgnoreCase)
            .Replace("{dd}", context.AsOfDate.Day.ToString("D2"), StringComparison.OrdinalIgnoreCase)
            .Replace("{date}", context.AsOfDate.ToString("yyyy-MM-dd"), StringComparison.OrdinalIgnoreCase);

        // Normalize path separators to forward slash (blob storage standard)
        expanded = expanded.Replace('\\', '/');

        // Trim leading slashes (blob paths are relative)
        expanded = expanded.TrimStart('/');

        return expanded;
    }
}

