﻿using Azure;

namespace Archival.Infrastructure.BlobStorage.Resilience;

/// <summary>
/// Abstraction for executing Azure Storage operations with resilience policies.
/// Handles transient failures (429, 408, 500, 502, 503, 504) with exponential backoff and jitter.
/// Respects cancellation tokens and propagates meaningful error details.
/// </summary>
public interface IAzureStorageResilience
{
    /// <summary>
    /// Executes an Azure Storage operation with exponential backoff retry policy.
    /// Automatically retries on transient failures (429, 408, 500, 502, 503, 504).
    /// Does not retry on permanent failures (404, 401, etc.).
    /// Respects cancellation token; does not retry if cancellation is requested.
    /// </summary>
    /// <typeparam name="T">Return type of the operation</typeparam>
    /// <param name="operation">Async operation that accepts a CancellationToken</param>
    /// <param name="operationName">Name of the operation for logging (e.g., "SetBlobCold", "ListPrefixes")</param>
    /// <param name="ct">Cancellation token; stops retries if requested</param>
    /// <returns>Result of the operation if successful; throws on permanent failures or max retries exceeded</returns>
    /// <exception cref="RequestFailedException">Non-transient Azure errors or max retries exhausted</exception>
    /// <exception cref="OperationCanceledException">If cancellation requested before operation completes</exception>
    Task<T> ExecuteAsync<T>(Func<CancellationToken, Task<T>> operation, string operationName, CancellationToken ct);
}

