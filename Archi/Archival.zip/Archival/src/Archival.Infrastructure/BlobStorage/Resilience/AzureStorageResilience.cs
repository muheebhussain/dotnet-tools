﻿using Azure;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.BlobStorage.Resilience;

/// <summary>
/// Implementation of Azure Storage resilience with exponential backoff and jitter.
/// Handles transient failures (429, 408, 500, 502, 503, 504) without external Polly dependency.
/// Provides manual retry logic suitable for Azure SDK operations.
/// </summary>
public sealed class AzureStorageResilience : IAzureStorageResilience
{
    private readonly ILogger<AzureStorageResilience> _logger;

    /// <summary>
    /// Transient HTTP status codes that should be retried.
    /// Based on Azure SDK recommendations and HTTP standards.
    /// </summary>
    private static readonly int[] TransientStatusCodes = { 408, 429, 500, 502, 503, 504 };

    /// <summary>
    /// Configuration for retry behavior.
    /// </summary>
    private sealed record RetryConfig
    {
        public int MaxRetryAttempts { get; init; } = 6;
        public TimeSpan InitialDelay { get; init; } = TimeSpan.FromMilliseconds(100);
        public double BackoffMultiplier { get; init; } = 2.0;
        public TimeSpan MaxDelay { get; init; } = TimeSpan.FromSeconds(30);
        public TimeSpan TotalTimeout { get; init; } = TimeSpan.FromSeconds(60);
    }

    public AzureStorageResilience(ILogger<AzureStorageResilience> logger)
    {
        _logger = logger;
    }

    public async Task<T> ExecuteAsync<T>(Func<CancellationToken, Task<T>> operation, string operationName, CancellationToken ct)
    {
        if (ct.IsCancellationRequested)
            throw new OperationCanceledException("Cancellation requested before operation started");

        var config = new RetryConfig();
        var totalStopwatch = System.Diagnostics.Stopwatch.StartNew();

        for (int attempt = 1; attempt <= config.MaxRetryAttempts; attempt++)
        {
            // Check if total timeout exceeded
            if (totalStopwatch.Elapsed > config.TotalTimeout)
            {
                _logger.LogError("Operation timeout exceeded (>{TimeoutMs}ms): {OperationName}",
                    config.TotalTimeout.TotalMilliseconds, operationName);
                throw new TimeoutException($"Operation {operationName} exceeded timeout of {config.TotalTimeout.TotalSeconds}s");
            }

            try
            {
                _logger.LogDebug("Starting operation attempt {Attempt}: {OperationName}", attempt, operationName);

                // Create a cancellation token that respects both user CT and total timeout
                using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                var remainingTime = config.TotalTimeout - totalStopwatch.Elapsed;
                if (remainingTime > TimeSpan.Zero)
                {
                    timeoutCts.CancelAfter(remainingTime);
                }

                var result = await operation(timeoutCts.Token);

                _logger.LogDebug("Operation completed successfully on attempt {Attempt}: {OperationName}", attempt, operationName);
                return result;
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                _logger.LogInformation("Operation cancelled by user: {OperationName}", operationName);
                throw;
            }
            catch (RequestFailedException ex)
            {
                // Check if transient
                if (!IsTransient(ex))
                {
                    _logger.LogWarning(ex, "Operation failed with non-transient error (attempt {Attempt}): {OperationName}, Status={Status}",
                        attempt, operationName, ex.Status);
                    throw;
                }

                // Transient error - decide whether to retry
                if (attempt >= config.MaxRetryAttempts)
                {
                    _logger.LogError(ex, "Operation failed with transient error after max retries ({MaxRetries}): {OperationName}, Status={Status}",
                        config.MaxRetryAttempts, operationName, ex.Status);
                    throw;
                }

                // Calculate backoff
                var delayMs = CalculateBackoff(config, attempt);
                _logger.LogDebug("Transient failure (attempt {Attempt}), retrying after {DelayMs}ms: {OperationName}, Status={Status}",
                    attempt, delayMs, operationName, ex.Status);

                // Wait before retry (respecting cancellation)
                try
                {
                    await Task.Delay(delayMs, ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    _logger.LogInformation("Cancellation requested during retry backoff: {OperationName}", operationName);
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Operation failed with unexpected error (attempt {Attempt}): {OperationName}",
                    attempt, operationName);
                throw;
            }
        }

        // Should not reach here
        throw new InvalidOperationException($"Unexpected state in {nameof(ExecuteAsync)}");
    }

    /// <summary>
    /// Calculates exponential backoff with jitter for the given attempt number.
    /// Formula: min(initialDelay * (multiplier ^ (attempt-1)) * jitter, maxDelay)
    /// where jitter is random between 0.5 and 1.5
    /// </summary>
    private static int CalculateBackoff(RetryConfig config, int attemptNumber)
    {
        // Exponential: 100ms, 200ms, 400ms, 800ms, 1600ms, 3200ms (with 2.0x multiplier)
        var exponentialDelayMs = config.InitialDelay.TotalMilliseconds *
                                  Math.Pow(config.BackoffMultiplier, attemptNumber - 1);

        // Add jitter: random between 0.5x and 1.5x
        var jitterFactor = 0.5 + (Random.Shared.NextDouble() * 1.0);
        var withJitterMs = exponentialDelayMs * jitterFactor;

        // Cap at max delay
        var cappedDelayMs = Math.Min(withJitterMs, config.MaxDelay.TotalMilliseconds);

        return (int)cappedDelayMs;
    }

    /// <summary>
    /// Determines if a RequestFailedException represents a transient error that should be retried.
    /// </summary>
    private static bool IsTransient(RequestFailedException ex)
    {
        return TransientStatusCodes.Contains(ex.Status);
    }
}




