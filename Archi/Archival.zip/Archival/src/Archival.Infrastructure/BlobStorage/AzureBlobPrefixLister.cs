﻿using Archival.Application.Contracts.Storage;
using Archival.Infrastructure.BlobStorage.Resilience;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.BlobStorage;

/// <summary>
/// Infrastructure implementation for listing blob folder prefixes using hierarchical listing.
/// Uses resilience policies to handle transient Azure Storage failures.
/// </summary>
public sealed class AzureBlobPrefixLister(
    IAzureStorageResilience resilience,
    ILogger<AzureBlobPrefixLister> logger) : IBlobPrefixLister
{
    public async Task<IReadOnlyList<string>> ListPrefixesAsync(
        string storageConnectionString,
        string containerName,
        string prefix,
        CancellationToken ct)
    {
        var prefixes = new List<string>();

        try
        {
            // Use resilience layer to handle transient failures
            await resilience.ExecuteAsync(
                async (cancellationToken) =>
                {
                    var container = new BlobContainerClient(storageConnectionString, containerName);

                    // Use GetBlobsByHierarchyAsync with delimiter "/" to get only immediate child prefixes
                    await foreach (var item in container.GetBlobsByHierarchyAsync(
                        traits: BlobTraits.None,
                        states: BlobStates.None,
                        delimiter: "/",
                        prefix: prefix,
                        cancellationToken: cancellationToken))
                    {
                        // BlobHierarchyItem can be either a prefix (virtual directory) or a blob
                        // Prefixes are returned with Blob=null; actual blobs have Blob property set
                        if (item.Blob is null)
                        {
                            prefixes.Add(item.Prefix);
                        }
                    }
                    return true;
                },
                $"ListBlobPrefixes:{containerName}/{prefix}",
                ct);

            logger.LogDebug("Listed {Count} prefixes under {Container}/{Prefix}", prefixes.Count, containerName, prefix);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to list blob prefixes: {Container}/{Prefix}", containerName, prefix);
            throw;
        }

        return prefixes;
    }
}

