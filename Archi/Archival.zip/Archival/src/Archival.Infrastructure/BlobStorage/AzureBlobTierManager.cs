﻿using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Infrastructure.BlobStorage.Resilience;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Files.DataLake;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.BlobStorage;

public sealed class AzureBlobTierManager(
    IAzureStorageResilience resilience,
    ILogger<AzureBlobTierManager> logger) : IBlobTierManager
{
    public async Task<bool> TrySetColdAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            await resilience.ExecuteAsync(
                async (cancellationToken) =>
                {
                    var blob = new BlobClient(storageConn, containerName, blobName);
                    await blob.SetAccessTierAsync(AccessTier.Cold, cancellationToken: cancellationToken);
                    return true;
                },
                $"SetBlobCold:{containerName}/{blobName}",
                ct);
            return true;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            // Blob not found is not an error; continue
            logger.LogDebug("Blob not found for tier change: {Container}/{Blob}", containerName, blobName);
            return false;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to set blob cold tier: {Container}/{Blob}", containerName, blobName);
            return false;
        }
    }

    public async Task<bool> TrySetArchiveAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        var (success, _) = await TrySetArchiveWithReasonAsync(storageConn, containerName, blobName, ct);
        return success;
    }

    /// <summary>
    /// Attempts to change a blob's access tier to Archive with failure reason detection.
    /// Returns tuple indicating success and reason for failure (if failed).
    /// Used to determine if fallback to Cold tier should be attempted.
    /// </summary>
    public async Task<(bool Success, ArchiveFailureReason? Reason)> TrySetArchiveWithReasonAsync(
        string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            await resilience.ExecuteAsync(
                async (cancellationToken) =>
                {
                    var blob = new BlobClient(storageConn, containerName, blobName);
                    await blob.SetAccessTierAsync(AccessTier.Archive, cancellationToken: cancellationToken);
                    return true;
                },
                $"SetBlobArchive:{containerName}/{blobName}",
                ct);
            return (true, null);
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            // Blob not found - skip it
            logger.LogDebug("Blob not found for archive tier change: {Container}/{Blob}", containerName, blobName);
            return (false, ArchiveFailureReason.BlobNotFound);
        }
        catch (RequestFailedException ex) when (ex.Status == 400 || ex.Status == 409)
        {
            // Archive tier not supported for this account type (Premium, Legacy, etc.)
            logger.LogWarning(ex, "Archive tier not supported for storage account: {Container}/{Blob}, Status={Status}",
                containerName, blobName, ex.Status);
            return (false, ArchiveFailureReason.NotSupported);
        }
        catch (RequestFailedException ex) when (ex.Status == 403)
        {
            // Permission denied
            logger.LogWarning(ex, "Permission denied for archive tier: {Container}/{Blob}", containerName, blobName);
            return (false, ArchiveFailureReason.PermissionDenied);
        }
        catch (OperationCanceledException ex) when (ct.IsCancellationRequested)
        {
            logger.LogWarning(ex, "Archive operation cancelled: {Container}/{Blob}", containerName, blobName);
            return (false, ArchiveFailureReason.Timeout);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to set blob archive tier: {Container}/{Blob}", containerName, blobName);
            return (false, ArchiveFailureReason.Other);
        }
    }


    public async Task<bool> TryDeleteAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            await resilience.ExecuteAsync(
                async (cancellationToken) =>
                {
                    var blob = new BlobClient(storageConn, containerName, blobName);
                    await blob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, cancellationToken: cancellationToken);
                    return true;
                },
                $"DeleteBlob:{containerName}/{blobName}",
                ct);
            return true;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            logger.LogDebug("Blob not found for deletion: {Container}/{Blob}", containerName, blobName);
            return false;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to delete blob: {Container}/{Blob}", containerName, blobName);
            return false;
        }
    }

    public async Task<Result<DateFolderDeletionResult>> DeleteDateFolderAsync(
        string storageConn,
        string containerName,
        string datePrefix,
        CancellationToken ct)
    {
        try
        {
            logger.LogInformation("Starting date folder deletion: Container={Container}, DatePrefix={DatePrefix}",
                containerName, datePrefix);

            var container = new BlobContainerClient(storageConn, containerName);

            // Step 1: List all blobs under datePrefix
            var blobsToDelete = new List<string>();
            await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: datePrefix, cancellationToken: ct))
            {
                blobsToDelete.Add(item.Name);
            }

            logger.LogInformation("Found {Count} blobs to delete under datePrefix={DatePrefix}",
                blobsToDelete.Count, datePrefix);

            // Step 2: Delete all blobs
            int deletedCount = 0;
            foreach (var blobName in blobsToDelete)
            {
                try
                {
                    await resilience.ExecuteAsync(
                        async (cancellationToken) =>
                        {
                            var blob = container.GetBlobClient(blobName);
                            await blob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, cancellationToken: cancellationToken);
                            return true;
                        },
                        $"DeleteBlob:{containerName}/{blobName}",
                        ct);
                    deletedCount++;
                }
                catch (RequestFailedException ex) when (ex.Status == 404)
                {
                    // Blob already gone, that's fine
                }
                catch (Exception ex)
                {
                    logger.LogWarning(ex, "Failed to delete blob: {BlobName}", blobName);
                }
            }

            logger.LogInformation("Deleted {DeletedCount}/{TotalCount} blobs", deletedCount, blobsToDelete.Count);

            // Step 3: Attempt to delete directory marker blob (exact path with trailing slash)
            bool markerDeleted = false;
            var markerBlobName = datePrefix.TrimEnd('/') + "/";
            try
            {
                var response = await resilience.ExecuteAsync(
                    async (cancellationToken) =>
                    {
                        var markerBlob = container.GetBlobClient(markerBlobName);
                        return await markerBlob.DeleteIfExistsAsync(cancellationToken: cancellationToken);
                    },
                    $"DeleteMarkerBlob:{containerName}/{markerBlobName}",
                    ct);
                markerDeleted = response.Value;

                if (markerDeleted)
                {
                    logger.LogInformation("Directory marker blob deleted: {MarkerBlobName}", markerBlobName);
                }
                else
                {
                    logger.LogDebug("No directory marker blob found: {MarkerBlobName}", markerBlobName);
                }
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Marker blob deletion attempt failed (may not exist): {MarkerBlobName}", markerBlobName);
            }

            // Step 4: Attempt HNS directory deletion (if hierarchical namespace is enabled)
            bool hnsDirectoryDeleted = false;
            bool hnsSupported = false;
            try
            {
                // Try to create DataLake client with same connection string
                var dataLakeServiceClient = new DataLakeServiceClient(storageConn);
                var fileSystem = dataLakeServiceClient.GetFileSystemClient(containerName);

                // Normalize directory path (remove trailing slash for DataLake API)
                var directoryPath = datePrefix.TrimEnd('/');

                var directoryClient = fileSystem.GetDirectoryClient(directoryPath);

                // Check if directory exists and delete it
                var exists = await directoryClient.ExistsAsync(ct);
                if (exists.Value)
                {
                    await directoryClient.DeleteAsync(recursive: true, cancellationToken: ct);
                    hnsDirectoryDeleted = true;
                    hnsSupported = true;
                    logger.LogInformation("HNS directory deleted: {DirectoryPath}", directoryPath);
                }
                else
                {
                    hnsSupported = true; // HNS is supported, but directory doesn't exist (already deleted via blobs)
                    logger.LogDebug("HNS directory does not exist: {DirectoryPath}", directoryPath);
                }
            }
            catch (RequestFailedException ex) when (ex.ErrorCode == "FeatureNotSupported" || ex.ErrorCode == "InvalidUri")
            {
                // HNS not enabled on this account
                hnsSupported = false;
                logger.LogDebug("HNS not supported on this storage account (expected for non-ADLS Gen2)");
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "HNS directory deletion failed: {DatePrefix}", datePrefix);
            }

            // Step 5: Verify no blobs remain under datePrefix
            var remainingCount = 0;
            await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: datePrefix, cancellationToken: ct))
            {
                remainingCount++;
            }

            if (remainingCount > 0)
            {
                logger.LogWarning("Verification failed: {Count} blobs still remain under datePrefix={DatePrefix}",
                    remainingCount, datePrefix);
            }
            else
            {
                logger.LogInformation("Verification passed: No blobs remain under datePrefix={DatePrefix}", datePrefix);
            }

            var result = new DateFolderDeletionResult(
                BlobsDeleted: deletedCount,
                MarkerDeleted: markerDeleted,
                HnsDirectoryDeleted: hnsDirectoryDeleted,
                HnsSupported: hnsSupported);

            return Result<DateFolderDeletionResult>.Success(result);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Date folder deletion failed: Container={Container}, DatePrefix={DatePrefix}",
                containerName, datePrefix);
            return Result<DateFolderDeletionResult>.Fail($"Date folder deletion failed: {ex.Message}");
        }
    }

    public async Task<Result<PrefixDeletionResultDto>> DeletePrefixAndCleanupParentsAsync(
        string storageConn,
        string containerName,
        string datasetPrefix,
        string rootPrefix,
        CancellationToken ct)
    {
        try
        {
            var container = new BlobContainerClient(storageConn, containerName);

            // Step 1: Delete all blobs under datasetPrefix
            var blobsToDelete = new List<string>();
            await foreach (var item in container.GetBlobsAsync(
                               traits: BlobTraits.None,
                               states: BlobStates.None,
                               prefix: datasetPrefix,
                               cancellationToken: ct))
            {
                blobsToDelete.Add(item.Name);
            }

            logger.LogDebug("Found {Count} blobs under prefix {Prefix}", blobsToDelete.Count, datasetPrefix);

            int deletedCount = 0;
            foreach (var blobName in blobsToDelete)
            {
                try
                {
                    var blob = container.GetBlobClient(blobName);
                    await blob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, cancellationToken: ct);
                    deletedCount++;
                }
                catch (Exception ex)
                {
                    logger.LogWarning(ex, "Failed to delete blob: {BlobName}", blobName);
                }
            }

            logger.LogInformation("Deleted {DeletedCount}/{TotalCount} blobs under prefix {Prefix}",
                deletedCount, blobsToDelete.Count, datasetPrefix);

            // Step 2: Delete marker blob (folder marker with trailing slash)
            bool markerDeleted = false;
            var markerBlobName = datasetPrefix.TrimEnd('/') + "/";
            try
            {
                var markerBlob = container.GetBlobClient(markerBlobName);
                var response = await markerBlob.DeleteIfExistsAsync(cancellationToken: ct);
                markerDeleted = response.Value;
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Marker blob deletion attempt failed: {MarkerBlobName}", markerBlobName);
            }

            // Step 3: Delete HNS directory and cleanup parents
            bool hnsDirectoryDeleted = false;
            bool hnsSupported = false;
            int parentDirectoriesDeleted = 0;

            try
            {
                var dataLakeServiceClient = new DataLakeServiceClient(storageConn);
                var fileSystem = dataLakeServiceClient.GetFileSystemClient(containerName);
                hnsSupported = true;

                // Delete the dataset prefix directory
                var directoryPath = datasetPrefix.TrimEnd('/');
                var directoryClient = fileSystem.GetDirectoryClient(directoryPath);

                var exists = await directoryClient.ExistsAsync(ct);
                if (exists.Value)
                {
                    await directoryClient.DeleteAsync(recursive: true, cancellationToken: ct);
                    hnsDirectoryDeleted = true;
                    logger.LogInformation("HNS directory deleted: {DirectoryPath}", directoryPath);
                }

                // Step 4: Cleanup empty parent directories up to rootPrefix boundary
                var currentDir = GetParentDirectory(directoryPath);

                while (!string.IsNullOrEmpty(currentDir) && IsWithinRootBoundary(currentDir, rootPrefix))
                {
                    var parentDirClient = fileSystem.GetDirectoryClient(currentDir);

                    try
                    {
                        var parentExists = await parentDirClient.ExistsAsync(ct);
                        if (!parentExists.Value)
                        {
                            currentDir = GetParentDirectory(currentDir);
                            continue;
                        }

                        // Try to delete the directory
                        try
                        {
                            await parentDirClient.DeleteAsync(recursive: false, cancellationToken: ct);
                            parentDirectoriesDeleted++;
                            logger.LogDebug("Empty parent directory deleted: {DirectoryPath}", currentDir);
                            currentDir = GetParentDirectory(currentDir);
                        }
                        catch (RequestFailedException ex) when (ex.Status == 409)
                        {
                            logger.LogDebug("Parent directory {DirectoryPath} is not empty, stopping cleanup", currentDir);
                            break;
                        }
                        catch (RequestFailedException ex) when (ex.Status == 404)
                        {
                            currentDir = GetParentDirectory(currentDir);
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.LogWarning(ex, "Error processing parent directory: {DirectoryPath}", currentDir);
                        break;
                    }
                }
            }
            catch (RequestFailedException ex) when (ex.ErrorCode == "FeatureNotSupported" || ex.ErrorCode == "InvalidUri")
            {
                hnsSupported = false;
                logger.LogDebug("HNS not supported on this storage account");
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "HNS cleanup failed for prefix: {DatasetPrefix}", datasetPrefix);
            }

            var result = new PrefixDeletionResultDto(
                BlobsDeleted: deletedCount,
                MarkerDeleted: markerDeleted,
                HnsDirectoryDeleted: hnsDirectoryDeleted,
                ParentDirectoriesDeleted: parentDirectoriesDeleted,
                HnsSupported: hnsSupported);

            return Result<PrefixDeletionResultDto>.Success(result);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Prefix deletion with cleanup failed: Container={Container}, DatasetPrefix={DatasetPrefix}, RootPrefix={RootPrefix}",
                containerName, datasetPrefix, rootPrefix);
            return Result<PrefixDeletionResultDto>.Fail($"Prefix deletion with cleanup failed: {ex.Message}");
        }
    }

    private static string GetParentDirectory(string path)
    {
        path = path.TrimEnd('/');
        int lastSlash = path.LastIndexOf('/');
        if (lastSlash < 0)
            return string.Empty;
        return path[..lastSlash];
    }

    /// <summary>
    /// Normalizes a path by trimming leading/trailing slashes and ensuring consistent format.
    /// </summary>
    private static string NormalizePath(string path)
    {
        if (string.IsNullOrEmpty(path))
            return string.Empty;

        return path.Trim('/');
    }

    /// <summary>
    /// Checks if a path is within the boundary of a root prefix using segment-based comparison.
    /// This prevents false positives like "data" matching "dat" or "file-output" matching "file".
    /// </summary>
    /// <param name="path">The path to check (e.g., "file-output/modules/sgas/2026/02")</param>
    /// <param name="rootPrefix">The root prefix boundary (e.g., "file-output/modules/sgas")</param>
    /// <returns>True if path is within the root prefix boundary</returns>
    private static bool IsWithinRootBoundary(string path, string rootPrefix)
    {
        // Normalize both paths
        var normalizedPath = NormalizePath(path);
        var normalizedRoot = NormalizePath(rootPrefix);

        // Empty root means no boundary (shouldn't happen, but handle defensively)
        if (string.IsNullOrEmpty(normalizedRoot))
            return false;

        // Path must be at least as long as root
        if (normalizedPath.Length < normalizedRoot.Length)
            return false;

        // Split into segments for accurate comparison
        var pathSegments = normalizedPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        var rootSegments = normalizedRoot.Split('/', StringSplitOptions.RemoveEmptyEntries);

        // Path must have at least as many segments as root
        if (pathSegments.Length < rootSegments.Length)
            return false;

        // Compare each segment
        for (int i = 0; i < rootSegments.Length; i++)
        {
            if (!pathSegments[i].Equals(rootSegments[i], StringComparison.Ordinal))
                return false;
        }

        // Path is within boundary if all root segments match
        return true;
    }
}