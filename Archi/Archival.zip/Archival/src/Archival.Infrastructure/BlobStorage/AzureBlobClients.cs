using System.Runtime.CompilerServices;
using Archival.Application.Contracts.Infrastructure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using AppBlobItem = Archival.Application.Shared.Models.BlobItem;

namespace Archival.Infrastructure.BlobStorage;

public sealed class AzureBlobLister : IBlobLister
{
    public async IAsyncEnumerable<AppBlobItem> ListBlobsAsync(
        string storageConn,
        string containerName,
        string prefix,
        [EnumeratorCancellation] CancellationToken ct)
    {
        var container = new BlobContainerClient(storageConn, containerName);

        await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: prefix, cancellationToken: ct))
        {
            var props = item.Properties;

            // CreatedOn isn't always available; we fall back to LastModified (your rule).
            var created = props.CreatedOn?.UtcDateTime ?? props.LastModified?.UtcDateTime ?? DateTime.UtcNow;
            var lastMod = props.LastModified?.UtcDateTime ?? created;

            yield return new AppBlobItem(
                Name: item.Name,
                ContentLength: props.ContentLength,
                CreatedAt: created,
                LastModified: lastMod,
                AccessTier: props.AccessTier?.ToString()
            );
        }
    }
}