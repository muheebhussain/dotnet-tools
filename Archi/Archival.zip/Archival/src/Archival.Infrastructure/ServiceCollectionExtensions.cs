﻿using Archival.Infrastructure.BlobStorage;
using Archival.Infrastructure.BlobStorage.Resilience;
using Microsoft.Extensions.Options;
using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Contracts.Tables;
using Archival.Infrastructure.Parquet;
using Archival.Infrastructure.SqlServer;
using Microsoft.Extensions.DependencyInjection;

namespace Archival.Infrastructure;
/// <summary>
/// Extension methods for registering infrastructure layer services.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Adds infrastructure layer services to the dependency injection container.
    /// </summary>
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, string? secretsDirectory = null)
    {
        // Core infrastructure
        services.AddSingleton<Archival.Application.Contracts.Time.IClock, Time.SystemClock>();

        var secretsDir = secretsDirectory ?? "/secrets/";
        services.AddSingleton<Archival.Application.Contracts.Configuration.IConnectionStringResolver>(
            new Secrets.ConnectionStringResolver(secretsDir));

        // Resilience layer for Azure Storage operations
        services.AddScoped<IAzureStorageResilience, AzureStorageResilience>();

        // Storage contracts
        services.AddScoped<Application.Contracts.Storage.IBlobInventory, AzureBlobInventory>();
        services.AddScoped<Application.Contracts.Storage.IBlobLifecycleExecutor, AzureBlobLifecycleExecutor>();
        services.AddScoped<Application.Contracts.Storage.IBlobPrefixLister, AzureBlobPrefixLister>();

        // Table contracts
        services.AddScoped<Archival.Application.Contracts.Tables.ITableArchiver, Tables.SqlTableArchiver>();

        // Retention contracts
        services.AddScoped<Archival.Application.Contracts.Retention.IRetentionCalculator, Retention.RetentionService>();

        // SQL Server adapters (interfaces from Contracts.Infrastructure)
        services.AddScoped<IBusinessCalendar, SqlServerBusinessCalendar>();
        services.AddScoped<IPresentDateFinder, SqlServerPresentDateFinder>();
        services.AddScoped<IArchivalExporter, SqlServerArchivalExporter>();
        services.AddScoped<ISourceDeleter, SqlServerSourceDeleter>();

        // Parquet processors
        services.AddScoped<IParquetSchemaBuilder, ParquetSchemaBuilder>();
        services.AddScoped<IParquetPartWriter, ParquetPartWriter>();
        services.AddScoped<IArchivePathTemplateExpander, ArchivePathTemplateExpander>();

        // Blob utilities
        services.AddScoped<BlobBusinessDateExtractor>();
        services.AddScoped<IBlobBusinessDateExtractor, BlobBusinessDateExtractor>();
        services.AddScoped<AzureBlobTierManager>();  // Register concrete class for direct injection
        services.AddScoped<IBlobTierManager>(sp => sp.GetRequiredService<AzureBlobTierManager>());  // Also register as interface
        services.AddScoped<IBlobLister, AzureBlobLister>();
        services.AddScoped<Application.Contracts.Storage.IBlobPrefixLister, AzureBlobPrefixLister>();
        services.AddScoped<Application.Contracts.BlobLifecycle.IDatasetPathTemplateExpander, BlobLifecycle.DatasetPathTemplateExpander>();

        // Configuration validators and options
        services.AddOptions<ParquetExportOptions>()
            .BindConfiguration(ParquetExportOptions.SectionName)
            .ValidateOnStart();
        services.AddSingleton<IValidateOptions<ParquetExportOptions>, ParquetExportOptionsValidator>();

        return services;
    }
}

