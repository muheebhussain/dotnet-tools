using Archival.Application.Shared.Models;
using Archival.Application.Contracts.Infrastructure;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System.Data;

namespace Archival.Infrastructure.SqlServer;

internal static class SqlDateParameters
{
    internal static SqlParameter CreateDateParam(string name, DateOnly value)
    {
        var date = new DateTime(value.Year, value.Month, value.Day);
        return new SqlParameter(name, SqlDbType.Date) { Value = date };
    }
}

public sealed class SqlServerBusinessCalendar(ILogger<SqlServerBusinessCalendar> logger) : IBusinessCalendar
{
    public async Task<IReadOnlyList<ClassifiedBusinessDate>> GetClassifiedDatesAsync(string sourceDbConn, DateOnly from, DateOnly to, CancellationToken ct)
    {
        // Inclusive range for dates.
        var sql = @"
SELECT date_type, current_business_date
FROM dbo.v_business_date_classification
WHERE current_business_date >= @from AND current_business_date < @to
ORDER BY current_business_date;
";
        await using var conn = new SqlConnection(sourceDbConn);
        await conn.OpenAsync(ct);

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(SqlDateParameters.CreateDateParam("@from", from));
        cmd.Parameters.Add(SqlDateParameters.CreateDateParam("@to", to));

        var list = new List<ClassifiedBusinessDate>();
        await using var reader = await cmd.ExecuteReaderAsync(ct);

        while (await reader.ReadAsync(ct))
        {
            var dt = reader.GetString(0);
            var date = reader.GetDateTime(1);
            var dateOnly = DateOnly.FromDateTime(date);

            var type = dt switch
            {
                "EOY" => DateType.EOY,
                "EOQ" => DateType.EOQ,
                "EOM" => DateType.EOM,
                "EOD" => DateType.EOD,
                _ => throw new InvalidOperationException($"Unknown business date type '{dt}' returned from v_business_date_classification for date {dateOnly}. Expected one of: EOY, EOQ, EOM, EOD")
            };

            // Log classified dates
            logger.LogDebug("Classified business date {Date}: {DateType}", dateOnly, type);

            list.Add(new ClassifiedBusinessDate(new BusinessDate(dateOnly), type));
        }

        return list;
    }
}

public sealed class SqlServerPresentDateFinder : IPresentDateFinder
{
    public async Task<IReadOnlyList<BusinessDate>> GetPresentBusinessDatesAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        DateOnly from,
        DateOnly to,
        CancellationToken ct)
    {
        // Join business_date to target table on date-truncated datetime.
        // Assumption: business_date.current_business_date is midnight or comparable.
        var fullTable = $"[{schemaName}].[{tableName}]";
        var col = $"[{businessDateColumnName}]";

        var sql = $@"
SELECT DISTINCT CAST(t.{col} AS date) AS as_of_date
FROM {fullTable} t
JOIN dbo.business_date bd
  ON CAST(t.{col} AS date) = CAST(bd.current_business_date AS date)
WHERE t.{col} >= @from AND t.{col} < @to
ORDER BY as_of_date;
";

        await using var conn = new SqlConnection(sourceDbConn);
        await conn.OpenAsync(ct);

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(SqlDateParameters.CreateDateParam("@from", from));
        cmd.Parameters.Add(SqlDateParameters.CreateDateParam("@to", to));

        var list = new List<BusinessDate>();
        await using var reader = await cmd.ExecuteReaderAsync(ct);

        while (await reader.ReadAsync(ct))
        {
            var date = reader.GetDateTime(0);
            list.Add(new BusinessDate(DateOnly.FromDateTime(date)));
        }
        return list;
    }
}
