﻿using Archival.Application.Contracts.Retention;
using Archival.Application.Contracts.Time;
using Archival.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.Retention;

/// <summary>
/// Calculates retention dates based on table retention policy.
/// </summary>
public sealed class RetentionService(ArchivalDbContext db, IClock clock, ILogger<RetentionService> log)
    : IRetentionCalculator
{
    public async Task<IReadOnlySet<DateOnly>> CalculateKeepDatesAsync(
        int tableConfigurationId,
        IReadOnlyList<DateOnly> presentDates,
        CancellationToken ct)
    {
        const string sql = @"
DECLARE @today DATE = @p_today;

DECLARE @keep_eod INT, @keep_eom INT, @keep_eoq INT, @keep_eoy INT;

SELECT
  @keep_eod = ISNULL(trp.keep_last_eod, 0),
  @keep_eom = ISNULL(trp.keep_last_eom, 0),
  @keep_eoq = ISNULL(trp.keep_last_eoq, 0),
  @keep_eoy = ISNULL(trp.keep_last_eoy, 0)
FROM dbo.archival_table_configuration tc
LEFT JOIN dbo.archival_table_policy trp
  ON trp.id = tc.table_policy_id
WHERE tc.id = @p_tcid;

WITH
k_eod AS (
  SELECT TOP (ISNULL(@keep_eod, 0)) current_business_date AS d
  FROM dbo.v_business_date_classification
  WHERE date_type = 'EOD' AND current_business_date <= @today
  ORDER BY current_business_date DESC
),
k_eom AS (
  SELECT TOP (ISNULL(@keep_eom, 0)) current_business_date AS d
  FROM dbo.v_business_date_classification
  WHERE date_type = 'EOM' AND current_business_date <= @today
  ORDER BY current_business_date DESC
),
k_eoq AS (
  SELECT TOP (ISNULL(@keep_eoq, 0)) current_business_date AS d
  FROM dbo.v_business_date_classification
  WHERE date_type = 'EOQ' AND current_business_date <= @today
  ORDER BY current_business_date DESC
),
k_eoy AS (
  SELECT TOP (ISNULL(@keep_eoy, 0)) current_business_date AS d
  FROM dbo.v_business_date_classification
  WHERE date_type = 'EOY' AND current_business_date <= @today
  ORDER BY current_business_date DESC
),
keep_base AS (
  SELECT d FROM k_eod
  UNION SELECT d FROM k_eom
  UNION SELECT d FROM k_eoq
  UNION SELECT d FROM k_eoy
),
table_exempt AS (
  SELECT DISTINCT x.as_of_date AS d
  FROM dbo.archival_table_exemption x
  WHERE x.table_configuration_id = @p_tcid
),
keep_set AS (
  SELECT d FROM keep_base
  UNION
  SELECT d FROM table_exempt
)
SELECT CAST(d AS DATE) AS keep_date
FROM keep_set;
";

        var today = DateOnly.FromDateTime(clock.UtcNow);
        var connStr = db.Database.GetDbConnection().ConnectionString ?? throw new InvalidOperationException("DbContext connection string not configured.");

        await using var conn = new SqlConnection(connStr);
        if (conn.State == System.Data.ConnectionState.Closed)
            await conn.OpenAsync(ct).ConfigureAwait(false);

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;

        cmd.Parameters.Add(new SqlParameter("@p_today", System.Data.SqlDbType.Date) { Value = today.ToDateTime(TimeOnly.MinValue) });
        cmd.Parameters.Add(new SqlParameter("@p_tcid", System.Data.SqlDbType.Int) { Value = tableConfigurationId });

        var result = new List<DateOnly>();
        await using var reader = await cmd.ExecuteReaderAsync(ct).ConfigureAwait(false);
        while (await reader.ReadAsync(ct).ConfigureAwait(false))
        {
            var dt = reader.GetFieldValue<DateTime>(0);
            result.Add(DateOnly.FromDateTime(dt));
        }

        var distinct = result.Distinct().ToArray();
        log.LogInformation("Keep set for table_config_id={TableConfigId}: {Count} dates", tableConfigurationId, distinct.Length);
        return distinct.ToHashSet();
    }

    /// <summary>
    /// Phase 4 Optimization: Calculate retention for multiple tables in one batch.
    /// </summary>
    public async Task<IReadOnlyDictionary<int, IReadOnlySet<DateOnly>>> CalculateKeepDatesForMultipleAsync(
        IReadOnlyList<int> tableConfigurationIds,
        IReadOnlyDictionary<int, IReadOnlyList<DateOnly>> presentDatesByTableId,
        CancellationToken ct)
    {
        if (tableConfigurationIds.Count == 0)
            return new Dictionary<int, IReadOnlySet<DateOnly>>();

        var result = new Dictionary<int, IReadOnlySet<DateOnly>>();

        // For each table, calculate keep dates using the existing method
        // This could be optimized further with a single SQL batch query in the future
        foreach (var tableConfigId in tableConfigurationIds)
        {
            if (presentDatesByTableId.TryGetValue(tableConfigId, out var presentDates))
            {
                var keepSet = await CalculateKeepDatesAsync(tableConfigId, presentDates, ct);
                result[tableConfigId] = keepSet;
            }
        }

        log.LogInformation("Phase 4: Batch calculated retention for {Count} tables", tableConfigurationIds.Count);
        return result;
    }
}
