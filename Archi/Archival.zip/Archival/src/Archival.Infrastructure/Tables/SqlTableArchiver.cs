﻿using Archival.Application.Shared.Models;
using Archival.Application.Contracts.Tables;
using Archival.Application.Contracts.Infrastructure;

namespace Archival.Infrastructure.Tables;

public sealed class SqlTableArchiver(
    IPresentDateFinder presentDateFinder,
    IArchivalExporter exporter,
    ISourceDeleter deleter) : ITableArchiver
{
    public async Task<IReadOnlyList<DateOnly>> GetPresentDatesAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken ct)
    {
        var from = DateOnly.FromDateTime(fromDate);
        var to = DateOnly.FromDateTime(toDate);

        var businessDates = await presentDateFinder.GetPresentBusinessDatesAsync(
            connectionString, schemaName, tableName, asOfDateColumn, from, to, ct);

        return businessDates.Select(bd => bd.Value).ToList();
    }

    public async Task<Application.Shared.Results.Result<ExportResultDto>> ExportToParquetAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateOnly businessDate,
        string storageConnectionString,
        string containerName,
        string blobPrefix,
        CancellationToken ct)
    {
        // Convert DateOnly to BusinessDateRange (single day)
        var rangeUtc = new BusinessDateRange(
            businessDate.ToDateTime(TimeOnly.MinValue),
            businessDate.ToDateTime(TimeOnly.MinValue).AddDays(1));

        var result = await exporter.ExportToMultipartParquetAsync(
            connectionString, schemaName, tableName, asOfDateColumn, rangeUtc,
            storageConnectionString, containerName, blobPrefix, ct);

        if (!result.Ok || result.Value is null)
            return Application.Shared.Results.Result<ExportResultDto>.Fail(result.Error ?? "Export failed");

        return Application.Shared.Results.Result<ExportResultDto>.Success(new ExportResultDto(
            result.Value.PartCount,
            result.Value.RowCount,
            result.Value.TotalBytes));
    }

    public async Task<Application.Shared.Results.Result> DeleteRowsAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateOnly businessDate,
        int batchSize,
        CancellationToken ct)
    {
        // Convert DateOnly to BusinessDateRange (single day)
        var rangeUtc = new BusinessDateRange(
            businessDate.ToDateTime(TimeOnly.MinValue),
            businessDate.ToDateTime(TimeOnly.MinValue).AddDays(1));

        var result = await deleter.DeleteByBusinessDateRangeAsync(
            connectionString, schemaName, tableName, asOfDateColumn, rangeUtc, batchSize, ct);

        if (!result.Ok)
            return Application.Shared.Results.Result.Fail(result.Error ?? "Delete failed");

        return Application.Shared.Results.Result.Success();
    }
}

