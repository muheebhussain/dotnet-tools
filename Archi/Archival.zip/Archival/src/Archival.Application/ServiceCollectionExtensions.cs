﻿using Archival.Application.Configuration;
using Archival.Application.Features.BlobLifecycle.DiscoverBlobDatasets;
using Archival.Application.Features.BlobLifecycle.ExecuteBlobDatasets;
using Archival.Application.Features.Configurations.GetTableConfiguration;
using Archival.Application.Features.TableArchival.BuildTableArchivalPlan;
using Archival.Application.Features.TableArchival.BuildConfigurationCache;
using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Features.TableArchival.RunTableArchival;
using Archival.Application.Shared.Caching;
using Archival.Application.Shared.Metrics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace  Archival.Application;

/// <summary>
/// Extension methods for registering application layer services.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Adds application feature handlers to the dependency injection container.
    /// </summary>
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {

        // Configuration options
        services.AddOptions<BlobLifecycleOptions>()
            .BindConfiguration(BlobLifecycleOptions.SectionName)
            .ValidateOnStart();
        services.AddSingleton<IValidateOptions<BlobLifecycleOptions>, BlobLifecycleOptionsValidator>();

        // Phase 1: Configuration cache
        services.AddScoped<BuildConfigurationCacheHandler>();

        // Phase 6: Global configuration cache
        services.AddSingleton<IGlobalConfigurationCache>(provider =>
            new GlobalConfigurationCache(
                provider.GetRequiredService<Microsoft.Extensions.Logging.ILogger<GlobalConfigurationCache>>()));

        // Phase 7: Parallel archival processor
        services.AddScoped<ParallelArchivalProcessor>();

        // Phase 8: Performance metrics
        services.AddScoped<ArchivalPerformanceMetrics>();

        // Orchestration handlers
        services.AddScoped<RunTableArchivalHandler>();

        // Configuration handlers
        services.AddScoped<GetTableConfigurationHandler>();

        // Table archival execution handlers
        services.AddScoped<BuildTableArchivalPlanHandler>();
        services.AddScoped<ExecuteTableArchivalHandler>();


        // Blob discovery and execution handlers (v2)
        services.AddScoped<DiscoverBlobDatasetsHandler>();
        services.AddScoped<ExecuteBlobDatasetsHandler>();

        return services;
    }
}

