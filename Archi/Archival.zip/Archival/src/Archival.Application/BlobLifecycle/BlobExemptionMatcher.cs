﻿using Archival.Application.Contracts.BlobLifecycle;

namespace Archival.Application.BlobLifecycle;

/// <summary>
/// Efficient blob exemption matcher using precomputed HashSet for exact matches
/// and Trie for prefix-based matching.
///
/// Performance characteristics:
/// - Exact match: O(1) via HashSet
/// - Prefix match: O(m) where m = prefix length (via Trie)
/// - Memory: O(n * k) where n = exemptions count, k = avg prefix length
/// </summary>
public sealed class BlobExemptionMatcher : IBlobExemptionMatcher
{
    private readonly HashSet<ExemptionKey> _exactMatches;
    private readonly PrefixTrie _prefixTrie;

    /// <summary>
    /// Creates a matcher from a list of blob exemptions.
    /// Normalizes paths and builds efficient lookup structures.
    /// </summary>
    public static BlobExemptionMatcher Create(IEnumerable<(string Container, string Prefix, DateOnly Date)> exemptions)
    {
        var exactMatches = new HashSet<ExemptionKey>();
        var prefixTrie = new PrefixTrie();

        foreach (var (container, prefix, date) in exemptions)
        {
            // Normalize container name (case-insensitive)
            var normalizedContainer = container.ToLowerInvariant();

            // Normalize prefix (trim slashes for consistent matching)
            var normalizedPrefix = NormalizePath(prefix);

            var key = new ExemptionKey(normalizedContainer, normalizedPrefix, date);

            // Add to exact match set
            exactMatches.Add(key);

            // Add to prefix trie for prefix-based matching
            prefixTrie.Add(normalizedContainer, normalizedPrefix, date);
        }

        return new BlobExemptionMatcher(exactMatches, prefixTrie);
    }


    private BlobExemptionMatcher(HashSet<ExemptionKey> exactMatches, PrefixTrie prefixTrie)
    {
        _exactMatches = exactMatches;
        _prefixTrie = prefixTrie;
    }

    public bool IsExempt(string containerName, string blobPrefix, DateOnly asOfDate)
    {
        var normalizedContainer = containerName.ToLowerInvariant();
        var normalizedPrefix = NormalizePath(blobPrefix);

        // Try exact match first (O(1))
        var key = new ExemptionKey(normalizedContainer, normalizedPrefix, asOfDate);
        if (_exactMatches.Contains(key))
            return true;

        // Try prefix match (O(m) where m = prefix length)
        return _prefixTrie.HasMatchingPrefix(normalizedContainer, normalizedPrefix, asOfDate);
    }

    private static string NormalizePath(string path)
    {
        if (string.IsNullOrEmpty(path))
            return string.Empty;

        // Trim leading and trailing slashes for consistent matching
        return path.Trim('/');
    }

    /// <summary>
    /// Key for exact exemption matching.
    /// </summary>
    private readonly record struct ExemptionKey(string Container, string Prefix, DateOnly Date);

    /// <summary>
    /// Trie data structure for efficient prefix matching.
    /// Supports prefix-based exemptions like "data/2023" matching "data/2023/file.txt".
    /// </summary>
    private sealed class PrefixTrie
    {
        private readonly TrieNode _root = new();

        public void Add(string container, string prefix, DateOnly date)
        {
            // Trie key: container + "/" + prefix
            var fullKey = $"{container}/{prefix}";
            var segments = fullKey.Split('/', StringSplitOptions.RemoveEmptyEntries);

            var current = _root;
            foreach (var segment in segments)
            {
                if (!current.Children.TryGetValue(segment, out var child))
                {
                    child = new TrieNode();
                    current.Children[segment] = child;
                }
                current = child;
            }

            // Mark this node as an exemption endpoint
            current.Dates.Add(date);
        }

        public bool HasMatchingPrefix(string container, string prefix, DateOnly date)
        {
            var fullKey = $"{container}/{prefix}";
            var segments = fullKey.Split('/', StringSplitOptions.RemoveEmptyEntries);

            var current = _root;

            // Traverse the trie and check for matching prefixes at each level
            for (int i = 0; i < segments.Length; i++)
            {
                var segment = segments[i];

                // Check if current node is an exemption endpoint that matches our date
                if (current.Dates.Contains(date))
                    return true; // Found a matching prefix exemption

                // Move to next segment
                if (!current.Children.TryGetValue(segment, out var child))
                    return false; // No matching prefix

                current = child;
            }

            // Check the final node
            return current.Dates.Contains(date);
        }

        private sealed class TrieNode
        {
            public Dictionary<string, TrieNode> Children { get; } = new(StringComparer.Ordinal);
            public HashSet<DateOnly> Dates { get; } = new();
        }
    }
}

