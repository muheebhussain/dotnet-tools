﻿using Microsoft.Extensions.Options;

namespace Archival.Application.Configuration;

/// <summary>
/// Validates BlobLifecycleOptions configuration on startup.
/// </summary>
public sealed class BlobLifecycleOptionsValidator : IValidateOptions<BlobLifecycleOptions>
{
    public ValidateOptionsResult Validate(string? name, BlobLifecycleOptions options)
    {
        if (options.DatasetsParallelism <= 0)
        {
            return ValidateOptionsResult.Fail(
                "BlobLifecycleOptions.DatasetsParallelism must be greater than 0. " +
                $"Current value: {options.DatasetsParallelism}");
        }

        if (options.DatasetsParallelism > 100)
        {
            return ValidateOptionsResult.Fail(
                "BlobLifecycleOptions.DatasetsParallelism must not exceed 100. " +
                $"Current value: {options.DatasetsParallelism}");
        }

        return ValidateOptionsResult.Success;
    }
}

