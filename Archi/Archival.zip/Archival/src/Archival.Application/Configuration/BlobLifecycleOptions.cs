﻿namespace Archival.Application.Configuration;

/// <summary>
/// Configuration options for blob lifecycle processing.
/// </summary>
public sealed class BlobLifecycleOptions
{
    public const string SectionName = "BlobLifecycle";

    /// <summary>
    /// Number of datasets to process in parallel per blob configuration.
    /// Default is 4.
    /// </summary>
    public int DatasetsParallelism { get; init; } = 4;

    /// <summary>
    /// Maximum number of concurrent blob operations (list/tier/delete) per configuration.
    /// Default is 8.
    /// </summary>
    public int BlobOperationsParallelism { get; init; } = 8;

    /// <summary>
    /// Batch size for per-prefix blob operations to avoid creating too many tasks at once.
    /// Default is 50.
    /// </summary>
    public int BlobOperationsBatchSize { get; init; } = 50;
}
