using Archival.Application.Shared.Models;

namespace Archival.Application.Configuration;

public sealed record TableConfiguration(
    int Id,
    bool IsActive,
    string DatabaseName,
    string SchemaName,
    string TableName,
    string BusinessDateColumnName,
    int TablePolicyId,
    int BlobConfigurationId,
    string ArchivePathTemplate,
    bool DeleteAfterExport,
    int BatchDeleteSize);

public sealed record TablePolicy(
    int Id,
    bool IsActive,
    int? KeepLastEod,
    int? KeepLastEom,
    int? KeepLastEoq,
    int? KeepLastEoy);

public sealed record BlobPolicy(
    int Id,
    bool IsActive,
    int? ColdMinAgeDays,
    int? ArchiveMinAgeDays,
    int? DeleteMinAgeDays);

public sealed record BlobConfiguration(
    int Id,
    bool IsEnabled,
    string StorageAccountName,
    string ContainerName,
    string Prefix,
    string? IncludePattern,
    string? ExcludePattern,
    BusinessDateSource BusinessDateSource,
    int BlobPolicyId,
    bool IsExternal = false,
    string? DatasetPathTemplate = null,
    string? BusinessDateFolderFormat = null,
    int BusinessDateFolderDepth = 1);
