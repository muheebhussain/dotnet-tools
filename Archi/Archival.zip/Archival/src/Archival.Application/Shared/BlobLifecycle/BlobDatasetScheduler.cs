﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Shared.BlobLifecycle;

/// <summary>
/// Shared helper for computing blob dataset lifecycle scheduling.
/// Determines next action and timing based on policy thresholds and current date.
/// </summary>
public static class BlobDatasetScheduler
{
    /// <summary>
    /// Computes the next lifecycle action and scheduled execution time for a blob dataset.
    /// Precedence: Delete > Archive > Cold > None.
    /// </summary>
    /// <param name="policy">Lifecycle policy with age thresholds (days)</param>
    /// <param name="supportsArchiveTier">Whether the storage account supports Archive tier</param>
    /// <param name="asOfDate">Business date of the dataset</param>
    /// <param name="utcNow">Current UTC time for age calculations</param>
    /// <returns>Tuple of (NextAction, NextActionAt?). NextActionAt is null if action can be executed now.</returns>
    public static (BlobDatasetNextAction Action, DateTime? ActionAt) ComputeNext(
        LifecyclePolicyDto policy,
        bool supportsArchiveTier,
        DateOnly asOfDate,
        DateTime utcNow)
    {
        // Calculate age in days from asOfDate to today
        var today = DateOnly.FromDateTime(utcNow);
        int ageDays = (int)(today.DayNumber - asOfDate.DayNumber);

        // Precedence: Delete > Archive > Cold > None
        // DeleteMinAgeDays takes highest priority
        if (policy.DeleteMinAgeDays.HasValue && ageDays >= policy.DeleteMinAgeDays.Value)
            return (BlobDatasetNextAction.Delete, null);  // Execute immediately

        // ArchiveMinAgeDays second priority (only if tier is supported)
        if (supportsArchiveTier && policy.ArchiveMinAgeDays.HasValue && ageDays >= policy.ArchiveMinAgeDays.Value)
            return (BlobDatasetNextAction.SetArchive, null);  // Execute immediately

        // ColdMinAgeDays third priority
        if (policy.ColdMinAgeDays.HasValue && ageDays >= policy.ColdMinAgeDays.Value)
            return (BlobDatasetNextAction.SetCold, null);  // Execute immediately

        // No action needed yet - calculate when to check again
        // Find the nearest threshold that will be triggered
        var nextCheckDate = GetNextActionDate(policy, supportsArchiveTier, asOfDate);
        if (nextCheckDate.HasValue)
        {
            // Schedule check for the day the next threshold will be met (start of day UTC)
            var nextCheckTime = nextCheckDate.Value.ToDateTime(TimeOnly.MinValue);
            return (BlobDatasetNextAction.None, nextCheckTime);
        }

        // No thresholds configured at all
        return (BlobDatasetNextAction.None, null);
    }

    /// <summary>
    /// Calculates the date when the next lifecycle action threshold will be met.
    /// </summary>
    private static DateOnly? GetNextActionDate(
        LifecyclePolicyDto policy,
        bool supportsArchiveTier,
        DateOnly asOfDate)
    {
        var candidates = new List<DateOnly>();

        // Delete threshold
        if (policy.DeleteMinAgeDays.HasValue)
            candidates.Add(asOfDate.AddDays(policy.DeleteMinAgeDays.Value));

        // Archive threshold (if supported)
        if (supportsArchiveTier && policy.ArchiveMinAgeDays.HasValue)
            candidates.Add(asOfDate.AddDays(policy.ArchiveMinAgeDays.Value));

        // Cold threshold
        if (policy.ColdMinAgeDays.HasValue)
            candidates.Add(asOfDate.AddDays(policy.ColdMinAgeDays.Value));

        // Return the nearest future date
        return candidates.Any() ? candidates.Min() : null;
    }

    /// <summary>
    /// Computes the earliest date that any lifecycle action would apply.
    /// Useful for optimization: skip discovery of blobs newer than this threshold.
    /// </summary>
    /// <param name="policy">Lifecycle policy with age thresholds (days)</param>
    /// <param name="supportsArchiveTier">Whether the storage account supports Archive tier</param>
    /// <param name="utcNow">Current UTC time for age calculations</param>
    /// <returns>DateOnly representing the oldest date that needs action, or null if no actions are configured</returns>
    public static DateOnly? ComputeMinThresholdDate(
        LifecyclePolicyDto policy,
        bool supportsArchiveTier,
        DateTime utcNow)
    {
        var today = DateOnly.FromDateTime(utcNow);
        var candidates = new List<DateOnly>();

        if (policy.DeleteMinAgeDays.HasValue)
            candidates.Add(today.AddDays(-policy.DeleteMinAgeDays.Value));

        if (supportsArchiveTier && policy.ArchiveMinAgeDays.HasValue)
            candidates.Add(today.AddDays(-policy.ArchiveMinAgeDays.Value));

        if (policy.ColdMinAgeDays.HasValue)
            candidates.Add(today.AddDays(-policy.ColdMinAgeDays.Value));

        return candidates.Any() ? candidates.Min() : null;
    }
}

