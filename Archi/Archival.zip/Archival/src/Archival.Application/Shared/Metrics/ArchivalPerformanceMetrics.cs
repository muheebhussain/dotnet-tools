﻿using System.Diagnostics;

namespace Archival.Application.Shared.Metrics;

/// <summary>
/// Phase 8: Performance metrics tracking for archival operations.
/// Measures and tracks the impact of database optimizations.
/// </summary>
public sealed class ArchivalPerformanceMetrics
{
    private readonly Stopwatch _totalTimer = new();
    private long _totalMetadataDbCalls;
    private long _totalSourceDbCalls;
    private long _totalExportOperations;
    private long _totalDeleteOperations;
    private readonly Dictionary<string, (long count, long totalMs)> _phaseMetrics = new();

    public long TotalMetadataDbCalls => _totalMetadataDbCalls;
    public long TotalSourceDbCalls => _totalSourceDbCalls;
    public long TotalExportOperations => _totalExportOperations;
    public long TotalDeleteOperations => _totalDeleteOperations;

    /// <summary>
    /// Start measuring overall operation time.
    /// </summary>
    public void StartTotal()
    {
        _totalTimer.Restart();
    }

    /// <summary>
    /// Stop measuring overall operation time.
    /// </summary>
    public TimeSpan StopTotal()
    {
        _totalTimer.Stop();
        return _totalTimer.Elapsed;
    }

    /// <summary>
    /// Record a metadata database operation.
    /// </summary>
    public void RecordMetadataDbCall()
    {
        Interlocked.Increment(ref _totalMetadataDbCalls);
    }

    /// <summary>
    /// Record multiple metadata database calls.
    /// </summary>
    public void RecordMetadataDbCalls(long count)
    {
        Interlocked.Add(ref _totalMetadataDbCalls, count);
    }

    /// <summary>
    /// Record a source database operation.
    /// </summary>
    public void RecordSourceDbCall()
    {
        Interlocked.Increment(ref _totalSourceDbCalls);
    }

    /// <summary>
    /// Record an export operation.
    /// </summary>
    public void RecordExportOperation()
    {
        Interlocked.Increment(ref _totalExportOperations);
    }

    /// <summary>
    /// Record a delete operation.
    /// </summary>
    public void RecordDeleteOperation()
    {
        Interlocked.Increment(ref _totalDeleteOperations);
    }

    /// <summary>
    /// Record phase timing (Phase 1-8).
    /// </summary>
    public void RecordPhaseMetric(string phaseName, long elapsedMs, long operationCount = 1)
    {
        if (_phaseMetrics.TryGetValue(phaseName, out var existing))
        {
            _phaseMetrics[phaseName] = (existing.count + operationCount, existing.totalMs + elapsedMs);
        }
        else
        {
            _phaseMetrics[phaseName] = (operationCount, elapsedMs);
        }
    }

    /// <summary>
    /// Get summary of all metrics.
    /// </summary>
    public ArchivalMetricsSummary GetSummary()
    {
        return new ArchivalMetricsSummary(
            TotalElapsedMs: _totalTimer.ElapsedMilliseconds,
            MetadataDbCallCount: _totalMetadataDbCalls,
            SourceDbCallCount: _totalSourceDbCalls,
            ExportOperationCount: _totalExportOperations,
            DeleteOperationCount: _totalDeleteOperations,
            PhaseMetrics: _phaseMetrics.ToDictionary(
                kvp => kvp.Key,
                kvp => new PhaseMetric(kvp.Value.count, kvp.Value.totalMs)));
    }
}

/// <summary>
/// Summary of archival performance metrics.
/// </summary>
public sealed record ArchivalMetricsSummary(
    long TotalElapsedMs,
    long MetadataDbCallCount,
    long SourceDbCallCount,
    long ExportOperationCount,
    long DeleteOperationCount,
    IReadOnlyDictionary<string, PhaseMetric> PhaseMetrics)
{
    /// <summary>
    /// Get formatted metrics for logging.
    /// </summary>
    public string ToFormattedString()
    {
        var lines = new List<string>
        {
            $"=== Archival Performance Metrics ===",
            $"Total Time: {TotalElapsedMs}ms ({TotalElapsedMs / 1000.0:F2}s)",
            $"Metadata DB Calls: {MetadataDbCallCount}",
            $"Source DB Calls: {SourceDbCallCount}",
            $"Export Operations: {ExportOperationCount}",
            $"Delete Operations: {DeleteOperationCount}",
            $"",
            $"=== Phase Breakdown ===",
        };

        foreach (var (phase, metric) in PhaseMetrics.OrderBy(x => x.Key))
        {
            lines.Add($"{phase}: {metric.ElapsedMs}ms ({metric.OperationCount} operations)");
        }

        return string.Join(Environment.NewLine, lines);
    }
}

/// <summary>
/// Metrics for a single phase.
/// </summary>
public sealed record PhaseMetric(long OperationCount, long ElapsedMs);

