﻿namespace Archival.Application.Shared.Models;

public sealed record TableConfigurationDto(
    int Id,
    bool IsActive,
    string DatabaseName,
    string SchemaName,
    string TableName,
    string BusinessDateColumnName,
    int TablePolicyId,
    int BlobConfigurationId,
    string ArchivePathTemplate,
    bool DeleteAfterExport,
    int BatchDeleteSize);