﻿namespace Archival.Application.Shared.Models;

/// <summary>
/// Execution status for blob dataset lifecycle processing.
/// Enables crash-safe, idempotent discover-execute pattern.
/// </summary>
public enum BlobDatasetExecutionStatus
{
    /// <summary>
    /// Dataset discovered; waiting for execution phase to process it.
    /// </summary>
    Pending = 0,

    /// <summary>
    /// Execution phase completed successfully; all lifecycle actions applied.
    /// </summary>
    Succeeded = 1,

    /// <summary>
    /// Execution phase encountered error; retry possible or manual investigation needed.
    /// </summary>
    Failed = 2
}

