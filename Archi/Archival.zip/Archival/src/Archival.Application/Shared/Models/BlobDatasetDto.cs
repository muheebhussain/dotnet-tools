﻿namespace Archival.Application.Shared.Models;

public sealed record BlobDatasetDto(
    long Id,
    int BlobConfigurationId,
    BlobDatasetSourceType SourceType,
    DateOnly AsOfDate,
    string StorageAccountName,
    string ContainerName,
    string BlobPrefix,
    long? ArchivalDatasetId,
    BlobTierState CurrentTier,
    BlobDatasetNextAction NextAction,
    DateTime? NextActionAt,
    int AttemptCount,
    string? LastError,
    BlobDatasetExecutionStatus ExecutionStatus,
    DateTime? ExecutedAt);