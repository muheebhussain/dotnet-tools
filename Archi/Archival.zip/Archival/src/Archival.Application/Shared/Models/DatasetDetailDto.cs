﻿namespace Archival.Application.Shared.Models;

public sealed record DatasetDetailDto(
    long DatasetId,
    DateOnly AsOfDate,
    DateType DateType,
    string StorageAccountName,
    string ContainerName,
    string BlobPrefix,
    DatasetStatus Status);