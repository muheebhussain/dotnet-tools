﻿namespace Archival.Application.Shared.Models;

public sealed record BlobItemDto(
    string Name,
    long? ContentLength,
    DateTime CreatedAt,
    DateTime LastModified,
    string? AccessTier);