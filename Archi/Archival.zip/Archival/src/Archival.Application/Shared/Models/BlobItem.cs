﻿namespace Archival.Application.Shared.Models;

public sealed record BlobItem(
    string Name,
    long? ContentLength,
    DateTime CreatedAt,
    DateTime LastModified,
    string? AccessTier);