﻿namespace Archival.Application.Shared.Models;

public sealed record BlobDatasetMarkResultDto(
    BlobDatasetLastAction LastAction,
    DateTime LastActionAt,
    string? LastError,
    int? NextAttemptAfterMinutes);