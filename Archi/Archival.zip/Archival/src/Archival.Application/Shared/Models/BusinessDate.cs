﻿namespace Archival.Application.Shared.Models;

// Blob dataset lifecycle enums

// Value Objects (shared domain types)
public sealed record BusinessDate(DateOnly Value)
{
    public override string ToString() => Value.ToString("yyyy-MM-dd");
}