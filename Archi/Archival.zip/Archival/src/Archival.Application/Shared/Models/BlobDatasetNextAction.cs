﻿namespace Archival.Application.Shared.Models;

public enum BlobDatasetNextAction { None = 0, SetCold = 1, SetArchive = 2, Delete = 3 }