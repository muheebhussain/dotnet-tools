﻿namespace Archival.Application.Shared.Models;

public sealed record DatasetDto(
    long DatasetId,
    DateOnly AsOfDate,
    DateType DateType,
    string StorageAccountName,
    string ContainerName,
    string BlobPrefix);