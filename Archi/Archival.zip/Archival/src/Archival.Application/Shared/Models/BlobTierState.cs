﻿namespace Archival.Application.Shared.Models;

public enum BlobTierState { Unknown = 0, Hot = 1, Cold = 2, Archive = 3 }