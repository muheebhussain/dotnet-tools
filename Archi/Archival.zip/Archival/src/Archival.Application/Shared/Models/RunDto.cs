﻿namespace Archival.Application.Shared.Models;

public sealed record RunDto(
    long Id,
    RunType RunType,
    DateTime StartedAt,
    DateTime? EndedAt,
    RunStatus Status,
    string? Note);

// Blob Dataset DTOs