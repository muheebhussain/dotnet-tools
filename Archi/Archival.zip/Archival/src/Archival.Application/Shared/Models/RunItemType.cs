﻿namespace Archival.Application.Shared.Models;

public enum RunItemType { Dataset = 1, Prefix = 2 }