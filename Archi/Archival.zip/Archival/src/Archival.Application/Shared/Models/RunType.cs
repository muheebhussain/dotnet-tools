﻿namespace Archival.Application.Shared.Models;

public enum RunType { Archive = 1, Lifecycle = 2 }