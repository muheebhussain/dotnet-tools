﻿namespace Archival.Application.Shared.Models;

public enum BlobDatasetSourceType { Internal = 1, External = 2 }