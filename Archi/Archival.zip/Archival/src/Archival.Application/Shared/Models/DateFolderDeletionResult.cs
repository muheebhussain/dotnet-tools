﻿namespace Archival.Application.Shared.Models;

public sealed record DateFolderDeletionResult(
    int BlobsDeleted,
    bool MarkerDeleted,
    bool HnsDirectoryDeleted,
    bool HnsSupported);