﻿namespace Archival.Application.Shared.Models;

public enum RunItemStatus { Pending = 1, Succeeded = 2, Failed = 3, Skipped = 4 }