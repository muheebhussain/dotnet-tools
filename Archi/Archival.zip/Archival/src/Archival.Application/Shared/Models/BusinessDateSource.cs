﻿namespace Archival.Application.Shared.Models;

public enum BusinessDateSource { FromFileName = 1, CreatedOn = 2, LastModified = 3 }