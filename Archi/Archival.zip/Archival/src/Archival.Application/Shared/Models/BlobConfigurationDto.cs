﻿namespace Archival.Application.Shared.Models;

public sealed record BlobConfigurationDto(
    int Id,
    bool IsEnabled,
    string StorageAccountName,
    string ContainerName,
    string Prefix,
    string? IncludePattern,
    string? ExcludePattern,
    BusinessDateSource BusinessDateSource,
    int BlobPolicyId,
    bool IsExternal = false,
    string? DatasetPathTemplate = null,
    string? BusinessDateFolderFormat = null,
    int BusinessDateFolderDepth = 1);