﻿namespace Archival.Application.Shared.Models;

public sealed record TableRetentionPolicyDto(
    int Id,
    bool IsActive,
    int? KeepLastEod,
    int? KeepLastEom,
    int? KeepLastEoq,
    int? KeepLastEoy);