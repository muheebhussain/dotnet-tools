﻿namespace Archival.Application.Shared.Models;

public enum DateType { EOD = 1, EOM = 2, EOQ = 3, EOY = 4 }