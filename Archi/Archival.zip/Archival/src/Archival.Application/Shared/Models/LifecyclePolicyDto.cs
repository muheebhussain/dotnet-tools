﻿namespace Archival.Application.Shared.Models;

public sealed record LifecyclePolicyDto(
    int Id,
    bool IsActive,
    int? ColdMinAgeDays,
    int? ArchiveMinAgeDays,
    int? DeleteMinAgeDays);