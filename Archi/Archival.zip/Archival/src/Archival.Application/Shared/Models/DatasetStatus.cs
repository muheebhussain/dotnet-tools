﻿namespace Archival.Application.Shared.Models;

public enum DatasetStatus { Pending = 1, Succeeded = 2, Failed = 3, Partial = 4 }