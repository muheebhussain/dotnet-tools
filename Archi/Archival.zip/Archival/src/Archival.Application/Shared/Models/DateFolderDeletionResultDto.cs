﻿namespace Archival.Application.Shared.Models;

public sealed record DateFolderDeletionResultDto(
    int BlobsDeleted,
    bool MarkerDeleted,
    bool HnsDirectoryDeleted,
    bool HnsSupported);