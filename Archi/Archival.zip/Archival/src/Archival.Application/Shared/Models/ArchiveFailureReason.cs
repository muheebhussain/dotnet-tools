﻿namespace Archival.Application.Shared.Models;

/// <summary>
/// Indicates the reason an archive tier operation failed.
/// Used to determine if fallback to Cold tier should be attempted.
/// </summary>
public enum ArchiveFailureReason
{
    /// <summary>
    /// Archive tier is not supported for this storage account type.
    /// Safe to fallback to Cold tier.
    /// Azure error codes: 400 (Bad Request) or 409 (Conflict)
    /// </summary>
    NotSupported = 0,

    /// <summary>
    /// Blob was not found (status 404).
    /// No action needed.
    /// </summary>
    BlobNotFound = 1,

    /// <summary>
    /// Permission denied (status 403).
    /// Requires credential/permission fix.
    /// </summary>
    PermissionDenied = 2,

    /// <summary>
    /// Operation timed out (408 or exceeds timeout).
    /// Can retry later.
    /// </summary>
    Timeout = 3,

    /// <summary>
    /// Other transient or permanent error.
    /// Requires investigation.
    /// </summary>
    Other = 4
}

