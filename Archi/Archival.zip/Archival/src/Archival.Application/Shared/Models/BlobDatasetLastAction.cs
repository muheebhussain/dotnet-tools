﻿namespace Archival.Application.Shared.Models;

public enum BlobDatasetLastAction { None = 0, SetCold = 1, SetArchive = 2, Delete = 3 }