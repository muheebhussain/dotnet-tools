﻿namespace Archival.Application.Shared.Models;

public sealed record PrefixDeletionResultDto(
    int BlobsDeleted,
    bool MarkerDeleted,
    bool HnsDirectoryDeleted,
    int ParentDirectoriesDeleted,
    bool HnsSupported);