﻿namespace Archival.Application.Shared.Models;

public sealed record BusinessDateRange(DateTime StartInclusiveUtc, DateTime EndExclusiveUtc);