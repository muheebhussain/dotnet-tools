﻿namespace Archival.Application.Shared.Models;

public sealed record ExportResultDto(
    int PartCount,
    long RowCount,
    long TotalBytes);