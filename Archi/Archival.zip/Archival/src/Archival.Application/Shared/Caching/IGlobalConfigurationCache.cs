﻿using Archival.Application.Shared.Models;
using Archival.Application.Configuration;
using Archival.Application.Features.TableArchival;

namespace Archival.Application.Shared.Caching;

/// <summary>
/// Global (application-level) cache of configuration data.
/// Cached across multiple archival runs to avoid repeated loading.
///
/// Note: Configuration changes require application restart to pick up.
/// Use per-run cache (IConfigurationCache) if dynamic config updates are needed.
/// </summary>
public interface IGlobalConfigurationCache
{
    /// <summary>
    /// Get or build the global cache if not already built.
    /// Thread-safe lazy initialization.
    /// </summary>
    Task<IConfigurationCache> GetOrBuildAsync(
        IReadOnlyList<TableConfigurationDto> tableConfigs,
        CancellationToken ct);

    /// <summary>
    /// Force rebuild of the cache (for testing or config updates).
    /// </summary>
    Task RefreshAsync(
        IReadOnlyList<TableConfigurationDto> tableConfigs,
        CancellationToken ct);

    /// <summary>
    /// Clear the cached configuration.
    /// </summary>
    void Clear();

    /// <summary>
    /// Check if cache is built and valid.
    /// </summary>
    bool IsInitialized { get; }
}

