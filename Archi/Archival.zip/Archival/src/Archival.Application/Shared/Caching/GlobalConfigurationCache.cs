﻿using Archival.Application.Shared.Models;
using Archival.Application.Configuration;
using Archival.Application.Features.TableArchival;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Shared.Caching;

/// <summary>
/// Thread-safe global configuration cache implementation.
/// Caches configurations across archival runs using lazy initialization pattern.
/// </summary>
public sealed class GlobalConfigurationCache : IGlobalConfigurationCache
{
    private readonly object _lockObject = new();
    private IConfigurationCache? _cache;
    private readonly ILogger<GlobalConfigurationCache> _logger;

    public bool IsInitialized
    {
        get
        {
            lock (_lockObject)
            {
                return _cache != null;
            }
        }
    }

    public GlobalConfigurationCache(ILogger<GlobalConfigurationCache> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Phase 6: Get or build cache lazily on first request.
    /// Subsequent requests return the same cached instance.
    /// Thread-safe using lock pattern.
    /// </summary>
    public async Task<IConfigurationCache> GetOrBuildAsync(
        IReadOnlyList<TableConfigurationDto> tableConfigs,
        CancellationToken ct)
    {
        // Double-checked locking pattern for thread safety
        if (_cache != null)
        {
            _logger.LogDebug("Phase 6: Returning cached configuration (hit)");
            return _cache;
        }

        lock (_lockObject)
        {
            // Re-check after acquiring lock
            if (_cache != null)
            {
                return _cache;
            }

            _logger.LogInformation("Phase 6: Building global configuration cache on first request");
            _cache = BuildCache(tableConfigs);
            return _cache;
        }
    }

    /// <summary>
    /// Force refresh the cache (for testing or config reload scenarios).
    /// </summary>
    public async Task RefreshAsync(
        IReadOnlyList<TableConfigurationDto> tableConfigs,
        CancellationToken ct)
    {
        lock (_lockObject)
        {
            _logger.LogInformation("Phase 6: Refreshing global configuration cache");
            _cache = BuildCache(tableConfigs);
        }
    }

    /// <summary>
    /// Clear the cache.
    /// </summary>
    public void Clear()
    {
        lock (_lockObject)
        {
            _logger.LogDebug("Phase 6: Clearing global configuration cache");
            _cache = null;
        }
    }

    /// <summary>
    /// Build the cache synchronously from table configurations.
    /// This is a simplified version - in production, you'd batch-load from DB.
    /// </summary>
    private IConfigurationCache BuildCache(IReadOnlyList<TableConfigurationDto> tableConfigs)
    {
        // For now, return an empty cache
        // In a real implementation, this would batch-load from database
        // and merge results into a single ConfigurationCache object

        var emptyTablePlans = new Dictionary<int, TableArchivalPlan>();
        var emptyBlobConfigs = new Dictionary<int, BlobConfiguration>();

        return new ConfigurationCache(
            tablePlansByConfigId: emptyTablePlans,
            blobConfigsById: emptyBlobConfigs);
    }
}

