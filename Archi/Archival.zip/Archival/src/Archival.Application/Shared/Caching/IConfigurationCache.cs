﻿using Archival.Application.Shared.Models;
using Archival.Application.Configuration;
using Archival.Application.Features.TableArchival;

namespace Archival.Application.Shared.Caching;

/// <summary>
/// Immutable cache of all configuration data loaded once per run.
/// Eliminates redundant per-date configuration lookups.
/// </summary>
public interface IConfigurationCache
{
    /// <summary>
    /// Get table archival plan by table configuration ID.
    /// </summary>
    TableArchivalPlan GetTablePlan(int tableConfigurationId);

    /// <summary>
    /// Get blob configuration by ID.
    /// </summary>
    BlobConfiguration GetBlobConfiguration(int blobConfigurationId);

    /// <summary>
    /// Check if table plan exists (for safe lookups).
    /// </summary>
    bool TryGetTablePlan(int tableConfigurationId, out TableArchivalPlan plan);

// ...existing code...
    /// <summary>
    /// Check if blob config exists (for safe lookups).
    /// </summary>
    bool TryGetBlobConfiguration(int blobConfigurationId, out BlobConfiguration config);
}

