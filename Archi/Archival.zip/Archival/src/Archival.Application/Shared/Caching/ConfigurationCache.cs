﻿using Archival.Application.Shared.Models;
using Archival.Application.Configuration;
using Archival.Application.Features.TableArchival;

namespace Archival.Application.Shared.Caching;

/// <summary>
/// Immutable implementation of configuration cache.
/// All data loaded once and stored as readonly dictionaries.
/// </summary>
public sealed class ConfigurationCache : IConfigurationCache
{
    private readonly IReadOnlyDictionary<int, TableArchivalPlan> _tablePlansByConfigId;
    private readonly IReadOnlyDictionary<int, BlobConfiguration> _blobConfigsById;

    public ConfigurationCache(
        IReadOnlyDictionary<int, TableArchivalPlan> tablePlansByConfigId,
        IReadOnlyDictionary<int, BlobConfiguration> blobConfigsById)
    {
        _tablePlansByConfigId = tablePlansByConfigId ?? throw new ArgumentNullException(nameof(tablePlansByConfigId));
        _blobConfigsById = blobConfigsById ?? throw new ArgumentNullException(nameof(blobConfigsById));
    }

    public TableArchivalPlan GetTablePlan(int tableConfigurationId)
    {
        if (!_tablePlansByConfigId.TryGetValue(tableConfigurationId, out var plan))
            throw new InvalidOperationException($"Table plan not found for configuration ID {tableConfigurationId}");
        return plan;
    }

    public BlobConfiguration GetBlobConfiguration(int blobConfigurationId)
    {
        if (!_blobConfigsById.TryGetValue(blobConfigurationId, out var config))
            throw new InvalidOperationException($"Blob configuration not found for ID {blobConfigurationId}");
        return config;
    }

    public bool TryGetTablePlan(int tableConfigurationId, out TableArchivalPlan plan)
        => _tablePlansByConfigId.TryGetValue(tableConfigurationId, out plan);

    public bool TryGetBlobConfiguration(int blobConfigurationId, out BlobConfiguration config)
        => _blobConfigsById.TryGetValue(blobConfigurationId, out config);
}

