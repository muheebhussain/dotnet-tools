﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Retention;
using Archival.Application.Contracts.Tables;
using Archival.Application.Contracts.Time;
using Archival.Application.Features.TableArchival.BuildConfigurationCache;
using Archival.Application.Shared.Caching;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.RunTableArchival;

/// <summary>
/// Orchestrates table archival workflow for one or more tables.
/// This is an orchestration-level handler (indicated by "Run" prefix) that manages
/// the complete workflow including run tracking, iteration over configurations,
/// and delegation to worker handlers.
/// </summary>
/// <remarks>
/// <para><b>Handler Pattern: Orchestrator</b></para>
/// <para>
/// This handler follows the orchestration pattern where:
/// - It manages workflow lifecycle (start run, iterate, complete run)
/// - It tracks runs and run items for observability
/// - It delegates actual archival work to ExecuteTableArchivalHandler
/// - It aggregates results and handles run-level error reporting
/// </para>
/// <para>
/// The "Run" prefix distinguishes orchestration handlers from worker handlers.
/// Worker handlers (e.g., ExecuteTableArchivalHandler) perform specific tasks
/// and return typed results without managing run tracking.
/// </para>
/// </remarks>
public sealed class RunTableArchivalHandler(
    IRunsStore runsStore,
    IRunItemsStore runItemsStore,
    IConfigurationStore configurationStore,
    IExemptionsStore exemptionsStore,
    IDatasetStore datasetStore,
    IRetentionCalculator retentionCalculator,
    ITableArchiver tableArchiver,
    IConnectionStringResolver connectionResolver,
    BuildConfigurationCacheHandler buildCacheHandler,
    ExecuteTableArchival.ExecuteTableArchivalHandler executeTableArchivalHandler,
    ILogger<RunTableArchivalHandler> logger,
    IClock clock)
{
    public async Task<Result> HandleAsync(RunTableArchivalCommand command, CancellationToken ct)
    {
        var runId = -1L;
        bool anyFailed = false;
        int successCount = 0;
        var runItemsToInsert = new List<RunItemBatchDto>();

        try
        {
            // Start run (inline logic)
            logger.LogInformation("Starting table archival run");
            var run = await runsStore.StartRunAsync(RunType.Archive, ct);
            runId = run.Id;
            logger.LogInformation("Archive run started: RunId={RunId}", runId);

            // Get table configurations
            var tables = command.TableConfigId.HasValue
                ? new[] { await configurationStore.GetTableConfigurationAsync(command.TableConfigId.Value, ct) }
                    .Where(t => t is not null).ToList()!
                : (await configurationStore.GetActiveTableConfigurationsAsync(ct)).ToList();

            logger.LogInformation("Processing {Count} table(s)", tables.Count);

            // Build configuration cache once per run (batch load all configs)
            var cacheResult = await buildCacheHandler.HandleAsync(tables, ct);
            if (!cacheResult.Ok)
            {
                logger.LogError("Failed to build configuration cache: {Error}", cacheResult.Error);
                return Result.Fail($"Failed to build configuration cache: {cacheResult.Error}");
            }

            var configCache = cacheResult.Value!;
            logger.LogDebug("Configuration cache built successfully");

            // Phase 3 Optimization: Batch load all exemptions for all tables in one DB call
            var tableIds = tables.Where(t => t.IsActive).Select(t => t.Id).ToList();
            var exemptionsByTableId = await exemptionsStore.GetTableExemptionsByTableIdsAsync(tableIds, ct);
            logger.LogDebug("Phase 3: Batch loaded exemptions for {Count} tables",
                tableIds.Count);

            // Phase 4 Optimization: Batch load all present dates first, then batch calculate retention
            var presentDatesByTableId = new Dictionary<int, IReadOnlyList<DateOnly>>();
            foreach (var table in tables.Where(t => t.IsActive))
            {
                var from = DateOnly.MinValue;
                var to = DateOnly.FromDateTime(clock.UtcNow.AddDays(1));
                var presentDates = await tableArchiver.GetPresentDatesAsync(
                    connectionResolver.ResolveSourceConnection(table.DatabaseName),
                    table.SchemaName,
                    table.TableName,
                    table.BusinessDateColumnName,
                    from.ToDateTime(TimeOnly.MinValue),
                    to.ToDateTime(TimeOnly.MinValue),
                    ct);
                presentDatesByTableId[table.Id] = presentDates;
            }

            // Phase 4: Batch calculate retention for all tables at once
            var keepDatesByTableId = await retentionCalculator.CalculateKeepDatesForMultipleAsync(
                tableIds,
                presentDatesByTableId,
                ct);
            logger.LogDebug("Phase 4: Batch calculated retention for {Count} tables", tableIds.Count);

            foreach (var table in tables)
            {
                if (!table.IsActive)
                {
                    logger.LogDebug("Skipping inactive table: {Schema}.{Table}", table.SchemaName, table.TableName);
                    continue;
                }

                logger.LogInformation("Processing table: Schema={Schema}, Table={Table}, ConfigId={ConfigId}",
                    table.SchemaName, table.TableName, table.Id);

                try
                {
                    // Get connection string
                    var sourceConn = connectionResolver.ResolveSourceConnection(table.DatabaseName);

                    // Get present dates from the table (all available dates, no time window limit)
                    // Phase 4: Use pre-loaded present dates
                    var presentDates = presentDatesByTableId[table.Id];

                    logger.LogInformation("Found {Count} distinct dates in table {Schema}.{Table}",
                        presentDates.Count, table.SchemaName, table.TableName);

                    if (presentDates.Count > 10000)
                    {
                        logger.LogWarning(
                            "Unusually large number of distinct dates found: {Count} for table {Schema}.{Table}. " +
                            "This may impact performance.", presentDates.Count, table.SchemaName, table.TableName);
                    }

                    // Phase 4: Use pre-calculated keep set instead of per-table calculation
                    var keepSet = keepDatesByTableId[table.Id];
                    logger.LogInformation("Keep set calculated: {KeepCount} dates to retain for table {Schema}.{Table}",
                        keepSet.Count, table.SchemaName, table.TableName);

                    // Phase 3 Optimization: Use batch-loaded exemptions instead of per-table DB call
                    var exemptions = exemptionsByTableId.GetValueOrDefault(table.Id, new HashSet<DateOnly>());
                    logger.LogInformation("Found {Count} exemption(s) for table {Schema}.{Table}",
                        exemptions.Count, table.SchemaName, table.TableName);

                    // Calculate candidates (present dates - keep dates - exemptions - already archived)
                    var candidates = presentDates
                        .Where(d => !keepSet.Contains(d))
                        .Where(d => !exemptions.Contains(d))
                        .ToList();

                    logger.LogInformation("Archive candidates: {Count} date(s) for table {Schema}.{Table}",
                        candidates.Count, table.SchemaName, table.TableName);

                    // Phase 2 Optimization: Batch load all candidate datasets in one DB call
                    var candidateDatasets = await datasetStore.GetDatasetsByTableAndDatesAsync(
                        table.Id, candidates, ct);
                    logger.LogDebug("Batch loaded {Count} existing dataset(s) for {Count} candidate dates",
                        candidateDatasets.Count, candidates.Count);

                    // Process each candidate date
                    foreach (var businessDate in candidates)
                    {
                        // Check if already successfully archived (allow retry of failed datasets)
                        // Use batch-loaded data instead of per-date DB call
                        var datasetKey = (table.Id, businessDate);
                        var existingDataset =
                            candidateDatasets.TryGetValue(datasetKey, out var dataset) ? dataset : null;

                        if (existingDataset?.Status == DatasetStatus.Succeeded)
                        {
                            logger.LogDebug(
                                "Dataset already successfully archived: Table={Schema}.{Table}, Date={Date}",
                                table.SchemaName, table.TableName, businessDate);
                            continue;
                        }

                        if (existingDataset?.Status == DatasetStatus.Failed)
                        {
                            logger.LogInformation(
                                "Retrying previously failed dataset: Table={Schema}.{Table}, Date={Date}",
                                table.SchemaName, table.TableName, businessDate);
                        }

                        logger.LogInformation("Archiving: Table={Schema}.{Table}, Date={Date}",
                            table.SchemaName, table.TableName, businessDate);

                        // Execute archival for this date
                        var archiveResult = await executeTableArchivalHandler.HandleAsync(
                            new ExecuteTableArchival.ExecuteTableArchivalCommand(table.Id, businessDate),
                            configCache,
                            existingDataset,
                            ct);

                        // Record run item
                        var itemStatus = archiveResult.Ok
                            ? RunItemStatus.Succeeded
                            : RunItemStatus.Failed;

                        // Phase 5: Collect run item for batch insert
                        runItemsToInsert.Add(new RunItemBatchDto(
                            ItemType: RunItemType.Dataset,
                            Status: itemStatus,
                            TableConfigurationId: table.Id,
                            AsOfDate: businessDate,
                            RowsAffected: archiveResult.Ok ? archiveResult.Value?.RowsArchived : null,
                            BytesAffected: archiveResult.Ok ? archiveResult.Value?.BytesArchived : null,
                            Error: archiveResult.Ok ? null : archiveResult.Error));


                        if (archiveResult.Ok)
                        {
                            successCount++;
                            logger.LogInformation(
                                "Successfully archived: Table={Schema}.{Table}, Date={Date}, Rows={Rows}, Bytes={Bytes}",
                                table.SchemaName, table.TableName, businessDate,
                                archiveResult.Value?.RowsArchived ?? 0, archiveResult.Value?.BytesArchived ?? 0);
                        }
                        else
                        {
                            anyFailed = true;
                            logger.LogError("Failed to archive: Table={Schema}.{Table}, Date={Date}, Error={Error}",
                                table.SchemaName, table.TableName, businessDate, archiveResult.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    anyFailed = true;
                    logger.LogError(ex, "Error processing table: {Schema}.{Table}", table.SchemaName, table.TableName);

                    // Phase 5: Collect error run item
                    runItemsToInsert.Add(new RunItemBatchDto(
                        ItemType: RunItemType.Dataset,
                        Status: RunItemStatus.Failed,
                        TableConfigurationId: table.Id,
                        Error: ex.Message));
                }
            }

            // Complete run (inline logic)
            var finalStatus = anyFailed
                ? (successCount > 0 ? RunStatus.PartiallySucceeded : RunStatus.Failed)
                : RunStatus.Succeeded;

            // Phase 5: Batch insert all collected run items
            if (runItemsToInsert.Count > 0)
            {
                await runItemsStore.AddRunItemsBatchAsync(runId, runItemsToInsert, ct);
                logger.LogDebug("Phase 5: Batch inserted {Count} run items", runItemsToInsert.Count);
            }

            var note = $"Processed {tables.Count} table(s), {successCount} successful archive(s)";
            await runsStore.CompleteRunAsync(runId, finalStatus, note, ct);

            logger.LogInformation(
                "Archive run completed: RunId={RunId}, Status={Status}, Success={Success}, Failed={Failed}",
                runId, finalStatus, successCount, anyFailed);

            return anyFailed ? Result.Fail("Some tables failed to archive") : Result.Success();
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            logger.LogWarning("Table archival was cancelled");

            // Try to complete the run if it was started (inline logic)
            if (runId > 0)
            {
                try
                {
                    await runsStore.CompleteRunAsync(runId, RunStatus.Failed, "Cancelled by user", default);
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after cancellation");
                }
            }

            return Result.Fail("Table archival cancelled by user");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Table archival orchestration failed");

            // Try to complete the run if it was started (inline logic)
            if (runId > 0)
            {
                try
                {
                    await runsStore.CompleteRunAsync(runId, RunStatus.Failed, ex.Message, ct);
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after error");
                }
            }

            return Result.Fail($"Table archival failed: {ex.Message}");
        }
    }
}