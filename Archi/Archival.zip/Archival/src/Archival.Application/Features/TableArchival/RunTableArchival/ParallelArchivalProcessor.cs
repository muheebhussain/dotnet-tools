﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Shared.Caching;
using Archival.Application.Shared.Models;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.RunTableArchival;

/// <summary>
/// Phase 7: Parallel archival processor.
/// Processes multiple dates concurrently in batches to improve throughput.
///
/// This complements the batching optimizations (Phases 1-5) by parallelizing
/// the actual archival execution rather than doing it serially.
/// </summary>
public sealed class ParallelArchivalProcessor
{
    private readonly ExecuteTableArchivalHandler _executeTableArchivalHandler;
    private readonly IRunItemsStore _runItemsStore;
    private readonly ILogger<ParallelArchivalProcessor> _logger;
    private readonly int _maxParallelism;

    public ParallelArchivalProcessor(
        ExecuteTableArchivalHandler executeTableArchivalHandler,
        IRunItemsStore runItemsStore,
        ILogger<ParallelArchivalProcessor> logger,
        int maxParallelism = 4)
    {
        _executeTableArchivalHandler = executeTableArchivalHandler ?? throw new ArgumentNullException(nameof(executeTableArchivalHandler));
        _runItemsStore = runItemsStore ?? throw new ArgumentNullException(nameof(runItemsStore));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _maxParallelism = maxParallelism > 0 ? maxParallelism : Environment.ProcessorCount;
    }

    /// <summary>
    /// Phase 7: Process dates in parallel batches.
    /// </summary>
    public async Task<List<RunItemBatchDto>> ProcessDatesInParallelAsync(
        int tableConfigurationId,
        string schemaName,
        string tableName,
        IReadOnlyList<DateOnly> candidateDates,
        IConfigurationCache configCache,
        IReadOnlyDictionary<(int, DateOnly), DatasetDetailDto> candidateDatasets,
        CancellationToken ct)
    {
        var runItems = new List<RunItemBatchDto>();

        if (candidateDates.Count == 0)
            return runItems;

        _logger.LogInformation(
            "Phase 7: Processing {Count} dates in parallel batches (max parallelism: {MaxParallelism})",
            candidateDates.Count, _maxParallelism);

        // Create batches of dates to process in parallel
        var batches = candidateDates
            .Chunk(_maxParallelism)
            .ToList();

        var batchIndex = 0;
        foreach (var batch in batches)
        {
            batchIndex++;
            _logger.LogDebug("Phase 7: Processing batch {BatchNum}/{TotalBatches} ({Count} dates)",
                batchIndex, batches.Count, batch.Length);

            // Process all dates in this batch in parallel
            var tasks = batch.Select(businessDate =>
                ProcessSingleDateAsync(
                    tableConfigurationId,
                    businessDate,
                    configCache,
                    candidateDatasets.TryGetValue((tableConfigurationId, businessDate), out var dataset) ? dataset : null,
                    ct));

            var batchResults = await Task.WhenAll(tasks);
            runItems.AddRange(batchResults);
        }

        _logger.LogInformation("Phase 7: Completed parallel processing of {Count} dates",
            candidateDates.Count);

        return runItems;
    }

    /// <summary>
    /// Process a single date and return the run item result.
    /// </summary>
    private async Task<RunItemBatchDto> ProcessSingleDateAsync(
        int tableConfigurationId,
        DateOnly businessDate,
        IConfigurationCache configCache,
        DatasetDetailDto? existingDataset,
        CancellationToken ct)
    {
        try
        {
            var command = new ExecuteTableArchivalCommand(tableConfigurationId, businessDate);
            var result = await _executeTableArchivalHandler.HandleAsync(command, configCache, existingDataset, ct);

            return new RunItemBatchDto(
                ItemType: RunItemType.Dataset,
                Status: result.Ok ? RunItemStatus.Succeeded : RunItemStatus.Failed,
                TableConfigurationId: tableConfigurationId,
                AsOfDate: businessDate,
                RowsAffected: result.Ok ? result.Value?.RowsArchived : null,
                BytesAffected: result.Ok ? result.Value?.BytesArchived : null,
                Error: result.Ok ? null : result.Error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Phase 7: Error processing date {Date} for table {TableConfigId}",
                businessDate, tableConfigurationId);

            return new RunItemBatchDto(
                ItemType: RunItemType.Dataset,
                Status: RunItemStatus.Failed,
                TableConfigurationId: tableConfigurationId,
                AsOfDate: businessDate,
                Error: ex.Message);
        }
    }
}

