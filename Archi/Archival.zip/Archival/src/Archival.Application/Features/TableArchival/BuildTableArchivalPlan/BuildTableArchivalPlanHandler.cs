﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.BuildTableArchivalPlan;

public sealed class BuildTableArchivalPlanHandler(
    IConfigurationStore configurationStore,
    ILogger<BuildTableArchivalPlanHandler> logger)
{
    public async Task<Result<TableArchivalPlan>> HandleAsync(BuildTableArchivalPlanQuery query, CancellationToken ct)
    {
        logger.LogInformation("Building table archival plan: TableConfigId={ConfigId}", query.TableConfigurationId);

        // Load table configuration
        var tableConfig = await configurationStore.GetTableConfigurationAsync(query.TableConfigurationId, ct);
        if (tableConfig is null)
            return Result<TableArchivalPlan>.Fail($"Table configuration {query.TableConfigurationId} not found");

        // Load blob configuration to get storage account and container
        var blobConfig = await configurationStore.GetBlobConfigurationAsync(tableConfig.BlobConfigurationId, ct);
        if (blobConfig is null)
            return Result<TableArchivalPlan>.Fail(
                $"Blob configuration {tableConfig.BlobConfigurationId} not found for table config {query.TableConfigurationId}");

        // Build plan from configuration
        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfig.Id,
            DatabaseName: tableConfig.DatabaseName,
            SchemaName: tableConfig.SchemaName,
            TableName: tableConfig.TableName,
            BusinessDateColumnName: tableConfig.BusinessDateColumnName,
            StorageAccountName: blobConfig.StorageAccountName,
            ContainerName: blobConfig.ContainerName,
            BaseBlobPrefix: tableConfig.ArchivePathTemplate,
            // Date type is determined at execution time per business date
            DateType: DateType.EOD,
            // Delete behavior from config
            DeleteAfterExport: tableConfig.DeleteAfterExport,
            BatchDeleteSize: tableConfig.BatchDeleteSize);

        logger.LogInformation(
            "Plan built: Schema={Schema}, Table={Table}, Storage={Account}/{Container}, BlobConfigId={BlobConfigId}, DeleteAfterExport={Delete}",
            plan.SchemaName, plan.TableName, plan.StorageAccountName, plan.ContainerName,
            tableConfig.BlobConfigurationId, plan.DeleteAfterExport);

        return Result<TableArchivalPlan>.Success(plan);
    }

    public async Task<TableConfigurationDto?> GetTableConfigurationAsync(int tableConfigId, CancellationToken ct)
    {
        return await configurationStore.GetTableConfigurationAsync(tableConfigId, ct);
    }
}
