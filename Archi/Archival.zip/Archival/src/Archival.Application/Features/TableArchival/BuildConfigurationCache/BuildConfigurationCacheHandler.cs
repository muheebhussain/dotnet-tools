﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Caching;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Archival.Application.Features.TableArchival;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.BuildConfigurationCache;

/// <summary>
/// Builds an immutable configuration cache by batch-loading all needed data once.
/// Replaces per-date configuration lookups with in-memory dictionary access.
/// </summary>
public sealed class BuildConfigurationCacheHandler(
    IConfigurationStore configurationStore,
    ILogger<BuildConfigurationCacheHandler> logger)
{
    public async Task<Result<IConfigurationCache>> HandleAsync(
        IReadOnlyList<TableConfigurationDto> tableConfigs,
        CancellationToken ct)
    {
        try
        {
            logger.LogInformation("Building configuration cache for {Count} table(s)", tableConfigs.Count);

            // Collect all unique blob config IDs
            var blobConfigIds = new HashSet<int>();

            foreach (var table in tableConfigs)
            {
                if (table.BlobConfigurationId > 0)
                    blobConfigIds.Add(table.BlobConfigurationId);
            }

            // Batch load blob configurations
            var blobConfigs = await configurationStore.GetEnabledBlobConfigurationsAsync(ct);

            // Convert BlobConfigurationDto to BlobConfiguration records for cache
            var blobConfigsById = new Dictionary<int, BlobConfiguration>();
            foreach (var dto in blobConfigs.Where(bc => blobConfigIds.Contains(bc.Id)))
            {
                var config = new BlobConfiguration(
                    Id: dto.Id,
                    IsEnabled: dto.IsEnabled,
                    StorageAccountName: dto.StorageAccountName,
                    ContainerName: dto.ContainerName,
                    Prefix: dto.Prefix,
                    IncludePattern: dto.IncludePattern,
                    ExcludePattern: dto.ExcludePattern,
                    BusinessDateSource: dto.BusinessDateSource,
                    BlobPolicyId: dto.BlobPolicyId,
                    IsExternal: dto.IsExternal,
                    DatasetPathTemplate: dto.DatasetPathTemplate,
                    BusinessDateFolderFormat: dto.BusinessDateFolderFormat,
                    BusinessDateFolderDepth: dto.BusinessDateFolderDepth);
                blobConfigsById[dto.Id] = config;
            }

            // Build table archival plans (requires table + blob config)
            var tablePlans = new Dictionary<int, TableArchivalPlan>();
            foreach (var table in tableConfigs)
            {
                if (table.BlobConfigurationId <= 0 || !blobConfigsById.TryGetValue(table.BlobConfigurationId, out var blobConfig))
                {
                    logger.LogWarning("Skipping table config {TableConfigId}: blob configuration {BlobConfigId} not found",
                        table.Id, table.BlobConfigurationId);
                    continue;
                }

                var plan = new TableArchivalPlan(
                    TableConfigurationId: table.Id,
                    DatabaseName: table.DatabaseName,
                    SchemaName: table.SchemaName,
                    TableName: table.TableName,
                    BusinessDateColumnName: table.BusinessDateColumnName,
                    StorageAccountName: blobConfig.StorageAccountName,
                    ContainerName: blobConfig.ContainerName,
                    BaseBlobPrefix: table.ArchivePathTemplate,
                    DateType: DateType.EOD,
                    DeleteAfterExport: table.DeleteAfterExport,
                    BatchDeleteSize: table.BatchDeleteSize);

                tablePlans[table.Id] = plan;
            }

            var cache = new ConfigurationCache(
                tablePlansByConfigId: tablePlans,
                blobConfigsById: blobConfigsById);

            logger.LogInformation("Configuration cache built: {TablePlanCount} table plans, {BlobConfigCount} blob configs",
                tablePlans.Count, blobConfigsById.Count);

            return Result<IConfigurationCache>.Success(cache);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to build configuration cache");
            return Result<IConfigurationCache>.Fail($"Failed to build configuration cache: {ex.Message}");
        }
    }
}


