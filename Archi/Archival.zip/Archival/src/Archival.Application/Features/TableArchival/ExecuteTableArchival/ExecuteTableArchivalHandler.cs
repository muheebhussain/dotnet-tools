﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Tables;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Caching;
using Archival.Application.Shared.BlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.ExecuteTableArchival;

/// <summary>
/// Executes table archival for a single table and business date.
/// This is a worker handler that performs the actual archival work including
/// exporting data to Parquet, marking datasets as succeeded, and optionally
/// deleting source data.
/// </summary>
/// <remarks>
/// <para><b>Handler Pattern: Worker</b></para>
/// <para>
/// This handler follows the worker pattern where:
/// - It performs a specific task (archive single table/date)
/// - It returns a typed result (ExecuteTableArchivalResponse)
/// - It does NOT manage run tracking (that's done by RunTableArchivalHandler)
/// - It can be called independently or as part of an orchestration
/// </para>
/// <para>
/// The "Execute" prefix (verb) distinguishes worker handlers from orchestration
/// handlers (which use "Run" prefix). Worker handlers focus on doing specific
/// work and returning results, while orchestrators manage workflow and tracking.
/// </para>
/// </remarks>
public sealed class ExecuteTableArchivalHandler(
    IDatasetStore datasetStore,
    IBusinessCalendar businessCalendar,
    IConnectionStringResolver connectionStringResolver,
    ITableArchiver tableArchiver,
    IArchivePathTemplateExpander templateExpander,
    IConfigurationStore configurationStore,
    IBlobDatasetStore blobDatasetStore,
    ILogger<ExecuteTableArchivalHandler> logger,
    IClock clock)
{
    public async Task<Result<ExecuteTableArchivalResponse>> HandleAsync(
        ExecuteTableArchivalCommand command,
        IConfigurationCache configCache,
        DatasetDetailDto? preLoadedDataset,
        CancellationToken ct)
    {
        logger.LogInformation("Executing table archival: TableConfigId={TableConfigId}, BusinessDate={BusinessDate}",
            command.TableConfigurationId, command.BusinessDate);

        // Get execution plan from configuration cache (no DB call)
        if (!configCache.TryGetTablePlan(command.TableConfigurationId, out var plan))
            return Result<ExecuteTableArchivalResponse>.Fail($"Table plan not found in cache for config ID {command.TableConfigurationId}");

        var sourceConn = connectionStringResolver.ResolveSourceConnection(plan.DatabaseName);
        var storageConn = connectionStringResolver.ResolveStorageConnection(plan.StorageAccountName);

        // Determine date type for this specific business date from the business calendar
        var classifiedDates = await businessCalendar.GetClassifiedDatesAsync(
            sourceConn,
            command.BusinessDate,
            command.BusinessDate.AddDays(1),
            ct);
        var dateType = classifiedDates.FirstOrDefault()?.DateType ?? DateType.EOD;
        logger.LogDebug("Classified business date {Date}: {DateType}", command.BusinessDate, dateType);

        // Check if already successfully exported (skip only succeeded datasets, allow retry of failed)
        // Phase 2 Optimization: Use pre-loaded dataset if provided, otherwise query
        var existingDataset = preLoadedDataset ?? await datasetStore.GetDatasetAsync(command.TableConfigurationId, command.BusinessDate, ct);
        if (existingDataset?.Status == DatasetStatus.Succeeded)
        {
            logger.LogInformation("Dataset already successfully exists, attempting to push internal blob dataset if missing: TableConfigId={TableConfigId}, Date={Date}",
                command.TableConfigurationId, command.BusinessDate);

            // Attempt push (idempotent upsert) for internal blob dataset tracking
            // This allows recovery from previous push failures on subsequent runs
            try
            {
                await PushInternalBlobDatasetAsync(
                    command.TableConfigurationId,
                    command.BusinessDate,
                    existingDataset.StorageAccountName,
                    existingDataset.ContainerName,
                    existingDataset.BlobPrefix,
                    existingDataset.DatasetId,
                    ct);

                logger.LogInformation("Successfully pushed internal blob dataset for existing succeeded dataset: TableConfigId={TableConfigId}, Date={Date}",
                    command.TableConfigurationId, command.BusinessDate);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Failed to push internal blob dataset for existing succeeded dataset: TableConfigId={TableConfigId}",
                    command.TableConfigurationId);
                // Continue - the archival itself succeeded, this is just post-processing
            }

            return Result<ExecuteTableArchivalResponse>.Success(new ExecuteTableArchivalResponse(false, false, 0, 0));
        }

        long datasetId;
        if (existingDataset != null)
        {
            // Reuse existing dataset record (regardless of status: Pending, Processing, Failed, etc.)
            // This ensures we don't violate the unique constraint on (table_config_id, as_of_date)
            datasetId = existingDataset.DatasetId;

            var statusLog = existingDataset.Status == DatasetStatus.Failed
                ? "Retrying previously failed dataset"
                : $"Reusing existing dataset with status {existingDataset.Status}";

            logger.LogInformation("{StatusLog}: TableConfigId={TableConfigId}, Date={Date}, DatasetId={DatasetId}",
                statusLog, command.TableConfigurationId, command.BusinessDate, datasetId);
        }
        else
        {
            // Create new dataset record only if one doesn't exist
            datasetId = await datasetStore.CreateDatasetAsync(
                command.TableConfigurationId,
                command.BusinessDate,
                dateType,
                plan.StorageAccountName,
                plan.ContainerName,
                "", // temporary, will be set below
                ct);
        }

        // Expand archive path template with actual values
        var templateContext = new ArchivePathTemplateContext(
            DatabaseName: plan.DatabaseName,
            SchemaName: plan.SchemaName,
            TableName: plan.TableName,
            AsOfDate: command.BusinessDate,
            DateType: dateType);

        var blobPrefix = templateExpander.ExpandTemplate(plan.BaseBlobPrefix, templateContext);

        // Ensure trailing slash for blob prefix
        if (!blobPrefix.EndsWith('/'))
            blobPrefix += "/";

        logger.LogDebug("Expanded archive path template: Template={Template}, Expanded={Expanded}",
            plan.BaseBlobPrefix, blobPrefix);

        // Export using plan configuration
        var exportResult = await tableArchiver.ExportToParquetAsync(
            sourceConn,
            plan.SchemaName,
            plan.TableName,
            plan.BusinessDateColumnName,
            command.BusinessDate,
            storageConn,
            plan.ContainerName,
            blobPrefix,
            ct);

        if (!exportResult.Ok)
        {
            await datasetStore.MarkDatasetFailedAsync(datasetId, exportResult.Error ?? "Export failed", ct);
            return Result<ExecuteTableArchivalResponse>.Fail($"Export failed: {exportResult.Error}");
        }

        // Mark dataset succeeded and push blob dataset atomically
        // IDatasetStore handles transaction internally in the Data layer
        var transactionResult = await datasetStore.MarkDatasetSucceededAndPushBlobDatasetAsync(
            datasetId,
            exportResult.Value!.PartCount,
            exportResult.Value.RowCount,
            exportResult.Value.TotalBytes,
            command.TableConfigurationId,
            command.BusinessDate,
            plan.StorageAccountName,
            plan.ContainerName,
            blobPrefix,
            ct);

        if (!transactionResult.Ok)
        {
            return Result<ExecuteTableArchivalResponse>.Fail(transactionResult.Error ?? "Failed to mark dataset succeeded and push blob dataset");
        }

        // Delete if configured in plan
        var deleteSucceeded = false;
        if (plan.DeleteAfterExport)
        {
            var deleteResult = await tableArchiver.DeleteRowsAsync(
                sourceConn,
                plan.SchemaName,
                plan.TableName,
                plan.BusinessDateColumnName,
                command.BusinessDate,
                plan.BatchDeleteSize,
                ct);

            deleteSucceeded = deleteResult.Ok;
            if (!deleteResult.Ok)
            {
                logger.LogWarning("Delete failed: {Error}", deleteResult.Error);
            }
        }

        logger.LogInformation("Table archival completed: Rows={Rows}, Bytes={Bytes}, Parts={Parts}, Deleted={Deleted}",
            exportResult.Value.RowCount, exportResult.Value.TotalBytes, exportResult.Value.PartCount, deleteSucceeded);

        return Result<ExecuteTableArchivalResponse>.Success(new ExecuteTableArchivalResponse(
            true,
            deleteSucceeded,
            exportResult.Value.RowCount,
            exportResult.Value.TotalBytes));
    }

    private async Task PushInternalBlobDatasetAsync(
        int tableConfigurationId,
        DateOnly businessDate,
        string storageAccountName,
        string containerName,
        string blobPrefix,
        long datasetId,
        CancellationToken ct)
    {
        // Get table configuration to access blob configuration
        var tableConfig = await configurationStore.GetTableConfigurationAsync(tableConfigurationId, ct);
        if (tableConfig?.BlobConfigurationId is null or <= 0)
        {
            logger.LogDebug("Table config {TableConfigId} has no blob configuration, skipping blob dataset push",
                tableConfigurationId);
            return;
        }

        // Load blob configuration
        var blobConfig = await configurationStore.GetBlobConfigurationAsync(tableConfig.BlobConfigurationId, ct);
        if (blobConfig is null)
        {
            logger.LogWarning("Blob configuration {BlobConfigId} not found, skipping blob dataset push",
                tableConfig.BlobConfigurationId);
            return;
        }

        // Load policy for scheduling
        var policy = await configurationStore.GetLifecyclePolicyAsync(blobConfig.BlobPolicyId, ct);
        if (policy is null || !policy.IsActive)
        {
            logger.LogWarning("Blob policy {PolicyId} not found or inactive, skipping blob dataset push",
                blobConfig.BlobPolicyId);
            return;
        }

        // Compute next action
        // Note: Archive support determined at runtime via fallback mechanism
        var (nextAction, nextActionAt) = BlobDatasetScheduler.ComputeNext(
            policy, supportsArchiveTier: true, businessDate, clock.UtcNow);

        // Upsert blob dataset
        var upsertDto = new BlobDatasetUpsertDto(
            BlobConfigurationId: blobConfig.Id,
            SourceType: BlobDatasetSourceType.Internal,
            AsOfDate: businessDate,
            StorageAccountName: storageAccountName,
            ContainerName: containerName,
            BlobPrefix: blobPrefix,
            ArchivalDatasetId: datasetId,
            CurrentTier: BlobTierState.Hot,
            NextAction: nextAction,
            NextActionAt: nextActionAt);

        await blobDatasetStore.UpsertAsync(upsertDto, ct);

        logger.LogInformation("Pushed internal blob dataset: BlobConfigId={BlobConfigId}, DatasetId={DatasetId}, Prefix={Prefix}, NextAction={NextAction}",
            blobConfig.Id, datasetId, blobPrefix, nextAction);
    }
}
