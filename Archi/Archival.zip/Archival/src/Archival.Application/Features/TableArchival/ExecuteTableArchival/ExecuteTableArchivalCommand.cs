﻿namespace Archival.Application.Features.TableArchival.ExecuteTableArchival;

public sealed record ExecuteTableArchivalCommand(
    int TableConfigurationId,
    DateOnly BusinessDate);

public sealed record ExecuteTableArchivalResponse(
    bool ExportSucceeded,
    bool DeleteSucceeded,
    long RowsArchived,
    long BytesArchived);

