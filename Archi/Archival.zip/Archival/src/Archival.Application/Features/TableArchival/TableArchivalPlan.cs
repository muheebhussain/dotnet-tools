﻿namespace Archival.Application.Features.TableArchival;

/// <summary>
/// Execution plan for table archival derived from configuration.
/// Centralizes all configuration decisions to remove hardcoded defaults.
/// </summary>
public sealed record TableArchivalPlan(
    int TableConfigurationId,
    string DatabaseName,
    string SchemaName,
    string TableName,
    string BusinessDateColumnName,
    string StorageAccountName,
    string ContainerName,
    string BaseBlobPrefix,
    Shared.Models.DateType DateType,
    bool DeleteAfterExport,
    int BatchDeleteSize);

