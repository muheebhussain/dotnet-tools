﻿using System.Collections.Concurrent;
using Archival.Application.Configuration;
using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.BlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Archival.Application.Features.BlobLifecycle.ExecuteBlobDatasets;

/// <summary>
/// Handler for executing lifecycle actions on discovered blob datasets.
/// Processes due datasets with bounded concurrency, applies tier changes and deletions,
/// and cleans up empty HNS directories.
/// </summary>
public sealed class ExecuteBlobDatasetsHandler(
    IConfigurationStore configurationStore,
    IBlobDatasetStore blobDatasetStore,
    IExemptionsStore exemptionsStore,
    IConnectionStringResolver connectionStringResolver,
    IBlobLister blobLister,
    IBlobLifecycleExecutor blobLifecycleExecutor,
    IOptions<BlobLifecycleOptions> options,
    ILogger<ExecuteBlobDatasetsHandler> logger,
    IClock clock)
{
    private readonly BlobLifecycleOptions _options = options.Value;
    private const int DatasetsPerBatch = 100;

    public async Task<Result<ExecuteBlobDatasetsResponse>> HandleAsync(ExecuteBlobDatasetsCommand command, CancellationToken ct)
    {
        logger.LogInformation("Starting blob dataset execution: Mode={Mode}", command.BlobMode);

        int configurationsProcessed = 0;
        int actionsExecuted = 0;
        int actionsFailed = 0;

        try
        {
            // Get target configurations
            var configs = await GetTargetConfigurationsAsync(command, ct);
            logger.LogInformation("Found {ConfigCount} target blob configurations", configs.Count);

            foreach (var config in configs)
            {
                configurationsProcessed++;

                try
                {
                    // Load policy
                    var policy = await configurationStore.GetLifecyclePolicyAsync(config.BlobPolicyId, ct);
                    if (policy is null || !policy.IsActive)
                    {
                        logger.LogWarning("Skipping config {ConfigId}: policy not found or inactive", config.Id);
                        continue;
                    }

                    // Process datasets in batches with bounded concurrency
                    int datasetCount = await ProcessConfigurationDatasetsAsync(
                        config, policy, command, ct);

                    actionsExecuted += datasetCount;
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error processing config {ConfigId}", config.Id);
                    actionsFailed++;
                }
            }

            logger.LogInformation("Blob dataset execution completed: Configs={Configs}, Actions={Actions}, Failed={Failed}",
                configurationsProcessed, actionsExecuted, actionsFailed);

            return Result<ExecuteBlobDatasetsResponse>.Success(
                new ExecuteBlobDatasetsResponse(configurationsProcessed, actionsExecuted, actionsFailed));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error during blob dataset execution");
            return Result<ExecuteBlobDatasetsResponse>.Fail($"Blob dataset execution failed: {ex.Message}");
        }
    }

    private async Task<List<BlobConfigurationDto>> GetTargetConfigurationsAsync(
        ExecuteBlobDatasetsCommand command, CancellationToken ct)
    {
        var allConfigs = await configurationStore.GetEnabledBlobConfigurationsAsync(ct);

        // Filter by target selection
        var filtered = command.AllTargets
            ? allConfigs.ToList()
            : allConfigs.Where(c => c.Id == command.TargetId).ToList();

        // Filter by mode
        if (command.BlobMode == "external")
            filtered = filtered.Where(c => c.IsExternal).ToList();
        else if (command.BlobMode == "internal")
            filtered = filtered.Where(c => !c.IsExternal).ToList();

        return filtered;
    }

    private async Task<int> ProcessConfigurationDatasetsAsync(
        BlobConfigurationDto config,
        LifecyclePolicyDto policy,
        ExecuteBlobDatasetsCommand command,
        CancellationToken ct)
    {
        logger.LogInformation("Processing datasets for config {ConfigId}", config.Id);

        int totalExecuted = 0;

        // Fetch exemption matcher ONCE per configuration
        var exemptionMatcher = await exemptionsStore.GetBlobExemptionMatcherAsync(config.Id, ct);

        logger.LogDebug("Built exemption matcher for config {ConfigId}", config.Id);

        // Storage-side limiter for listing/tiering/delete calls
        using var blobOpsSemaphore = new SemaphoreSlim(_options.BlobOperationsParallelism, _options.BlobOperationsParallelism);

        // Process in batches
        while (true)
        {
            // Query due datasets
            var datasets = await blobDatasetStore.GetDueAsync(
                config.Id,
                clock.UtcNow,
                DatasetsPerBatch,
                ct);

            if (datasets.Count == 0)
                break;

            logger.LogInformation("Processing {Count} due datasets for config {ConfigId}",
                datasets.Count, config.Id);

            // Process with bounded concurrency, passing pre-built matcher
            using var semaphore = new SemaphoreSlim(_options.DatasetsParallelism, _options.DatasetsParallelism);
            var tasks = datasets.Select(dataset => ProcessDatasetAsync(
                dataset, config, policy, exemptionMatcher, blobOpsSemaphore, semaphore, ct));

            var results = await Task.WhenAll(tasks);

            // Batch update all dataset results in one DB call
            await blobDatasetStore.MarkActionResultsBatchAsync(results, ct);

            totalExecuted += datasets.Count;
        }

        return totalExecuted;
    }

    private async Task<BlobDatasetMarkBatchItem> ProcessDatasetAsync(
        BlobDatasetDto dataset,
        BlobConfigurationDto config,
        LifecyclePolicyDto policy,
        Archival.Application.BlobLifecycle.BlobExemptionMatcher exemptionMatcher,
        SemaphoreSlim blobOpsSemaphore,
        SemaphoreSlim semaphore,
        CancellationToken ct)
    {
        await semaphore.WaitAsync(ct);
        try
        {
            logger.LogDebug("Processing dataset: ConfigId={ConfigId}, Prefix={Prefix}, AsOfDate={AsOfDate}",
                config.Id, dataset.BlobPrefix, dataset.AsOfDate.ToString("yyyy-MM-dd"));

            var storageConn = connectionStringResolver.ResolveStorageConnection(config.StorageAccountName);
            string? lastError = null;
            BlobDatasetLastAction lastAction = BlobDatasetLastAction.None;
            BlobDatasetNextAction nextAction = dataset.NextAction;

            try
            {
                // If NextAction = None (scheduled dataset), recalculate the action for today
                if (nextAction == BlobDatasetNextAction.None)
                {
                    var (calculatedAction, _) = BlobDatasetScheduler.ComputeNext(
                        policy, supportsArchiveTier: true, dataset.AsOfDate, clock.UtcNow);
                    nextAction = calculatedAction;

                    logger.LogDebug(
                        "Recalculated action for scheduled dataset {Id}: {Action}",
                        dataset.Id, nextAction);
                }

                // List blobs under this dataset prefix (guarded by storage limiter)
                var blobs = new List<BlobItem>();
                await blobOpsSemaphore.WaitAsync(ct);
                try
                {
                    await foreach (var blob in blobLister.ListBlobsAsync(
                        storageConn,
                        config.ContainerName,
                        dataset.BlobPrefix,
                        ct))
                    {
                        bool isExempt = exemptionMatcher.IsExempt(
                            config.ContainerName,
                            blob.Name,
                            dataset.AsOfDate);

                        if (!isExempt)
                            blobs.Add(blob);
                    }
                }
                finally
                {
                    blobOpsSemaphore.Release();
                }

                logger.LogDebug("Found {BlobCount} non-exempted blobs for dataset {Prefix}",
                    blobs.Count, dataset.BlobPrefix);

                // Execute action (using recalculated action if needed)
                switch (nextAction)
                {
                    case BlobDatasetNextAction.SetCold:
                        var (coldSuccess, coldError) = await ExecuteSetColdAsync(blobs, config, storageConn, blobOpsSemaphore, ct);
                        lastAction = coldSuccess ? BlobDatasetLastAction.SetCold : BlobDatasetLastAction.None;
                        if (!coldSuccess) lastError = coldError;
                        break;

                    case BlobDatasetNextAction.SetArchive:
                        var (archiveSuccess, archiveError) = await ExecuteSetArchiveAsync(blobs, config, storageConn, blobOpsSemaphore, ct);
                        lastAction = archiveSuccess ? BlobDatasetLastAction.SetArchive : BlobDatasetLastAction.None;
                        if (!archiveSuccess) lastError = archiveError;
                        break;

                    case BlobDatasetNextAction.Delete:
                        var (deleteSuccess, deleteError) = await ExecuteDeleteAsync(
                            dataset, config, storageConn, ct);
                        lastAction = deleteSuccess ? BlobDatasetLastAction.Delete : BlobDatasetLastAction.None;
                        if (!deleteSuccess) lastError = deleteError;
                        break;

                    default:
                        lastAction = BlobDatasetLastAction.None;
                        break;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error processing dataset {Prefix}", dataset.BlobPrefix);
                lastError = ex.Message;
                lastAction = BlobDatasetLastAction.None;
            }

            var markDto = new BlobDatasetMarkResultDto(
                lastAction,
                clock.UtcNow,
                lastError,
                null); // No retry scheduling for now

            return new BlobDatasetMarkBatchItem(dataset.Id, markDto);
        }
        finally
        {
            semaphore.Release();
        }
    }

    private async Task<(bool Success, string? Error)> ExecuteSetColdAsync(
        List<BlobItem> blobs,
        BlobConfigurationDto config,
        string storageConn,
        SemaphoreSlim blobOpsSemaphore,
        CancellationToken ct)
    {
        if (blobs.Count == 0)
            return (true, null);

        int successCount = 0;
        var errors = new ConcurrentQueue<string>();

        foreach (var batch in blobs.Chunk(_options.BlobOperationsBatchSize))
        {
            var tasks = batch.Select(async blob =>
            {
                await blobOpsSemaphore.WaitAsync(ct);
                try
                {
                    bool success = await blobLifecycleExecutor.TrySetColdAsync(
                        storageConn, config.ContainerName, blob.Name, ct);
                    if (success)
                        Interlocked.Increment(ref successCount);
                    else
                        errors.Enqueue($"SetCold failed on {blob.Name}");
                }
                catch (Exception ex)
                {
                    errors.Enqueue($"SetCold error on {blob.Name}: {ex.Message}");
                    logger.LogWarning(ex, "Failed to set cold: {BlobName}", blob.Name);
                }
                finally
                {
                    blobOpsSemaphore.Release();
                }
            });

            await Task.WhenAll(tasks);
        }

        bool allSucceeded = successCount == blobs.Count;
        logger.LogInformation("SetCold complete: {Success}/{Total} blobs", successCount, blobs.Count);
        return (allSucceeded, errors.LastOrDefault());
    }

    private async Task<(bool Success, string? Error)> ExecuteSetArchiveAsync(
        List<BlobItem> blobs,
        BlobConfigurationDto config,
        string storageConn,
        SemaphoreSlim blobOpsSemaphore,
        CancellationToken ct)
    {
        if (blobs.Count == 0)
            return (true, null);

        int successCount = 0;
        int archiveCount = 0;
        int coldFallbackCount = 0;
        var errors = new ConcurrentQueue<string>();

        foreach (var batch in blobs.Chunk(_options.BlobOperationsBatchSize))
        {
            var tasks = batch.Select(async blob =>
            {
                await blobOpsSemaphore.WaitAsync(ct);
                try
                {
                    var (archiveSuccess, archiveReason) = await blobLifecycleExecutor.TrySetArchiveWithReasonAsync(
                        storageConn, config.ContainerName, blob.Name, ct);

                    if (archiveSuccess)
                    {
                        Interlocked.Increment(ref successCount);
                        Interlocked.Increment(ref archiveCount);
                    }
                    else if (archiveReason == ArchiveFailureReason.NotSupported)
                    {
                        logger.LogDebug("Archive not supported, falling back to Cold: {BlobName}", blob.Name);
                        bool coldSuccess = await blobLifecycleExecutor.TrySetColdAsync(
                            storageConn, config.ContainerName, blob.Name, ct);
                        if (coldSuccess)
                        {
                            Interlocked.Increment(ref successCount);
                            Interlocked.Increment(ref coldFallbackCount);
                        }
                        else
                        {
                            errors.Enqueue($"SetCold fallback failed on {blob.Name}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    errors.Enqueue($"SetArchive error on {blob.Name}: {ex.Message}");
                    logger.LogWarning(ex, "Failed to set archive with fallback: {BlobName}", blob.Name);
                }
                finally
                {
                    blobOpsSemaphore.Release();
                }
            });

            await Task.WhenAll(tasks);
        }

        bool allSucceeded = successCount == blobs.Count;
        logger.LogInformation("SetArchive complete: {Success}/{Total} blobs (Archive={Archive}, ColdFallback={ColdFallback})",
            successCount, blobs.Count, archiveCount, coldFallbackCount);
        return (allSucceeded, errors.LastOrDefault());
    }

    private async Task<(bool Success, string? Error)> ExecuteDeleteAsync(
        BlobDatasetDto dataset,
        BlobConfigurationDto config,
        string storageConn,
        CancellationToken ct)
    {
        try
        {
            var result = await blobLifecycleExecutor.DeletePrefixAndCleanupParentsAsync(
                storageConn,
                config.ContainerName,
                dataset.BlobPrefix,
                config.Prefix,
                ct);

            if (!result.Ok)
            {
                return (false, result.Error);
            }

            logger.LogInformation("Delete complete: {BlobsDeleted} blobs, {ParentsDeleted} parent dirs",
                result.Value!.BlobsDeleted, result.Value!.ParentDirectoriesDeleted);

            return (true, null);
        }
        catch (Exception ex)
        {
            var error = $"Delete error: {ex.Message}";
            logger.LogError(ex, "Failed to delete prefix: {Prefix}", dataset.BlobPrefix);
            return (false, error);
        }
    }
}

public sealed record ExecuteBlobDatasetsCommand(
    bool AllTargets,
    int? TargetId,
    string? BlobMode = "all");

public sealed record ExecuteBlobDatasetsResponse(
    int ConfigurationsProcessed,
    int ActionsExecuted,
    int ActionsFailed);

