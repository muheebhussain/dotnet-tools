﻿﻿using Archival.Application.Contracts.BlobLifecycle;
using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.BlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;
using System.Globalization;

namespace Archival.Application.Features.BlobLifecycle.DiscoverBlobDatasets;

/// <summary>
/// Handler for discovering external blob datasets by listing date folders.
/// Populates ArchivalBlobDataset rows for external configurations.
/// </summary>
public sealed class DiscoverBlobDatasetsHandler(
    IConfigurationStore configurationStore,
    IBlobPrefixLister blobPrefixLister,
    IDatasetPathTemplateExpander pathTemplateExpander,
    IBlobDatasetStore blobDatasetStore,
    IConnectionStringResolver connectionStringResolver,
    ILogger<DiscoverBlobDatasetsHandler> logger,
    IClock clock)
{
    public async Task<Result<DiscoverBlobDatasetsResponse>> HandleAsync(DiscoverBlobDatasetsCommand command, CancellationToken ct)
    {
        logger.LogInformation("Starting blob dataset discovery: AllTargets={AllTargets}, TargetId={TargetId}, Mode={Mode}",
            command.AllTargets, command.TargetId, command.BlobMode);

        int configurationsProcessed = 0;
        int datasetsDiscovered = 0;
        int datasetsUpserted = 0;

        try
        {
            // Get target configurations
            var configs = await GetTargetConfigurationsAsync(command, ct);
            logger.LogInformation("Found {ConfigCount} target blob configurations", configs.Count);

            foreach (var config in configs)
            {
                configurationsProcessed++;

                // Skip internal configurations
                if (!config.IsExternal)
                {
                    logger.LogDebug("Skipping internal configuration: {ConfigId}", config.Id);
                    continue;
                }

                // Validate external configuration
                if (string.IsNullOrWhiteSpace(config.DatasetPathTemplate) || string.IsNullOrWhiteSpace(config.BusinessDateFolderFormat))
                {
                    logger.LogWarning("Skipping external configuration {ConfigId}: DatasetPathTemplate or BusinessDateFolderFormat not configured", config.Id);
                    continue;
                }

                // Discover datasets for this configuration
                int discovered = await DiscoverConfigurationAsync(config, ct);
                datasetsDiscovered += discovered;
                datasetsUpserted += discovered; // Each discovered is upserted
            }

            logger.LogInformation("Blob dataset discovery completed: Configs={ConfigCount}, Discovered={DiscoveredCount}, Upserted={UpsertedCount}",
                configurationsProcessed, datasetsDiscovered, datasetsUpserted);

            return Result<DiscoverBlobDatasetsResponse>.Success(
                new DiscoverBlobDatasetsResponse(configurationsProcessed, datasetsDiscovered, datasetsUpserted));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error during blob dataset discovery");
            return Result<DiscoverBlobDatasetsResponse>.Fail($"Blob dataset discovery failed: {ex.Message}");
        }
    }

    private async Task<List<BlobConfigurationDto>> GetTargetConfigurationsAsync(DiscoverBlobDatasetsCommand command, CancellationToken ct)
    {
        var allConfigs = await configurationStore.GetEnabledBlobConfigurationsAsync(ct);

        // Filter by target selection
        var filtered = command.AllTargets
            ? allConfigs.ToList()
            : allConfigs.Where(c => c.Id == command.TargetId).ToList();

        // Filter by mode (internal/external/all)
        if (command.BlobMode == "external")
            filtered = filtered.Where(c => c.IsExternal).ToList();
        else if (command.BlobMode == "internal")
            filtered = filtered.Where(c => !c.IsExternal).ToList();
        // "all" includes both

        return filtered;
    }

    private async Task<int> DiscoverConfigurationAsync(BlobConfigurationDto config, CancellationToken ct)
    {
        logger.LogInformation("Discovering datasets for external config: {ConfigId}, Prefix={Prefix}",
            config.Id, config.Prefix);

        int upsertedCount = 0;

        try
        {
            // Get storage connection
            var storageConn = connectionStringResolver.ResolveStorageConnection(config.StorageAccountName);

            // List date folder prefixes under config.Prefix
            var datePrefixes = await blobPrefixLister.ListPrefixesAsync(
                storageConn,
                config.ContainerName,
                config.Prefix,
                ct);

            logger.LogInformation("Found {PrefixCount} date folder prefixes under config {ConfigId}",
                datePrefixes.Count, config.Id);

            // Get policy to compute scheduling (for optimization)
            var policy = await configurationStore.GetLifecyclePolicyAsync(config.BlobPolicyId, ct);
            if (policy is null || !policy.IsActive)
            {
                logger.LogWarning("Skipping config {ConfigId}: policy not found or inactive", config.Id);
                return 0;
            }

            // Optional: compute threshold date and skip newer folders
            // Note: Archive support is now determined at runtime via fallback, so use all lifecycle thresholds
            var minThresholdDate = BlobDatasetScheduler.ComputeMinThresholdDate(policy, supportsArchiveTier: true, clock.UtcNow);
            logger.LogDebug("Config {ConfigId}: minimum threshold date for lifecycle action = {ThresholdDate}",
                config.Id, minThresholdDate?.ToString("yyyy-MM-dd") ?? "None");

            // Watermark (latest discovered date) for visibility
            var maxDiscoveredDate = await blobDatasetStore.GetMaxAsOfDateAsync(config.Id, ct);
            logger.LogDebug("Config {ConfigId}: latest discovered date = {MaxDate}",
                config.Id, maxDiscoveredDate?.ToString("yyyy-MM-dd") ?? "None");

            // Collect upserts by AsOfDate to avoid duplicates
            var upserts = new Dictionary<DateOnly, BlobDatasetUpsertDto>();

            // Process each date prefix
            foreach (var prefix in datePrefixes)
            {
                // Validate required fields before processing
                if (string.IsNullOrWhiteSpace(config.BusinessDateFolderFormat))
                {
                    logger.LogWarning("Skipping prefix {Prefix}: BusinessDateFolderFormat is null or empty", prefix);
                    continue;
                }

                if (string.IsNullOrWhiteSpace(config.DatasetPathTemplate))
                {
                    logger.LogWarning("Skipping prefix {Prefix}: DatasetPathTemplate is null or empty", prefix);
                    continue;
                }

                // Try to extract date from folder name
                if (TryParseDateFromPrefix(prefix, config.BusinessDateFolderFormat, config.BusinessDateFolderDepth, out var asOfDate))
                {
                    // Skip if newer than threshold (optimization)
                    if (minThresholdDate.HasValue && asOfDate > minThresholdDate.Value)
                    {
                        logger.LogDebug("Skipping prefix {Prefix}: date {Date} is newer than threshold {Threshold}",
                            prefix, asOfDate.ToString("yyyy-MM-dd"), minThresholdDate.Value.ToString("yyyy-MM-dd"));
                        continue;
                    }

                    // Render full dataset path
                    var datasetPrefix = RenderDatasetPath(
                        config.Prefix,
                        config.DatasetPathTemplate,
                        asOfDate,
                        config.BusinessDateFolderFormat);

                    // Compute next action using scheduler
                    // Note: Archive support determined at runtime via fallback mechanism
                    var (nextAction, nextActionAt) = BlobDatasetScheduler.ComputeNext(policy, supportsArchiveTier: true, asOfDate, clock.UtcNow);

                    // Upsert dataset
                    var upsertDto = new BlobDatasetUpsertDto(
                        BlobConfigurationId: config.Id,
                        SourceType: BlobDatasetSourceType.External,
                        AsOfDate: asOfDate,
                        StorageAccountName: config.StorageAccountName,
                        ContainerName: config.ContainerName,
                        BlobPrefix: datasetPrefix,
                        ArchivalDatasetId: null,
                        CurrentTier: BlobTierState.Unknown,
                        NextAction: nextAction,
                        NextActionAt: nextActionAt);

                    upserts[asOfDate] = upsertDto;
                }
                else
                {
                    logger.LogWarning("Could not parse business date from prefix: BlobConfigId={BlobConfigId}, Prefix={Prefix}, ExpectedFormat={ExpectedFormat}, FolderDepth={FolderDepth}",
                        config.Id, prefix, config.BusinessDateFolderFormat, config.BusinessDateFolderDepth);
                }
            }

            if (upserts.Count == 0)
                return 0;

            // Batch upsert
            var (inserted, updated) = await blobDatasetStore.UpsertBatchAsync(upserts.Values.ToList(), ct);
            upsertedCount = inserted + updated;

            logger.LogInformation("Completed discovery for config {ConfigId}: Inserted={Inserted}, Updated={Updated}",
                config.Id, inserted, updated);

            return upsertedCount;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error discovering datasets for config {ConfigId}", config.Id);
            throw;
        }
    }

    private bool TryParseDateFromPrefix(string prefix, string dateFormat, int folderDepth, out DateOnly asOfDate)
    {
        asOfDate = default;

        // Remove trailing slash for processing
        var trimmed = prefix.TrimEnd('/');

        // Split by / to get segments
        var segments = trimmed.Split('/', StringSplitOptions.RemoveEmptyEntries);

        // Get the segment at specified depth (1-based: depth 1 = last segment, depth 2 = second to last, etc.)
        if (segments.Length < folderDepth)
            return false;

        var dateSegment = segments[segments.Length - folderDepth];

        // Try parsing with the provided format
        // DateOnly.TryParseExact overload: (string, string[], IFormatProvider, DateTimeStyles, out DateOnly)
        return DateOnly.TryParseExact(
            dateSegment,
            new[] { dateFormat },
            CultureInfo.InvariantCulture,
            DateTimeStyles.None,
            out asOfDate);
    }

    private string RenderDatasetPath(string configPrefix, string template, DateOnly asOfDate, string? dateFolderFormat)
    {
        // Expand template with date context
        var context = new DatasetPathTemplateContext(asOfDate);
        var expanded = pathTemplateExpander.ExpandTemplate(template, context);

        // If template does not contain a date folder segment, insert the date folder
        if (!TemplateHasDateFolderSegment(template) && !string.IsNullOrWhiteSpace(dateFolderFormat))
        {
            var dateFolder = asOfDate.ToString(dateFolderFormat, CultureInfo.InvariantCulture);
            expanded = InsertDateFolder(expanded, dateFolder);
        }

        // Combine with config prefix
        var combined = configPrefix.TrimEnd('/') + "/" + expanded;

        // Normalize to forward slashes and remove duplicate slashes
        combined = combined.Replace('\\', '/');
        while (combined.Contains("//"))
            combined = combined.Replace("//", "/");

        return combined;
    }

    private static bool TemplateHasDateFolderSegment(string template)
    {
        var normalized = template.Replace('\\', '/');

        // Only treat date tokens as folder segments if they are delimited by '/'
        return normalized.Contains("/{yyyy}/", StringComparison.OrdinalIgnoreCase)
            || normalized.Contains("/{MM}/", StringComparison.OrdinalIgnoreCase)
            || normalized.Contains("/{dd}/", StringComparison.OrdinalIgnoreCase)
            || normalized.Contains("/{date}/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith("{yyyy}/", StringComparison.OrdinalIgnoreCase)
            || normalized.StartsWith("{date}/", StringComparison.OrdinalIgnoreCase);
    }

    private static string InsertDateFolder(string expandedPath, string dateFolder)
    {
        if (string.IsNullOrWhiteSpace(expandedPath))
            return dateFolder;

        var normalized = expandedPath.Replace('\\', '/').TrimStart('/');
        var segments = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries);

        if (segments.Length == 0)
            return dateFolder + "/";

        // If the path ends with '/', treat it as a directory and append date folder
        if (normalized.EndsWith("/", StringComparison.Ordinal))
            return normalized.TrimEnd('/') + "/" + dateFolder + "/";

        if (segments.Length == 1)
            return dateFolder + "/" + normalized;

        var parent = string.Join("/", segments[..^1]);
        var fileName = segments[^1];
        return parent + "/" + dateFolder + "/" + fileName;
    }
}
