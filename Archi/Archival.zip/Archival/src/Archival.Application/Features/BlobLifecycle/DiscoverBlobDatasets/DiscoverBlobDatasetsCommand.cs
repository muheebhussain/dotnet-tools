﻿namespace Archival.Application.Features.BlobLifecycle.DiscoverBlobDatasets;

public sealed record DiscoverBlobDatasetsCommand(
    bool AllTargets,
    int? TargetId,
    string? BlobMode = "all");

public sealed record DiscoverBlobDatasetsResponse(
    int ConfigurationsProcessed,
    int DatasetsDiscovered,
    int DatasetsUpserted);

