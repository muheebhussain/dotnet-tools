﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Results;

namespace Archival.Application.Features.Configurations.GetTableConfiguration;

public sealed class GetTableConfigurationHandler(
    IConfigurationStore configurationStore)
{
    public async Task<Result<GetTableConfigurationResponse>> HandleAsync(GetTableConfigurationQuery query, CancellationToken ct)
    {
        var config = await configurationStore.GetTableConfigurationAsync(query.TableConfigurationId, ct);
        if (config is null)
            return Result<GetTableConfigurationResponse>.Fail($"Table configuration {query.TableConfigurationId} not found");

        var policy = await configurationStore.GetTableRetentionPolicyAsync(config.TablePolicyId, ct);
        if (policy is null)
            return Result<GetTableConfigurationResponse>.Fail($"Retention policy {config.TablePolicyId} not found");

        return Result<GetTableConfigurationResponse>.Success(new GetTableConfigurationResponse(
            config.Id,
            config.DatabaseName,
            config.SchemaName,
            config.TableName,
            config.BusinessDateColumnName,
            config.TablePolicyId,
            config.BlobConfigurationId,
            config.ArchivePathTemplate,
            config.DeleteAfterExport,
            config.BatchDeleteSize,
            policy.KeepLastEod,
            policy.KeepLastEom,
            policy.KeepLastEoq,
            policy.KeepLastEoy));
    }
}
