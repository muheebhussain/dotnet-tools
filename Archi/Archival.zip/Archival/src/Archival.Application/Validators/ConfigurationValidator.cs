﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Validators;

/// <summary>
/// Validates table and blob configuration values to prevent runtime failures.
/// Ensures invariants like positive batch sizes and required fields are met.
/// </summary>
public static class ConfigurationValidator
{
    /// <summary>
    /// Validates a table configuration.
    /// </summary>
    public static Result ValidateTableConfiguration(TableConfigurationDto config)
    {
        if (config == null)
            return Result.Fail("Configuration is null");

        // Validate batch size
        if (config.BatchDeleteSize <= 0)
            return Result.Fail($"BatchDeleteSize must be positive, got {config.BatchDeleteSize}");

        // Validate archive path template is not empty
        if (string.IsNullOrWhiteSpace(config.ArchivePathTemplate))
            return Result.Fail("ArchivePathTemplate is required and cannot be empty");

        // Validate template contains no invalid blob path characters
        var invalidChars = new[] { '\\', '\"', '<', '>', '|', '?', '*' };
        var hasInvalidChar = config.ArchivePathTemplate.Any(c => invalidChars.Contains(c));
        if (hasInvalidChar)
            return Result.Fail($"ArchivePathTemplate contains invalid blob path characters. Invalid chars: {string.Join(", ", invalidChars)}");

        return Result.Success();
    }

    /// <summary>
    /// Validates a blob configuration.
    /// </summary>
    public static Result ValidateBlobConfiguration(BlobConfigurationDto config)
    {
        if (config == null)
            return Result.Fail("Configuration is null");

        // Validate storage account and container are not empty
        if (string.IsNullOrWhiteSpace(config.StorageAccountName))
            return Result.Fail("StorageAccountName is required");

        if (string.IsNullOrWhiteSpace(config.ContainerName))
            return Result.Fail("ContainerName is required");

        // Container name must follow Azure naming rules (lowercase, no underscores, etc.)
        if (!IsValidContainerName(config.ContainerName))
            return Result.Fail($"ContainerName '{config.ContainerName}' does not follow Azure container naming rules (3-63 chars, lowercase alphanumeric and hyphens only)");

        // Prefix should not start with slash
        if (config.Prefix != null && config.Prefix.StartsWith('/'))
            return Result.Fail("Prefix should not start with a forward slash");

        return Result.Success();
    }

    /// <summary>
    /// Validates Azure container naming rules:
    /// - 3 to 63 characters
    /// - Lowercase letters, numbers, and hyphens only
    /// - Must start and end with letter or number
    /// </summary>
    private static bool IsValidContainerName(string name)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length < 3 || name.Length > 63)
            return false;

        if (!char.IsLetterOrDigit(name[0]) || !char.IsLetterOrDigit(name[^1]))
            return false;

        return name.All(c => char.IsLower(c) || char.IsDigit(c) || c == '-');
    }
}

