﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Infrastructure;

public sealed record ClassifiedBusinessDate(BusinessDate BusinessDate, DateType DateType);

public interface IBusinessCalendar
{
    Task<IReadOnlyList<ClassifiedBusinessDate>> GetClassifiedDatesAsync(string sourceDbConn, DateOnly from, DateOnly to, CancellationToken ct);
}

public interface IPresentDateFinder
{
    Task<IReadOnlyList<BusinessDate>> GetPresentBusinessDatesAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        DateOnly from,
        DateOnly to,
        CancellationToken ct);
}


