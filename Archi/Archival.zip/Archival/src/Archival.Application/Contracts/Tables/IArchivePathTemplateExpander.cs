﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Tables;

/// <summary>
/// Context for expanding archive path template tokens.
/// </summary>
public sealed record ArchivePathTemplateContext(
    string DatabaseName,
    string SchemaName,
    string TableName,
    DateOnly AsOfDate,
    DateType DateType);

/// <summary>
/// Contract for expanding archive path templates with actual values.
/// Replaces tokens like {database}, {schema}, {table}, {yyyy}, {MM}, {dd} with real values.
/// </summary>
public interface IArchivePathTemplateExpander
{
    /// <summary>
    /// Expands an archive path template by replacing tokens with actual values from the context.
    /// </summary>
    /// <param name="template">Template string containing tokens to expand (e.g., "sales/{schema}/{table}/{yyyy}/{MM}/{dd}/")</param>
    /// <param name="context">Context containing values for token replacement</param>
    /// <returns>Expanded path with all tokens replaced</returns>
    string ExpandTemplate(string template, ArchivePathTemplateContext context);

    /// <summary>
    /// Validates that a template contains only known tokens.
    /// </summary>
    /// <param name="template">Template to validate</param>
    /// <exception cref="ArgumentException">Thrown if template contains unknown tokens</exception>
    void ValidateTemplate(string template);
}

