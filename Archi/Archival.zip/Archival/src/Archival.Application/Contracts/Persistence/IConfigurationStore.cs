﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Unified store interface for all configuration operations.
/// Consolidates table configurations, blob configurations, and policies.
/// </summary>
public interface IConfigurationStore
{
    // Table Configuration Operations
    Task<IReadOnlyList<TableConfigurationDto>> GetActiveTableConfigurationsAsync(CancellationToken ct);
    Task<TableConfigurationDto?> GetTableConfigurationAsync(int id, CancellationToken ct);

    // Table Policy Operations
    Task<TableRetentionPolicyDto?> GetTableRetentionPolicyAsync(int id, CancellationToken ct);

    // Blob Configuration Operations
    Task<IReadOnlyList<BlobConfigurationDto>> GetEnabledBlobConfigurationsAsync(CancellationToken ct);
    Task<BlobConfigurationDto?> GetBlobConfigurationAsync(int id, CancellationToken ct);

    // Blob Policy Operations
    Task<LifecyclePolicyDto?> GetLifecyclePolicyAsync(int id, CancellationToken ct);
}

