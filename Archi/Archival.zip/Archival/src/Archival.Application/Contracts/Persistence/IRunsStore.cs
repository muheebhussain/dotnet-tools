﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for managing archival runs in the metadata database.
/// Provides operations to start, complete, and track archival operations.
/// </summary>
public interface IRunsStore
{
    /// <summary>
    /// Creates a new run record and marks it as started.
    /// </summary>
    /// <param name="runType">Type of run (Archive for table archival, Lifecycle for blob management).</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Created run DTO containing the run ID and start timestamp.</returns>
    Task<RunDto> StartRunAsync(RunType runType, CancellationToken ct);

    /// <summary>
    /// Marks a run as completed with the specified status and optional note.
    /// </summary>
    /// <param name="runId">ID of the run to complete.</param>
    /// <param name="status">Final status of the run (Succeeded, Failed, PartiallySucceeded).</param>
    /// <param name="note">Optional descriptive note about the run completion (e.g., error summary, stats).</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    Task CompleteRunAsync(long runId, RunStatus status, string? note, CancellationToken ct);
}

