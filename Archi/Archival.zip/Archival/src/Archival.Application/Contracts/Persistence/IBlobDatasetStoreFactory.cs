﻿namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Factory for creating isolated BlobDatasetStore instances for thread-safe concurrent operations.
/// Each call creates a new store with its own DbContext to prevent threading conflicts.
/// </summary>
public interface IBlobDatasetStoreFactory
{
    /// <summary>
    /// Creates a new IBlobDatasetStore instance with an isolated DbContext.
    /// Used for concurrent operations to avoid shared DbContext state.
    /// </summary>
    IBlobDatasetStore CreateStore();
}

