﻿using Archival.Application.BlobLifecycle;
using Archival.Application.Shared.Results;

 namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for exemption access (table and blob exemptions).
/// </summary>
public interface IExemptionsStore
{
    Task<IReadOnlySet<(int TableConfigurationId, DateOnly AsOfDate)>> GetTableExemptionsAsync(int tableConfigurationId, CancellationToken ct);

    /// <summary>
    /// Batch query exemptions for multiple table configurations.
    /// Returns dictionary keyed by tableConfigurationId with set of exempted dates.
    /// Reduces N individual DB calls to 1 batch query.
    /// </summary>
    Task<IReadOnlyDictionary<int, IReadOnlySet<DateOnly>>> GetTableExemptionsByTableIdsAsync(
        IReadOnlyList<int> tableConfigurationIds,
        CancellationToken ct);

    /// <summary>
    /// Get blob exemption matcher with materialized exemptions.
    /// Returns a ready-to-use matcher for efficient exemption checking.
    /// </summary>
    Task<BlobExemptionMatcher> GetBlobExemptionMatcherAsync(int blobConfigurationId, CancellationToken ct);

    /// <summary>
    /// Add a table exemption with unique constraint validation.
    /// Returns failure if duplicate already exists.
    /// </summary>
    Task<Result<bool>> AddTableExemptionAsync(int tableConfigurationId, DateOnly asOfDate, string reason, string? createdBy, CancellationToken ct);

    /// <summary>
    /// Add a blob exemption with unique constraint validation.
    /// Returns failure if duplicate already exists.
    /// </summary>
    Task<Result<bool>> AddBlobExemptionAsync(int blobConfigurationId, string prefix, string? containerName, DateOnly asOfDate, string reason, string? createdBy, CancellationToken ct);
}

