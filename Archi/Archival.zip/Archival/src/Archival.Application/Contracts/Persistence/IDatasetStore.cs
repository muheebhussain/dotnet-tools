﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for dataset tracking and lifecycle management.
/// </summary>
public interface IDatasetStore
{
    Task<bool> DatasetExistsAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct);
    Task<DatasetDetailDto?> GetDatasetAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct);

    /// <summary>
    /// Batch query multiple datasets by table configuration ID and dates.
    /// Returns dictionary keyed by (tableConfigId, asOfDate) tuple with dataset details.
    /// Reduces N individual DB calls to 1 batch query.
    /// </summary>
    Task<IReadOnlyDictionary<(int TableConfigId, DateOnly AsOfDate), DatasetDetailDto>> GetDatasetsByTableAndDatesAsync(
        int tableConfigId,
        IReadOnlyList<DateOnly> asOfDates,
        CancellationToken ct);

    Task<long> CreateDatasetAsync(int tableConfigId, DateOnly asOfDate, DateType dateType, string storageAccountName, string containerName, string blobPrefix, CancellationToken ct);
    Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct);
    Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct);

    /// <summary>
    /// Mark dataset as succeeded and push internal blob dataset atomically.
    /// Transaction is managed internally in the Data layer.
    /// If push fails, entire transaction is rolled back and dataset marked Failed.
    /// </summary>
    Task<Result<bool>> MarkDatasetSucceededAndPushBlobDatasetAsync(
        long datasetId,
        int partCount,
        long rowCount,
        long totalBytes,
        int tableConfigurationId,
        DateOnly businessDate,
        string storageAccountName,
        string containerName,
        string blobPrefix,
        CancellationToken ct);
}
