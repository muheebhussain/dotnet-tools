﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Data transfer object for batch run item insertion.
/// Used by Phase 5 optimization to collect multiple run items before batch insert.
/// </summary>
public sealed record RunItemBatchDto(
    RunItemType ItemType,
    RunItemStatus Status,
    int? TableConfigurationId = null,
    DateOnly? AsOfDate = null,
    int? BlobConfigurationId = null,
    LifecycleAction? Action = null,
    long? RowsAffected = null,
    long? BytesAffected = null,
    string? ItemKey = null,
    string? Error = null);

