﻿﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for blob dataset persistence and lifecycle management.
/// </summary>
public interface IBlobDatasetStore
{
    /// <summary>
    /// Upserts a blob dataset record. Uses unique index (BlobConfigurationId, AsOfDate, BlobPrefix) for idempotency.
    /// </summary>
    Task UpsertAsync(BlobDatasetUpsertDto dto, CancellationToken ct);

    /// <summary>
    /// Batch upsert multiple blob datasets in one DB round-trip.
    /// Returns counts of inserted and updated records.
    /// </summary>
    Task<(int Inserted, int Updated)> UpsertBatchAsync(
        IReadOnlyList<BlobDatasetUpsertDto> dtos,
        CancellationToken ct);

    /// <summary>
    /// Gets the maximum AsOfDate discovered for a blob configuration.
    /// Used as a watermark for discovery efficiency.
    /// </summary>
    Task<DateOnly?> GetMaxAsOfDateAsync(int blobConfigId, CancellationToken ct);

    /// <summary>
    /// Retrieves datasets due for lifecycle action, ordered by NextActionAt.
    /// Filters to records where NextActionAt <= utcNow and IsDeleted = false.
    /// </summary>
    Task<IReadOnlyList<BlobDatasetDto>> GetDueAsync(int blobConfigId, DateTime utcNow, int batchSize, CancellationToken ct);

    /// <summary>
    /// Marks a dataset action as attempted/completed and schedules next retry if needed.
    /// Updates LastAction, LastActionAt, LastError, and AttemptCount.
    /// If dto.NextAttemptAfterMinutes is set, schedules next action.
    /// </summary>
    Task MarkActionResultAsync(long id, BlobDatasetMarkResultDto dto, CancellationToken ct);

    /// <summary>
    /// Batch update execution results for multiple datasets.
    /// </summary>
    Task MarkActionResultsBatchAsync(IReadOnlyList<BlobDatasetMarkBatchItem> items, CancellationToken ct);
}
