﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for recording individual run item executions within an archival run.
/// Each run item represents a single operation (e.g., archiving one table/date, processing one blob prefix).
/// </summary>
public interface IRunItemsStore
{
    /// <summary>
    /// Records a run item execution with its status and metrics.
    /// </summary>
    /// <param name="runId">Parent run ID that owns this item.</param>
    /// <param name="itemType">Type of item (Dataset for table archival, Prefix for blob operations).</param>
    /// <param name="status">Status of this item (Succeeded, Failed).</param>
    /// <param name="tableConfigurationId">Optional table configuration ID (for Dataset items).</param>
    /// <param name="asOfDate">Optional business date being processed.</param>
    /// <param name="blobConfigurationId">Optional blob configuration ID (for Prefix items).</param>
    /// <param name="action">Optional lifecycle action performed (SetCold, SetArchive, Delete).</param>
    /// <param name="rowsAffected">Optional number of rows archived or deleted.</param>
    /// <param name="bytesAffected">Optional number of bytes processed.</param>
    /// <param name="itemKey">Optional descriptive key for the item (e.g., "container/prefix").</param>
    /// <param name="error">Optional error message if status is Failed.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    Task AddRunItemAsync(
        long runId,
        RunItemType itemType,
        RunItemStatus status,
        int? tableConfigurationId = null,
        DateOnly? asOfDate = null,
        int? blobConfigurationId = null,
        LifecycleAction? action = null,
        long? rowsAffected = null,
        long? bytesAffected = null,
        string? itemKey = null,
        string? error = null,
        CancellationToken ct = default);

    /// <summary>
    /// Phase 5 Optimization: Batch insert multiple run items in one operation.
    /// Returns quickly after batch insert without per-item idempotency checks.
    /// </summary>
    Task AddRunItemsBatchAsync(
        long runId,
        IReadOnlyList<RunItemBatchDto> items,
        CancellationToken ct);
}
