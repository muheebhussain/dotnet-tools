﻿namespace Archival.Application.Contracts.Retention;

/// <summary>
/// Contract for calculating which dates to retain based on retention policy.
/// </summary>
public interface IRetentionCalculator
{
    Task<IReadOnlySet<DateOnly>> CalculateKeepDatesAsync(
        int tableConfigurationId,
        IReadOnlyList<DateOnly> presentDates,
        CancellationToken ct);

    /// <summary>
    /// Phase 4 Optimization: Calculate retention for multiple tables in one operation.
    /// Returns dictionary keyed by tableConfigurationId with set of dates to keep.
    /// Reduces N individual operations to 1 batch operation.
    /// </summary>
    Task<IReadOnlyDictionary<int, IReadOnlySet<DateOnly>>> CalculateKeepDatesForMultipleAsync(
        IReadOnlyList<int> tableConfigurationIds,
        IReadOnlyDictionary<int, IReadOnlyList<DateOnly>> presentDatesByTableId,
        CancellationToken ct);
}
