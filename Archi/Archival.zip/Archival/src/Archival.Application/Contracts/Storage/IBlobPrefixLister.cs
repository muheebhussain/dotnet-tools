﻿namespace Archival.Application.Contracts.Storage;

/// <summary>
/// Contract for listing blob folder prefixes (hierarchical listing).
/// Provides operations to enumerate immediate child folder prefixes under a given prefix.
/// </summary>
public interface IBlobPrefixLister
{
    /// <summary>
    /// Lists immediate child folder prefixes under the specified prefix.
    /// Uses hierarchical listing (delimiter: "/") to enumerate only first-level subdirectories.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container name to query.</param>
    /// <param name="prefix">Parent prefix to list under (e.g., "data/"). Empty string lists root-level folders.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>List of folder prefix strings, each ending with "/". Empty list if no subfolders found.</returns>
    Task<IReadOnlyList<string>> ListPrefixesAsync(
        string storageConnectionString,
        string containerName,
        string prefix,
        CancellationToken ct);
}

