﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Storage;

/// <summary>
/// Contract for listing and inspecting blobs in Azure Blob Storage.
/// Provides operations to enumerate blobs and extract business dates from blob paths.
/// </summary>
public interface IBlobInventory
{
    /// <summary>
    /// Lists all blobs under the specified container and prefix.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container name to query.</param>
    /// <param name="prefix">Blob prefix filter (e.g., "archive/2026/"). Empty string lists all blobs.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>List of blob items with metadata (name, size, created date, tier).</returns>
    Task<IReadOnlyList<BlobItemDto>> ListBlobsAsync(
        string storageConnectionString,
        string containerName,
        string prefix,
        CancellationToken ct);

    /// <summary>
    /// Attempts to extract a business date from the blob path.
    /// Assumes date is in format YYYY-MM-DD somewhere in the path.
    /// </summary>
    /// <param name="blobName">Full blob path (e.g., "archive/2026-02-15/data.parquet").</param>
    /// <param name="date">Extracted date if successful.</param>
    /// <returns>True if date was extracted, false otherwise.</returns>
    bool TryExtractDateFromPath(string blobName, out DateOnly date);

    /// <summary>
    /// Attempts to extract a business date from a specific path segment after the configured prefix.
    /// </summary>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="configuredPrefix">Configured prefix to skip (e.g., "archive/").</param>
    /// <param name="date">Extracted date if successful.</param>
    /// <returns>True if date was extracted from the segment after prefix, false otherwise.</returns>
    bool TryExtractDateFromPathSegment(string blobName, string configuredPrefix, out DateOnly date);
}

