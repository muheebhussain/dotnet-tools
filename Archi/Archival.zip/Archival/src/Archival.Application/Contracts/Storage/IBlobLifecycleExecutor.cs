﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Storage;

/// <summary>
/// Contract for executing blob lifecycle actions in Azure Blob Storage.
/// Provides operations to change blob access tiers and delete blobs/folders.
/// </summary>
public interface IBlobLifecycleExecutor
{
    /// <summary>
    /// Attempts to change a blob's access tier to Cool (Cold).
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if tier change succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TrySetColdAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Attempts to change a blob's access tier to Archive with detailed error reason detection.
    /// Returns tuple indicating success and failure reason (if failed).
    /// Used to determine if fallback to Cold tier should be attempted.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Tuple of (success, failureReason). Reason is null if successful, or indicates why it failed.</returns>
    Task<(bool Success, ArchiveFailureReason? Reason)> TrySetArchiveWithReasonAsync(
        string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Attempts to change a blob's access tier to Archive.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if tier change succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TrySetArchiveAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Attempts to delete a blob.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if deletion succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TryDeleteAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Deletes all blobs under a date-based folder prefix and the folder marker itself.
    /// Handles both flat namespace and hierarchical namespace (ADLS Gen2) storage.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the folder.</param>
    /// <param name="datePrefix">Date folder prefix (e.g., "archive/2026-02-15/").</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Result containing deletion statistics (blobs deleted, marker deleted, HNS directory deleted).</returns>
    Task<Result<DateFolderDeletionResultDto>> DeleteDateFolderAsync(string storageConnectionString, string containerName, string datePrefix, CancellationToken ct);

    /// <summary>
    /// Deletes all blobs under a prefix and cleans up empty parent directories up to a root prefix boundary.
    /// Ensures no empty HNS folders remain after deletion.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the prefix.</param>
    /// <param name="datasetPrefix">Dataset blob prefix to delete (e.g., "data/2026-02-15/").</param>
    /// <param name="rootPrefix">Root prefix boundary - cleanup stops at this level (e.g., "data/").</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Result containing deletion and cleanup statistics.</returns>
    Task<Result<PrefixDeletionResultDto>> DeletePrefixAndCleanupParentsAsync(
        string storageConnectionString,
        string containerName,
        string datasetPrefix,
        string rootPrefix,
        CancellationToken ct);
}
