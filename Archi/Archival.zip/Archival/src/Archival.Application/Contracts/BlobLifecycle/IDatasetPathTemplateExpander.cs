﻿namespace Archival.Application.Contracts.BlobLifecycle;

/// <summary>
/// Context for expanding dataset path template tokens.
/// Used in blob discovery to render external dataset paths.
/// </summary>
public sealed record DatasetPathTemplateContext(
    DateOnly AsOfDate);

/// <summary>
/// Contract for expanding dataset path templates with actual values.
/// Replaces tokens like {yyyy}, {MM}, {dd}, {date} with real values.
/// </summary>
public interface IDatasetPathTemplateExpander
{
    /// <summary>
    /// Expands a dataset path template by replacing tokens with actual values from the context.
    /// Supports date-based tokens: {yyyy}, {MM}, {dd}, {date}.
    /// </summary>
    /// <param name="template">Template string containing tokens to expand (e.g., "data/{yyyy}-{MM}-{dd}/")</param>
    /// <param name="context">Context containing values for token replacement</param>
    /// <returns>Expanded path with all tokens replaced</returns>
    string ExpandTemplate(string template, DatasetPathTemplateContext context);

    /// <summary>
    /// Validates that a template contains only known tokens.
    /// </summary>
    /// <param name="template">Template string to validate</param>
    /// <exception cref="ArgumentException">Thrown if template contains unknown tokens</exception>
    void ValidateTemplate(string template);
}

