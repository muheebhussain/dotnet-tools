﻿namespace Archival.Application.Contracts.BlobLifecycle;

/// <summary>
/// Efficient matcher for blob exemptions.
/// Precomputes data structures for O(1) exact matches and efficient prefix matches.
/// </summary>
public interface IBlobExemptionMatcher
{
    /// <summary>
    /// Checks if a blob is exempted from lifecycle operations.
    /// </summary>
    /// <param name="containerName">Container name (case-insensitive)</param>
    /// <param name="blobPrefix">Blob prefix or full path</param>
    /// <param name="asOfDate">Business date associated with the blob</param>
    /// <returns>True if the blob matches any exemption rule</returns>
    bool IsExempt(string containerName, string blobPrefix, DateOnly asOfDate);
}

