-- =====================================================================
-- Archival Metadata Database Schema
-- =====================================================================
-- Version: 1.0
-- Last Updated: February 17, 2026
-- Description: Complete schema for Archival system metadata database
-- Naming: snake_case with archival_ prefix
-- =====================================================================

-- =====================================================================
-- POLICY TABLES
-- Define retention rules and lifecycle thresholds
-- =====================================================================

-- Table Retention Policy
-- Defines how many EOD/EOM/EOQ/EOY snapshots to keep for tables
CREATE TABLE archival_table_policy (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  is_active BIT NOT NULL,
  keep_last_eod INT NULL,           -- Keep last N end-of-day snapshots
  keep_last_eom INT NULL,           -- Keep last N end-of-month snapshots
  keep_last_eoq INT NULL,           -- Keep last N end-of-quarter snapshots
  keep_last_eoy INT NULL,           -- Keep last N end-of-year snapshots
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL
);

-- Blob Lifecycle Policy
-- Defines age thresholds for cold/archive/delete lifecycle actions
CREATE TABLE archival_blob_policy (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  is_active BIT NOT NULL,
  cold_min_age_days INT NULL,       -- Move to Cold tier after N days
  archive_min_age_days INT NULL,    -- Move to Archive tier after N days
  delete_min_age_days INT NULL,     -- Delete after N days
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL
);

-- =====================================================================
-- CONFIGURATION TABLES
-- Define what to archive and how to manage blobs
-- =====================================================================

-- Blob Configuration
-- Defines blob storage targets and lifecycle settings
-- NOTE: Archive tier support is determined at runtime via automatic fallback mechanism
--       (tries Archive first, falls back to Cold if not supported for the account)
CREATE TABLE archival_blob_configuration (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  is_enabled BIT NOT NULL,
  storage_account_name NVARCHAR(128) NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  prefix NVARCHAR(1024) NOT NULL,
  include_pattern NVARCHAR(2000) NULL,
  exclude_pattern NVARCHAR(2000) NULL,
  business_date_source NVARCHAR(20) NOT NULL,  -- Internal (from table archival) or External (discovered)
  is_external BIT NOT NULL DEFAULT 0,          -- True for external blob discovery
  dataset_path_template NVARCHAR(1024) NULL,   -- Path template for dataset discovery
  business_date_folder_format NVARCHAR(50) NULL, -- Date format in folder names (e.g., yyyy/MM/dd)
  business_date_folder_depth INT NULL,         -- Folder depth for date extraction
  blob_policy_id INT NOT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_blob_configuration_blob_policy FOREIGN KEY (blob_policy_id)
    REFERENCES archival_blob_policy(id)
);

-- Table Configuration
-- Defines which tables to archive and where to store them
CREATE TABLE archival_table_configuration (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  is_active BIT NOT NULL,
  database_name NVARCHAR(128) NOT NULL,
  schema_name NVARCHAR(128) NOT NULL,
  table_name NVARCHAR(128) NOT NULL,
  as_of_date_column NVARCHAR(128) NOT NULL,   -- Column containing business date
  archive_path_template NVARCHAR(400) NOT NULL, -- Blob path template (e.g., 'sales/{yyyy}/{MM}/{dd}/')
  table_policy_id INT NOT NULL,
  blob_configuration_id INT NOT NULL,          -- Links to blob config for storage info
  delete_after_export BIT NOT NULL,
  batch_delete_size INT NOT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL,
  CONSTRAINT uq_archival_table_configuration_table UNIQUE (database_name, schema_name, table_name),
  CONSTRAINT fk_archival_table_configuration_table_policy FOREIGN KEY (table_policy_id)
    REFERENCES archival_table_policy(id),
  CONSTRAINT fk_archival_table_configuration_blob_configuration FOREIGN KEY (blob_configuration_id)
    REFERENCES archival_blob_configuration(id)
);

-- =====================================================================
-- EXEMPTION TABLES
-- Define data that should NOT be archived or deleted
-- =====================================================================

-- Table Exemptions
-- Prevents specific dates from being archived for specific tables
CREATE TABLE archival_table_exemption (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  table_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  reason NVARCHAR(4000) NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_table_exemption_table FOREIGN KEY (table_configuration_id)
    REFERENCES archival_table_configuration(id)
);

-- UNIQUE constraint: One exemption per (table config, date)
CREATE UNIQUE INDEX uq_archival_table_exemption_config_date
  ON archival_table_exemption (table_configuration_id, as_of_date);

-- Blob Exemptions
-- Prevents specific blob prefixes/dates from lifecycle actions
CREATE TABLE archival_blob_exemption (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  blob_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  prefix NVARCHAR(1024) NOT NULL,
  reason NVARCHAR(4000) NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_blob_exemption_blob_configuration FOREIGN KEY (blob_configuration_id)
    REFERENCES archival_blob_configuration(id)
);

-- UNIQUE constraint: One exemption per (blob config, prefix, date)
CREATE UNIQUE INDEX uq_archival_blob_exemption_config_prefix_date
  ON archival_blob_exemption (blob_configuration_id, prefix, as_of_date);

-- =====================================================================
-- RUN TRACKING TABLES
-- Track archival runs and their results
-- =====================================================================

-- Run
-- Tracks each archival run (table archival or blob lifecycle)
CREATE TABLE archival_run (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  run_type NVARCHAR(20) NOT NULL,              -- Archive (table) or Lifecycle (blob)
  started_at DATETIME2(3) NOT NULL,
  ended_at DATETIME2(3) NULL,
  status NVARCHAR(20) NOT NULL,                -- Running, Succeeded, Failed, PartiallySucceeded
  note NVARCHAR(4000) NULL
);

-- Run Item
-- Tracks individual items processed in a run (table/date or blob/action)
CREATE TABLE archival_run_item (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  run_id BIGINT NOT NULL,
  item_type NVARCHAR(20) NOT NULL,             -- Dataset or BlobAction

  -- Structured identity columns (allows querying by table or blob config)
  table_configuration_id INT NULL,
  as_of_date DATE NULL,
  blob_configuration_id INT NULL,

  -- Optional display/debug field
  item_key NVARCHAR(1200) NULL,

  action NVARCHAR(40) NULL,                    -- SetCold, SetArchive, Delete, etc.
  status NVARCHAR(20) NOT NULL,                -- Succeeded, Failed
  rows_affected BIGINT NULL,
  bytes_affected BIGINT NULL,
  error_message NVARCHAR(MAX) NULL,
  created_at DATETIME2(3) NOT NULL,
  CONSTRAINT fk_archival_run_item_run FOREIGN KEY (run_id)
    REFERENCES archival_run(id),
  CONSTRAINT fk_archival_run_item_table_config FOREIGN KEY (table_configuration_id)
    REFERENCES archival_table_configuration(id),
  CONSTRAINT fk_archival_run_item_blob_config FOREIGN KEY (blob_configuration_id)
    REFERENCES archival_blob_configuration(id)
);

-- UNIQUE constraint: One run item per (run, type, table config, date) - filtered for non-null
CREATE UNIQUE INDEX uq_run_item_table_dataset
  ON archival_run_item (run_id, item_type, table_configuration_id, as_of_date)
  WHERE table_configuration_id IS NOT NULL AND as_of_date IS NOT NULL;

-- UNIQUE constraint: One run item per (run, type, blob config, date) - filtered for non-null
CREATE UNIQUE INDEX uq_run_item_blob_date_folder
  ON archival_run_item (run_id, item_type, blob_configuration_id, as_of_date)
  WHERE blob_configuration_id IS NOT NULL AND as_of_date IS NOT NULL;

-- =====================================================================
-- DATASET TABLES
-- Track archived datasets (table exports and blob datasets)
-- =====================================================================

-- Table Dataset (Archived Table Data)
-- Records each table/date export to Parquet
CREATE TABLE archival_dataset (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  table_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  date_type NVARCHAR(4) NOT NULL,              -- EOD, EOM, EOQ, EOY
  storage_account_name NVARCHAR(128) NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  blob_prefix NVARCHAR(1024) NOT NULL,
  part_count INT NOT NULL,                     -- Number of Parquet files
  total_bytes BIGINT NULL,
  row_count BIGINT NULL,
  status NVARCHAR(20) NOT NULL,                -- Pending, Succeeded, Failed
  created_at DATETIME2(3) NOT NULL,
  completed_at DATETIME2(3) NULL,
  error_summary NVARCHAR(MAX) NULL,
  CONSTRAINT uq_archival_dataset_table_date UNIQUE (table_configuration_id, as_of_date),
  CONSTRAINT fk_archival_dataset_table FOREIGN KEY (table_configuration_id)
    REFERENCES archival_table_configuration(id)
);

-- Blob Dataset (Blob Lifecycle Tracking)
-- Tracks blob datasets and their lifecycle actions
CREATE TABLE archival_blob_dataset (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  blob_configuration_id INT NOT NULL,
  source_type INT NOT NULL,                    -- 0 = Internal (from table export), 1 = External (discovered)
  as_of_date DATE NOT NULL,
  storage_account_name NVARCHAR(128) NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  blob_prefix NVARCHAR(2048) NOT NULL,
  archival_dataset_id BIGINT NULL,             -- Links to table dataset if source_type = Internal

  -- Current lifecycle state
  current_tier INT NOT NULL,                   -- 0 = Unknown, 1 = Hot, 2 = Cool, 3 = Cold, 4 = Archive
  next_action INT NOT NULL,                    -- 0 = None, 1 = SetCold, 2 = SetArchive, 3 = Delete
  next_action_at DATETIME2(3) NULL,
  is_deleted BIT NOT NULL DEFAULT 0,

  -- Last action tracking
  last_action INT NULL,                        -- 1 = SetCold, 2 = SetArchive, 3 = Delete
  last_action_at DATETIME2(3) NULL,
  attempt_count INT NOT NULL DEFAULT 0,
  last_error NVARCHAR(2000) NULL,

  -- Discover-Execute tracking (for idempotency and crash recovery)
  discovered_at DATETIME2(3) NOT NULL,
  executed_at DATETIME2(3) NULL,
  execution_status INT NOT NULL,               -- 0 = Pending, 1 = Succeeded, 2 = Failed

  created_at DATETIME2(3) NOT NULL,
  updated_at DATETIME2(3) NOT NULL,

  CONSTRAINT fk_archival_blob_dataset_blob_config FOREIGN KEY (blob_configuration_id)
    REFERENCES archival_blob_configuration(id),
  CONSTRAINT fk_archival_blob_dataset_archival_dataset FOREIGN KEY (archival_dataset_id)
    REFERENCES archival_dataset(id) ON DELETE SET NULL
);

-- UNIQUE constraint: One blob dataset per (blob config, date) - prevents duplicate discovery
CREATE UNIQUE INDEX uq_archival_blob_dataset_config_date
  ON archival_blob_dataset (blob_configuration_id, as_of_date);

-- Index for querying pending datasets (discover-execute pattern)
CREATE INDEX ix_archival_blob_dataset_config_exec_status
  ON archival_blob_dataset (blob_configuration_id, execution_status);

-- Index for querying due datasets (lifecycle scheduling)
CREATE INDEX ix_archival_blob_dataset_config_next_action_at
  ON archival_blob_dataset (blob_configuration_id, next_action_at);

-- =====================================================================
-- END OF SCHEMA
-- =====================================================================

