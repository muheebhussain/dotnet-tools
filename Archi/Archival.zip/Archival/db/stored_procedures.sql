﻿-- =====================================================================
-- Archival Configuration Stored Procedures
-- =====================================================================
-- Version: 1.0
-- Date: February 17, 2026
-- Description: Stored procedures for managing policies and configurations
-- =====================================================================

-- =====================================================================
-- TABLE POLICY PROCEDURES
-- =====================================================================

-- Create or Update Table Retention Policy
CREATE OR ALTER PROCEDURE sp_upsert_table_policy
    @policy_id INT = NULL,                    -- NULL for insert, ID for update
    @name NVARCHAR(200),
    @is_active BIT = 1,
    @keep_last_eod INT = NULL,
    @keep_last_eom INT = NULL,
    @keep_last_eoq INT = NULL,
    @keep_last_eoy INT = NULL,
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Name is required
    IF @name IS NULL OR LTRIM(RTRIM(@name)) = ''
    BEGIN
        RAISERROR('Policy name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: At least one retention rule must be specified
    IF @keep_last_eod IS NULL AND @keep_last_eom IS NULL
       AND @keep_last_eoq IS NULL AND @keep_last_eoy IS NULL
    BEGIN
        RAISERROR('At least one retention rule (keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy) must be specified', 16, 1);
        RETURN -1;
    END

    -- Validation: Retention values must be positive if specified
    IF (@keep_last_eod IS NOT NULL AND @keep_last_eod <= 0)
       OR (@keep_last_eom IS NOT NULL AND @keep_last_eom <= 0)
       OR (@keep_last_eoq IS NOT NULL AND @keep_last_eoq <= 0)
       OR (@keep_last_eoy IS NOT NULL AND @keep_last_eoy <= 0)
    BEGIN
        RAISERROR('Retention values must be positive integers', 16, 1);
        RETURN -1;
    END

    -- Validation: Check for duplicate name (excluding current policy if update)
    IF EXISTS (
        SELECT 1 FROM archival_table_policy
        WHERE name = @name AND (@policy_id IS NULL OR id != @policy_id)
    )
    BEGIN
        RAISERROR('A policy with this name already exists', 16, 1);
        RETURN -1;
    END

    -- Insert or Update
    IF @policy_id IS NULL
    BEGIN
        -- Insert new policy
        INSERT INTO archival_table_policy (
            name, is_active, keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy,
            created_at, created_by
        )
        VALUES (
            @name, @is_active, @keep_last_eod, @keep_last_eom, @keep_last_eoq, @keep_last_eoy,
            GETUTCDATE(), @created_by
        );

        SELECT SCOPE_IDENTITY() AS policy_id, 'Table policy created successfully' AS message;
    END
    ELSE
    BEGIN
        -- Update existing policy
        IF NOT EXISTS (SELECT 1 FROM archival_table_policy WHERE id = @policy_id)
        BEGIN
            RAISERROR('Table policy not found', 16, 1);
            RETURN -1;
        END

        UPDATE archival_table_policy
        SET name = @name,
            is_active = @is_active,
            keep_last_eod = @keep_last_eod,
            keep_last_eom = @keep_last_eom,
            keep_last_eoq = @keep_last_eoq,
            keep_last_eoy = @keep_last_eoy,
            updated_at = GETUTCDATE(),
            updated_by = @created_by
        WHERE id = @policy_id;

        SELECT @policy_id AS policy_id, 'Table policy updated successfully' AS message;
    END

    RETURN 0;
END
GO

-- =====================================================================
-- BLOB POLICY PROCEDURES
-- =====================================================================

-- Create or Update Blob Lifecycle Policy
CREATE OR ALTER PROCEDURE sp_upsert_blob_policy
    @policy_id INT = NULL,                    -- NULL for insert, ID for update
    @name NVARCHAR(200),
    @is_active BIT = 1,
    @cold_min_age_days INT = NULL,
    @archive_min_age_days INT = NULL,
    @delete_min_age_days INT = NULL,
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Name is required
    IF @name IS NULL OR LTRIM(RTRIM(@name)) = ''
    BEGIN
        RAISERROR('Policy name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: At least one lifecycle threshold must be specified
    IF @cold_min_age_days IS NULL AND @archive_min_age_days IS NULL AND @delete_min_age_days IS NULL
    BEGIN
        RAISERROR('At least one lifecycle threshold (cold, archive, or delete) must be specified', 16, 1);
        RETURN -1;
    END

    -- Validation: Age values must be positive if specified
    IF (@cold_min_age_days IS NOT NULL AND @cold_min_age_days <= 0)
       OR (@archive_min_age_days IS NOT NULL AND @archive_min_age_days <= 0)
       OR (@delete_min_age_days IS NOT NULL AND @delete_min_age_days <= 0)
    BEGIN
        RAISERROR('Age thresholds must be positive integers', 16, 1);
        RETURN -1;
    END

    -- Validation: Lifecycle progression must be logical (Cold < Archive < Delete)
    IF @cold_min_age_days IS NOT NULL AND @archive_min_age_days IS NOT NULL
       AND @cold_min_age_days >= @archive_min_age_days
    BEGIN
        RAISERROR('cold_min_age_days must be less than archive_min_age_days', 16, 1);
        RETURN -1;
    END

    IF @archive_min_age_days IS NOT NULL AND @delete_min_age_days IS NOT NULL
       AND @archive_min_age_days >= @delete_min_age_days
    BEGIN
        RAISERROR('archive_min_age_days must be less than delete_min_age_days', 16, 1);
        RETURN -1;
    END

    IF @cold_min_age_days IS NOT NULL AND @delete_min_age_days IS NOT NULL
       AND @cold_min_age_days >= @delete_min_age_days
    BEGIN
        RAISERROR('cold_min_age_days must be less than delete_min_age_days', 16, 1);
        RETURN -1;
    END

    -- Validation: Check for duplicate name (excluding current policy if update)
    IF EXISTS (
        SELECT 1 FROM archival_blob_policy
        WHERE name = @name AND (@policy_id IS NULL OR id != @policy_id)
    )
    BEGIN
        RAISERROR('A blob policy with this name already exists', 16, 1);
        RETURN -1;
    END

    -- Insert or Update
    IF @policy_id IS NULL
    BEGIN
        -- Insert new policy
        INSERT INTO archival_blob_policy (
            name, is_active, cold_min_age_days, archive_min_age_days, delete_min_age_days,
            created_at, created_by
        )
        VALUES (
            @name, @is_active, @cold_min_age_days, @archive_min_age_days, @delete_min_age_days,
            GETUTCDATE(), @created_by
        );

        SELECT SCOPE_IDENTITY() AS policy_id, 'Blob policy created successfully' AS message;
    END
    ELSE
    BEGIN
        -- Update existing policy
        IF NOT EXISTS (SELECT 1 FROM archival_blob_policy WHERE id = @policy_id)
        BEGIN
            RAISERROR('Blob policy not found', 16, 1);
            RETURN -1;
        END

        UPDATE archival_blob_policy
        SET name = @name,
            is_active = @is_active,
            cold_min_age_days = @cold_min_age_days,
            archive_min_age_days = @archive_min_age_days,
            delete_min_age_days = @delete_min_age_days,
            updated_at = GETUTCDATE(),
            updated_by = @created_by
        WHERE id = @policy_id;

        SELECT @policy_id AS policy_id, 'Blob policy updated successfully' AS message;
    END

    RETURN 0;
END
GO

-- =====================================================================
-- BLOB CONFIGURATION PROCEDURES
-- =====================================================================

-- Create or Update Blob Configuration
-- NOTE: Archive tier support is now determined at runtime via automatic fallback mechanism.
--       No longer need to preconfigure this value per blob configuration.
-- NOTE: BusinessDateSource must be one of: 'FromFileName', 'CreatedOn', 'LastModified'
CREATE OR ALTER PROCEDURE sp_upsert_blob_configuration
    @config_id INT = NULL,                    -- NULL for insert, ID for update
    @is_enabled BIT = 1,
    @storage_account_name NVARCHAR(128),
    @container_name NVARCHAR(128),
    @prefix NVARCHAR(1024),
    @include_pattern NVARCHAR(2000) = NULL,
    @exclude_pattern NVARCHAR(2000) = NULL,
    @business_date_source NVARCHAR(20),       -- 'FromFileName', 'CreatedOn', or 'LastModified'
    @is_external BIT = 0,
    @dataset_path_template NVARCHAR(1024) = NULL,
    @business_date_folder_format NVARCHAR(50) = NULL,
    @business_date_folder_depth INT = NULL,
    @blob_policy_id INT,
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Storage account name is required
    IF @storage_account_name IS NULL OR LTRIM(RTRIM(@storage_account_name)) = ''
    BEGIN
        RAISERROR('Storage account name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Container name is required
    IF @container_name IS NULL OR LTRIM(RTRIM(@container_name)) = ''
    BEGIN
        RAISERROR('Container name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Prefix is required
    IF @prefix IS NULL OR LTRIM(RTRIM(@prefix)) = ''
    BEGIN
        RAISERROR('Blob prefix is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Prefix should end with /
    IF RIGHT(@prefix, 1) != '/'
    BEGIN
        SET @prefix = @prefix + '/';
    END

    -- Validation: Business date source must be one of the valid enum values
    IF @business_date_source NOT IN ('FromFileName', 'CreatedOn', 'LastModified')
    BEGIN
        RAISERROR('business_date_source must be one of: ''FromFileName'', ''CreatedOn'', or ''LastModified''', 16, 1);
        RETURN -1;
    END

    -- Validation: External configurations require additional fields
    IF @is_external = 1
    BEGIN
        IF @dataset_path_template IS NULL OR LTRIM(RTRIM(@dataset_path_template)) = ''
        BEGIN
            RAISERROR('dataset_path_template is required for external blob configurations', 16, 1);
            RETURN -1;
        END

        IF @business_date_folder_format IS NULL OR LTRIM(RTRIM(@business_date_folder_format)) = ''
        BEGIN
            RAISERROR('business_date_folder_format is required for external blob configurations', 16, 1);
            RETURN -1;
        END

        IF @business_date_folder_depth IS NULL
        BEGIN
            RAISERROR('business_date_folder_depth is required for external blob configurations', 16, 1);
            RETURN -1;
        END
    END

    -- Validation: Blob policy must exist and be active
    IF NOT EXISTS (SELECT 1 FROM archival_blob_policy WHERE id = @blob_policy_id)
    BEGIN
        RAISERROR('Blob policy not found', 16, 1);
        RETURN -1;
    END

    IF NOT EXISTS (SELECT 1 FROM archival_blob_policy WHERE id = @blob_policy_id AND is_active = 1)
    BEGIN
        RAISERROR('Blob policy is not active', 16, 1);
        RETURN -1;
    END

    -- Validation: Storage account name format (lowercase alphanumeric, 3-24 chars)
    IF LEN(@storage_account_name) < 3 OR LEN(@storage_account_name) > 24
    BEGIN
        RAISERROR('Storage account name must be 3-24 characters', 16, 1);
        RETURN -1;
    END

    IF @storage_account_name != LOWER(@storage_account_name)
       OR @storage_account_name LIKE '%[^a-z0-9]%'
    BEGIN
        RAISERROR('Storage account name must be lowercase alphanumeric only', 16, 1);
        RETURN -1;
    END

    -- Validation: Container name format (lowercase alphanumeric and hyphens, 3-63 chars)
    IF LEN(@container_name) < 3 OR LEN(@container_name) > 63
    BEGIN
        RAISERROR('Container name must be 3-63 characters', 16, 1);
        RETURN -1;
    END

    IF @container_name != LOWER(@container_name)
       OR @container_name LIKE '%[^a-z0-9-]%'
    BEGIN
        RAISERROR('Container name must be lowercase alphanumeric and hyphens only', 16, 1);
        RETURN -1;
    END

    -- Insert or Update
    IF @config_id IS NULL
    BEGIN
        -- Insert new configuration
        INSERT INTO archival_blob_configuration (
            is_enabled, storage_account_name, container_name, prefix,
            include_pattern, exclude_pattern,
            business_date_source, is_external, dataset_path_template,
            business_date_folder_format, business_date_folder_depth,
            blob_policy_id, created_at, created_by
        )
        VALUES (
            @is_enabled, @storage_account_name, @container_name, @prefix,
            @include_pattern, @exclude_pattern,
            @business_date_source, @is_external, @dataset_path_template,
            @business_date_folder_format, @business_date_folder_depth,
            @blob_policy_id, GETUTCDATE(), @created_by
        );

        SELECT SCOPE_IDENTITY() AS config_id, 'Blob configuration created successfully' AS message;
    END
    ELSE
    BEGIN
        -- Update existing configuration
        IF NOT EXISTS (SELECT 1 FROM archival_blob_configuration WHERE id = @config_id)
        BEGIN
            RAISERROR('Blob configuration not found', 16, 1);
            RETURN -1;
        END

        UPDATE archival_blob_configuration
        SET is_enabled = @is_enabled,
            storage_account_name = @storage_account_name,
            container_name = @container_name,
            prefix = @prefix,
            include_pattern = @include_pattern,
            exclude_pattern = @exclude_pattern,
            business_date_source = @business_date_source,
            is_external = @is_external,
            dataset_path_template = @dataset_path_template,
            business_date_folder_format = @business_date_folder_format,
            business_date_folder_depth = @business_date_folder_depth,
            blob_policy_id = @blob_policy_id,
            updated_at = GETUTCDATE(),
            updated_by = @created_by
        WHERE id = @config_id;

        SELECT @config_id AS config_id, 'Blob configuration updated successfully' AS message;
    END

    RETURN 0;
END
GO

-- =====================================================================
-- TABLE CONFIGURATION PROCEDURES
-- =====================================================================

-- Create or Update Table Configuration
CREATE OR ALTER PROCEDURE sp_upsert_table_configuration
    @config_id INT = NULL,                    -- NULL for insert, ID for update
    @is_active BIT = 1,
    @database_name NVARCHAR(128),
    @schema_name NVARCHAR(128),
    @table_name NVARCHAR(128),
    @as_of_date_column NVARCHAR(128),
    @archive_path_template NVARCHAR(400),
    @table_policy_id INT,
    @blob_configuration_id INT,
    @delete_after_export BIT = 0,
    @batch_delete_size INT = 10000,
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Database name is required
    IF @database_name IS NULL OR LTRIM(RTRIM(@database_name)) = ''
    BEGIN
        RAISERROR('Database name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Schema name is required
    IF @schema_name IS NULL OR LTRIM(RTRIM(@schema_name)) = ''
    BEGIN
        RAISERROR('Schema name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Table name is required
    IF @table_name IS NULL OR LTRIM(RTRIM(@table_name)) = ''
    BEGIN
        RAISERROR('Table name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Business date column is required
    IF @as_of_date_column IS NULL OR LTRIM(RTRIM(@as_of_date_column)) = ''
    BEGIN
        RAISERROR('Business date column name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Archive path template is required
    IF @archive_path_template IS NULL OR LTRIM(RTRIM(@archive_path_template)) = ''
    BEGIN
        RAISERROR('Archive path template is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Archive path should end with /
    IF RIGHT(@archive_path_template, 1) != '/'
    BEGIN
        SET @archive_path_template = @archive_path_template + '/';
    END

    -- Validation: Archive path must contain date tokens
    IF @archive_path_template NOT LIKE '%{yyyy}%'
       AND @archive_path_template NOT LIKE '%{MM}%'
       AND @archive_path_template NOT LIKE '%{dd}%'
    BEGIN
        RAISERROR('Archive path template must contain at least one date token: {yyyy}, {MM}, or {dd}', 16, 1);
        RETURN -1;
    END

    -- Validation: Table policy must exist and be active
    IF NOT EXISTS (SELECT 1 FROM archival_table_policy WHERE id = @table_policy_id)
    BEGIN
        RAISERROR('Table policy not found', 16, 1);
        RETURN -1;
    END

    IF NOT EXISTS (SELECT 1 FROM archival_table_policy WHERE id = @table_policy_id AND is_active = 1)
    BEGIN
        RAISERROR('Table policy is not active', 16, 1);
        RETURN -1;
    END

    -- Validation: Blob configuration must exist and be enabled
    IF NOT EXISTS (SELECT 1 FROM archival_blob_configuration WHERE id = @blob_configuration_id)
    BEGIN
        RAISERROR('Blob configuration not found', 16, 1);
        RETURN -1;
    END

    IF NOT EXISTS (SELECT 1 FROM archival_blob_configuration WHERE id = @blob_configuration_id AND is_enabled = 1)
    BEGIN
        RAISERROR('Blob configuration is not enabled', 16, 1);
        RETURN -1;
    END

    -- Validation: Batch delete size must be positive
    IF @batch_delete_size <= 0
    BEGIN
        RAISERROR('Batch delete size must be a positive integer', 16, 1);
        RETURN -1;
    END

    -- Validation: Check for duplicate table (excluding current config if update)
    IF EXISTS (
        SELECT 1 FROM archival_table_configuration
        WHERE database_name = @database_name
          AND schema_name = @schema_name
          AND table_name = @table_name
          AND (@config_id IS NULL OR id != @config_id)
    )
    BEGIN
        RAISERROR('A configuration for this table already exists', 16, 1);
        RETURN -1;
    END

    -- Insert or Update
    IF @config_id IS NULL
    BEGIN
        -- Insert new configuration
        INSERT INTO archival_table_configuration (
            is_active, database_name, schema_name, table_name, as_of_date_column,
            archive_path_template, table_policy_id, blob_configuration_id,
            delete_after_export, batch_delete_size, created_at, created_by
        )
        VALUES (
            @is_active, @database_name, @schema_name, @table_name, @as_of_date_column,
            @archive_path_template, @table_policy_id, @blob_configuration_id,
            @delete_after_export, @batch_delete_size, GETUTCDATE(), @created_by
        );

        SELECT SCOPE_IDENTITY() AS config_id, 'Table configuration created successfully' AS message;
    END
    ELSE
    BEGIN
        -- Update existing configuration
        IF NOT EXISTS (SELECT 1 FROM archival_table_configuration WHERE id = @config_id)
        BEGIN
            RAISERROR('Table configuration not found', 16, 1);
            RETURN -1;
        END

        UPDATE archival_table_configuration
        SET is_active = @is_active,
            database_name = @database_name,
            schema_name = @schema_name,
            table_name = @table_name,
            as_of_date_column = @as_of_date_column,
            archive_path_template = @archive_path_template,
            table_policy_id = @table_policy_id,
            blob_configuration_id = @blob_configuration_id,
            delete_after_export = @delete_after_export,
            batch_delete_size = @batch_delete_size,
            updated_at = GETUTCDATE(),
            updated_by = @created_by
        WHERE id = @config_id;

        SELECT @config_id AS config_id, 'Table configuration updated successfully' AS message;
    END

    RETURN 0;
END
GO

-- =====================================================================
-- EXEMPTION PROCEDURES
-- =====================================================================

-- Add Table Exemption
CREATE OR ALTER PROCEDURE sp_add_table_exemption
    @table_configuration_id INT,
    @as_of_date DATE,
    @reason NVARCHAR(4000),
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Table configuration must exist
    IF NOT EXISTS (SELECT 1 FROM archival_table_configuration WHERE id = @table_configuration_id)
    BEGIN
        RAISERROR('Table configuration not found', 16, 1);
        RETURN -1;
    END

    -- Validation: Date is required
    IF @as_of_date IS NULL
    BEGIN
        RAISERROR('As-of date is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Reason is required
    IF @reason IS NULL OR LTRIM(RTRIM(@reason)) = ''
    BEGIN
        RAISERROR('Exemption reason is required', 16, 1);
        RETURN -1;
    END

    -- Check for duplicate (unique constraint will also prevent this)
    IF EXISTS (
        SELECT 1 FROM archival_table_exemption
        WHERE table_configuration_id = @table_configuration_id
          AND as_of_date = @as_of_date
    )
    BEGIN
        RAISERROR('An exemption for this table and date already exists', 16, 1);
        RETURN -1;
    END

    -- Insert exemption
    INSERT INTO archival_table_exemption (
        table_configuration_id, as_of_date, reason, created_at, created_by
    )
    VALUES (
        @table_configuration_id, @as_of_date, @reason, GETUTCDATE(), @created_by
    );

    SELECT SCOPE_IDENTITY() AS exemption_id, 'Table exemption added successfully' AS message;
    RETURN 0;
END
GO

-- Add Blob Exemption
CREATE OR ALTER PROCEDURE sp_add_blob_exemption
    @blob_configuration_id INT,
    @as_of_date DATE,
    @container_name NVARCHAR(128),
    @prefix NVARCHAR(1024),
    @reason NVARCHAR(4000),
    @created_by NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validation: Blob configuration must exist
    IF NOT EXISTS (SELECT 1 FROM archival_blob_configuration WHERE id = @blob_configuration_id)
    BEGIN
        RAISERROR('Blob configuration not found', 16, 1);
        RETURN -1;
    END

    -- Validation: Date is required
    IF @as_of_date IS NULL
    BEGIN
        RAISERROR('As-of date is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Container name is required
    IF @container_name IS NULL OR LTRIM(RTRIM(@container_name)) = ''
    BEGIN
        RAISERROR('Container name is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Prefix is required
    IF @prefix IS NULL OR LTRIM(RTRIM(@prefix)) = ''
    BEGIN
        RAISERROR('Blob prefix is required', 16, 1);
        RETURN -1;
    END

    -- Validation: Prefix should end with /
    IF RIGHT(@prefix, 1) != '/'
    BEGIN
        SET @prefix = @prefix + '/';
    END

    -- Validation: Reason is required
    IF @reason IS NULL OR LTRIM(RTRIM(@reason)) = ''
    BEGIN
        RAISERROR('Exemption reason is required', 16, 1);
        RETURN -1;
    END

    -- Check for duplicate (unique constraint will also prevent this)
    IF EXISTS (
        SELECT 1 FROM archival_blob_exemption
        WHERE blob_configuration_id = @blob_configuration_id
          AND prefix = @prefix
          AND as_of_date = @as_of_date
    )
    BEGIN
        RAISERROR('An exemption for this blob configuration, prefix, and date already exists', 16, 1);
        RETURN -1;
    END

    -- Insert exemption
    INSERT INTO archival_blob_exemption (
        blob_configuration_id, as_of_date, container_name, prefix, reason, created_at, created_by
    )
    VALUES (
        @blob_configuration_id, @as_of_date, @container_name, @prefix, @reason, GETUTCDATE(), @created_by
    );

    SELECT SCOPE_IDENTITY() AS exemption_id, 'Blob exemption added successfully' AS message;
    RETURN 0;
END
GO

-- =====================================================================
-- HELPER/QUERY PROCEDURES
-- =====================================================================

-- Get All Table Policies
CREATE OR ALTER PROCEDURE sp_get_table_policies
    @is_active BIT = NULL  -- NULL = all, 1 = active only, 0 = inactive only
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        id,
        name,
        is_active,
        keep_last_eod,
        keep_last_eom,
        keep_last_eoq,
        keep_last_eoy,
        created_at,
        created_by,
        updated_at,
        updated_by
    FROM archival_table_policy
    WHERE @is_active IS NULL OR is_active = @is_active
    ORDER BY name;
END
GO

-- Get All Blob Policies
CREATE OR ALTER PROCEDURE sp_get_blob_policies
    @is_active BIT = NULL  -- NULL = all, 1 = active only, 0 = inactive only
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        id,
        name,
        is_active,
        cold_min_age_days,
        archive_min_age_days,
        delete_min_age_days,
        created_at,
        created_by,
        updated_at,
        updated_by
    FROM archival_blob_policy
    WHERE @is_active IS NULL OR is_active = @is_active
    ORDER BY name;
END
GO

-- Get All Blob Configurations
CREATE OR ALTER PROCEDURE sp_get_blob_configurations
    @is_enabled BIT = NULL  -- NULL = all, 1 = enabled only, 0 = disabled only
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        bc.id,
        bc.is_enabled,
        bc.storage_account_name,
        bc.container_name,
        bc.prefix,
        bc.include_pattern,
        bc.exclude_pattern,
        bc.business_date_source,
        bc.is_external,
        bc.dataset_path_template,
        bc.business_date_folder_format,
        bc.business_date_folder_depth,
        bc.blob_policy_id,
        bp.name AS blob_policy_name,
        bc.created_at,
        bc.created_by,
        bc.updated_at,
        bc.updated_by
    FROM archival_blob_configuration bc
    JOIN archival_blob_policy bp ON bc.blob_policy_id = bp.id
    WHERE @is_enabled IS NULL OR bc.is_enabled = @is_enabled
    ORDER BY bc.storage_account_name, bc.container_name, bc.prefix;
END
GO

-- Get All Table Configurations
CREATE OR ALTER PROCEDURE sp_get_table_configurations
    @is_active BIT = NULL  -- NULL = all, 1 = active only, 0 = inactive only
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        tc.id,
        tc.is_active,
        tc.database_name,
        tc.schema_name,
        tc.table_name,
        tc.as_of_date_column,
        tc.archive_path_template,
        tc.table_policy_id,
        tp.name AS table_policy_name,
        tc.blob_configuration_id,
        bc.storage_account_name,
        bc.container_name,
        tc.delete_after_export,
        tc.batch_delete_size,
        tc.created_at,
        tc.created_by,
        tc.updated_at,
        tc.updated_by
    FROM archival_table_configuration tc
    JOIN archival_table_policy tp ON tc.table_policy_id = tp.id
    JOIN archival_blob_configuration bc ON tc.blob_configuration_id = bc.id
    WHERE @is_active IS NULL OR tc.is_active = @is_active
    ORDER BY tc.database_name, tc.schema_name, tc.table_name;
END
GO

-- =====================================================================
-- SAMPLE CONFIGURATIONS (REAL-WORLD)
-- =====================================================================
-- Internal blob configuration (generated by table archival)
-- Storage Account: usfinregreparchival
-- Container: brokerdealer
-- Prefix: tbl_reporting_comb_stock_record/
-- BusinessDateSource: FromFileName (extract date from blob filename)
-- Note: Archive tier support is now determined at runtime via automatic fallback
--
-- EXEC dbo.sp_upsert_blob_configuration
--     @storage_account_name = 'usfinregreparchival',
--     @container_name       = 'brokerdealer',
--     @prefix               = 'tbl_reporting_comb_stock_record/',
--     @business_date_source = 'FromFileName',
--     @is_external          = 0,
--     @blob_policy_id       = 1,
--     @created_by           = 'dev.user';
--
-- External blob configuration (discovered from existing blobs)
-- Storage Account: yacoasysqe5cvf8b1private
-- Container: app
-- Prefix: file-output/modules/sgas/15c3-3/output/AllocationSummary/
-- DatasetPathTemplate: AllocationSummary_{yyyy}{MM}{dd}.parquet
-- BusinessDateSource: FromFileName (extract date from blob filename)
-- Note: Archive tier support is now determined at runtime via automatic fallback
--
-- EXEC dbo.sp_upsert_blob_configuration
--     @storage_account_name        = 'yacoasysqe5cvf8b1private',
--     @container_name              = 'app',
--     @prefix                      = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
--     @business_date_source        = 'FromFileName',
--     @is_external                 = 1,
--     @dataset_path_template       = 'AllocationSummary_{yyyy}{MM}{dd}.parquet',
--     @business_date_folder_format = 'yyyy-MM-dd',
--     @business_date_folder_depth  = 1,
--     @blob_policy_id              = 1,
--     @created_by                  = 'dev.user';
--
-- Alternative: Using CreatedOn for business date (blob creation timestamp)
--
-- EXEC dbo.sp_upsert_blob_configuration
--     @storage_account_name        = 'yacoasysqe5cvf8b1private',
--     @container_name              = 'app',
--     @prefix                      = 'file-output/modules/other/',
--     @business_date_source        = 'CreatedOn',
--     @is_external                 = 1,
--     @dataset_path_template       = 'data_{yyyy}{MM}{dd}.parquet',
--     @business_date_folder_format = 'yyyy-MM-dd',
--     @business_date_folder_depth  = 1,
--     @blob_policy_id              = 1,
--     @created_by                  = 'dev.user';
--
-- Alternative: Using LastModified for business date (blob last modified timestamp)
--
-- EXEC dbo.sp_upsert_blob_configuration
--     @storage_account_name        = 'yacoasysqe5cvf8b1private',
--     @container_name              = 'app',
--     @prefix                      = 'file-output/modules/updated/',
--     @business_date_source        = 'LastModified',
--     @is_external                 = 1,
--     @dataset_path_template       = 'updated_{yyyy}{MM}{dd}.parquet',
--     @business_date_folder_format = 'yyyy-MM-dd',
--     @business_date_folder_depth  = 1,
--     @blob_policy_id              = 1,
--     @created_by                  = 'dev.user';
--
-- Table configuration (archival output path)
-- Database: CoreDb
-- Schema: dbo
-- Table: tbl_reporting_comb_stock_record
-- BusinessDateColumn: businessDate
-- ArchivePathTemplate: /{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/
--
-- EXEC dbo.sp_upsert_table_configuration
--     @database_name         = 'CoreDb',
--     @schema_name           = 'dbo',
--     @table_name            = 'tbl_reporting_comb_stock_record',
--     @as_of_date_column     = 'businessDate',
--     @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
--     @table_policy_id       = 1,
--     @blob_configuration_id = 1,
--     @delete_after_export   = 1,
--     @batch_delete_size     = 10000,
--     @created_by            = 'dev.user';
--
-- =====================================================================
-- BUSINESS DATE SOURCE VALUES
-- =====================================================================
-- FromFileName:   Extract business date from the blob filename
--                 Example: AllocationSummary_20231108.parquet → 2023-11-08
--
-- CreatedOn:      Use the blob creation timestamp as the business date
--                 Use when dates are embedded in blob metadata (creation time)
--
-- LastModified:   Use the blob last-modified timestamp as the business date
--                 Use when dates are tracked via blob updates
--
-- =====================================================================
-- END OF STORED PROCEDURES
-- =====================================================================

