﻿# Archival Configuration Guide - Stored Procedures

**Version**: 1.0  
**Date**: February 17, 2026  
**Audience**: Developers configuring archival policies and tables

---

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Stored Procedures Reference](#stored-procedures-reference)
- [Configuration Workflows](#configuration-workflows)
- [Examples](#examples)
- [Validation Rules](#validation-rules)
- [Troubleshooting](#troubleshooting)

---

## Overview

This guide explains how to configure the Archival system using stored procedures. All configuration is stored in the metadata database and requires no application deployment.

### What You Can Configure
1. **Table Retention Policies** - How many snapshots to keep
2. **Blob Lifecycle Policies** - Cold/Archive/Delete thresholds
3. **Blob Configurations** - Storage locations and lifecycle settings
4. **Table Configurations** - Which tables to archive
5. **Exemptions** - Data to protect from archival/lifecycle

---

## Prerequisites

### Required
- SQL Server access with `db_datareader`, `db_datawriter`, and `EXECUTE` permissions
- Connection strings configured in application secrets
- Azure Storage accounts created

### Recommended Tools
- Azure Data Studio (recommended)
- SQL Server Management Studio (SSMS)
- sqlcmd (command-line)

---

## Quick Start

### 1. Install Stored Procedures

```bash
sqlcmd -S your-server -d ArchivalMetadata -i db/stored_procedures.sql
```

### 2. Create Your First Configuration (5 steps)

```sql
-- Step 1: Create table retention policy
EXEC sp_upsert_table_policy 
    @name = 'keep_90_days',
    @keep_last_eod = 90,
    @created_by = 'john.doe';

-- Step 2: Create blob lifecycle policy
EXEC sp_upsert_blob_policy 
    @name = 'standard_lifecycle',
    @cold_min_age_days = 30,
    @archive_min_age_days = 90,
    @delete_min_age_days = 365,
    @created_by = 'john.doe';

-- Step 3: Create blob configuration
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'usfinregreparchival',
    @container_name = 'brokerdealer',
    @prefix = 'tbl_reporting_comb_stock_record/',
    @supports_archive_tier = 1,
    @blob_policy_id = 2,  -- From step 2
    @created_by = 'dev.user';

-- Step 4: Create table configuration
EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb',
    @schema_name = 'dbo',
    @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = 1,  -- From step 1
    @blob_configuration_id = 3,  -- From step 3
    @delete_after_export = 1,
    @created_by = 'dev.user';

-- Step 5: Verify configuration
EXEC sp_get_table_configurations @is_active = 1;
```

**Done!** ✅ Your table is now configured for archival.

---

## Stored Procedures Reference

### Policy Procedures

#### sp_upsert_table_policy
Create or update a table retention policy.

**Parameters**:
- `@policy_id` (INT, optional) - NULL for insert, ID for update
- `@name` (NVARCHAR(200), required) - Policy name (must be unique)
- `@is_active` (BIT, default 1) - Whether policy is active
- `@keep_last_eod` (INT, optional) - Keep last N end-of-day snapshots
- `@keep_last_eom` (INT, optional) - Keep last N end-of-month snapshots
- `@keep_last_eoq` (INT, optional) - Keep last N end-of-quarter snapshots
- `@keep_last_eoy` (INT, optional) - Keep last N end-of-year snapshots
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `policy_id` and success message

**Example**:
```sql
-- Create new policy
EXEC sp_upsert_table_policy 
    @name = 'keep_90_days',
    @keep_last_eod = 90,
    @created_by = 'john.doe';

-- Update existing policy
EXEC sp_upsert_table_policy 
    @policy_id = 1,
    @name = 'keep_90_days_updated',
    @keep_last_eod = 120,
    @created_by = 'john.doe';
```

**Validation**:
- ✅ Name is required and must be unique
- ✅ At least one retention rule must be specified
- ✅ Retention values must be positive integers

---

#### sp_upsert_blob_policy
Create or update a blob lifecycle policy.

**Parameters**:
- `@policy_id` (INT, optional) - NULL for insert, ID for update
- `@name` (NVARCHAR(200), required) - Policy name (must be unique)
- `@is_active` (BIT, default 1) - Whether policy is active
- `@cold_min_age_days` (INT, optional) - Move to Cold after N days
- `@archive_min_age_days` (INT, optional) - Move to Archive after N days
- `@delete_min_age_days` (INT, optional) - Delete after N days
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `policy_id` and success message

**Example**:
```sql
-- Aggressive lifecycle (fast deletion)
EXEC sp_upsert_blob_policy 
    @name = 'aggressive_lifecycle',
    @cold_min_age_days = 7,
    @archive_min_age_days = 30,
    @delete_min_age_days = 180,
    @created_by = 'john.doe';

-- Conservative lifecycle (slow deletion)
EXEC sp_upsert_blob_policy 
    @name = 'conservative_lifecycle',
    @cold_min_age_days = 90,
    @archive_min_age_days = 365,
    @delete_min_age_days = 2555,  -- ~7 years
    @created_by = 'john.doe';
```

**Validation**:
- ✅ Name is required and must be unique
- ✅ At least one lifecycle threshold must be specified
- ✅ Age values must be positive integers
- ✅ Logical progression: Cold < Archive < Delete

---

### Configuration Procedures

#### sp_upsert_blob_configuration
Create or update a blob storage configuration.

**Parameters**:
- `@config_id` (INT, optional) - NULL for insert, ID for update
- `@is_enabled` (BIT, default 1) - Whether config is enabled
- `@storage_account_name` (NVARCHAR(128), required) - Azure storage account
- `@container_name` (NVARCHAR(128), required) - Blob container
- `@prefix` (NVARCHAR(1024), required) - Blob prefix (auto-appends `/`)
- `@include_pattern` (NVARCHAR(2000), optional) - Glob pattern to include
- `@exclude_pattern` (NVARCHAR(2000), optional) - Glob pattern to exclude
- `@supports_archive_tier` (BIT, default 1) - Storage supports Archive tier
- `@business_date_source` (NVARCHAR(20), default 'FromFileName') - 'CreatedOn' or 'LastModified'
- `@is_external` (BIT, default 0) - External blob discovery
- `@dataset_path_template` (NVARCHAR(1024), optional) - Path template for external
- `@business_date_folder_format` (NVARCHAR(50), optional) - Date format for external
- `@business_date_folder_depth` (INT, optional) - Folder depth for external
- `@blob_policy_id` (INT, required) - FK to blob policy
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `config_id` and success message

**Example** (Internal - for table archives):
```sql
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'usfinregreparchival',
    @container_name = 'brokerdealer',
    @prefix = 'tbl_reporting_comb_stock_record/',
    @supports_archive_tier = 1,
    @business_date_source = 'FromFileName',
    @blob_policy_id = 1,
    @created_by = 'dev.user';
```

**Example** (External - for existing blobs):
```sql
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'yacoasysqe5cvf8b1private',
    @container_name = 'app',
    @prefix = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
    @supports_archive_tier = 1,
    @business_date_source = 'FromFileName',
    @is_external = 1,
    @dataset_path_template = 'AllocationSummary_{yyyy}{MM}{dd}.parquet',
    @business_date_folder_format = 'yyyy-MM-dd',
    @business_date_folder_depth = 1,
    @blob_policy_id = 1,
    @created_by = 'dev.user';
```

**Internal prefix note**:
- The stored procedure **requires** `@prefix` for **all** blob configurations (Internal and external).
- For **Internal** configs, the runtime **does not build blob paths from this prefix**; it uses the table configuration `archive_path_template` to generate the export path.
- The Intrenal prefix is still stored on `archival_blob_configuration` and can be used for grouping, filtering, and future reporting.

**Validation**:
- ✅ Storage account name: 3-24 chars, lowercase alphanumeric
- ✅ Container name: 3-63 chars, lowercase alphanumeric and hyphens
- ✅ Prefix is required (auto-appends `/`)
- ✅ Blob policy must exist and be active
- ✅ External configs require `dataset_path_template`, `business_date_folder_format`, `business_date_folder_depth`

---

#### sp_upsert_table_configuration
Create or update a table archival configuration.

**Parameters**:
- `@config_id` (INT, optional) - NULL for insert, ID for update
- `@is_active` (BIT, default 1) - Whether config is active
- `@database_name` (NVARCHAR(128), required) - Source database name
- `@schema_name` (NVARCHAR(128), required) - Source schema (e.g., 'dbo')
- `@table_name` (NVARCHAR(128), required) - Source table name
- `@as_of_date_column` (NVARCHAR(128), required) - Business date column
- `@archive_path_template` (NVARCHAR(400), required) - Blob path with date tokens
- `@table_policy_id` (INT, required) - FK to table policy
- `@blob_configuration_id` (INT, required) - FK to blob configuration
- `@delete_after_export` (BIT, default 0) - Delete source rows after export
- `@batch_delete_size` (INT, default 10000) - Batch size for deletes
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `config_id` and success message

**Example**:
```sql
EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb',
    @schema_name = 'dbo',
    @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = 1,
    @blob_configuration_id = 1,
    @delete_after_export = 1,
    @batch_delete_size = 10000,
    @created_by = 'dev.user';
```

**Path Template Tokens**:
- `{yyyy}` - 4-digit year (e.g., 2026)
- `{MM}` - 2-digit month (e.g., 02)
- `{dd}` - 2-digit day (e.g., 17)

**Validation**:
- ✅ All required fields must be provided
- ✅ Path template must contain at least one date token
- ✅ Table policy must exist and be active
- ✅ Blob configuration must exist and be enabled
- ✅ Unique per (database, schema, table)
- ✅ Batch delete size must be positive

---

### Exemption Procedures

#### sp_add_table_exemption
Protect a specific table/date from archival.

**Parameters**:
- `@table_configuration_id` (INT, required) - FK to table configuration
- `@as_of_date` (DATE, required) - Date to exempt
- `@reason` (NVARCHAR(4000), required) - Why this is exempt
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `exemption_id` and success message

**Example**:
```sql
EXEC sp_add_table_exemption 
    @table_configuration_id = 5,
    @as_of_date = '2026-02-15',
    @reason = 'Data under investigation for quality issues',
    @created_by = 'john.doe';
```

**Use Cases**:
- Data quality investigations
- Compliance holds
- Temporary protection during audits
- Known bad data that shouldn't be archived

---

#### sp_add_blob_exemption
Protect a specific blob prefix/date from lifecycle actions.

**Parameters**:
- `@blob_configuration_id` (INT, required) - FK to blob configuration
- `@as_of_date` (DATE, required) - Date to exempt
- `@container_name` (NVARCHAR(128), required) - Container name
- `@prefix` (NVARCHAR(1024), required) - Blob prefix (auto-appends `/`)
- `@reason` (NVARCHAR(4000), required) - Why this is exempt
- `@created_by` (NVARCHAR(100), optional) - Your username/email

**Returns**: `exemption_id` and success message

**Example**:
```sql
EXEC sp_add_blob_exemption 
    @blob_configuration_id = 1,
    @as_of_date = '2023-11-08',
    @container_name = 'app',
    @prefix = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
    @reason = 'Needed for audit',
    @created_by = 'dev.user';
```

---

### Query Procedures

#### sp_get_table_policies
List all table retention policies.

**Parameters**:
- `@is_active` (BIT, optional) - NULL = all, 1 = active only, 0 = inactive only

**Example**:
```sql
-- All policies
EXEC sp_get_table_policies;

-- Active only
EXEC sp_get_table_policies @is_active = 1;
```

---

#### sp_get_blob_policies
List all blob lifecycle policies.

**Parameters**:
- `@is_active` (BIT, optional) - NULL = all, 1 = active only, 0 = inactive only

**Example**:
```sql
-- All policies
EXEC sp_get_blob_policies;

-- Active only
EXEC sp_get_blob_policies @is_active = 1;
```

---

#### sp_get_blob_configurations
List all blob storage configurations.

**Parameters**:
- `@is_enabled` (BIT, optional) - NULL = all, 1 = enabled only, 0 = disabled only

**Example**:
```sql
-- All configurations
EXEC sp_get_blob_configurations;

-- Enabled only
EXEC sp_get_blob_configurations @is_enabled = 1;
```

---

#### sp_get_table_configurations
List all table archival configurations.

**Parameters**:
- `@is_active` (BIT, optional) - NULL = all, 1 = active only, 0 = inactive only

**Example**:
```sql
-- All configurations
EXEC sp_get_table_configurations;

-- Active only
EXEC sp_get_table_configurations @is_active = 1;
```

---

## Configuration Workflows

### Workflow 1: Configure Table Archival (Internal Blobs)

**Goal**: Archive a table and manage its blob lifecycle.

**Steps**:
1. Create table retention policy
2. Create blob lifecycle policy
3. Create blob configuration (Internal)
4. Create table configuration
5. Test with dry-run (optional)

**Script**:
```sql
-- 1. Table retention: Keep 90 days
DECLARE @table_policy_id INT;
EXEC sp_upsert_table_policy 
    @name = 'keep_90_days',
    @keep_last_eod = 90,
    @created_by = 'john.doe';
SET @table_policy_id = SCOPE_IDENTITY();

-- 2. Blob lifecycle: Cold@30, Archive@90, Delete@365
DECLARE @blob_policy_id INT;
EXEC sp_upsert_blob_policy 
    @name = 'standard_lifecycle',
    @cold_min_age_days = 30,
    @archive_min_age_days = 90,
    @delete_min_age_days = 365,
    @created_by = 'john.doe';
SET @blob_policy_id = SCOPE_IDENTITY();

-- 3. Blob config for table archives
DECLARE @blob_config_id INT;
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'usfinregreparchival',
    @container_name = 'brokerdealer',
    @prefix = 'tbl_reporting_comb_stock_record/',
    @supports_archive_tier = 1,
    @blob_policy_id = @blob_policy_id,
    @created_by = 'dev.user';
SET @blob_config_id = SCOPE_IDENTITY();

-- 4. Table config
EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb',
    @schema_name = 'dbo',
    @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = @table_policy_id,
    @blob_configuration_id = @blob_config_id,
    @delete_after_export = 1,
    @created_by = 'dev.user';

-- 5. Verify
EXEC sp_get_table_configurations @is_active = 1;
```

---

### Workflow 2: Configure External Blob Lifecycle

**Goal**: Manage lifecycle of existing blobs (not from table archival).

**Steps**:
1. Create blob lifecycle policy
2. Create blob configuration (External)
3. Run blob lifecycle discover + execute

**Script**:
```sql
-- 1. Blob lifecycle policy
DECLARE @blob_policy_id INT;
EXEC sp_upsert_blob_policy 
    @name = 'sensors_lifecycle',
    @cold_min_age_days = 7,
    @archive_min_age_days = 30,
    @delete_min_age_days = 180,
    @created_by = 'john.doe';
SET @blob_policy_id = SCOPE_IDENTITY();

-- 2. External blob configuration
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'yacoasysqe5cvf8b1private',
    @container_name = 'app',
    @prefix = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
    @supports_archive_tier = 1,
    @business_date_source = 'External',
    @is_external = 1,
    @dataset_path_template = 'AllocationSummary_{yyyy}{MM}{dd}.parquet',
    @business_date_folder_format = 'yyyy-MM-dd',
    @business_date_folder_depth = 1,
    @blob_policy_id = @blob_policy_id,
    @created_by = 'dev.user';

-- 3. Verify
EXEC sp_get_blob_configurations @is_enabled = 1;
```

---

### Workflow 3: Add Exemptions

**Goal**: Temporarily protect data from archival/lifecycle.

**Script**:
```sql
-- Table exemption
EXEC sp_add_table_exemption 
    @table_configuration_id = 5,
    @as_of_date = '2026-02-15',
    @reason = 'Under investigation',
    @created_by = 'john.doe';

-- Blob exemption
EXEC sp_add_blob_exemption 
    @blob_configuration_id = 1,
    @as_of_date = '2023-11-08',
    @container_name = 'app',
    @prefix = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
    @reason = 'Needed for audit',
    @created_by = 'dev.user';
```

---

## Examples

### Example 1: Multiple Tables, Same Policy

```sql
-- Create shared policy
DECLARE @table_policy_id INT, @blob_config_id INT;

EXEC sp_upsert_table_policy 
    @name = 'shared_90_days',
    @keep_last_eod = 90,
    @created_by = 'john.doe';
SET @table_policy_id = SCOPE_IDENTITY();

-- Reuse existing blob config
SET @blob_config_id = 1;

-- Configure multiple tables
EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb', @schema_name = 'dbo', @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = @table_policy_id, @blob_configuration_id = @blob_config_id,
    @delete_after_export = 1,
    @created_by = 'dev.user';

EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb', @schema_name = 'dbo', @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = @table_policy_id, @blob_configuration_id = @blob_config_id,
    @delete_after_export = 1,
    @created_by = 'dev.user';
```

---

### Example 2: Different Retention Rules

```sql
-- Short retention (30 days)
DECLARE @short_policy_id INT;
EXEC sp_upsert_table_policy 
    @name = 'keep_30_days',
    @keep_last_eod = 30,
    @created_by = 'john.doe';
SET @short_policy_id = SCOPE_IDENTITY();

-- Long retention (1 year + monthly + yearly)
DECLARE @long_policy_id INT;
EXEC sp_upsert_table_policy 
    @name = 'keep_1_year_plus_monthly',
    @keep_last_eod = 365,
    @keep_last_eom = 36,  -- 3 years of month-ends
    @keep_last_eoy = 10,  -- 10 years of year-ends
    @created_by = 'john.doe';
SET @long_policy_id = SCOPE_IDENTITY();
```

---

### Example 3: Delete Source Data After Export

⚠️ **WARNING**: This is destructive! Ensure backups exist.

```sql
EXEC sp_upsert_table_configuration 
    @database_name = 'CoreDb',
    @schema_name = 'dbo',
    @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = 1,
    @blob_configuration_id = 1,
    @delete_after_export = 1,  -- ⚠️ DESTRUCTIVE
    @batch_delete_size = 10000,
    @created_by = 'dev.user';
```

---

### Example 4: Update Existing Configuration

```sql
-- Disable a table configuration
EXEC sp_upsert_table_configuration 
    @config_id = 5,  -- Existing config ID
    @is_active = 0,  -- Disable
    @database_name = 'CoreDb',
    @schema_name = 'dbo',
    @table_name = 'tbl_reporting_comb_stock_record',
    @as_of_date_column = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id = 1,
    @blob_configuration_id = 1,
    @delete_after_export = 1,
    @created_by = 'dev.user';

-- Update retention policy
EXEC sp_upsert_table_policy 
    @policy_id = 1,  -- Existing policy ID
    @name = 'keep_120_days_updated',
    @keep_last_eod = 120,  -- Changed from 90
    @created_by = 'john.doe';
```

---

## Real-World Sample Configurations

### Internal Blob Configuration (Generated by Table Archival)

```sql
EXEC dbo.sp_upsert_blob_configuration
    @storage_account_name = 'usfinregreparchival',
    @container_name       = 'brokerdealer',
    @prefix               = 'tbl_reporting_comb_stock_record/',
    @supports_archive_tier= 1,
    @business_date_source = 'FromFileName',
    @is_external          = 0,
    @blob_policy_id       = 1,
    @created_by           = 'dev.user';
```

**Internal vs External (quick note)**:
- **Internal** configs are for blobs created by table archival.
- They use the **table configuration’s** `archive_path_template` to build blob paths.
- External-only fields (`dataset_path_template`, `business_date_folder_format`, `business_date_folder_depth`) are **not required**.

---

### External Blob Configuration (Discovered from Existing Blobs)

```sql
EXEC dbo.sp_upsert_blob_configuration
    @storage_account_name        = 'yacoasysqe5cvf8b1private',
    @container_name              = 'app',
    @prefix                      = 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
    @supports_archive_tier       = 1,
    @business_date_source        = 'External',
    @is_external                 = 1,
    @dataset_path_template       = 'AllocationSummary_{yyyy}{MM}{dd}.parquet',
    @business_date_folder_format = 'yyyy-MM-dd',
    @business_date_folder_depth  = 1,
    @blob_policy_id              = 1,
    @created_by                  = 'dev.user';
```

**How the external path is interpreted**:
- The **date folder** (e.g., `2023-11-08`) is parsed using `business_date_folder_format`.
- `dataset_path_template` defines the dataset file/folder name used for lifecycle tracking.

**Example full path**:
```
/app/file-output/modules/sgas/15c3-3/output/AllocationSummary/2023-11-08/AllocationSummary_20231108.parquet/part-00000-<guid>-c000.snappy.parquet
```

---

### Table Configuration (Archival Output Path)

```sql
EXEC dbo.sp_upsert_table_configuration
    @database_name         = 'CoreDb',
    @schema_name           = 'dbo',
    @table_name            = 'tbl_reporting_comb_stock_record',
    @as_of_date_column     = 'businessDate',
    @archive_path_template = '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/',
    @table_policy_id       = 1,
    @blob_configuration_id = 1,
    @delete_after_export   = 1,
    @batch_delete_size     = 10000,
    @created_by            = 'dev.user';
```

**Generated path (Internal)**:
```
usfinregreparchival/brokerdealer/tbl_reporting_comb_stock_record/
  dbo.tbl_reporting_comb_stock_record/2023-11-08/
  tbl_reporting_comb_stock_record_20231108.Parquet/
  part-00000-<guid>-c000.snappy.parquet
```

---

## Validation Rules

### Table Policy Validation
- ✅ Name is required and must be unique
- ✅ At least one retention rule (EOD/EOM/EOQ/EOY) must be specified
- ✅ Retention values must be positive integers
- ✅ Policy cannot be deleted if referenced by active table configurations

### Blob Policy Validation
- ✅ Name is required and must be unique
- ✅ At least one lifecycle threshold must be specified
- ✅ Age values must be positive integers
- ✅ Logical progression: Cold < Archive < Delete
- ✅ Policy cannot be deleted if referenced by enabled blob configurations

### Blob Configuration Validation
- ✅ Storage account name: 3-24 characters, lowercase alphanumeric only
- ✅ Container name: 3-63 characters, lowercase alphanumeric and hyphens only
- ✅ Prefix is required (auto-appends `/` if missing)
- ✅ Blob policy must exist and be active
- ✅ External configs require: `dataset_path_template`, `business_date_folder_format`, `business_date_folder_depth`

### Table Configuration Validation
- ✅ All required fields must be provided
- ✅ Archive path template must contain at least one date token: `{yyyy}`, `{MM}`, or `{dd}`
- ✅ Table policy must exist and be active
- ✅ Blob configuration must exist and be enabled
- ✅ Unique per (database, schema, table)
- ✅ Batch delete size must be positive

### Exemption Validation
- ✅ Configuration must exist
- ✅ Date is required
- ✅ Reason is required
- ✅ Unique per (configuration, prefix, date)

---

## Troubleshooting

### Error: "Policy name already exists"
**Cause**: Duplicate policy name  
**Solution**: Choose a different name or update existing policy
```sql
-- Find existing policies
EXEC sp_get_table_policies;
EXEC sp_get_blob_policies;

-- Update existing instead of creating new
EXEC sp_upsert_table_policy @policy_id = 1, @name = 'new_name', ...;
```

---

### Error: "Blob policy is not active"
**Cause**: Referenced policy is inactive  
**Solution**: Activate policy first
```sql
-- Activate policy
EXEC sp_upsert_blob_policy @policy_id = 1, @is_active = 1, ...;
```

---

### Error: "Storage account name must be lowercase alphanumeric only"
**Cause**: Invalid storage account name format  
**Solution**: Use lowercase letters and numbers only (3-24 chars)
```sql
-- ❌ Invalid
@storage_account_name = 'ProdArchive'  -- uppercase
@storage_account_name = 'prod-archive' -- hyphen not allowed
@storage_account_name = 'pa'           -- too short

-- ✅ Valid
@storage_account_name = 'prodarchive'
```

---

### Error: "Archive path template must contain at least one date token"
**Cause**: Path template missing date tokens  
**Solution**: Add `{yyyy}`, `{MM}`, or `{dd}`
```sql
-- ❌ Invalid
@archive_path_template = 'sales/orders/'

-- ✅ Valid
@archive_path_template = 'sales/orders/{yyyy}/{MM}/{dd}/'
```

---

### Error: "cold_min_age_days must be less than archive_min_age_days"
**Cause**: Lifecycle progression is illogical  
**Solution**: Ensure Cold < Archive < Delete
```sql
-- ❌ Invalid
@cold_min_age_days = 90,
@archive_min_age_days = 30  -- Archive before Cold!

-- ✅ Valid
@cold_min_age_days = 30,
@archive_min_age_days = 90,
@delete_min_age_days = 365
```

---

### Error: "A configuration for this table already exists"
**Cause**: Duplicate table configuration  
**Solution**: Update existing configuration
```sql
-- Find existing config ID
SELECT id FROM archival_table_configuration 
WHERE database_name = 'SalesDB' AND schema_name = 'dbo' AND table_name = 'Orders';

-- Update instead of insert
EXEC sp_upsert_table_configuration @config_id = 5, ...;
```

---

## Best Practices

### 1. Naming Conventions
```sql
-- Use descriptive names
✅ 'keep_90_days_sales_tables'
✅ 'aggressive_lifecycle_temp_data'
❌ 'policy1'
❌ 'config_test'
```

### 2. Always Specify created_by
```sql
-- Track who created/modified
EXEC sp_upsert_table_policy 
    @name = 'keep_90_days',
    @keep_last_eod = 90,
    @created_by = 'john.doe';  -- ✅ Good for audit trail
```

### 3. Test Before Enabling
```sql
-- Create configuration as inactive first
EXEC sp_upsert_table_configuration 
    @is_active = 0,  -- ✅ Test first
    ...;

-- Enable after validation
EXEC sp_upsert_table_configuration 
    @config_id = 5,
    @is_active = 1,  -- ✅ Now enable
    ...;
```

### 4. Start Conservative
```sql
-- Start with longer retention, shorten later
✅ @keep_last_eod = 180  -- Start with 6 months
❌ @keep_last_eod = 7    -- Risky to start aggressive
```

### 5. Document Exemptions
```sql
-- Always provide clear reason
EXEC sp_add_table_exemption 
    @table_configuration_id = 5,
    @as_of_date = '2026-02-15',
    @reason = 'Under investigation - Ticket #12345 - Expected resolution 2026-03-01',
    @created_by = 'john.doe';
```

---

## Quick Reference

### Minimal Table Archival Setup
```sql
-- 1. Table policy
EXEC sp_upsert_table_policy @name = 'policy_name', @keep_last_eod = 90, @created_by = 'user';

-- 2. Blob policy
EXEC sp_upsert_blob_policy @name = 'policy_name', @cold_min_age_days = 30, @created_by = 'user';

-- 3. Blob config
EXEC sp_upsert_blob_configuration 
    @storage_account_name = 'account', @container_name = 'container', @prefix = 'prefix/', 
    @blob_policy_id = 1, @created_by = 'user';

-- 4. Table config
EXEC sp_upsert_table_configuration 
    @database_name = 'DB', @schema_name = 'dbo', @table_name = 'Table',
    @as_of_date_column = 'date_col', @archive_path_template = 'path/{yyyy}/{MM}/{dd}/',
    @table_policy_id = 1, @blob_configuration_id = 1, @created_by = 'user';
```

### View All Active Configurations
```sql
EXEC sp_get_table_policies @is_active = 1;
EXEC sp_get_blob_policies @is_active = 1;
EXEC sp_get_blob_configurations @is_enabled = 1;
EXEC sp_get_table_configurations @is_active = 1;
```

---

**Document Version**: 1.0  
**Last Updated**: February 17, 2026  
**Maintained By**: Data Platform Team

---

**Need Help?**
- Check [SCHEMA_DOCUMENTATION.md](SCHEMA_DOCUMENTATION.md) for table details
- Check [README.md](../README.md) for application usage
- Contact: [data-platform-team@example.com]

---

**END OF GUIDE**
