﻿# Metadata database (SQL Server)

Archival is configuration-driven. It uses a **SQL Server metadata database** to store:

- *What to archive* (table configurations)
- *How much to retain* (table retention policies)
- *Which blob prefixes to manage* (blob configurations)
- *When to tier/delete* (blob lifecycle policies)
- Exemptions
- Run history + per-item results
- Dataset tracking (table exports and blob datasets)

> Source of truth for schema: `src/Archival.Data/ArchivalDbContext.cs` (EF Core model). The SQL script in `db/archival_schema.sql` should match it; verify before using in production.

## Engine and schema management

- **DB engine**: SQL Server
- **Schema definition**:
  - EF Core model in `src/Archival.Data/ArchivalDbContext.cs`
  - A baseline schema script exists at `db/archival_schema.sql`
  - SQL migrations exist under `db/migrations/` (SQL scripts)

> This repo does **not** contain EF Core migration classes; DB evolution appears to be managed via SQL scripts + keeping EF mapping in sync.

## Schema summary (tables and purpose)

### Policy tables
- `archival_table_policy`: retention rules for keeping EOD/EOM/EOQ/EOY snapshots.
- `archival_blob_policy`: lifecycle thresholds (cold/archive/delete min age in days).

### Configuration tables
- `archival_table_configuration`: what source tables to archive and where to write in Blob storage.
- `archival_blob_configuration`: blob target/prefix and (for external sources) discovery settings.

### Exemption tables
- `archival_table_exemption`: skip specific (table configuration, business date) from archival.
- `archival_blob_exemption`: skip specific (blob configuration, prefix, business date) from lifecycle actions.

### Run tracking tables
- `archival_run`: one row per CLI invocation (table archival or blob lifecycle).
- `archival_run_item`: per-dataset/per-action results for observability.

### Dataset tables
- `archival_dataset`: one row per archived (table configuration, business date) export.
- `archival_blob_dataset`: one row per (blob configuration, business date) dataset/prefix tracked for lifecycle.

## Key relationships / constraints (high-signal)

- `archival_table_configuration.table_policy_id` → `archival_table_policy.id`
- `archival_table_configuration.blob_configuration_id` → `archival_blob_configuration.id`

- `archival_blob_configuration.blob_policy_id` → `archival_blob_policy.id`

- `archival_dataset.table_configuration_id` → `archival_table_configuration.id`
  - Unique: `(table_configuration_id, as_of_date)` (idempotency)

- `archival_blob_dataset.blob_configuration_id` → `archival_blob_configuration.id`
  - Unique: `(blob_configuration_id, as_of_date)` (idempotency across discover runs)
  - Optional link: `archival_blob_dataset.archival_dataset_id` → `archival_dataset.id`

- `archival_run_item.run_id` → `archival_run.id`
  - Filtered unique indexes for deduplication within a run:
    - `(run_id, item_type, table_configuration_id, as_of_date)` when table/date are non-null
    - `(run_id, item_type, blob_configuration_id, as_of_date)` when blob/date are non-null

## Diagram (ER-ish)

```mermaid
erDiagram
  archival_table_policy ||--o{ archival_table_configuration : has
  archival_blob_policy  ||--o{ archival_blob_configuration  : has

  archival_blob_configuration ||--o{ archival_table_configuration : destination

  archival_table_configuration ||--o{ archival_table_exemption : exempts
  archival_blob_configuration  ||--o{ archival_blob_exemption  : exempts

  archival_table_configuration ||--o{ archival_dataset : produces
  archival_blob_configuration  ||--o{ archival_blob_dataset : tracks

  archival_dataset ||--o{ archival_blob_dataset : links_optional

  archival_run ||--o{ archival_run_item : contains
  archival_table_configuration ||--o{ archival_run_item : references_optional
  archival_blob_configuration  ||--o{ archival_run_item : references_optional
```

## Creating / updating the DB locally

### Option A (recommended): run the schema script

Use the script under `db/archival_schema.sql`.

How to verify it matches code:
- Compare the created tables/columns with the EF mappings in `src/Archival.Data/ArchivalDbContext.cs`.
- Pay extra attention to indexes and unique constraints (they drive idempotency).

### Option B: apply SQL migrations

Run migration scripts in `db/migrations/` in numeric order.

Example: the repo contains `db/migrations/010_remove_supports_archive_tier.sql` which drops a column from `archival_blob_configuration`.

## Configuration records (what the app expects)

Archival reads configuration at runtime from the metadata tables.

### Minimal setup for table archival
1. Create a `archival_table_policy`
2. Create a `archival_blob_policy`
3. Create a `archival_blob_configuration` (destination storage account/container/prefix)
4. Create a `archival_table_configuration` (source table + blob config + retention policy)

### Minimal setup for blob lifecycle
1. Create a `archival_blob_policy`
2. Create one or more `archival_blob_configuration` rows
   - For **external** discovery, set:
     - `is_external = 1`
     - `dataset_path_template`
     - `business_date_folder_format`
     - `business_date_folder_depth`
   - For **internal**, discovery is driven by table archival pushing rows into `archival_blob_dataset`.

> Note (verified in code): external discovery currently uses `IsExternal` as the switch. See `DiscoverBlobDatasetsHandler`.

## Stored procedures

A helper script exists at `db/stored_procedures.sql` to create upsert/query stored procedures.

Important: comments inside that file currently describe `business_date_source` values as `'FromFileName'|'CreatedOn'|'LastModified'`, which matches the enum `BusinessDateSource` in code (`src/Archival.Application/Shared/Models/BusinessDateSource.cs`). That is separate from the internal/external concept which is controlled by `is_external`.

If something doesn’t match your environment:
- Prefer the EF Core model as the schema truth.
- Prefer verifying the stored procedure parameter semantics by reading `db/stored_procedures.sql` and the consumers in `src/Archival.Data`.

