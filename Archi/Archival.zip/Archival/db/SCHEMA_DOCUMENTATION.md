﻿# Archival Database Schema Documentation

**Version**: 1.0  
**Date**: February 17, 2026  
**Audience**: Developers, Database Administrators

---

## Overview

The Archival metadata database stores configuration, policies, run history, and tracking data for the Archival system. It consists of **10 tables** organized into 5 logical groups.

### Quick Navigation
- [Architecture Overview](#architecture-overview)
- [Table Groups](#table-groups)
- [Table Descriptions](#table-descriptions)
- [Relationships](#relationships)
- [Indexes and Constraints](#indexes-and-constraints)
- [Data Flow](#data-flow)
- [Common Queries](#common-queries)

---

## Architecture Overview

### Design Principles
1. **Configuration-Driven**: All archival rules stored in database
2. **Idempotent**: Safe to re-run operations (unique constraints prevent duplicates)
3. **Traceable**: Complete audit trail via run/run_item tables
4. **Flexible**: Supports multiple storage accounts, retention policies, and lifecycle rules

### Naming Conventions
- **Tables**: `snake_case` with `archival_` prefix
- **Primary Keys**: `id` (INT for config tables, BIGINT for transactional tables)
- **Foreign Keys**: `{referenced_table}_id` (e.g., `table_policy_id`)
- **Timestamps**: `{action}_at` suffix (e.g., `created_at`, `started_at`)
- **All timestamps**: UTC (DATETIME2(3))

---

## Table Groups

### 1. Policy Tables (2 tables)
Define retention rules and lifecycle thresholds.

| Table | Purpose |
|-------|---------|
| `archival_table_policy` | Table retention rules (keep last N EOD/EOM/EOQ/EOY) |
| `archival_blob_policy` | Blob lifecycle thresholds (cold/archive/delete age) |

### 2. Configuration Tables (2 tables)
Define what to archive and where to store it.

| Table | Purpose |
|-------|---------|
| `archival_blob_configuration` | Blob storage targets and lifecycle settings |
| `archival_table_configuration` | Tables to archive and where to store exports |

### 3. Exemption Tables (2 tables)
Protect specific data from archival or lifecycle actions.

| Table | Purpose |
|-------|---------|
| `archival_table_exemption` | Dates to exclude from table archival |
| `archival_blob_exemption` | Blob prefixes/dates to exclude from lifecycle |

### 4. Run Tracking Tables (2 tables)
Track archival runs and results.

| Table | Purpose |
|-------|---------|
| `archival_run` | High-level run tracking (table archival or blob lifecycle) |
| `archival_run_item` | Individual items processed in each run |

### 5. Dataset Tables (2 tables)
Track archived datasets and blob lifecycle state.

| Table | Purpose |
|-------|---------|
| `archival_dataset` | Table exports (Parquet files) |
| `archival_blob_dataset` | Blob datasets and lifecycle actions |

---

## Table Descriptions

### 1. archival_table_policy

**Purpose**: Defines how many historical snapshots to keep for tables.

**Columns**:
- `id` (PK): Unique policy identifier
- `name`: Policy name (e.g., "keep_90_days", "keep_1_year")
- `is_active`: Whether policy is currently active
- `keep_last_eod`: Keep last N end-of-day snapshots (NULL = don't apply this rule)
- `keep_last_eom`: Keep last N end-of-month snapshots
- `keep_last_eoq`: Keep last N end-of-quarter snapshots
- `keep_last_eoy`: Keep last N end-of-year snapshots
- `created_at`, `created_by`, `updated_at`, `updated_by`: Audit fields

**Retention Logic**: A date is kept if it matches ANY of the keep rules. Example:
- `keep_last_eod = 90, keep_last_eom = 12, keep_last_eoy = 5`
- Keeps: Last 90 days + last 12 month-ends + last 5 year-ends

**Example**:
```sql
INSERT INTO archival_table_policy (name, is_active, keep_last_eod, keep_last_eom, created_at)
VALUES ('standard_90_days', 1, 90, 12, GETUTCDATE());
```

---

### 2. archival_blob_policy

**Purpose**: Defines lifecycle thresholds for blob tier management.

**Columns**:
- `id` (PK): Unique policy identifier
- `name`: Policy name (e.g., "aggressive_lifecycle", "standard_lifecycle")
- `is_active`: Whether policy is currently active
- `cold_min_age_days`: Move blobs to Cold tier after N days (NULL = skip Cold)
- `archive_min_age_days`: Move blobs to Archive tier after N days (NULL = skip Archive)
- `delete_min_age_days`: Delete blobs after N days (NULL = never delete)
- `created_at`, `created_by`, `updated_at`, `updated_by`: Audit fields

**Lifecycle Precedence**: Delete > Archive > Cold (highest age wins)

**Example**:
```sql
INSERT INTO archival_blob_policy (name, is_active, cold_min_age_days, archive_min_age_days, delete_min_age_days, created_at)
VALUES ('standard_lifecycle', 1, 30, 90, 365, GETUTCDATE());
-- Means: Cold after 30 days, Archive after 90 days, Delete after 365 days
```

---

### 3. archival_blob_configuration

**Purpose**: Defines blob storage locations and lifecycle settings.

**Columns**:
- `id` (PK): Unique configuration identifier
- `is_enabled`: Whether this configuration is active
- `storage_account_name`: Azure Storage account name
- `container_name`: Blob container name
- `prefix`: Blob prefix to manage (e.g., "sales/transactions/")
- `include_pattern`: Optional glob pattern to include (e.g., "*.parquet")
- `exclude_pattern`: Optional glob pattern to exclude (e.g., "*.tmp")
- `supports_archive_tier`: Whether storage account supports Archive tier
- `business_date_source`: "Internal" (from table archival) or "External" (discovered)
- `is_external`: True for external blob discovery (vs internal table exports)
- `dataset_path_template`: Template for dataset path (e.g., "{yyyy}/{MM}/{dd}/")
- `business_date_folder_format`: Date format in folder names (e.g., "yyyy/MM/dd")
- `business_date_folder_depth`: Folder depth to extract date from (0-based)
- `blob_policy_id` (FK): References `archival_blob_policy`
- `created_at`, `created_by`, `updated_at`, `updated_by`: Audit fields

**Use Cases**:
1. **Internal**: Manages blobs created by table archival (source_type = Internal)
2. **External**: Discovers and manages existing blobs (source_type = External)

**Archive Tier Support**:
Archive tier support is now **determined at runtime** during lifecycle execution using a fallback mechanism:
- Lifecycle execution **always attempts Archive tier first** (optimistic approach)
- If Archive fails with status 400/409 (not supported), automatically **falls back to Cold tier**
- This handles all Azure storage account types (Standard with Archive, Premium without Archive, Legacy)
- No preconfiguration needed — the system automatically adapts to account capabilities

**Example**:
```sql
-- Internal configuration (for table archives)
INSERT INTO archival_blob_configuration 
(is_enabled, storage_account_name, container_name, prefix, supports_archive_tier, 
 business_date_source, is_external, blob_policy_id, created_at)
VALUES 
(1, 'usfinregreparchival', 'brokerdealer', 'tbl_reporting_comb_stock_record/', 1, 'Internal', 0, 1, GETUTCDATE());

-- External configuration (for existing blobs)
INSERT INTO archival_blob_configuration 
(is_enabled, storage_account_name, container_name, prefix, supports_archive_tier, 
 business_date_source, is_external, dataset_path_template, business_date_folder_format, 
 business_date_folder_depth, blob_policy_id, created_at)
VALUES 
(1, 'yacoasysqe5cvf8b1private', 'app', 'file-output/modules/sgas/15c3-3/output/AllocationSummary/', 1, 'External', 1, 
 'AllocationSummary_{yyyy}{MM}{dd}.parquet', 'yyyy-MM-dd', 1, 1, GETUTCDATE());
```

**Internal vs External (quick note)**:
- Internal uses the **table configuration** `archive_path_template` to build blob paths.
- External uses the **blob configuration** `dataset_path_template` and date folder parsing.
- The `prefix` field is still **required** for internal configs and stored for grouping/filtering.

---

### 4. archival_table_configuration

**Purpose**: Defines which tables to archive and where to store exports.

**Columns**:
- `id` (PK): Unique configuration identifier
- `is_active`: Whether this table is actively archived
- `database_name`: Source database name
- `schema_name`: Source schema name (e.g., "dbo")
- `table_name`: Source table name
- `as_of_date_column`: Column containing business date (e.g., "transaction_date")
- `archive_path_template`: Blob path template (e.g., "sales/orders/{yyyy}/{MM}/{dd}/")
- `table_policy_id` (FK): References `archival_table_policy`
- `blob_configuration_id` (FK): References `archival_blob_configuration`
- `delete_after_export`: Whether to delete source rows after successful export
- `batch_delete_size`: Batch size for DELETE operations (e.g., 10000)
- `created_at`, `created_by`, `updated_at`, `updated_by`: Audit fields

**Unique Constraint**: `(database_name, schema_name, table_name)` - one config per table

**Path Template Tokens**:
- `{yyyy}`: 4-digit year (e.g., 2026)
- `{MM}`: 2-digit month (e.g., 02)
- `{dd}`: 2-digit day (e.g., 17)

**Example**:
```sql
INSERT INTO archival_table_configuration 
(is_active, database_name, schema_name, table_name, as_of_date_column, 
 archive_path_template, table_policy_id, blob_configuration_id, 
 delete_after_export, batch_delete_size, created_at)
VALUES 
(1, 'CoreDb', 'dbo', 'tbl_reporting_comb_stock_record', 'businessDate', 
 '/{schema}.{table}/{yyyy}-{MM}-{dd}/{table}_{yyyy}{MM}{dd}.Parquet/', 1, 1, 
 1, 10000, GETUTCDATE());
```

---

### 5. archival_table_exemption

**Purpose**: Protects specific table/date combinations from archival.

**Columns**:
- `id` (PK): Unique exemption identifier
- `table_configuration_id` (FK): References `archival_table_configuration`
- `as_of_date`: Date to exempt (DATE type)
- `reason`: Why this date is exempt (e.g., "Under investigation", "Compliance hold")
- `created_at`, `created_by`: Audit fields

**Unique Constraint**: `(table_configuration_id, as_of_date)` - one exemption per table/date

**Use Case**: 
- Temporarily protect data from archival during investigation
- Compliance holds on specific dates
- Known bad data that shouldn't be archived

**Example**:
```sql
INSERT INTO archival_table_exemption 
(table_configuration_id, as_of_date, reason, created_at, created_by)
VALUES 
(5, '2026-02-15', 'Under investigation for data quality issue', GETUTCDATE(), 'john.doe');
```

---

### 6. archival_blob_exemption

**Purpose**: Protects specific blob prefixes/dates from lifecycle actions.

**Columns**:
- `id` (PK): Unique exemption identifier
- `blob_configuration_id` (FK): References `archival_blob_configuration`
- `as_of_date`: Date to exempt (DATE type)
- `container_name`: Blob container
- `prefix`: Blob prefix to protect (e.g., "sales/2026/02/15/")
- `reason`: Why this is exempt
- `created_at`, `created_by`: Audit fields

**Unique Constraint**: `(blob_configuration_id, prefix, as_of_date)` - one exemption per config/prefix/date

**Example**:
```sql
INSERT INTO archival_blob_exemption 
(blob_configuration_id, as_of_date, container_name, prefix, reason, created_at, created_by)
VALUES 
(1, '2023-11-08', 'app', 'file-output/modules/sgas/15c3-3/output/AllocationSummary/',
 'Needed for audit', GETUTCDATE(), 'dev.user');
```

---

### 7. archival_run

**Purpose**: Tracks high-level archival runs.

**Columns**:
- `id` (PK): Unique run identifier (BIGINT)
- `run_type`: "Archive" (table archival) or "Lifecycle" (blob lifecycle)
- `started_at`: Run start timestamp (UTC)
- `ended_at`: Run end timestamp (UTC, NULL if still running)
- `status`: "Running", "Succeeded", "Failed", "PartiallySucceeded"
- `note`: Optional note (e.g., "Processed 50 tables, 5 failed")

**Use Case**: High-level run tracking and monitoring

**Example**:
```sql
-- Inserted by application on run start
INSERT INTO archival_run (run_type, started_at, status)
VALUES ('Archive', GETUTCDATE(), 'Running');

-- Updated on run completion
UPDATE archival_run 
SET ended_at = GETUTCDATE(), status = 'Succeeded', note = 'Processed 10 tables'
WHERE id = 42;
```

---

### 8. archival_run_item

**Purpose**: Tracks individual items processed in each run.

**Columns**:
- `id` (PK): Unique item identifier (BIGINT)
- `run_id` (FK): References `archival_run`
- `item_type`: "Dataset" (table export) or "BlobAction" (lifecycle action)
- `table_configuration_id` (FK, nullable): For table datasets
- `as_of_date` (nullable): Business date
- `blob_configuration_id` (FK, nullable): For blob actions
- `item_key`: Optional display key (e.g., "SalesDB.dbo.Orders/2026-02-15")
- `action`: Action taken (e.g., "Export", "SetCold", "Delete")
- `status`: "Succeeded" or "Failed"
- `rows_affected`: Number of rows (for table operations)
- `bytes_affected`: Number of bytes (for blob operations)
- `error_message`: Error details if status = Failed
- `created_at`: Timestamp (UTC)

**Unique Constraints** (filtered for non-null):
- `(run_id, item_type, table_configuration_id, as_of_date)` - prevents duplicate table items
- `(run_id, item_type, blob_configuration_id, as_of_date)` - prevents duplicate blob items

**Example**:
```sql
INSERT INTO archival_run_item 
(run_id, item_type, table_configuration_id, as_of_date, action, status, 
 rows_affected, bytes_affected, created_at)
VALUES 
(42, 'Dataset', 5, '2026-02-15', 'Export', 'Succeeded', 
 125000, 5242880, GETUTCDATE());
```

---

### 9. archival_dataset

**Purpose**: Records each table export (Parquet files).

**Columns**:
- `id` (PK): Unique dataset identifier (BIGINT)
- `table_configuration_id` (FK): References `archival_table_configuration`
- `as_of_date`: Business date (DATE)
- `date_type`: "EOD" (end of day), "EOM" (end of month), "EOQ" (end of quarter), "EOY" (end of year)
- `storage_account_name`: Where exported
- `container_name`: Blob container
- `blob_prefix`: Blob prefix (e.g., "sales/orders/2026/02/15/")
- `part_count`: Number of Parquet files (e.g., 5 files: part-0000.parquet to part-0004.parquet)
- `total_bytes`: Total size in bytes
- `row_count`: Total rows exported
- `status`: "Pending", "Succeeded", "Failed"
- `created_at`: When export started (UTC)
- `completed_at`: When export completed (UTC, NULL if not complete)
- `error_summary`: Error details if status = Failed

**Unique Constraint**: `(table_configuration_id, as_of_date)` - one dataset per table/date (idempotent)

**Example**:
```sql
INSERT INTO archival_dataset 
(table_configuration_id, as_of_date, date_type, storage_account_name, container_name, 
 blob_prefix, part_count, total_bytes, row_count, status, created_at, completed_at)
VALUES 
(1, '2023-11-08', 'EOD', 'usfinregreparchival', 'brokerdealer', 
 '/dbo.tbl_reporting_comb_stock_record/2023-11-08/tbl_reporting_comb_stock_record_20231108.Parquet/',
 1, 5242880, 125000, 'Succeeded',
 GETUTCDATE(), GETUTCDATE());
```

---

### 10. archival_blob_dataset

**Purpose**: Tracks blob datasets and their lifecycle state.

**Columns**:

**Identity**:
- `id` (PK): Unique dataset identifier (BIGINT)
- `blob_configuration_id` (FK): References `archival_blob_configuration`
- `source_type`: 0 = Internal (from table export), 1 = External (discovered)
- `as_of_date`: Business date (DATE)
- `storage_account_name`: Storage account
- `container_name`: Container
- `blob_prefix`: Prefix (up to 2048 chars)
- `archival_dataset_id` (FK, nullable): Links to `archival_dataset` if source_type = Internal

**Lifecycle State**:
- `current_tier`: 0 = Unknown, 1 = Hot, 2 = Cool, 3 = Cold, 4 = Archive
- `next_action`: 0 = None, 1 = SetCold, 2 = SetArchive, 3 = Delete
- `next_action_at`: When next action is due (UTC)
- `is_deleted`: True if deleted (soft delete for audit trail)

**Last Action Tracking**:
- `last_action`: 1 = SetCold, 2 = SetArchive, 3 = Delete
- `last_action_at`: When last action completed (UTC)
- `attempt_count`: Number of retry attempts
- `last_error`: Last error message (up to 2000 chars)

**Discover-Execute Pattern** (for idempotency and crash recovery):
- `discovered_at`: When dataset was discovered (UTC)
- `executed_at`: When execution completed (UTC, NULL if pending)
- `execution_status`: 0 = Pending, 1 = Succeeded, 2 = Failed

**Timestamps**:
- `created_at`: Record creation (UTC)
- `updated_at`: Last update (UTC)

**Unique Constraint**: `(blob_configuration_id, as_of_date)` - prevents duplicate discovery

**Indexes**:
- `(blob_configuration_id, execution_status)` - for querying pending datasets
- `(blob_configuration_id, next_action_at)` - for querying due datasets

**Example**:
```sql
-- Internal blob dataset (from table export)
INSERT INTO archival_blob_dataset 
(blob_configuration_id, source_type, as_of_date, storage_account_name, container_name, 
 blob_prefix, archival_dataset_id, current_tier, next_action, next_action_at, 
 is_deleted, discovered_at, execution_status, created_at, updated_at)
VALUES 
(1, 0, '2023-11-08', 'usfinregreparchival', 'brokerdealer', 
 'tbl_reporting_comb_stock_record/dbo.tbl_reporting_comb_stock_record/2023-11-08/tbl_reporting_comb_stock_record_20231108.Parquet/',
 1, 1, 1, DATEADD(day, 30, '2023-11-08'), 
 0, GETUTCDATE(), 0, GETUTCDATE(), GETUTCDATE());

-- Means: Hot tier, SetCold action due 30 days after 2023-11-08, Pending execution
```

---

## Relationships

### Entity-Relationship Diagram (Simplified)

```
archival_table_policy ──┐
                        ├──→ archival_table_configuration ──┐
archival_blob_configuration ─┘                              ├──→ archival_table_exemption
                                                            │
                                                            ├──→ archival_dataset ──┐
                                                            │                       │
archival_blob_policy ──→ archival_blob_configuration ──┐   │                       │
                                                       ├───┼──→ archival_blob_exemption
                                                       │   │
                                                       └───┼──→ archival_blob_dataset
                                                           │        │
archival_run ──→ archival_run_item ──┐                    │        │
                                     ├────────────────────┘        │
                                     └───────────────────────────────┘
```

### Key Relationships

1. **archival_table_configuration**:
   - References `archival_table_policy` (retention rules)
   - References `archival_blob_configuration` (storage location)

2. **archival_blob_configuration**:
   - References `archival_blob_policy` (lifecycle thresholds)

3. **archival_dataset**:
   - References `archival_table_configuration` (which table)

4. **archival_blob_dataset**:
   - References `archival_blob_configuration` (lifecycle rules)
   - References `archival_dataset` (if Internal source type)

5. **archival_run_item**:
   - References `archival_run` (parent run)
   - References `archival_table_configuration` (for table items)
   - References `archival_blob_configuration` (for blob items)

6. **archival_table_exemption**:
   - References `archival_table_configuration`

7. **archival_blob_exemption**:
   - References `archival_blob_configuration`

---

## Indexes and Constraints

### Unique Constraints (Idempotency)

| Table | Constraint | Purpose |
|-------|-----------|---------|
| `archival_table_configuration` | `(database_name, schema_name, table_name)` | One config per table |
| `archival_table_exemption` | `(table_configuration_id, as_of_date)` | One exemption per table/date |
| `archival_blob_exemption` | `(blob_configuration_id, prefix, as_of_date)` | One exemption per config/prefix/date |
| `archival_dataset` | `(table_configuration_id, as_of_date)` | One dataset per table/date |
| `archival_blob_dataset` | `(blob_configuration_id, as_of_date)` | One blob dataset per config/date |
| `archival_run_item` | `(run_id, item_type, table_configuration_id, as_of_date)` | One table item per run (filtered) |
| `archival_run_item` | `(run_id, item_type, blob_configuration_id, as_of_date)` | One blob item per run (filtered) |

### Performance Indexes

| Table | Index | Purpose |
|-------|-------|---------|
| `archival_blob_dataset` | `(blob_configuration_id, execution_status)` | Query pending datasets |
| `archival_blob_dataset` | `(blob_configuration_id, next_action_at)` | Query due datasets |

### Foreign Key Constraints

All foreign keys use `ON DELETE` behavior:
- **RESTRICT**: Prevents deletion if referenced (most relationships)
- **SET NULL**: Sets to NULL on parent delete (`archival_blob_dataset.archival_dataset_id`)
- **NO ACTION**: Default behavior (`archival_run_item` references)

---

## Data Flow

### Table Archival Flow

1. **Configuration**: Admin inserts records into:
   - `archival_table_policy` (retention rules)
   - `archival_blob_configuration` (storage location)
   - `archival_table_configuration` (table to archive)

2. **Run Start**: Application inserts into `archival_run` (status = Running)

3. **For Each Table**:
   - Check `archival_table_exemption` for exempt dates
   - Calculate retention (using `archival_table_policy`)
   - Export candidate dates to Parquet
   - Insert into `archival_dataset` (status = Succeeded)
   - Insert into `archival_run_item` (status = Succeeded/Failed)
   - If export succeeded:
     - Insert into `archival_blob_dataset` (for lifecycle tracking)

4. **Run Complete**: Update `archival_run` (status = Succeeded/Failed)

### Blob Lifecycle Flow

1. **Configuration**: Admin inserts records into:
   - `archival_blob_policy` (lifecycle thresholds)
   - `archival_blob_configuration` (blob prefixes to manage)

2. **Discover Stage**:
   - List blobs in storage
   - Upsert into `archival_blob_dataset` (execution_status = Pending)
   - Compute next_action based on age and policy

3. **Execute Stage**:
   - Query `archival_blob_dataset` WHERE execution_status = Pending AND next_action_at <= NOW
   - Perform lifecycle action (SetCold, SetArchive, Delete)
   - Update `archival_blob_dataset` (execution_status = Succeeded/Failed)
   - Insert into `archival_run_item`

4. **Idempotency**: If discover crashes and re-runs, unique constraint prevents duplicates

---

## Common Queries

### 1. View Active Table Configurations
```sql
SELECT 
    tc.id,
    tc.database_name,
    tc.schema_name,
    tc.table_name,
    tp.name AS table_policy,
    bc.storage_account_name,
    bc.container_name
FROM archival_table_configuration tc
JOIN archival_table_policy tp ON tc.table_policy_id = tp.id
JOIN archival_blob_configuration bc ON tc.blob_configuration_id = bc.id
WHERE tc.is_active = 1;
```

### 2. View Recent Runs
```sql
SELECT 
    id,
    run_type,
    started_at,
    ended_at,
    status,
    DATEDIFF(MINUTE, started_at, COALESCE(ended_at, GETUTCDATE())) AS duration_minutes
FROM archival_run
ORDER BY started_at DESC;
```

### 3. View Failed Run Items
```sql
SELECT 
    r.run_type,
    r.started_at,
    ri.item_type,
    ri.item_key,
    ri.error_message
FROM archival_run_item ri
JOIN archival_run r ON ri.run_id = r.id
WHERE ri.status = 'Failed'
  AND ri.created_at >= DATEADD(DAY, -7, GETUTCDATE())
ORDER BY ri.created_at DESC;
```

### 4. View Datasets Needing Lifecycle Action
```sql
SELECT 
    bd.id,
    bc.storage_account_name,
    bc.container_name,
    bd.blob_prefix,
    bd.current_tier,
    bd.next_action,
    bd.next_action_at
FROM archival_blob_dataset bd
JOIN archival_blob_configuration bc ON bd.blob_configuration_id = bc.id
WHERE bd.execution_status = 0  -- Pending
  AND bd.next_action != 0      -- Has action
  AND bd.next_action_at <= GETUTCDATE()
  AND bd.is_deleted = 0
ORDER BY bd.next_action_at;
```

### 5. View Exemptions
```sql
-- Table exemptions
SELECT 
    tc.table_name,
    te.as_of_date,
    te.reason,
    te.created_by
FROM archival_table_exemption te
JOIN archival_table_configuration tc ON te.table_configuration_id = tc.id;

-- Blob exemptions
SELECT 
    bc.prefix AS config_prefix,
    be.prefix AS exempt_prefix,
    be.as_of_date,
    be.reason
FROM archival_blob_exemption be
JOIN archival_blob_configuration bc ON be.blob_configuration_id = bc.id;
```

### 6. View Archive Statistics
```sql
SELECT 
    tc.table_name,
    COUNT(*) AS datasets_count,
    SUM(d.row_count) AS total_rows,
    SUM(d.total_bytes) / 1024 / 1024 / 1024 AS total_gb,
    MIN(d.as_of_date) AS oldest_date,
    MAX(d.as_of_date) AS newest_date
FROM archival_dataset d
JOIN archival_table_configuration tc ON d.table_configuration_id = tc.id
WHERE d.status = 'Succeeded'
GROUP BY tc.table_name;
```

---

## Schema Versioning

### Current Version: 1.0

**Migrations Applied**:
- `007_blob_dataset_idempotency_and_execution_status.sql` - Added discover-execute pattern
- `008_add_exemption_unique_constraints.sql` - Added unique constraints for idempotency

**Location**: `db/migrations/`

### Future Migration Strategy

When schema changes are needed:
1. Create new migration file: `00X_description.sql`
2. Document changes in migration file comments
3. Test on dev database
4. Apply to production with backup
5. Update this documentation

---

## Best Practices

### 1. Idempotency
- All operations should be safe to re-run
- Unique constraints prevent duplicate records
- Upsert patterns for discovery

### 2. Audit Trail
- Always populate `created_by` fields
- Never delete configuration records (set `is_active = 0` instead)
- Keep run history for troubleshooting

### 3. Performance
- Use indexes for frequently queried columns
- Filter by `is_active`, `is_enabled` to reduce result sets
- Use `as_of_date` ranges for time-based queries

### 4. Data Consistency
- Use transactions for multi-table operations
- Check foreign key constraints before deletion
- Validate dates before insertion (use DATE type consistently)

---

## Troubleshooting

### Issue: Cannot delete table configuration
**Cause**: Referenced by `archival_dataset` or `archival_run_item`  
**Solution**: Set `is_active = 0` instead of deleting

### Issue: Duplicate blob datasets
**Cause**: Unique constraint violation  
**Solution**: Check `(blob_configuration_id, as_of_date)` uniqueness

### Issue: Foreign key constraint violation
**Cause**: Referenced record doesn't exist  
**Solution**: Check parent table exists before inserting child record

---

## Glossary

- **EOD**: End of Day
- **EOM**: End of Month
- **EOQ**: End of Quarter
- **EOY**: End of Year
- **As-Of Date**: Business date for the data (not creation timestamp)
- **Dataset**: Collection of blobs representing one table/date export
- **Lifecycle**: Blob tier management (Hot → Cold → Archive → Delete)
- **Exemption**: Data protected from archival or lifecycle actions
- **Run**: One execution of table archival or blob lifecycle
- **Run Item**: Individual item processed in a run

---

**Document Version**: 1.0  
**Last Updated**: February 17, 2026  
**Maintained By**: Data Platform Team

---

**END OF DOCUMENTATION**
