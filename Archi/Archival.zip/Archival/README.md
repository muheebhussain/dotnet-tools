﻿# Archival — SQL→Parquet Archiver + Blob Lifecycle CLI

Archival is a **CLI-first** tool that:

1) **Archives SQL tables** by business date to **Azure Blob Storage** as **Parquet**
2) **Manages blob lifecycle** (tier to Cold/Archive, then Delete) for datasets under configured blob prefixes

Everything is **metadata-driven**: what runs and how it behaves is controlled primarily by records in the metadata database.

## Key concepts (mental model)

- **Metadata DB (SQL Server)**: stores *configuration* (what to archive / lifecycle rules) and *tracking* (runs, datasets, history)
- **Table archival**: for each configured table, find business dates present in the source table, apply retention rules, export candidates
- **Blob lifecycle**: discover datasets (mainly for *external* sources), then execute tier/delete actions for datasets that are due

## Repo map

- `src/Archival.App` — CLI entry point and composition root (DI/config/logging)
- `src/Archival.Application` — core workflows (handlers), domain models, result pattern
- `src/Archival.Data` — EF Core model + stores/repositories for the metadata DB
- `src/Archival.Infrastructure` — Azure Blob + Parquet + SQL Server adapters
- `db/` — schema + stored procedures + SQL migrations for the metadata DB
- `docs/architecture.md` — diagrams + deeper workflow and operational notes
- `db/README.md` — schema overview + how configuration tables drive runtime

## Prerequisites

- .NET SDK that supports `net10.0` (see `src/Archival.App/Archival.App.csproj`)
- SQL Server (for the metadata DB)
- Azure Storage account (Blob) for actual end-to-end runs

For local/dev-only exploration, you can still build and run help commands without Azure access.

## Quick start (local)

### 1) Restore + build

```powershell
cd C:\Users\muhee\Downloads\Archival\Archival

dotnet restore .\Archival.sln

dotnet build .\Archival.sln -c Release
```

### 2) Create the metadata database

This repo provides a baseline schema script:

- `db/archival_schema.sql`

Apply it to a SQL Server database you create (name it whatever you want).

How to verify the schema is current:
- Compare tables/columns/indexes to `src/Archival.Data/ArchivalDbContext.cs` (schema source of truth in code).

### 3) Configure the metadata DB connection

Archival reads the metadata DB connection string from:

- `src/Archival.App/appsettings.json` / `appsettings.Development.json` → `ConnectionStrings:ArchivalMetadataDb`
- or environment variable `ARCHIVAL_METADATA_DB` (fallback)

### 4) Create secrets files (source DBs + storage accounts)

Archival resolves **source database** and **storage account** connection strings via JSON files in a secrets directory.

Default secrets directory:
- from `src/Archival.App/appsettings.Development.json`: `SecretsPath = "./secrets/"`

Files expected in that directory:
- `archival-db-connections.json` — maps `database_name` → SQL connection string
- `archival-storage-connections.json` — maps `storage_account_name` → Azure Storage connection string

> The app wires `IConnectionStringResolver` to read these files. See `src/Archival.Infrastructure/ServiceCollectionExtensions.cs`.

Example shapes (sanitized):

```json
// secrets/archival-db-connections.json
{
  "reporting_db": "Server=YOURSERVER;Database=ReportingDb;Integrated Security=True;TrustServerCertificate=True;"
}
```

```json
// secrets/archival-storage-connections.json
{
  "prodarchive": "DefaultEndpointsProtocol=https;AccountName=prodarchive;AccountKey=***;EndpointSuffix=core.windows.net"
}
```

### 5) Run the CLI

From the repo root:

```powershell
# Help
cd C:\Users\muhee\Downloads\Archival\Archival

dotnet run --project .\src\Archival.App -- help

# Table archival

dotnet run --project .\src\Archival.App -- table --all-active

# Blob lifecycle (discover + execute)

dotnet run --project .\src\Archival.App -- blob lifecycle --all
```

If your secrets aren’t in the configured path, override at runtime:

```powershell
dotnet run --project .\src\Archival.App -- table --all-active --secrets-path C:\path\to\secrets\
```

## Running workflows (what actually happens)

### Table archival (`table`)

Commands (verified in `src/Archival.App/Cli/CliParser.cs`):

- `table --all-active`
- `table --table-config-id <ID>`

High-level:

1. CLI routes to `RunTableArchivalHandler`
2. Handler starts a run (`archival_run`)
3. Loads active table configurations
4. For each table:
   - Reads distinct business dates present in the source table
   - Applies table retention policy + exemptions
   - Skips dates already archived successfully
   - Exports remaining dates to Parquet in Azure Blob
   - Writes/updates `archival_dataset` and pushes/updates `archival_blob_dataset` (internal tracking)
5. Completes run and writes `archival_run_item` entries

### Blob lifecycle (`blob discover|execute|lifecycle`)

Commands (verified in `src/Archival.App/Cli/CliParser.cs`):

- `blob discover [--internal|--external|--all] [--blob-config-id <ID>]`
- `blob execute  [--internal|--external|--all] [--blob-config-id <ID>]`
- `blob lifecycle [--internal|--external|--all] [--blob-config-id <ID>]` (discover then execute)

Notes based on current handlers:

- `DiscoverBlobDatasetsHandler` **only processes external** configurations (`IsExternal = 1`). Internal datasets are expected to be created/updated by table archival.
- `ExecuteBlobDatasetsHandler` processes due datasets with bounded concurrency controlled by `BlobLifecycle` options.

## Configuration guide (runtime)

### App configuration files

- `src/Archival.App/appsettings.json`
- `src/Archival.App/appsettings.Development.json`

Key settings (verified in code):

- `ConnectionStrings:ArchivalMetadataDb`
- `SecretsPath`
- `BlobLifecycle:*` → binds to `BlobLifecycleOptions` (application layer)
- `ParquetExport:*` → binds to `ParquetExportOptions` (infrastructure layer)

If you’re unsure what a setting does:
- Search for its options class (`BlobLifecycleOptions`, `ParquetExportOptions`) and see how it’s consumed.

### Metadata DB configuration

Most runtime behavior comes from DB records:

- what tables are active (`archival_table_configuration.is_active`)
- retention rules (`archival_table_policy`)
- lifecycle thresholds (`archival_blob_policy`)
- lifecycle scope + discovery settings (`archival_blob_configuration`)
- exemptions (`archival_*_exemption`)

See `db/README.md` for the table-by-table breakdown.

## Diagrams (start here)

For full diagrams, see `docs/architecture.md`. A quick glance of the main flows:

```mermaid
flowchart LR
  CLI[Archival.App CLI] -->|table| Table[RunTableArchivalHandler]
  CLI -->|blob discover/execute| Blob[Discover/Execute Blob Datasets]
  Table --> Meta[(Metadata DB)]
  Blob --> Meta
  Table --> Src[(Source SQL DBs)]
  Table --> Storage[(Azure Blob Storage)]
  Blob --> Storage
```

## Troubleshooting

### Build/runtime
- **Target framework mismatch**: projects target `net10.0`. Make sure your installed SDK supports it.
- **Metadata DB connection fails**:
  - Validate `ConnectionStrings:ArchivalMetadataDb` in `src/Archival.App/appsettings*.json`
  - Or set `ARCHIVAL_METADATA_DB`
- **Secrets not found / connection resolver failures**:
  - Confirm `SecretsPath` (or pass `--secrets-path`)
  - Confirm the two JSON files exist and are valid JSON
- **Azure permission errors**:
  - Storage connection string must allow list, read, set tier, and delete depending on actions.
- **No work happening**:
  - Ensure you have active rows in `archival_table_configuration` / enabled rows in `archival_blob_configuration`
  - For `blob discover`, ensure configs are `is_external = 1` and include discovery fields.

## Where to go next

- Architecture + workflows + operational notes: `docs/architecture.md`
- Metadata DB schema + configuration tables: `db/README.md`
- Table Configurations: `db/CONFIGURATION_GUIDE.md`
- Schema Documentation: `db/SCHEMA_DOCUMENTATION.md`

