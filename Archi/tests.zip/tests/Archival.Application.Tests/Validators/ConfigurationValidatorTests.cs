﻿using Archival.Application.Shared.Models;
using Archival.Application.Validators;
using Xunit;

namespace Archival.Application.Tests.Validators;

/// <summary>
/// Tests for configuration validation logic.
/// Covers HIGH-3: Configuration validation.
/// </summary>
public class ConfigurationValidatorTests
{
    /// <summary>
    /// Tests that valid table configuration passes validation.
    /// </summary>
    [Fact]
    public void ValidateTableConfiguration_ValidConfig_ReturnsSuccess()
    {
        // Arrange
        var config = new TableConfigurationDto(
            Id: 1,
            IsActive: true,
            DatabaseName: "AdventureWorks",
            SchemaName: "dbo",
            TableName: "Orders",
            BusinessDateColumnName: "OrderDate",
            TablePolicyId: 1,
            BlobConfigurationId: 1,
            ArchivePathTemplate: "archive/{schema}/{table}/{yyyy}/{MM}/{dd}/",
            DeleteAfterExport: true,
            BatchDeleteSize: 10000);

        // Act
        var result = ConfigurationValidator.ValidateTableConfiguration(config);

        // Assert
        Assert.True(result.Ok);
    }

    /// <summary>
    /// Tests that batch delete size <= 0 fails validation.
    /// </summary>
    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    [InlineData(-100)]
    public void ValidateTableConfiguration_InvalidBatchSize_ReturnsFail(int batchSize)
    {
        // Arrange
        var config = new TableConfigurationDto(
            Id: 1, IsActive: true, DatabaseName: "AdventureWorks", SchemaName: "dbo",
            TableName: "Orders", BusinessDateColumnName: "OrderDate", TablePolicyId: 1,
            BlobConfigurationId: 1, ArchivePathTemplate: "archive/{schema}/{table}/",
            DeleteAfterExport: true, BatchDeleteSize: batchSize);

        // Act
        var result = ConfigurationValidator.ValidateTableConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("BatchDeleteSize must be positive", result.Error);
    }

    /// <summary>
    /// Tests that empty archive path template fails validation.
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("   ")]
    public void ValidateTableConfiguration_EmptyTemplate_ReturnsFail(string template)
    {
        // Arrange
        var config = new TableConfigurationDto(
            Id: 1, IsActive: true, DatabaseName: "AdventureWorks", SchemaName: "dbo",
            TableName: "Orders", BusinessDateColumnName: "OrderDate", TablePolicyId: 1,
            BlobConfigurationId: 1, ArchivePathTemplate: template,
            DeleteAfterExport: true, BatchDeleteSize: 10000);

        // Act
        var result = ConfigurationValidator.ValidateTableConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("ArchivePathTemplate is required", result.Error);
    }

    /// <summary>
    /// Tests that archive path with invalid blob characters fails validation.
    /// </summary>
    [Theory]
    [InlineData("archive/my|table/")]          // pipe
    [InlineData("archive/my\"table/")]         // quote
    [InlineData("archive/my<table>/")]         // angle bracket
    [InlineData("archive/my>table>/")]         // angle bracket
    [InlineData("archive/my?table/")]          // question mark
    [InlineData("archive/my*table/")]          // asterisk
    [InlineData("archive/my\\table/")]         // backslash
    public void ValidateTableConfiguration_InvalidCharacters_ReturnsFail(string template)
    {
        // Arrange
        var config = new TableConfigurationDto(
            Id: 1, IsActive: true, DatabaseName: "AdventureWorks", SchemaName: "dbo",
            TableName: "Orders", BusinessDateColumnName: "OrderDate", TablePolicyId: 1,
            BlobConfigurationId: 1, ArchivePathTemplate: template,
            DeleteAfterExport: true, BatchDeleteSize: 10000);

        // Act
        var result = ConfigurationValidator.ValidateTableConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("invalid blob path characters", result.Error);
    }

    /// <summary>
    /// Tests that valid blob configuration passes validation.
    /// </summary>
    [Fact]
    public void ValidateBlobConfiguration_ValidConfig_ReturnsSuccess()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1,
            IsEnabled: true,
            StorageAccountName: "myarchivalsa",
            ContainerName: "archive",
            Prefix: "blobs/",
            IncludePattern: "*.parquet",
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName,
            BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.True(result.Ok);
    }

    /// <summary>
    /// Tests that missing storage account fails validation.
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("   ")]
    public void ValidateBlobConfiguration_MissingStorageAccount_ReturnsFail(string storageAccount)
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: storageAccount,
            ContainerName: "archive", Prefix: "blobs/", IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("StorageAccountName is required", result.Error);
    }

    /// <summary>
    /// Tests that missing container name fails validation.
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("   ")]
    public void ValidateBlobConfiguration_MissingContainerName_ReturnsFail(string container)
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "mysa",
            ContainerName: container, Prefix: "blobs/", IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("ContainerName is required", result.Error);
    }

    /// <summary>
    /// Tests that invalid container names fail validation.
    /// </summary>
    [Theory]
    [InlineData("UPPERCASE")]               // uppercase not allowed
    [InlineData("my_container")]            // underscore not allowed
    [InlineData("my-container-")]           // ends with dash
    [InlineData("-my-container")]           // starts with dash
    [InlineData("ab")]                      // too short (< 3 chars)
    public void ValidateBlobConfiguration_InvalidContainerName_ReturnsFail(string containerName)
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "mysa",
            ContainerName: containerName, Prefix: "blobs/", IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("does not follow Azure container naming rules", result.Error);
    }

    /// <summary>
    /// Tests that valid container names pass validation.
    /// </summary>
    [Theory]
    [InlineData("archive")]                 // basic
    [InlineData("my-archive")]              // with dash
    [InlineData("archive2")]                // with number
    [InlineData("a1b2c3d4e5")]              // mixed alphanumeric
    [InlineData("abc")]                     // minimum length (3)
    public void ValidateBlobConfiguration_ValidContainerName_ReturnsSuccess(string containerName)
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "mysa",
            ContainerName: containerName, Prefix: "blobs/", IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.True(result.Ok);
    }

    /// <summary>
    /// Tests that prefix starting with slash is warned about.
    /// </summary>
    [Fact]
    public void ValidateBlobConfiguration_PrefixStartsWithSlash_ReturnsFail()
    {
        // Arrange
        var config = new BlobConfigurationDto(
            Id: 1, IsEnabled: true, StorageAccountName: "mysa",
            ContainerName: "archive", Prefix: "/blobs/", IncludePattern: null,
            ExcludePattern: null,
            BusinessDateSource: BusinessDateSource.FromFileName, BlobPolicyId: 1);

        // Act
        var result = ConfigurationValidator.ValidateBlobConfiguration(config);

        // Assert
        Assert.False(result.Ok);
        Assert.Contains("should not start with a forward slash", result.Error);
    }
}

