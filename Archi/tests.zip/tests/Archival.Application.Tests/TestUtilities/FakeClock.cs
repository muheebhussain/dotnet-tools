﻿using Archival.Application.Contracts.Time;

namespace Archival.Application.Tests.TestUtilities;

/// <summary>
/// Fake clock implementation for deterministic testing.
/// Allows tests to control "today" for age calculations.
/// </summary>
public class FakeClock : IClock
{
    private DateOnly _today;

    public FakeClock(DateOnly today)
    {
        _today = today;
    }

    public DateTime UtcNow => _today.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);
    
    public DateTime Now => _today.ToDateTime(TimeOnly.MinValue, DateTimeKind.Local);
    
    public DateOnly Today => _today;

    public void SetToday(DateOnly today)
    {
        _today = today;
    }

    public void AdvanceDays(int days)
    {
        _today = _today.AddDays(days);
    }

    /// <summary>
    /// Creates a FakeClock set to a specific date.
    /// </summary>
    public static FakeClock Create(int year, int month, int day)
    {
        return new FakeClock(new DateOnly(year, month, day));
    }

    /// <summary>
    /// Creates a FakeClock set to Feb 15, 2026 (current date in context).
    /// </summary>
    public static FakeClock CreateDefault()
    {
        return new FakeClock(new DateOnly(2026, 2, 15));
    }
}

