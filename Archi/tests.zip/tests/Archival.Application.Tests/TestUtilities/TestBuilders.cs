using Archival.Application.Shared.Models;

namespace Archival.Application.Tests.TestUtilities;

/// <summary>
/// Fluent builder for creating test TableConfigurationDto instances.
/// </summary>
public class TableConfigBuilder
{
    private int _id = 1;
    private bool _isActive = true;
    private string _databaseName = "TestDB";
    private string _schemaName = "dbo";
    private string _tableName = "TestTable";
    private string _businessDateColumnName = "AsOfDate";
    private int _tablePolicyId = 1;
    private int _blobConfigurationId = 1;
    private string _archivePathTemplate = "archive/{database}/{schema}/{table}/{yyyy}/{MM}/{dd}/";
    private bool _deleteAfterExport = true;
    private int _batchDeleteSize = 10000;

    public TableConfigBuilder WithId(int id)
    {
        _id = id;
        return this;
    }

    public TableConfigBuilder WithIsActive(bool isActive)
    {
        _isActive = isActive;
        return this;
    }

    public TableConfigBuilder WithDatabaseName(string databaseName)
    {
        _databaseName = databaseName;
        return this;
    }

    public TableConfigBuilder WithSchemaName(string schemaName)
    {
        _schemaName = schemaName;
        return this;
    }

    public TableConfigBuilder WithTableName(string tableName)
    {
        _tableName = tableName;
        return this;
    }

    public TableConfigBuilder WithBusinessDateColumnName(string columnName)
    {
        _businessDateColumnName = columnName;
        return this;
    }

    public TableConfigBuilder WithTablePolicyId(int policyId)
    {
        _tablePolicyId = policyId;
        return this;
    }

    public TableConfigBuilder WithBlobConfigurationId(int configId)
    {
        _blobConfigurationId = configId;
        return this;
    }

    public TableConfigBuilder WithArchivePathTemplate(string template)
    {
        _archivePathTemplate = template;
        return this;
    }

    public TableConfigBuilder WithDeleteAfterExport(bool delete)
    {
        _deleteAfterExport = delete;
        return this;
    }

    public TableConfigBuilder WithBatchDeleteSize(int size)
    {
        _batchDeleteSize = size;
        return this;
    }

    public TableConfigurationDto Build()
    {
        return new TableConfigurationDto(
            _id,
            _isActive,
            _databaseName,
            _schemaName,
            _tableName,
            _businessDateColumnName,
            _tablePolicyId,
            _blobConfigurationId,
            _archivePathTemplate,
            _deleteAfterExport,
            _batchDeleteSize);
    }
}

/// <summary>
/// Fluent builder for creating test BlobConfigurationDto instances.
/// </summary>
public class BlobConfigBuilder
{
    private int _id = 1;
    private bool _isEnabled = true;
    private string _storageAccountName = "teststorage";
    private string _containerName = "archive";
    private string _prefix = "archive/data/";
    private string? _includePattern = null;
    private string? _excludePattern = null;
    private BusinessDateSource _businessDateSource = BusinessDateSource.FromFileName;
    private int _blobPolicyId = 1;

    public BlobConfigBuilder WithId(int id)
    {
        _id = id;
        return this;
    }

    public BlobConfigBuilder WithIsEnabled(bool isEnabled)
    {
        _isEnabled = isEnabled;
        return this;
    }

    public BlobConfigBuilder WithStorageAccountName(string name)
    {
        _storageAccountName = name;
        return this;
    }

    public BlobConfigBuilder WithContainerName(string name)
    {
        _containerName = name;
        return this;
    }

    public BlobConfigBuilder WithPrefix(string prefix)
    {
        _prefix = prefix;
        return this;
    }

    public BlobConfigBuilder WithIncludePattern(string? pattern)
    {
        _includePattern = pattern;
        return this;
    }

    public BlobConfigBuilder WithExcludePattern(string? pattern)
    {
        _excludePattern = pattern;
        return this;
    }

    public BlobConfigBuilder WithBusinessDateSource(BusinessDateSource source)
    {
        _businessDateSource = source;
        return this;
    }

    public BlobConfigBuilder WithBlobPolicyId(int policyId)
    {
        _blobPolicyId = policyId;
        return this;
    }

    public BlobConfigurationDto Build()
    {
        return new BlobConfigurationDto(
            _id,
            _isEnabled,
            _storageAccountName,
            _containerName,
            _prefix,
            _includePattern,
            _excludePattern,
            _businessDateSource,
            _blobPolicyId);
    }
}

/// <summary>
/// Fluent builder for creating test DatasetDetailDto instances.
/// </summary>
public class DatasetDetailBuilder
{
    private long _datasetId = 1;
    private DateOnly _asOfDate = DateOnly.FromDateTime(DateTime.UtcNow);
    private DateType _dateType = DateType.EOD;
    private string _storageAccountName = "teststorage";
    private string _containerName = "archive";
    private string _blobPrefix = "archive/data/";
    private DatasetStatus _status = DatasetStatus.Succeeded;

    public DatasetDetailBuilder WithDatasetId(long id)
    {
        _datasetId = id;
        return this;
    }

    public DatasetDetailBuilder WithAsOfDate(DateOnly date)
    {
        _asOfDate = date;
        return this;
    }

    public DatasetDetailBuilder WithDateType(DateType dateType)
    {
        _dateType = dateType;
        return this;
    }

    public DatasetDetailBuilder WithStatus(DatasetStatus status)
    {
        _status = status;
        return this;
    }

    public DatasetDetailBuilder WithStorageAccountName(string name)
    {
        _storageAccountName = name;
        return this;
    }

    public DatasetDetailBuilder WithContainerName(string name)
    {
        _containerName = name;
        return this;
    }

    public DatasetDetailBuilder WithBlobPrefix(string prefix)
    {
        _blobPrefix = prefix;
        return this;
    }

    public DatasetDetailDto Build()
    {
        return new DatasetDetailDto(
            _datasetId,
            _asOfDate,
            _dateType,
            _storageAccountName,
            _containerName,
            _blobPrefix,
            _status);
    }
}

/// <summary>
/// Fluent builder for creating test LifecyclePolicyDto instances.
/// </summary>
public class LifecyclePolicyBuilder
{
    private int _id = 1;
    private string _name = "TestPolicy";
    private bool _isActive = true;
    private int? _coldMinAgeDays = 30;
    private int? _archiveMinAgeDays = 90;
    private int? _deleteMinAgeDays = 365;

    public LifecyclePolicyBuilder WithId(int id)
    {
        _id = id;
        return this;
    }

    public LifecyclePolicyBuilder WithName(string name)
    {
        _name = name;
        return this;
    }

    public LifecyclePolicyBuilder WithIsActive(bool isActive)
    {
        _isActive = isActive;
        return this;
    }

    public LifecyclePolicyBuilder WithColdMinAgeDays(int? days)
    {
        _coldMinAgeDays = days;
        return this;
    }

    public LifecyclePolicyBuilder WithArchiveMinAgeDays(int? days)
    {
        _archiveMinAgeDays = days;
        return this;
    }

    public LifecyclePolicyBuilder WithDeleteMinAgeDays(int? days)
    {
        _deleteMinAgeDays = days;
        return this;
    }

    public LifecyclePolicyDto Build()
    {
        return new LifecyclePolicyDto(
            _id, _isActive,
            _coldMinAgeDays,
            _archiveMinAgeDays,
            _deleteMinAgeDays);
    }
}

