﻿using Archival.Application.BlobLifecycle;
using Xunit;

namespace Archival.Application.Tests.BlobLifecycle;

/// <summary>
/// Tests for BlobExemptionMatcher optimized exemption checking.
/// Verifies exact matches, prefix matches, and edge cases.
/// </summary>
public class BlobExemptionMatcherTests
{
    [Fact]
    public void IsExempt_ExactMatch_ReturnsTrue()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026/02/10", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Exact match
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_ExactMatch_WithTrailingSlashes_ReturnsTrue()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026/02/10/", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Normalized matching (slashes trimmed)
        Assert.True(matcher.IsExempt("container1", "/data/2026/02/10", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10/", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_ContainerNameCaseInsensitive_ReturnsTrue()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("MyContainer", "data/file.txt", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Case-insensitive container matching
        Assert.True(matcher.IsExempt("mycontainer", "data/file.txt", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("MYCONTAINER", "data/file.txt", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("MyContainer", "data/file.txt", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_PrefixMatch_ReturnsTrue()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Prefix matches longer paths
        Assert.True(matcher.IsExempt("container1", "data/2026", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10/file.parquet", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_PartialSegmentDoesNotMatch_ReturnsFalse()
    {
        // Arrange - Critical edge case: "data" should NOT match "dat"
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Partial segments don't match
        Assert.False(matcher.IsExempt("container1", "dat", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "dat/2026", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "data-backup", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "data-backup/2026", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_SimilarPrefixesDoNotCrossMatch_ReturnsFalse()
    {
        // Arrange - Test similar but distinct prefixes
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "file-output", new DateOnly(2026, 2, 10)),
            ("container1", "data", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Similar prefixes don't cross-match
        Assert.False(matcher.IsExempt("container1", "file", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "file-output-backup", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "dat", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "data-archive", new DateOnly(2026, 2, 10)));

        // But actual prefixes and their children should match
        Assert.True(matcher.IsExempt("container1", "file-output", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "file-output/modules", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_DifferentDate_ReturnsFalse()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026/02/10", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Different date doesn't match
        Assert.False(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 11)));
        Assert.False(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 9)));
    }

    [Fact]
    public void IsExempt_DifferentContainer_ReturnsFalse()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/file.txt", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Different container doesn't match
        Assert.False(matcher.IsExempt("container2", "data/file.txt", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_EmptyExemptions_ReturnsFalse()
    {
        // Arrange
        var matcher = BlobExemptionMatcher.Create(Enumerable.Empty<(string Container, string Prefix, DateOnly Date)>());

        // Act & Assert - No exemptions means nothing is exempted
        Assert.False(matcher.IsExempt("container1", "data/file.txt", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_MultipleExemptions_MatchesAny()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026/02/10", new DateOnly(2026, 2, 10)),
            ("container1", "data/2026/02/11", new DateOnly(2026, 2, 11)),
            ("container2", "archive/2026", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - Each exemption matches independently
        Assert.True(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/2026/02/11", new DateOnly(2026, 2, 11)));
        Assert.True(matcher.IsExempt("container2", "archive/2026/file.txt", new DateOnly(2026, 2, 10)));

        // Cross-combinations don't match
        Assert.False(matcher.IsExempt("container1", "data/2026/02/10", new DateOnly(2026, 2, 11)));
        Assert.False(matcher.IsExempt("container2", "data/2026/02/10", new DateOnly(2026, 2, 10)));
    }

    [Fact]
    public void IsExempt_NestedPrefixes_MatchesDeepest()
    {
        // Arrange - Multiple levels of prefixes
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "file-output", new DateOnly(2026, 2, 10)),
            ("container1", "file-output/modules", new DateOnly(2026, 2, 10)),
            ("container1", "file-output/modules/sgas", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act & Assert - All nested levels match
        Assert.True(matcher.IsExempt("container1", "file-output", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "file-output/modules", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "file-output/modules/sgas", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "file-output/modules/sgas/2026", new DateOnly(2026, 2, 10)));
    }

    /// <summary>
    /// Performance-focused test to verify no repeated allocations in matching loop.
    /// Tests that matcher is efficient with large exemption sets.
    /// </summary>
    [Fact]
    public void IsExempt_LargeExemptionSet_PerformsEfficiently()
    {
        // Arrange - Create 1000 exemptions
        var exemptions = Enumerable.Range(1, 1000)
            .Select(i => ("container1", $"data/{i:D4}", new DateOnly(2026, 2, 10)))
            .ToList();

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Act - Perform 10,000 lookups (worst case: non-matching)
        var sw = System.Diagnostics.Stopwatch.StartNew();
        for (int i = 0; i < 10_000; i++)
        {
            _ = matcher.IsExempt("container1", $"data/{i % 1000:D4}/file.txt", new DateOnly(2026, 2, 10));
        }
        sw.Stop();

        // Assert - Should complete in reasonable time (< 100ms for 10k lookups)
        // On modern hardware, optimized matcher should be << 1μs per lookup
        Assert.True(sw.ElapsedMilliseconds < 100,
            $"10,000 lookups took {sw.ElapsedMilliseconds}ms (expected < 100ms)");

        // Verify correctness
        Assert.True(matcher.IsExempt("container1", "data/0042", new DateOnly(2026, 2, 10)));
        Assert.True(matcher.IsExempt("container1", "data/0042/subdir/file.txt", new DateOnly(2026, 2, 10)));
        Assert.False(matcher.IsExempt("container1", "data/9999", new DateOnly(2026, 2, 10)));
    }

    /// <summary>
    /// Memory allocation test: verify matcher creates stable structures
    /// and doesn't allocate per lookup.
    /// </summary>
    [Fact]
    public void IsExempt_RepeatedLookups_NoExcessiveAllocations()
    {
        // Arrange
        var exemptions = new List<(string Container, string Prefix, DateOnly Date)>
        {
            ("container1", "data/2026", new DateOnly(2026, 2, 10))
        };

        var matcher = BlobExemptionMatcher.Create(exemptions);

        // Force GC before test
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();

        var gen0Before = GC.CollectionCount(0);

        // Act - Perform 1000 lookups with same inputs (should hit cached paths)
        for (int i = 0; i < 1000; i++)
        {
            _ = matcher.IsExempt("container1", "data/2026/02/10/file.txt", new DateOnly(2026, 2, 10));
        }

        var gen0After = GC.CollectionCount(0);

        // Assert - Should cause minimal/no Gen0 collections
        // Optimized implementation should not allocate per lookup
        var gen0Collections = gen0After - gen0Before;
        Assert.True(gen0Collections <= 1,
            $"Too many Gen0 collections: {gen0Collections} (expected <= 1)");
    }
}

