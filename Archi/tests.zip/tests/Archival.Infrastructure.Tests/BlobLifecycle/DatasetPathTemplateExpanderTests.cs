﻿using Archival.Application.Contracts.BlobLifecycle;
using Archival.Application.Shared.Models;
using Archival.Infrastructure.BlobLifecycle;
using Xunit;

namespace Archival.Infrastructure.Tests.BlobLifecycle;

/// <summary>
/// Tests for dataset path template expansion used in blob discovery.
/// </summary>
public class DatasetPathTemplateExpanderTests
{
    private readonly IDatasetPathTemplateExpander _expander = new DatasetPathTemplateExpander();

    [Fact]
    public void ExpandTemplate_AllDateTokens_ExpandsCorrectly()
    {
        // Arrange
        var template = "data/{yyyy}/{MM}/{dd}/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("data/2023/11/08/", result);
    }

    [Fact]
    public void ExpandTemplate_DateToken_ExpandsCorrectly()
    {
        // Arrange
        var template = "dataset-{date}/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("dataset-2023-11-08/", result);
    }

    [Theory]
    [InlineData("{yyyy}", "2023")]
    [InlineData("{MM}", "11")]
    [InlineData("{dd}", "08")]
    [InlineData("{date}", "2023-11-08")]
    public void ExpandTemplate_IndividualTokens_ExpandCorrectly(string token, string expected)
    {
        // Arrange
        var template = token;
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public void ExpandTemplate_NoTokens_RemainsUnchanged()
    {
        // Arrange
        var template = "archive/fixed-path/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("archive/fixed-path/", result);
    }

    [Fact]
    public void ExpandTemplate_BackslashesConverted_ToForwardSlashes()
    {
        // Arrange
        var template = "data\\{yyyy}\\{MM}\\{dd}\\";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("data/2023/11/08/", result);
    }

    [Fact]
    public void ExpandTemplate_LeadingSlash_IsTrimmed()
    {
        // Arrange
        var template = "/{yyyy}-{MM}-{dd}/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("2023-11-08/", result);
    }

    [Fact]
    public void ExpandTemplate_CaseInsensitive_TokensExpand()
    {
        // Arrange
        var template = "{YYYY}/{MM}/{DD}/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act
        var result = _expander.ExpandTemplate(template, context);

        // Assert
        Assert.Equal("2023/11/08/", result);
    }

    [Fact]
    public void ExpandTemplate_UnknownToken_ThrowsException()
    {
        // Arrange
        var template = "{yyyy}/{unknown}/";
        var context = new DatasetPathTemplateContext(new DateOnly(2023, 11, 8));

        // Act & Assert
        Assert.Throws<ArgumentException>(() => _expander.ExpandTemplate(template, context));
    }

    [Fact]
    public void ValidateTemplate_EmptyTemplate_ThrowsException()
    {
        // Act & Assert
        Assert.Throws<ArgumentException>(() => _expander.ValidateTemplate(""));
    }

    [Fact]
    public void ValidateTemplate_ValidTemplate_DoesNotThrow()
    {
        // Act & Assert
        _expander.ValidateTemplate("data/{yyyy}/{MM}/{dd}/");
    }
}

