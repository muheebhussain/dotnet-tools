﻿using Archival.Application.Shared.Results;
using Archival.Infrastructure.BlobStorage;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Infrastructure.Tests.BlobStorage;

/// <summary>
/// Unit tests for AzureBlobTierManager path boundary checking logic.
/// Ensures that parent directory cleanup never deletes above the configured root prefix boundary.
/// </summary>
public class AzureBlobTierManagerPathBoundaryTests
{
    /// <summary>
    /// Tests that IsWithinRootBoundary correctly validates paths within the root prefix.
    /// Uses reflection to access the private method for testing.
    /// </summary>
    [Theory]
    [InlineData("file-output/modules/sgas/2026/02/10", "file-output/modules/sgas", true)]
    [InlineData("file-output/modules/sgas/2026", "file-output/modules/sgas", true)]
    [InlineData("file-output/modules/sgas", "file-output/modules/sgas", true)]
    [InlineData("file-output/modules", "file-output/modules/sgas", false)]
    [InlineData("file-output", "file-output/modules/sgas", false)]
    [InlineData("data/2026/02/10", "data", true)]
    [InlineData("data", "data", true)]
    [InlineData("dat", "data", false)]
    [InlineData("data-backup", "data", false)]
    [InlineData("file", "file-output", false)]
    [InlineData("file-output-archive", "file-output", false)]
    public void IsWithinRootBoundary_CorrectlyValidatesPathBoundaries(string path, string rootPrefix, bool expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (bool)method!.Invoke(null, new object[] { path, rootPrefix })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that IsWithinRootBoundary handles trailing slashes correctly.
    /// </summary>
    [Theory]
    [InlineData("file-output/modules/sgas/2026/", "file-output/modules/sgas/", true)]
    [InlineData("file-output/modules/sgas/2026", "file-output/modules/sgas/", true)]
    [InlineData("file-output/modules/sgas/", "file-output/modules/sgas", true)]
    [InlineData("/file-output/modules/sgas/2026", "/file-output/modules/sgas", true)]
    [InlineData("/file-output/modules/sgas/2026/", "/file-output/modules/sgas/", true)]
    public void IsWithinRootBoundary_HandlesTrailingSlashesCorrectly(string path, string rootPrefix, bool expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (bool)method!.Invoke(null, new object[] { path, rootPrefix })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that IsWithinRootBoundary handles leading slashes correctly.
    /// </summary>
    [Theory]
    [InlineData("file-output/modules/sgas/2026", "file-output/modules/sgas", true)]
    [InlineData("/file-output/modules/sgas/2026", "file-output/modules/sgas", true)]
    [InlineData("file-output/modules/sgas/2026", "/file-output/modules/sgas", true)]
    [InlineData("/file-output/modules/sgas/2026", "/file-output/modules/sgas", true)]
    public void IsWithinRootBoundary_HandlesLeadingSlashesCorrectly(string path, string rootPrefix, bool expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (bool)method!.Invoke(null, new object[] { path, rootPrefix })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that IsWithinRootBoundary prevents partial segment matching.
    /// This is critical to prevent "data" from matching "dat" or "file-output" from matching "file".
    /// </summary>
    [Theory]
    [InlineData("dat/2026", "data", false)] // "dat" should NOT match "data"
    [InlineData("data-backup/2026", "data", false)] // "data-backup" should NOT match "data"
    [InlineData("file/output", "file-output", false)] // "file" should NOT match "file-output"
    [InlineData("file-output-backup/modules", "file-output", false)] // "file-output-backup" should NOT match "file-output"
    [InlineData("sgas-archive/2026", "sgas", false)] // "sgas-archive" should NOT match "sgas"
    public void IsWithinRootBoundary_PreventsPartialSegmentMatching(string path, string rootPrefix, bool expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (bool)method!.Invoke(null, new object[] { path, rootPrefix })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that IsWithinRootBoundary handles edge cases correctly.
    /// </summary>
    [Theory]
    [InlineData("", "data", false)] // Empty path should return false
    [InlineData("data", "", false)] // Empty root should return false
    [InlineData("", "", false)] // Both empty should return false
    public void IsWithinRootBoundary_HandlesEdgeCases(string path, string rootPrefix, bool expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (bool)method!.Invoke(null, new object[] { path, rootPrefix })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests NormalizePath correctly removes leading and trailing slashes.
    /// </summary>
    [Theory]
    [InlineData("file-output/modules/sgas", "file-output/modules/sgas")]
    [InlineData("/file-output/modules/sgas", "file-output/modules/sgas")]
    [InlineData("file-output/modules/sgas/", "file-output/modules/sgas")]
    [InlineData("/file-output/modules/sgas/", "file-output/modules/sgas")]
    [InlineData("///file-output/modules/sgas///", "file-output/modules/sgas")]
    [InlineData("data", "data")]
    [InlineData("/data/", "data")]
    [InlineData("", "")]
    [InlineData("/", "")]
    [InlineData("///", "")]
    public void NormalizePath_RemovesLeadingAndTrailingSlashes(string input, string expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "NormalizePath",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (string)method!.Invoke(null, new object[] { input })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests GetParentDirectory returns the correct parent path.
    /// </summary>
    [Theory]
    [InlineData("file-output/modules/sgas/2026/02/10", "file-output/modules/sgas/2026/02")]
    [InlineData("file-output/modules/sgas/2026/02", "file-output/modules/sgas/2026")]
    [InlineData("file-output/modules/sgas/2026", "file-output/modules/sgas")]
    [InlineData("file-output/modules/sgas", "file-output/modules")]
    [InlineData("file-output/modules", "file-output")]
    [InlineData("file-output", "")]
    [InlineData("data", "")]
    [InlineData("", "")]
    public void GetParentDirectory_ReturnsCorrectParent(string input, string expected)
    {
        // Arrange
        var method = typeof(AzureBlobTierManager).GetMethod(
            "GetParentDirectory",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(method);

        // Act
        var result = (string)method!.Invoke(null, new object[] { input })!;

        // Assert
        Assert.Equal(expected, result);
    }

    /// <summary>
    /// Tests that parent directory traversal respects the root boundary.
    /// This simulates the cleanup loop logic to ensure it stops at the root.
    /// </summary>
    [Fact]
    public void ParentTraversal_StopsAtRootBoundary()
    {
        // Arrange
        var getParentMethod = typeof(AzureBlobTierManager).GetMethod(
            "GetParentDirectory",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        var isWithinBoundaryMethod = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(getParentMethod);
        Assert.NotNull(isWithinBoundaryMethod);

        var rootPrefix = "file-output/modules/sgas";
        var startPath = "file-output/modules/sgas/2026/02/10";
        var visitedPaths = new List<string>();

        // Act - Simulate parent traversal loop
        var currentDir = (string)getParentMethod!.Invoke(null, new object[] { startPath })!;

        while (!string.IsNullOrEmpty(currentDir) &&
               (bool)isWithinBoundaryMethod!.Invoke(null, new object[] { currentDir, rootPrefix })!)
        {
            visitedPaths.Add(currentDir);
            currentDir = (string)getParentMethod.Invoke(null, new object[] { currentDir })!;
        }

        // Assert
        Assert.Equal(3, visitedPaths.Count);
        Assert.Equal("file-output/modules/sgas/2026/02", visitedPaths[0]);
        Assert.Equal("file-output/modules/sgas/2026", visitedPaths[1]);
        Assert.Equal("file-output/modules/sgas", visitedPaths[2]);

        // Should NOT include "file-output/modules" or "file-output"
        Assert.DoesNotContain("file-output/modules", visitedPaths);
        Assert.DoesNotContain("file-output", visitedPaths);
    }

    /// <summary>
    /// Tests that parent directory traversal with shallow root boundary stops correctly.
    /// </summary>
    [Fact]
    public void ParentTraversal_WithShallowRoot_StopsAtBoundary()
    {
        // Arrange
        var getParentMethod = typeof(AzureBlobTierManager).GetMethod(
            "GetParentDirectory",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        var isWithinBoundaryMethod = typeof(AzureBlobTierManager).GetMethod(
            "IsWithinRootBoundary",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);

        Assert.NotNull(getParentMethod);
        Assert.NotNull(isWithinBoundaryMethod);

        var rootPrefix = "data";
        var startPath = "data/2026/02/10";
        var visitedPaths = new List<string>();

        // Act - Simulate parent traversal loop
        var currentDir = (string)getParentMethod!.Invoke(null, new object[] { startPath })!;

        while (!string.IsNullOrEmpty(currentDir) &&
               (bool)isWithinBoundaryMethod!.Invoke(null, new object[] { currentDir, rootPrefix })!)
        {
            visitedPaths.Add(currentDir);
            currentDir = (string)getParentMethod.Invoke(null, new object[] { currentDir })!;
        }

        // Assert
        Assert.Equal(3, visitedPaths.Count);
        Assert.Equal("data/2026/02", visitedPaths[0]);
        Assert.Equal("data/2026", visitedPaths[1]);
        Assert.Equal("data", visitedPaths[2]);

        // Should NOT go above "data"
    }
}

