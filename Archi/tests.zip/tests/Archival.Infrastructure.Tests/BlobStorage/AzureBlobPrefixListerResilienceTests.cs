﻿using Archival.Infrastructure.BlobStorage;
using Archival.Infrastructure.BlobStorage.Resilience;
using Azure;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Archival.Infrastructure.Tests.BlobStorage;

/// <summary>
/// Unit tests for AzureBlobPrefixLister with resilience layer.
/// Verifies that prefix listing properly uses the resilience policy.
/// </summary>
public class AzureBlobPrefixListerResilienceTests
{
    private readonly Mock<IAzureStorageResilience> _mockResilience;
    private readonly Mock<ILogger<AzureBlobPrefixLister>> _mockLogger;
    private readonly AzureBlobPrefixLister _prefixLister;

    public AzureBlobPrefixListerResilienceTests()
    {
        _mockResilience = new Mock<IAzureStorageResilience>();
        _mockLogger = new Mock<ILogger<AzureBlobPrefixLister>>();
        _prefixLister = new AzureBlobPrefixLister(_mockResilience.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task ListPrefixesAsync_ReturnsEmptyListOnSuccess()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        var result = await _prefixLister.ListPrefixesAsync(
            storageConn, containerName, prefix, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.Is<string>(s => s.Contains("ListBlobPrefixes")),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task ListPrefixesAsync_UsesResilienceLayer()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        await _prefixLister.ListPrefixesAsync(
            storageConn, containerName, prefix, CancellationToken.None);

        // Assert
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task ListPrefixesAsync_ThrowsOnTransientFailure()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/";

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new RequestFailedException(503, "Service unavailable"));

        // Act & Assert
        await Assert.ThrowsAsync<RequestFailedException>(
            () => _prefixLister.ListPrefixesAsync(storageConn, containerName, prefix, CancellationToken.None));
    }

    [Fact]
    public async Task ListPrefixesAsync_UsesUniqueOperationName()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/subfolder/";
        string capturedOperationName = null;

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Callback<Func<CancellationToken, Task<bool>>, string, CancellationToken>(
                (_, opName, _) => capturedOperationName = opName)
            .ReturnsAsync(true);

        // Act
        await _prefixLister.ListPrefixesAsync(
            storageConn, containerName, prefix, CancellationToken.None);

        // Assert
        Assert.NotNull(capturedOperationName);
        Assert.Contains("ListBlobPrefixes", capturedOperationName);
        Assert.Contains(containerName, capturedOperationName);
        Assert.Contains(prefix, capturedOperationName);
    }

    [Fact]
    public async Task ListPrefixesAsync_RespectsCancellationToken()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/";
        var cts = new CancellationTokenSource();
        cts.Cancel();

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                cts.Token))
            .ThrowsAsync(new OperationCanceledException());

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _prefixLister.ListPrefixesAsync(storageConn, containerName, prefix, cts.Token));
    }

    [Fact]
    public async Task ListPrefixesAsync_PassesCancellationTokenToResilience()
    {
        // Arrange
        var storageConn = "connection-string";
        var containerName = "test-container";
        var prefix = "data/";
        var cts = new CancellationTokenSource();

        _mockResilience
            .Setup(x => x.ExecuteAsync(
                It.IsAny<Func<CancellationToken, Task<bool>>>(),
                It.IsAny<string>(),
                cts.Token))
            .ReturnsAsync(true);

        // Act
        await _prefixLister.ListPrefixesAsync(storageConn, containerName, prefix, cts.Token);

        // Assert
        _mockResilience.Verify(x => x.ExecuteAsync(
            It.IsAny<Func<CancellationToken, Task<bool>>>(),
            It.IsAny<string>(),
            It.Is<CancellationToken>(ct => ct == cts.Token)), Times.Once);
    }
}

