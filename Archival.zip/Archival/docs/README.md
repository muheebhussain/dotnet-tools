﻿# Archival System Documentation

## Overview

**Archival** is a .NET 10 CLI application that manages SQL Server table data archival and Azure Blob Storage lifecycle operations. It runs as scheduled CronJobs in Azure Kubernetes Service (AKS) to:

1. **Archive SQL tables** - Export table data partitioned by business date to Parquet format in Azure Blob Storage, with optional row deletion from source
2. **Manage blob lifecycle** - Tier blobs between Hot/Cold/Archive storage tiers and delete old blobs based on age policies

### When to Use This System

- **Large transactional tables** that accumulate historical data by business date (e.g., daily trades, transactions, logs)
- **Regulatory compliance** requiring long-term retention of immutable data in cost-effective storage
- **Data lake ingestion** where operational SQL data needs to be exported to Parquet for analytics
- **Storage cost optimization** by automatically tiering old blobs to cheaper storage (Cold/Archive) or deleting them

### Key Features

✅ **Business date-aware** - Archives data based on business calendars (EOD/EOM/EOQ/EOY), not calendar dates  
✅ **Retention policies** - Keep last N EOD/EOM/EOQ/EOY dates, automatically archive older dates  
✅ **Exemptions** - Skip specific dates from archival or lifecycle operations  
✅ **Idempotent** - Safe to re-run; tracks what's already archived/processed  
✅ **Auditable** - Records all runs and operations in metadata database  
✅ **Parquet export** - Multi-part, compressed, columnar format for analytics  
✅ **Blob lifecycle** - Automatic tiering (Hot→Cold→Archive→Delete) based on age policies  

### Dependencies

- **.NET 10 Runtime** (Linux containers supported)
- **SQL Server** (2019+) - For source data and metadata database
- **Azure Blob Storage** - For archived Parquet files and lifecycle management
- **Business calendar** - Source DB must have `dbo.business_date` table and `dbo.v_business_date_classification` view

---

## Quick Start

### Local Development

**Prerequisites:**
1. .NET 10 SDK installed
2. Access to SQL Server (metadata DB + source DB)
3. Azure Storage Account with connection strings

**Setup:**

```bash
# 1. Clone and navigate to repo
cd Archival

# 2. Copy secret templates
cp secrets/archival-db-connections.template.json secrets/archival-db-connections.json
cp secrets/archival-storage-connections.template.json secrets/archival-storage-connections.json

# 3. Edit secret files with your connection strings
# - archival-db-connections.json: Add DB connection strings keyed by database name
# - archival-storage-connections.json: Add storage connection strings keyed by account name

# 4. Create metadata database
# Run the SQL script: db/metadata_schema.sql on your metadata DB

# 5. Set metadata DB connection
export ARCHIVAL_METADATA_DB="Server=localhost;Database=archival_meta;User ID=sa;Password=YourPassword;TrustServerCertificate=True"

# 6. Run table archival (all active configurations)
dotnet run --project src/Archival.App -- table --all-active --secrets-path ./secrets

# 7. Run blob lifecycle (all enabled targets)
dotnet run --project src/Archival.App -- blob --all-targets --secrets-path ./secrets
```

### Required Environment Variables

| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `ARCHIVAL_METADATA_DB` | **Yes** | Connection string for metadata database | `Server=...;Database=archival_meta;...` |
| `ARCHIVAL_SECRETS_PATH` | No | Path to secrets directory (default: `/secrets/`) | `./local-secrets` |

---

## Command Summary

### Table Archival Command

Archives SQL table data to Parquet files in Azure Blob Storage.

```bash
# Archive all active table configurations
dotnet run --project src/Archival.App -- table --all-active

# Archive a specific table configuration
dotnet run --project src/Archival.App -- table --table-config-id 5

# With custom secrets path
dotnet run --project src/Archival.App -- table --all-active --secrets-path ./secrets
```

**What it does:**
1. Queries source tables for distinct business dates (last 10 years)
2. Calculates retention policy (which dates to keep in source DB)
3. Filters out dates that should be retained or are exempted
4. Exports candidate dates to Parquet (multi-part files)
5. Optionally deletes exported rows from source table (if configured)
6. Records all operations in metadata DB for audit trail

### Blob Lifecycle Command

Manages Azure Blob Storage lifecycle operations (tier changes and deletions).

```bash
# Process all enabled blob configurations
dotnet run --project src/Archival.App -- blob --all-targets

# Process a specific blob configuration
dotnet run --project src/Archival.App -- blob --target-id 3

# With custom secrets path
dotnet run --project src/Archival.App -- blob --all-targets --secrets-path ./secrets
```

**What it does:**
1. Lists all blobs under configured prefixes
2. Calculates blob age (based on creation date or extracted date from path)
3. Applies lifecycle policy rules:
   - **Cold tier**: Blobs older than `cold_min_age_days`
   - **Archive tier**: Blobs older than `archive_min_age_days` (if supported)
   - **Delete**: Blobs older than `delete_min_age_days`
4. Executes tier changes or deletions
5. Records all operations in metadata DB

### Help Command

```bash
# Display help
dotnet run --project src/Archival.App -- help
# or
dotnet run --project src/Archival.App
```

---

## Architecture Documentation

Detailed architecture documentation is organized in `/docs/architecture/`:

- **[Architecture Overview](architecture/overview.md)** - System architecture, VSA pattern, project boundaries
- **[Execution Flows](architecture/execution_flows.md)** - Step-by-step flows for table and blob commands
- **[Business Rules](architecture/business_rules.md)** - Retention policies, business dates, exemptions, path templates
- **[Data Model](architecture/data_model.md)** - Metadata database schema, entities, relationships
- **[Operational Guide](architecture/operational_guides.md)** - Production deployment, troubleshooting, performance
- **[Security](architecture/security.md)** - Secrets management, permissions, audit trails
- **[Review Findings](architecture/review_findings.md)** - Architecture review notes and recommendations

---

## Project Structure

```
Archival/
├── src/
│   ├── Archival.App/              # CLI entry point and command handlers
│   ├── Archival.Application/      # VSA slices (handlers, contracts, DTOs)
│   ├── Archival.Data/             # EF Core, stores, repositories
│   └── Archival.Infrastructure/   # Azure SDK, Parquet, SQL implementations
├── db/
│   ├── metadata_schema.sql        # Metadata DB schema
│   └── migrations/                # Schema migration scripts
├── secrets/
│   ├── *.template.json            # Secret file templates
│   └── (your actual .json files)  # Git-ignored
└── docs/                          # This documentation
```

---

## Quick Links

- [Architecture Overview](architecture/overview.md) - Start here to understand the system
- [Execution Flows](architecture/execution_flows.md) - Trace command execution paths
- [Business Rules](architecture/business_rules.md) - Understand retention and lifecycle logic
- [Operational Guide](architecture/operational_guides.md) - Deploy and troubleshoot in production

---

## Support

For issues, questions, or contributions, refer to the [Review Findings](architecture/review_findings.md) document for known issues and recommendations.

