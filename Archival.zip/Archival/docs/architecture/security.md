﻿# Security

This document covers security considerations, secrets management, required permissions, and auditability for the Archival system.

## Table of Contents
- [Secrets Overview](#secrets-overview)
- [Connection String Management](#connection-string-management)
- [Azure Permissions Required](#azure-permissions-required)
- [SQL Server Permissions Required](#sql-server-permissions-required)
- [Audit Trail](#audit-trail)
- [Security Best Practices](#security-best-practices)
- [Threat Model](#threat-model)

---

## Secrets Overview

The system requires access to multiple sensitive resources:

| Secret Type | Purpose | Storage Method |
|-------------|---------|----------------|
| Metadata DB Connection | Access metadata database | Environment variable |
| Source DB Connections | Read from source tables | JSON file (CSI/Key Vault) |
| Storage Account Keys | Write Parquet, manage blobs | JSON file (CSI/Key Vault) |

**Security Principle:** Secrets are never logged, never stored in code, and are loaded at runtime.

---

## Connection String Management

### Secret File Structure

**File: `/secrets/archival-db-connections.json`**
```json
{
  "SourceDB1": "Server=sourcedb1.database.windows.net;Database=SourceDB1;User ID=archival_reader;Password=<strong_password>;Encrypt=True;TrustServerCertificate=False;",
  "TradingDB": "Server=tradingdb.database.windows.net;Database=TradingDB;User ID=archival_reader;Password=<strong_password>;Encrypt=True;TrustServerCertificate=False;"
}
```

**Security Requirements:**
- ✅ **Encrypt=True** - Always use encrypted connections
- ✅ **TrustServerCertificate=False** - Validate server certificate
- ✅ **Least privilege** - Use read-only accounts for source DBs
- ✅ **Strong passwords** - Min 16 chars, complex

**File: `/secrets/archival-storage-connections.json`**
```json
{
  "storageaccount1": "DefaultEndpointsProtocol=https;AccountName=storageaccount1;AccountKey=<storage_key>;EndpointSuffix=core.windows.net",
  "archivestorage": "DefaultEndpointsProtocol=https;AccountName=archivestorage;AccountKey=<storage_key>;EndpointSuffix=core.windows.net"
}
```

**Security Requirements:**
- ✅ **HTTPS only** - DefaultEndpointsProtocol=https
- ✅ **Rotate keys** - Regular key rotation (90 days recommended)
- ✅ **Key Vault** - Store in Azure Key Vault, mount via CSI
- ✅ **Avoid shared keys** - Consider Managed Identity (see below)

### Secret File Loading

**Implementation:**  
File: `Archival.Infrastructure/Secrets/ConnectionStringResolver.cs`

**Security properties:**
- Secrets loaded once at startup (not cached in application memory)
- File read with error handling (fails fast if missing)
- Keys are case-insensitive (reduces config errors)
- No secrets in logs (error messages don't include connection strings)

**Code snippet:**
```csharp
private static Dictionary<string, string> Load(string file)
{
    if (!File.Exists(file))
        throw new FileNotFoundException($"Required secret file not found: {file}");

    var json = File.ReadAllText(file);
    var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json, ...);
    
    // Normalize keys for stable lookups
    return dict.ToDictionary(k => k.Key.Trim(), v => v.Value, StringComparer.OrdinalIgnoreCase);
}
```

### Alternative: Managed Identity (Recommended)

**For SQL Server:**
```csharp
// Connection string without password
"Server=sourcedb.database.windows.net;Database=SourceDB1;Authentication=Active Directory Managed Identity;"
```

**Setup:**
1. Enable Managed Identity on AKS node pool or pod
2. Grant identity access to SQL databases
3. Use Authentication=Active Directory Managed Identity in connection string

**Benefits:**
- ✅ No passwords to manage
- ✅ Automatic token rotation
- ✅ Centralized access control (Azure AD)

**For Storage:**
```csharp
// Use DefaultAzureCredential (Managed Identity)
var blobClient = new BlobClient(new Uri(blobUrl), new DefaultAzureCredential());
```

**Limitation:** Current implementation uses connection strings. Managed Identity support requires code changes.

---

## Azure Permissions Required

### Storage Account Permissions

**For table archival (write Parquet files):**
- **Role:** Storage Blob Data Contributor
- **Scope:** Container where archives are stored (e.g., "archive" container)
- **Permissions:**
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read`
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write`

**For blob lifecycle (tier management, deletion):**
- **Role:** Storage Blob Data Contributor
- **Scope:** Containers managed by lifecycle policies
- **Permissions:**
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read`
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write`
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/delete`
  - `Microsoft.Storage/storageAccounts/blobServices/containers/blobs/setTier`

**Assignment example (Azure CLI):**
```bash
# Grant Managed Identity access to storage account
az role assignment create \
  --assignee <managed-identity-principal-id> \
  --role "Storage Blob Data Contributor" \
  --scope /subscriptions/<sub-id>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage-account>
```

### Key Vault Permissions (if using CSI)

**Permissions required:**
- **Get Secrets** - Read secrets from vault

**Assignment example:**
```bash
# Grant Managed Identity access to Key Vault secrets
az keyvault set-policy \
  --name <keyvault-name> \
  --object-id <managed-identity-object-id> \
  --secret-permissions get list
```

---

## SQL Server Permissions Required

### Metadata Database (archival_meta)

**User:** `archival_app` (or similar)

**Required permissions:**
```sql
-- Grant read/write access to archival tables
GRANT SELECT, INSERT, UPDATE ON SCHEMA::dbo TO archival_app;

-- Specific tables (if not using schema-level grant)
GRANT SELECT, INSERT, UPDATE ON dbo.archival_run TO archival_app;
GRANT SELECT, INSERT ON dbo.archival_run_item TO archival_app;
GRANT SELECT, INSERT, UPDATE ON dbo.archival_dataset TO archival_app;
GRANT SELECT ON dbo.archival_table_configuration TO archival_app;
GRANT SELECT ON dbo.archival_table_policy TO archival_app;
GRANT SELECT ON dbo.archival_table_exemption TO archival_app;
GRANT SELECT ON dbo.archival_blob_configuration TO archival_app;
GRANT SELECT ON dbo.archival_blob_policy TO archival_app;
GRANT SELECT ON dbo.archival_blob_exemption TO archival_app;
```

**Note:** Metadata DB user needs write access to audit tables, read access to config tables.

### Source Databases (tables being archived)

**User:** `archival_reader` (read-only account)

**Required permissions:**
```sql
-- Grant read access to specific tables
GRANT SELECT ON dbo.business_date TO archival_reader;
GRANT SELECT ON dbo.v_business_date_classification TO archival_reader;
GRANT SELECT ON dbo.Transactions TO archival_reader;
GRANT SELECT ON dbo.Trades TO archival_reader;
-- etc. for each table to archive

-- If using dynamic queries (current implementation), also grant VIEW DEFINITION
GRANT VIEW DEFINITION ON SCHEMA::dbo TO archival_reader;
```

**For delete operations** (if `delete_after_export = 1`):
```sql
-- Grant delete permission (separate user recommended)
CREATE USER archival_writer FOR LOGIN archival_writer_login;
GRANT SELECT, DELETE ON dbo.Transactions TO archival_writer;
GRANT SELECT, DELETE ON dbo.Trades TO archival_writer;
```

**Best Practice:** Use separate accounts for read-only vs. read-write operations.

### Business Calendar Requirements

**Required objects in source database:**
- `dbo.business_date` table (70-year calendar)
- `dbo.v_business_date_classification` view

**Permissions:**
```sql
GRANT SELECT ON dbo.business_date TO archival_reader;
GRANT SELECT ON dbo.v_business_date_classification TO archival_reader;
```

**Schema example:**
```sql
CREATE TABLE dbo.business_date (
  current_business_date DATE PRIMARY KEY,
  is_business_day BIT NOT NULL,
  -- other columns...
);

CREATE VIEW dbo.v_business_date_classification AS
SELECT
  current_business_date,
  CASE
    WHEN ... THEN 'EOY'
    WHEN ... THEN 'EOQ'
    WHEN ... THEN 'EOM'
    ELSE 'EOD'
  END AS date_type
FROM dbo.business_date
WHERE is_business_day = 1;
```

---

## Audit Trail

### What is Audited

The system maintains a complete audit trail of all operations:

**Run-level auditing:**
- Run ID, type (Archive/Lifecycle), start/end time, status
- Recorded in `archival_run` table

**Operation-level auditing:**
- Each dataset archived or prefix processed
- Row counts, byte counts, errors
- Recorded in `archival_run_item` table

**Dataset tracking:**
- Which datasets have been exported
- Where they are stored (storage account, container, prefix)
- Export metadata (part count, row count, bytes)
- Recorded in `archival_dataset` table

### Audit Queries

**View all runs in last 7 days:**
```sql
SELECT
  id,
  run_type,
  started_at,
  ended_at,
  DATEDIFF(SECOND, started_at, ended_at) / 60 AS duration_minutes,
  status,
  note
FROM archival_run
WHERE started_at >= DATEADD(DAY, -7, GETUTCDATE())
ORDER BY started_at DESC;
```

**View failed operations:**
```sql
SELECT
  r.id AS run_id,
  r.run_type,
  r.started_at,
  ri.item_type,
  ri.item_key,
  ri.status,
  ri.error_message
FROM archival_run_item ri
JOIN archival_run r ON ri.run_id = r.id
WHERE ri.status = 'Failed'
  AND ri.created_at >= DATEADD(DAY, -30, GETUTCDATE())
ORDER BY ri.created_at DESC;
```

**View dataset export history:**
```sql
SELECT
  tc.database_name,
  tc.schema_name,
  tc.table_name,
  d.as_of_date,
  d.row_count,
  d.total_bytes / 1024 / 1024 AS size_mb,
  d.storage_account_name,
  d.container_name,
  d.blob_prefix,
  d.created_at,
  d.completed_at
FROM archival_dataset d
JOIN archival_table_configuration tc ON d.table_configuration_id = tc.id
WHERE tc.schema_name = 'dbo'
  AND tc.table_name = 'Transactions'
ORDER BY d.as_of_date DESC;
```

### Audit Retention

**Recommendation:** Retain audit data for at least 90 days, ideally 1-2 years.

**Cleanup strategy:**
```sql
-- Archive old run records to separate table or export to data lake
-- Keep recent 90 days in hot table for queries

-- Delete old run items (after archiving)
DELETE FROM archival_run_item
WHERE created_at < DATEADD(DAY, -365, GETUTCDATE());

-- Delete old run records (after archiving)
DELETE FROM archival_run
WHERE started_at < DATEADD(DAY, -365, GETUTCDATE());
```

**Note:** Do NOT delete `archival_dataset` records - they prevent duplicate exports.

---

## Security Best Practices

### 1. Principle of Least Privilege

**Database accounts:**
- ✅ Source DBs: Read-only accounts
- ✅ Metadata DB: Read config, write audit, no DDL
- ✅ Separate accounts for delete operations
- ❌ Don't use `sa` or `db_owner` accounts

**Storage accounts:**
- ✅ Write access only to archive containers
- ✅ No access to production hot containers
- ❌ Don't use storage account keys if possible (use Managed Identity)

### 2. Secrets Rotation

**Schedule:**
- SQL passwords: Rotate every 90 days
- Storage account keys: Rotate every 90 days
- Key Vault secrets: Update after rotation

**Process:**
1. Generate new password/key
2. Update in Key Vault
3. Test with new secret
4. Update production (zero-downtime via dual keys)
5. Remove old password/key

### 3. Network Security

**Firewall rules:**
- Azure SQL: Whitelist AKS node IPs or use VNet integration
- Storage: Whitelist AKS node IPs or use Private Endpoints
- Disable public access if possible (use VNet)

**Kubernetes network policies:**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: archival-netpol
  namespace: data-ops
spec:
  podSelector:
    matchLabels:
      app: archival
  policyTypes:
  - Egress
  egress:
  - to:
    - namespaceSelector: {}  # Allow DNS
    ports:
    - protocol: TCP
      port: 53
  - to:
    - podSelector: {}  # Allow metadata DB
    ports:
    - protocol: TCP
      port: 1433
  - to:
    - podSelector: {}  # Allow storage
    ports:
    - protocol: TCP
      port: 443
```

### 4. Logging Security

**What to log:**
- ✅ Authentication attempts
- ✅ Configuration changes
- ✅ Failed operations
- ✅ Unusual patterns (e.g., sudden spike in deletes)

**What NOT to log:**
- ❌ Connection strings
- ❌ Passwords
- ❌ Storage account keys
- ❌ PII from source tables

**Current implementation:** Logs do not include secrets (verified).

### 5. Monitoring and Alerting

**Security alerts:**
- Failed authentication attempts
- Unexpected data access patterns
- Large delete operations (> threshold)
- Failed run items (potential data loss)

---

## Threat Model

### Threat 1: Compromised Secrets

**Attack:** Attacker gains access to connection strings (e.g., exposed Key Vault, leaked files).

**Impact:**
- Read access to source databases (data exfiltration)
- Write access to storage (data corruption, ransom)
- Delete access (data loss)

**Mitigations:**
- ✅ Use Managed Identity (no secrets to steal)
- ✅ Rotate secrets regularly
- ✅ Monitor unusual access patterns
- ✅ Use Private Endpoints (limit network exposure)
- ✅ Enable Azure Defender for SQL and Storage

### Threat 2: Malicious Configuration Changes

**Attack:** Attacker modifies table/blob configurations to delete production data.

**Impact:**
- Unintended data deletion from source tables
- Incorrect retention policies (premature deletion)

**Mitigations:**
- ✅ Restrict access to metadata DB (only authorized users)
- ✅ Audit all config changes (created_by, updated_by columns)
- ✅ Require approval for delete_after_export=1 configs
- ✅ Test configs in staging before production

### Threat 3: Data Exfiltration via Archives

**Attack:** Attacker accesses archived Parquet files in blob storage.

**Impact:**
- Exposure of historical data (PII, financial data)

**Mitigations:**
- ✅ Enable blob encryption (AES-256, enabled by default)
- ✅ Use Private Endpoints (no public access)
- ✅ Enable blob versioning and soft delete (prevent permanent deletion)
- ✅ Monitor blob access logs
- ✅ Use Azure Policy to enforce encryption

### Threat 4: Denial of Service via Resource Exhaustion

**Attack:** Attacker configures large tables or wide date ranges, causing excessive resource usage.

**Impact:**
- Slow/failed runs
- High SQL and storage costs
- Production database impact (query load)

**Mitigations:**
- ✅ Use read replicas for archival queries
- ✅ Set resource limits in Kubernetes (CPU, memory)
- ✅ Monitor run duration and alert on anomalies
- ✅ Rate limit blob lifecycle operations

### Threat 5: Accidental Data Loss

**Attack:** Misconfiguration (not malicious) causes unintended deletions.

**Impact:**
- Loss of source table data (if delete_after_export=1)
- Loss of archived data (if lifecycle policy too aggressive)

**Mitigations:**
- ✅ Test retention policies in non-production first
- ✅ Enable soft delete on blob storage (90-day retention)
- ✅ Backup metadata DB regularly
- ✅ Require manual approval for delete operations
- ✅ Audit trail for all deletions

---

## Compliance Considerations

### GDPR / Data Privacy

**Right to erasure:**
- Archived data must be deletable on request
- Implement process to delete specific datasets from blob storage
- Update metadata to mark dataset as deleted

**Data minimization:**
- Only archive necessary columns (consider column filtering)
- Apply retention policies to delete old data

### SOX / Financial Compliance

**Auditability:**
- Complete audit trail in `archival_run` and `archival_run_item` tables
- Immutable archives (blob versioning + legal hold)
- Access logs for all operations

**Data integrity:**
- Checksum validation (Parquet built-in CRC)
- Row count validation (compare source to Parquet)
- Prevent unauthorized modifications (WORM storage)

---

## Next Steps

- **[Operational Guide](operational_guides.md)** - Production deployment and monitoring
- **[Review Findings](review_findings.md)** - Known security issues and recommendations

