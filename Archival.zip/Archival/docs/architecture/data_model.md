﻿# Data Model

This document describes the metadata database schema, entities, relationships, and status enums used by the Archival system.

## Table of Contents
- [Schema Overview](#schema-overview)
- [Configuration Tables](#configuration-tables)
- [Audit Tables](#audit-tables)
- [Status Enums](#status-enums)
- [Relationships](#relationships)
- [Indexes and Constraints](#indexes-and-constraints)
- [Schema Migrations](#schema-migrations)

---

## Schema Overview

The metadata database contains **9 tables** organized into two categories:

**Configuration Tables** (what to archive/manage):
- `archival_table_policy` - Retention policies for tables
- `archival_table_configuration` - Table archival configurations
- `archival_table_exemption` - Date exemptions for table archival
- `archival_blob_policy` - Lifecycle policies for blobs
- `archival_blob_configuration` - Blob lifecycle configurations
- `archival_blob_exemption` - Blob exemptions for lifecycle

**Audit/Tracking Tables** (what was processed):
- `archival_run` - Run records (Archive or Lifecycle)
- `archival_run_item` - Individual operation results
- `archival_dataset` - Exported dataset tracking

### Entity Relationship Diagram

```
┌─────────────────────────┐
│ archival_table_policy   │
│   id (PK)               │
│   name                  │
│   keep_last_eod         │
│   keep_last_eom         │
│   keep_last_eoq         │
│   keep_last_eoy         │
└──────────┬──────────────┘
           │ 1:N
┌──────────▼──────────────────┐      ┌─────────────────────────┐
│ archival_table_configuration│◄─────┤ archival_table_exemption│
│   id (PK)                   │ 1:N  │   id (PK)               │
│   database_name             │      │   table_configuration_id│
│   schema_name               │      │   as_of_date            │
│   table_name                │      └─────────────────────────┘
│   as_of_date_column         │
│   archive_path_template     │
│   table_policy_id (FK)      │
│   blob_policy_id (FK)       │
│   delete_after_export       │
│   batch_delete_size         │
└──────────┬──────────────────┘
           │ 1:N
┌──────────▼──────────────────┐
│ archival_dataset            │
│   id (PK)                   │
│   table_configuration_id(FK)│
│   as_of_date                │
│   date_type                 │
│   storage_account_name      │
│   container_name            │
│   blob_prefix               │
│   part_count                │
│   total_bytes               │
│   row_count                 │
│   status                    │
│   completed_at              │
└─────────────────────────────┘

┌─────────────────────────┐
│ archival_blob_policy    │
│   id (PK)               │
│   name                  │
│   cold_min_age_days     │
│   archive_min_age_days  │
│   delete_min_age_days   │
└──────────┬──────────────┘
           │ 1:N
┌──────────▼──────────────────┐      ┌─────────────────────────┐
│ archival_blob_configuration │◄─────┤ archival_blob_exemption │
│   id (PK)                   │ 1:N  │   id (PK)               │
│   storage_account_name      │      │   blob_configuration_id │
│   container_name            │      │   as_of_date            │
│   prefix                    │      │   container_name        │
│   include_pattern           │      │   prefix                │
│   exclude_pattern           │      └─────────────────────────┘
│   supports_archive_tier     │
│   blob_policy_id (FK)       │
└─────────────────────────────┘

┌─────────────────────────┐
│ archival_run            │
│   id (PK)               │
│   run_type              │
│   started_at            │
│   ended_at              │
│   status                │
│   note                  │
└──────────┬──────────────┘
           │ 1:N
┌──────────▼──────────────────┐
│ archival_run_item           │
│   id (PK)                   │
│   run_id (FK)               │
│   item_type                 │
│   item_key                  │
│   action                    │
│   status                    │
│   rows_affected             │
│   bytes_affected            │
│   error_message             │
└─────────────────────────────┘
```

---

## Configuration Tables

### archival_table_policy

**Purpose:** Defines retention rules for table archival (how many dates to keep by type).

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| name | NVARCHAR(200) | No | Policy name (e.g., "Standard Retention", "Long Term") |
| is_active | BIT | No | Whether policy is active (unused in current implementation) |
| keep_last_eod | INT | Yes | Keep last N end-of-day dates |
| keep_last_eom | INT | Yes | Keep last N end-of-month dates |
| keep_last_eoq | INT | Yes | Keep last N end-of-quarter dates |
| keep_last_eoy | INT | Yes | Keep last N end-of-year dates |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |
| updated_at | DATETIME2(3) | Yes | Last update timestamp (UTC) |
| updated_by | NVARCHAR(100) | Yes | Last updater username/email |

**Example Policies:**
```sql
-- Keep last 30 EOD, 12 EOM, 4 EOQ, 2 EOY
INSERT INTO archival_table_policy (name, is_active, keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy, created_at)
VALUES ('Standard Retention', 1, 30, 12, 4, 2, GETUTCDATE());

-- Keep only EOY (minimal retention)
INSERT INTO archival_table_policy (name, is_active, keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy, created_at)
VALUES ('Minimal Retention', 1, 0, 0, 0, 7, GETUTCDATE());
```

---

### archival_table_configuration

**Purpose:** Specifies which tables to archive and how.

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| is_active | BIT | No | Whether configuration is active (only active configs are processed) |
| database_name | NVARCHAR(128) | No | Database name (key for connection string lookup) |
| schema_name | NVARCHAR(128) | No | Table schema (e.g., "dbo") |
| table_name | NVARCHAR(128) | No | Table name |
| as_of_date_column | NVARCHAR(128) | No | Column containing business date (e.g., "trade_date", "transaction_date") |
| archive_path_template | NVARCHAR(400) | No | Blob storage path template (e.g., "dbo/Transactions/") |
| table_policy_id | INT | No | FK to archival_table_policy |
| blob_policy_id | INT | No | FK to archival_blob_policy (for lifecycle of archived datasets) |
| delete_after_export | BIT | No | Whether to delete rows from source after successful export |
| batch_delete_size | INT | No | Batch size for deletes (e.g., 5000) |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |
| updated_at | DATETIME2(3) | Yes | Last update timestamp (UTC) |
| updated_by | NVARCHAR(100) | Yes | Last updater username/email |

**Constraints:**
- UNIQUE: (database_name, schema_name, table_name) - Prevent duplicate configs
- FK: table_policy_id → archival_table_policy(id)
- FK: blob_policy_id → archival_blob_policy(id)

**Example:**
```sql
INSERT INTO archival_table_configuration
(is_active, database_name, schema_name, table_name, as_of_date_column,
 archive_path_template, table_policy_id, blob_policy_id, delete_after_export,
 batch_delete_size, created_at)
VALUES
(1, 'TradingDB', 'dbo', 'Transactions', 'trade_date',
 'trading/transactions/', 1, 1, 1, 5000, GETUTCDATE());
```

---

### archival_table_exemption

**Purpose:** Exempts specific dates from archival for a table configuration.

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| table_configuration_id | INT | No | FK to archival_table_configuration |
| as_of_date | DATE | No | Date to exempt (e.g., "2025-12-25" for holiday) |
| reason | NVARCHAR(4000) | Yes | Reason for exemption (documentation) |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |

**Constraints:**
- FK: table_configuration_id → archival_table_configuration(id)

**Example:**
```sql
INSERT INTO archival_table_exemption
(table_configuration_id, as_of_date, reason, created_at)
VALUES
(1, '2025-12-25', 'Christmas - keep data indefinitely', GETUTCDATE());
```

---

### archival_blob_policy

**Purpose:** Defines lifecycle rules for blob storage (age-based tiering and deletion).

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| name | NVARCHAR(200) | No | Policy name (e.g., "Standard Lifecycle", "Long Term Archive") |
| is_active | BIT | No | Whether policy is active |
| cold_min_age_days | INT | Yes | Move to Cold tier if older than N days |
| archive_min_age_days | INT | Yes | Move to Archive tier if older than N days |
| delete_min_age_days | INT | Yes | Delete if older than N days |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |
| updated_at | DATETIME2(3) | Yes | Last update timestamp (UTC) |
| updated_by | NVARCHAR(100) | Yes | Last updater username/email |

**Example Policies:**
```sql
-- Standard lifecycle: Cold 30d, Archive 90d, Delete 7y
INSERT INTO archival_blob_policy (name, is_active, cold_min_age_days, archive_min_age_days, delete_min_age_days, created_at)
VALUES ('Standard Lifecycle', 1, 30, 90, 2555, GETUTCDATE());

-- Long term: Cold 90d, Archive 180d, Never delete
INSERT INTO archival_blob_policy (name, is_active, cold_min_age_days, archive_min_age_days, delete_min_age_days, created_at)
VALUES ('Long Term Archive', 1, 90, 180, NULL, GETUTCDATE());
```

---

### archival_blob_configuration

**Purpose:** Specifies which blob prefixes to manage with lifecycle policies.

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| is_enabled | BIT | No | Whether configuration is enabled (only enabled configs are processed) |
| storage_account_name | NVARCHAR(128) | No | Storage account name (key for connection string lookup) |
| container_name | NVARCHAR(128) | No | Container name (e.g., "archive") |
| prefix | NVARCHAR(1024) | No | Blob prefix (e.g., "trading/transactions/") |
| include_pattern | NVARCHAR(2000) | Yes | Regex pattern to include blobs (optional) |
| exclude_pattern | NVARCHAR(2000) | Yes | Regex pattern to exclude blobs (optional) |
| supports_archive_tier | BIT | No | Whether storage account supports Archive tier |
| blob_policy_id | INT | No | FK to archival_blob_policy |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |
| updated_at | DATETIME2(3) | Yes | Last update timestamp (UTC) |
| updated_by | NVARCHAR(100) | Yes | Last updater username/email |

**Constraints:**
- FK: blob_policy_id → archival_blob_policy(id)

**Example:**
```sql
INSERT INTO archival_blob_configuration
(is_enabled, storage_account_name, container_name, prefix, include_pattern,
 exclude_pattern, supports_archive_tier, blob_policy_id, created_at)
VALUES
(1, 'storageaccount1', 'archive', 'trading/transactions/', NULL, NULL, 1, 1, GETUTCDATE());
```

---

### archival_blob_exemption

**Purpose:** Exempts specific blobs/prefixes from lifecycle operations.

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | INT IDENTITY | No | Primary key |
| blob_configuration_id | INT | No | FK to archival_blob_configuration |
| as_of_date | DATE | No | Date to exempt |
| container_name | NVARCHAR(128) | No | Container name |
| prefix | NVARCHAR(1024) | No | Blob prefix to exempt |
| reason | NVARCHAR(4000) | Yes | Reason for exemption |
| created_at | DATETIME2(3) | No | Creation timestamp (UTC) |
| created_by | NVARCHAR(100) | Yes | Creator username/email |

**Constraints:**
- FK: blob_configuration_id → archival_blob_configuration(id)
- INDEX: (blob_configuration_id, container_name, prefix, as_of_date)

**Note:** Currently loaded but **not enforced** in lifecycle handler (see [Review Findings](review_findings.md)).

---

## Audit Tables

### archival_run

**Purpose:** Records each execution of table archival or blob lifecycle command.

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | BIGINT IDENTITY | No | Primary key (run ID) |
| run_type | NVARCHAR(20) | No | Type of run: "Archive" or "Lifecycle" |
| started_at | DATETIME2(3) | No | When run started (UTC) |
| ended_at | DATETIME2(3) | Yes | When run ended (UTC), NULL if still running |
| status | NVARCHAR(20) | No | Run status: "Running", "Succeeded", "Failed", "PartiallySucceeded" |
| note | NVARCHAR(4000) | Yes | Summary note (e.g., "Processed 5 tables, 120 dates archived") |

**Status Values:**
- `Running` - Run is in progress
- `Succeeded` - All operations succeeded
- `Failed` - All operations failed
- `PartiallySucceeded` - Some succeeded, some failed

**Example Query:**
```sql
-- Last 10 runs
SELECT id, run_type, started_at, ended_at, status, note
FROM archival_run
ORDER BY started_at DESC
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;

-- Failed runs
SELECT * FROM archival_run WHERE status = 'Failed';

-- Long-running runs (> 1 hour, still running)
SELECT * FROM archival_run
WHERE status = 'Running'
  AND started_at < DATEADD(HOUR, -1, GETUTCDATE());
```

---

### archival_run_item

**Purpose:** Records individual operations within a run (each dataset or prefix processed).

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | BIGINT IDENTITY | No | Primary key |
| run_id | BIGINT | No | FK to archival_run |
| item_type | NVARCHAR(20) | No | Type: "Dataset" or "Prefix" |
| item_key | NVARCHAR(1200) | No | Identifier (e.g., "dbo.Transactions:2026-01-15") |
| action | NVARCHAR(40) | No | Action performed: "Archive" or "Lifecycle" |
| status | NVARCHAR(20) | No | Item status: "Succeeded", "Failed", "Skipped" |
| rows_affected | BIGINT | Yes | Number of rows processed (for Dataset items) |
| bytes_affected | BIGINT | Yes | Number of bytes processed |
| error_message | NVARCHAR(MAX) | Yes | Error details if failed |
| created_at | DATETIME2(3) | No | Timestamp (UTC) |

**Constraints:**
- FK: run_id → archival_run(id)

**Item Key Format:**
- Dataset: `{schema}.{table}:{date}` (e.g., "dbo.Transactions:2026-01-15")
- Prefix: `{container}/{prefix}` (e.g., "archive/dbo/Transactions/")

**Example Query:**
```sql
-- All items for a run
SELECT item_type, item_key, status, rows_affected, bytes_affected, error_message
FROM archival_run_item
WHERE run_id = 42
ORDER BY created_at;

-- Failed items across all runs
SELECT r.id AS run_id, r.started_at, ri.item_key, ri.error_message
FROM archival_run_item ri
JOIN archival_run r ON ri.run_id = r.id
WHERE ri.status = 'Failed'
ORDER BY r.started_at DESC;
```

---

### archival_dataset

**Purpose:** Tracks exported datasets (prevents duplicate exports, records metadata).

**Columns:**
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | BIGINT IDENTITY | No | Primary key (dataset ID) |
| table_configuration_id | INT | No | FK to archival_table_configuration |
| as_of_date | DATE | No | Business date exported |
| date_type | NVARCHAR(4) | No | Date classification: "EOD", "EOM", "EOQ", "EOY" |
| storage_account_name | NVARCHAR(128) | No | Storage account where dataset is stored |
| container_name | NVARCHAR(128) | No | Container name |
| blob_prefix | NVARCHAR(1024) | No | Blob prefix (e.g., "dbo/Transactions/2026-01-15/") |
| part_count | INT | No | Number of Parquet parts (e.g., 5 for 50,000 rows) |
| total_bytes | BIGINT | Yes | Total size in bytes |
| row_count | BIGINT | Yes | Total row count |
| status | NVARCHAR(20) | No | Dataset status: "Pending", "Succeeded", "Failed" |
| created_at | DATETIME2(3) | No | When dataset record was created (UTC) |
| completed_at | DATETIME2(3) | Yes | When export completed (UTC) |
| error_summary | NVARCHAR(MAX) | Yes | Error details if failed |

**Constraints:**
- UNIQUE: (table_configuration_id, as_of_date) - Prevent duplicate exports
- FK: table_configuration_id → archival_table_configuration(id)

**Status Values:**
- `Pending` - Export in progress
- `Succeeded` - Export completed successfully
- `Failed` - Export failed

**Example Query:**
```sql
-- All datasets for a table
SELECT as_of_date, date_type, part_count, row_count, total_bytes, status, completed_at
FROM archival_dataset
WHERE table_configuration_id = 1
ORDER BY as_of_date DESC;

-- Failed datasets
SELECT tc.schema_name, tc.table_name, d.as_of_date, d.error_summary
FROM archival_dataset d
JOIN archival_table_configuration tc ON d.table_configuration_id = tc.id
WHERE d.status = 'Failed';

-- Storage usage by table
SELECT tc.schema_name, tc.table_name,
       COUNT(*) AS dataset_count,
       SUM(row_count) AS total_rows,
       SUM(total_bytes) / 1024 / 1024 / 1024.0 AS total_gb
FROM archival_dataset d
JOIN archival_table_configuration tc ON d.table_configuration_id = tc.id
WHERE d.status = 'Succeeded'
GROUP BY tc.schema_name, tc.table_name
ORDER BY total_gb DESC;
```

---

## Status Enums

### RunType
- `Archive` - Table archival run
- `Lifecycle` - Blob lifecycle run

### RunStatus
- `Running` - Run in progress
- `Succeeded` - All operations succeeded
- `Failed` - All operations failed
- `PartiallySucceeded` - Mix of success and failure

### RunItemStatus
- `Succeeded` - Operation succeeded
- `Failed` - Operation failed
- `Skipped` - Operation skipped (e.g., already archived)

### RunItemType
- `Dataset` - Table archival operation
- `Prefix` - Blob lifecycle operation

### DatasetStatus
- `Pending` - Export in progress
- `Succeeded` - Export completed
- `Failed` - Export failed

### DateType
- `EOD` - End of day
- `EOM` - End of month
- `EOQ` - End of quarter
- `EOY` - End of year

### LifecycleAction
- `Skip` - No action (blob too young)
- `SetCold` - Move to Cold tier
- `SetArchive` - Move to Archive tier
- `Delete` - Delete blob

---

## Relationships

### One-to-Many Relationships

```
archival_table_policy (1) ──> (N) archival_table_configuration
archival_blob_policy (1) ──> (N) archival_blob_configuration
archival_blob_policy (1) ──> (N) archival_table_configuration

archival_table_configuration (1) ──> (N) archival_table_exemption
archival_table_configuration (1) ──> (N) archival_dataset

archival_blob_configuration (1) ──> (N) archival_blob_exemption

archival_run (1) ──> (N) archival_run_item
```

### Foreign Key Constraints

All FKs use default ON DELETE NO ACTION (must delete child records first).

---

## Indexes and Constraints

### Primary Keys
All tables have IDENTITY PK on `id` column (INT or BIGINT).

### Unique Constraints
- `archival_table_configuration`: (database_name, schema_name, table_name)
- `archival_dataset`: (table_configuration_id, as_of_date)

### Indexes
- `archival_blob_exemption`: (blob_configuration_id, container_name, prefix, as_of_date)

**Recommendation:** Add indexes for common queries:
```sql
-- Run queries by date
CREATE INDEX ix_archival_run_started_at ON archival_run(started_at DESC);

-- Run item queries by status
CREATE INDEX ix_archival_run_item_status ON archival_run_item(status) WHERE status = 'Failed';

-- Dataset queries by table and date
CREATE INDEX ix_archival_dataset_table_date ON archival_dataset(table_configuration_id, as_of_date DESC);
```

---

## Schema Migrations

### Current Schema Version
**Base schema:** `db/metadata_schema.sql`

### Migration Scripts
Located in `db/migrations/`:
1. `002_vNext_run_items.sql` - Add run_item support
2. `003_simplify_blob_policy_naming.sql` - Rename blob policy fields
3. `004_simplify_blob_configuration_naming.sql` - Rename blob config fields
4. `005_simplify_table_policy_naming.sql` - Rename table policy fields

### Migration Process

**Manual migration:**
```sql
-- 1. Apply base schema (if new database)
-- Run: db/metadata_schema.sql

-- 2. Apply migrations in order
-- Run: db/migrations/002_*.sql
-- Run: db/migrations/003_*.sql
-- etc.
```

**No automated migration tool** (e.g., no EF Core migrations or Flyway).

**Recommendation:** Implement versioning table to track applied migrations:
```sql
CREATE TABLE archival_schema_version (
  id INT IDENTITY(1,1) PRIMARY KEY,
  version NVARCHAR(50) NOT NULL,
  script_name NVARCHAR(200) NOT NULL,
  applied_at DATETIME2(3) NOT NULL DEFAULT GETUTCDATE()
);

-- After applying migration:
INSERT INTO archival_schema_version (version, script_name)
VALUES ('002', '002_vNext_run_items.sql');
```

---

## Next Steps

- **[Operational Guide](operational_guides.md)** - Production deployment and monitoring
- **[Security](security.md)** - Secrets management and permissions
- **[Review Findings](review_findings.md)** - Known issues and recommendations

