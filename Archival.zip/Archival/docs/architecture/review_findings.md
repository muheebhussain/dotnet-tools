﻿# Architecture Review Findings

This document provides a "fresh eyes" review of the Archival system, identifying what works well, potential issues, and recommendations for improvement.

## Table of Contents
- [Executive Summary](#executive-summary)
- [What Looks Solid](#what-looks-solid)
- [Critical Findings](#critical-findings)
- [High Priority Findings](#high-priority-findings)
- [Medium Priority Findings](#medium-priority-findings)
- [Low Priority Findings](#low-priority-findings)
- [Recommendations Summary](#recommendations-summary)

---

## Executive Summary

**Overall Assessment:** The system is **well-architected** with clean VSA boundaries, proper separation of concerns, and good error handling patterns. The codebase is maintainable and follows modern .NET practices.

**Strengths:**
- ✅ Clean Vertical Slice Architecture
- ✅ Proper contract/interface boundaries
- ✅ Comprehensive audit trail
- ✅ Try-finally ensures run completion
- ✅ Cancellation token propagation
- ✅ Structured logging (Serilog)

**Areas for Improvement:**
- ⚠️ Some business logic not fully implemented (blob exemptions, template expansion)
- ⚠️ Failed datasets are not automatically retried
- ⚠️ Cancellation may leave runs in 'Running' state
- ⚠️ Hardcoded batch sizes and magic numbers
- ⚠️ Limited input validation
- ⚠️ No integration tests for end-to-end flows

**Recommended Next Steps:**
1. Implement blob exemptions enforcement (High)
2. Add retry logic for failed datasets (High)
3. Implement orphaned run cleanup (High)
4. Add configuration validation (Medium)
5. Add integration tests (Medium)

---

## What Looks Solid

### 1. Vertical Slice Architecture ✅

**Evidence:** Each feature is self-contained with clear boundaries.

**Files:**
- `Application/Features/TableArchival/ExecuteTableArchival/*`
- `Application/Features/BlobLifecycle/ExecuteBlobLifecycle/*`

**Why it's good:**
- Easy to understand what a feature does
- Changes are localized to one folder
- Adding new features doesn't affect existing ones

### 2. Contract-Based Dependencies ✅

**Evidence:** Application layer depends only on interfaces, not implementations.

**Example:**
```csharp
public ExecuteTableArchivalHandler(
    IDatasetStore datasetStore,           // Interface
    IConnectionStringResolver resolver,   // Interface
    ITableArchiver tableArchiver          // Interface
)
```

**Why it's good:**
- Testable (can mock interfaces)
- Implementations can be swapped
- Clear dependency boundaries

### 3. Run Completion Guarantees ✅

**Evidence:** Try-finally ensures runs are always completed, even on exceptions.

**Files:**
- `RunTableArchivalHandler.cs` lines 30-200
- `RunBlobLifecycleHandler.cs` lines 25-170

**Why it's good:**
- Prevents orphaned runs (status='Running' forever)
- Ensures audit trail is complete
- Proper cleanup on failure

### 4. Idempotency Checks ✅

**Evidence:** Dataset existence check prevents duplicate exports.

**Code:**
```csharp
if (await datasetStore.DatasetExistsAsync(table.Id, businessDate, ct)) {
  logger.LogDebug("Dataset already archived");
  continue; // Skip
}
```

**Why it's good:**
- Safe to re-run commands
- No duplicate data in blob storage
- Reduces cloud costs

### 5. Structured Logging ✅

**Evidence:** Serilog with structured properties.

**Examples:**
```csharp
logger.LogInformation("Archiving: Table={Schema}.{Table}, Date={Date}",
  table.SchemaName, table.TableName, businessDate);
```

**Why it's good:**
- Easy to query logs (by table, date, etc.)
- Better than string concatenation
- Works with log aggregation tools

### 6. Cancellation Token Propagation ✅

**Evidence:** CancellationToken flows from Program.cs to all async methods.

**Flow:**
```
Program.cs (Ctrl+C, SIGTERM)
  → Handler.HandleAsync(..., ct)
    → Store.SomeMethodAsync(..., ct)
      → SQL/Azure SDK operation (ct)
```

**Why it's good:**
- Graceful shutdown on Ctrl+C or SIGTERM
- Operations can be cancelled
- Kubernetes-friendly

---

## Critical Findings

### CRITICAL-1: Blob Exemptions Not Enforced

**Severity:** 🟢 **RESOLVED** ✅  
**Status:** Implementation Complete (February 15, 2026)

**Original Issue:**
Blob exemptions were loaded but never checked in `ExecuteBlobLifecycleHandler`.

**Solution Implemented:**
✅ **COMPLETE** - See `CRITICAL_1_DELIVERABLES_SUMMARY.md` for full implementation details.

**What Was Fixed:**
1. Added `IExemptionsStore exemptionsStore` dependency to handler
2. Load exemptions once after configuration/policy load (lines 37-40)
3. Check exemptions before processing each blob (lines 57-63)
4. Added `IsExempted()` helper method with matching rules:
   - Container match (case-insensitive)
   - Prefix match using `StartsWith()` (case-insensitive)
   - Date exact match
5. Exempted blobs skipped entirely (`continue` statement)
6. Added comprehensive logging and exemption counters
7. Created 8 comprehensive unit tests

**Files Modified:**
- `src/Archival.Application/Features/BlobLifecycle/ExecuteBlobLifecycle/ExecuteBlobLifecycleHandler.cs`

**Files Created:**
- `tests/Archival.Application.Tests/Archival.Application.Tests.csproj`
- `tests/Archival.Application.Tests/Features/BlobLifecycle/ExecuteBlobLifecycle/BlobExemptionTests.cs`

**Test Coverage:** 8 unit tests covering:
- ✅ Exemption matching when all criteria match
- ✅ Non-matching container
- ✅ Non-matching prefix
- ✅ Non-matching date
- ✅ Case-insensitive matching
- ✅ Empty exemptions
- ✅ Multiple exemptions
- ✅ Blob with subdirectories

**Risk Eliminated:** 🟢 Accidental deletion/tiering of exempt blobs is now **PREVENTED**

**Build Status:** ✅ SUCCESS - No errors, builds successfully

**Documentation:**
- `CRITICAL_1_IMPLEMENTATION_COMPLETE.md` - Technical details
- `CRITICAL_1_VISUAL_SUMMARY.md` - Visual before/after
- `CRITICAL_1_ACCEPTANCE_CHECKLIST.md` - Requirements verification
- `CRITICAL_1_DELIVERABLES_SUMMARY.md` - Complete deliverables summary

**Effort Actual:** ~6 hours (implementation + 8 unit tests + 4 documentation files)

---

### CRITICAL-2: Cancellation Leaves Runs in 'Running' State

**Severity:** 🔴 Critical  
**Risk Level:** Medium (operational issue, not data loss)

**Issue:**
If process is cancelled (Ctrl+C, SIGTERM), the run is not marked as completed.

**Evidence:**
```csharp
catch (OperationCanceledException) when (cts.IsCancellationRequested)
{
    Console.Error.WriteLine("Canceled.");
    return ExitCode.RuntimeError;
}
```

Run completion is in handler try-finally, but cancellation bypasses it.

**Impact:**
- Runs left in 'Running' state forever
- Requires manual SQL UPDATE to fix
- Confusing for operators

**Recommendation:**
Add finally block to Program.cs:
```csharp
var runId = -1L;
try {
  // ... run command
}
catch (OperationCanceledException) {
  // Mark run as failed if started
  if (runId > 0) {
    await MarkRunFailedAsync(runId, "Cancelled by user");
  }
}
```

Or: Implement orphaned run cleanup job that auto-fails runs stuck in 'Running' > 3 hours.

**Effort:** Medium (4-8 hours)  
**Priority:** High (operational impact)

---

## High Priority Findings

### HIGH-1: Failed Datasets Are Not Retried

**Severity:** 🟠 High  
**Risk Level:** Medium (data not archived, requires manual intervention)

**Issue:**
If dataset export fails, record is marked status='Failed'. Idempotency check prevents retry.

**Evidence:**
- `DatasetStore.CreateDatasetAsync()` creates record
- `DatasetStore.MarkDatasetFailedAsync()` sets status='Failed'
- `RunTableArchivalHandler` checks `DatasetExistsAsync()` (returns true for Failed)
- File: `Application/Features/TableArchival/RunTableArchival/RunTableArchivalHandler.cs` lines 108-113

**Impact:**
- Failed exports must be manually cleaned up (DELETE from archival_dataset)
- Transient failures (network timeouts) are not retried automatically

**Recommendation:**
**Option 1:** Change idempotency check to skip only 'Succeeded':
```csharp
var existingDataset = await datasetStore.GetDatasetAsync(table.Id, businessDate, ct);
if (existingDataset?.Status == DatasetStatus.Succeeded) {
  logger.LogDebug("Dataset already successfully archived");
  continue;
}
// If Pending or Failed, proceed (will update existing record)
```

**Option 2:** Add `--retry-failed` flag to explicitly retry failed datasets.

**Effort:** Low (2-4 hours)  
**Priority:** Implement soon (reduces operational burden)

---

### HIGH-2: Archive Path Template Expansion Not Used

**Severity:** 🟠 High  
**Risk Level:** Low (feature gap, not a bug)

**Issue:**
`ArchivePathTemplateExpander` supports tokens (`{database}`, `{schema}`, `{table}`, `{yyyy}`, `{MM}`, `{dd}`), but current code uses simple string concatenation.

**Evidence:**
- File: `Infrastructure/Parquet/ArchivePathTemplateExpander.cs` (70 lines, well-implemented)
- NOT used in: `ExecuteTableArchivalHandler.cs` line 45:
  ```csharp
  var blobPrefix = $"{plan.BaseBlobPrefix}{command.BusinessDate:yyyy-MM-dd}/";
  ```
- Template expansion logic exists but is never invoked

**Impact:**
- Configuration flexibility lost (can't use dynamic tokens)
- May confuse users if they try to use tokens in `archive_path_template`

**Recommendation:**
**Option 1:** Use the expander:
```csharp
var context = new ArchivePathTemplateContext(
  table.DatabaseName, table.SchemaName, table.TableName,
  businessDate, DateType.EOD
);
var blobPrefix = templateExpander.ExpandTemplate(plan.BaseBlobPrefix, context);
```

**Option 2:** Remove expander and document simple string format.

**Effort:** Low (if using expander: 2 hours; if removing: 1 hour)  
**Priority:** Decide direction and document

---

### HIGH-3: No Input Validation for Configuration

**Severity:** 🟠 High  
**Risk Level:** Medium (bad configs cause runtime failures)

**Issue:**
Configuration values from DB are not validated before use.

**Examples:**
- `archive_path_template` not validated (could have invalid chars)
- `batch_delete_size` not validated (could be 0 or negative)
- `cold_min_age_days > archive_min_age_days > delete_min_age_days` not enforced

**Evidence:**
No validation in:
- `TableConfigurationStore.GetTableConfigurationAsync()`
- `BlobConfigurationStore.GetBlobConfigurationAsync()`

**Impact:**
- Runtime errors (e.g., "Invalid blob name characters")
- Logic errors (e.g., archive tier applied before cold tier)
- Hard to diagnose issues

**Recommendation:**
Add validation layer:
```csharp
public static class ConfigurationValidator {
  public static Result Validate(TableConfigurationDto config) {
    if (config.BatchDeleteSize <= 0)
      return Result.Fail("BatchDeleteSize must be > 0");
    
    if (string.IsNullOrWhiteSpace(config.ArchivePathTemplate))
      return Result.Fail("ArchivePathTemplate is required");
    
    // Validate path doesn't have invalid chars
    if (config.ArchivePathTemplate.Any(c => Path.GetInvalidPathChars().Contains(c)))
      return Result.Fail("ArchivePathTemplate contains invalid characters");
    
    return Result.Success();
  }
}
```

Call validator after loading config.

**Effort:** Medium (8-16 hours for all configs)  
**Priority:** High (prevents runtime failures)

---

## Medium Priority Findings

### MED-1: Hardcoded Batch Size (10,000 Rows)

**Severity:** 🟡 Medium  
**Risk Level:** Low (works for most cases)

**Issue:**
Parquet export batch size is hardcoded at 10,000 rows.

**Evidence:**
File: `Infrastructure/SqlServer/SqlServerArchivalExporter.cs` line 54:
```csharp
const int batchSize = 10_000;
```

**Impact:**
- Not configurable for tables with very large rows (may cause OOM)
- Not configurable for tables with tiny rows (inefficient, many parts)

**Recommendation:**
Make configurable:
```sql
ALTER TABLE archival_table_configuration
ADD export_batch_size INT NOT NULL DEFAULT 10000;
```

Or use heuristic based on table row size.

**Effort:** Low (2-4 hours)  
**Priority:** Medium (optimization)

---

### MED-2: No Row Count Validation

**Severity:** 🟡 Medium  
**Risk Level:** Medium (silent data loss possible)

**Issue:**
Exported row count is not compared to source row count.

**Evidence:**
- Export returns row count
- No validation that count matches `SELECT COUNT(*) FROM source WHERE date = @date`

**Impact:**
- Partial exports may go unnoticed
- Data integrity issues

**Recommendation:**
```csharp
// After export
var expectedCount = await GetSourceRowCountAsync(sourceConn, schema, table, businessDate, ct);
if (exportResult.RowCount != expectedCount) {
  return Result.Fail($"Row count mismatch: exported {exportResult.RowCount}, expected {expectedCount}");
}
```

**Effort:** Low (2-4 hours)  
**Priority:** Medium (data integrity)

---

### MED-3: Date Range Window is Hardcoded (10 Years)

**Severity:** 🟡 Medium  
**Risk Level:** Low (may miss older data)

**Issue:**
Present date discovery only looks at last 10 years.

**Evidence:**
File: `RunTableArchivalHandler.cs` line 71:
```csharp
var from = DateTime.UtcNow.AddYears(-10);
```

**Impact:**
- Tables with data older than 10 years are not archived
- No warning to user

**Recommendation:**
Make configurable:
```sql
ALTER TABLE archival_table_configuration
ADD lookback_years INT NOT NULL DEFAULT 10;
```

Or: Remove window (query all dates). Risk: slow for very large tables.

**Effort:** Low (2-4 hours)  
**Priority:** Medium (feature completeness)

---

### MED-4: Business Date Classification Fallback Logic

**Severity:** 🟡 Medium  
**Risk Level:** Low (minor issue)

**Issue:**
If date type is unrecognized, it falls back to 'EOD' silently.

**Evidence:**
File: `Infrastructure/SqlServer/SqlServerBusinessCalendar.cs` lines 28-35:
```csharp
var type = dt switch
{
    "EOY" => DateType.EOY,
    "EOQ" => DateType.EOQ,
    "EOM" => DateType.EOM,
    _ => DateType.EOD  // Silent fallback
};
```

**Impact:**
- Invalid date_type values in view are not detected
- May affect retention calculation

**Recommendation:**
Log warning for unexpected values:
```csharp
_ => {
  logger.LogWarning("Unknown date_type: {DateType}, defaulting to EOD", dt);
  return DateType.EOD;
}
```

**Effort:** Low (1 hour)  
**Priority:** Low (rare case)

---

### MED-5: Blob Age Calculation May Be Negative

**Severity:** 🟡 Medium  
**Risk Level:** Low (edge case)

**Issue:**
If blob has future date in path, age calculation may be negative.

**Evidence:**
File: `ExecuteBlobLifecycleHandler.cs` line 50:
```csharp
var ageDays = (int)(clock.Today.DayNumber - blobDate.DayNumber);
// Could be negative if blobDate > Today
```

No check for negative age before policy evaluation.

**Impact:**
- Future-dated blobs are skipped (action = Skip) ✅
- But no logging to indicate anomaly

**Recommendation:**
```csharp
if (ageDays < 0) {
  logger.LogWarning("Blob has future date: {BlobName}, Date={Date}", blob.Name, blobDate);
  continue; // Skip
}
```

**Effort:** Low (1 hour)  
**Priority:** Low (edge case)

---

## Low Priority Findings

### LOW-1: Magic Number: Batch Delete Size Default

**Severity:** 🟢 Low  
**Risk Level:** Low (cosmetic)

**Issue:**
Batch delete size has no documented rationale.

**Evidence:**
Common values: 5000, 10000 in configurations.

**Recommendation:**
Document why this value was chosen (performance testing? SQL Server limits?).

**Effort:** Low (documentation only)

---

### LOW-2: Redundant Type Cast in Blob Lifecycle

**Severity:** 🟢 Low  
**Risk Level:** None (compiler warning)

**Issue:**
Redundant cast flagged by compiler.

**Evidence:**
File: `ExecuteBlobLifecycleHandler.cs` line 50:
```csharp
var ageDays = (int)(clock.Today.DayNumber - blobDate.DayNumber);
```

DayNumber subtraction already returns int.

**Recommendation:**
```csharp
var ageDays = clock.Today.DayNumber - blobDate.DayNumber;
```

**Effort:** Trivial (1 minute)  
**Priority:** Low (cosmetic)

---

### LOW-3: Unused ConfigurationProvider Class

**Severity:** 🟢 Low  
**Risk Level:** None (dead code)

**Issue:**
`ConfigurationProvider` class is not used anywhere (79 lines).

**Evidence:**
File: `Infrastructure/Providers/ConfigurationProviders.cs`  
No references found via grep.

**Recommendation:**
Delete the file (already documented in ANALYSIS_CONFIGURATIONPROVIDER_REPOSITORY.md).

**Effort:** Trivial (1 minute)  
**Priority:** Low (cleanup)

---

### LOW-4: Obsolete IConfigurationStore Still Exists

**Severity:** 🟢 Low  
**Risk Level:** None (technical debt)

**Issue:**
`IConfigurationStore` marked as obsolete but still in codebase.

**Evidence:**
File: `Application/Contracts/Persistence/IConfigurationStore.cs`  
No active usages (removed in ICONFIGURATIONSTORE_REMOVAL_COMPLETE.md).

**Recommendation:**
Delete interface and implementation after confirming no references.

**Effort:** Low (1-2 hours)  
**Priority:** Low (cleanup)

---

## Recommendations Summary

### Immediate Actions (Critical)
1. ✅ **Implement blob exemptions enforcement** (CRITICAL-1)
   - Effort: 2-4 hours
   - Impact: Prevents inappropriate deletions

2. ✅ **Add cancellation handling for run completion** (CRITICAL-2)
   - Effort: 4-8 hours
   - Impact: Prevents orphaned runs

### Short-Term (High Priority)
3. ✅ **Allow retry of failed datasets** (HIGH-1)
   - Effort: 2-4 hours
   - Impact: Reduces manual cleanup

4. ✅ **Decide on template expansion** (HIGH-2)
   - Effort: 1-2 hours (decide + document)
   - Impact: Clarifies feature scope

5. ✅ **Add configuration validation** (HIGH-3)
   - Effort: 8-16 hours
   - Impact: Prevents runtime errors

### Medium-Term (Medium Priority)
6. ⚙️ **Make batch sizes configurable** (MED-1)
   - Effort: 2-4 hours
   - Impact: Better performance tuning

7. ⚙️ **Add row count validation** (MED-2)
   - Effort: 2-4 hours
   - Impact: Data integrity guarantee

8. ⚙️ **Make date range configurable** (MED-3)
   - Effort: 2-4 hours
   - Impact: Handles older data

### Long-Term (Enhancements)
9. 📊 **Add integration tests**
   - Effort: 40-80 hours
   - Impact: Confidence in end-to-end flows

10. 📊 **Implement Managed Identity support**
    - Effort: 16-32 hours
    - Impact: Better security, no secrets

11. 📊 **Add metrics/observability**
    - Effort: 16-32 hours
    - Impact: Better production monitoring

---

## Conclusion

The Archival system is **production-ready** with minor fixes:
- Fix critical issues (blob exemptions, cancellation handling)
- Add validation to prevent bad configs
- Document feature scope (template expansion)

The architecture is **solid** and maintainable. The VSA pattern makes it easy to add features without breaking existing code. The audit trail provides good visibility into operations.

**Recommended rollout:**
1. Deploy to staging, test thoroughly
2. Fix critical issues identified in this review
3. Deploy to production with monitoring
4. Iterate on medium-priority improvements

---

## Contact

For questions or clarifications on any findings, refer to the specific file references in each finding.

