﻿# Business Rules

This document enumerates all business rules implemented in the Archival system, including where they're implemented, key assumptions, and edge cases.

## Table of Contents
- [Retention Policy Rules](#retention-policy-rules)
- [Business Date Rules](#business-date-rules)
- [Exemption Rules](#exemption-rules)
- [Archive Path Rules](#archive-path-rules)
- [Parquet Export Rules](#parquet-export-rules)
- [Lifecycle Policy Rules](#lifecycle-policy-rules)
- [Idempotency Rules](#idempotency-rules)
- [Run Status Transition Rules](#run-status-transition-rules)

---

## Retention Policy Rules

### Rule: Keep Last N Dates by Type

**Business Logic:**
For each table configuration, retain the last N business dates of each type (EOD/EOM/EOQ/EOY). Dates not in the keep set are candidates for archival.

**Configuration:**
```sql
archival_table_policy:
  - keep_last_eod (nullable int)   # Keep last N end-of-day dates
  - keep_last_eom (nullable int)   # Keep last N end-of-month dates
  - keep_last_eoq (nullable int)   # Keep last N end-of-quarter dates
  - keep_last_eoy (nullable int)   # Keep last N end-of-year dates
```

**Implementation:**
File: `Archival.Infrastructure/Retention/RetentionService.cs`  
Method: `CalculateKeepDatesAsync()`

SQL Logic:
```sql
-- Get top N dates for each type, descending (most recent first)
k_eod: SELECT TOP (@keep_eod) current_business_date FROM v_business_date_classification
       WHERE date_type = 'EOD' AND current_business_date <= @today
       ORDER BY current_business_date DESC

k_eom: SELECT TOP (@keep_eom) current_business_date ... WHERE date_type = 'EOM' ...
k_eoq: SELECT TOP (@keep_eoq) current_business_date ... WHERE date_type = 'EOQ' ...
k_eoy: SELECT TOP (@keep_eoy) current_business_date ... WHERE date_type = 'EOY' ...

-- UNION all keep dates
keep_set = k_eod UNION k_eom UNION k_eoq UNION k_eoy UNION table_exemptions
```

**Example:**
```
Policy: keep_last_eod=5, keep_last_eom=3, keep_last_eoq=2, keep_last_eoy=1
Today: 2026-02-15

Keep set might include:
  EOD: 2026-02-14, 2026-02-13, 2026-02-12, 2026-02-11, 2026-02-10
  EOM: 2026-01-31, 2025-12-31, 2025-11-30
  EOQ: 2025-12-31, 2025-09-30
  EOY: 2025-12-31

Total: ~11 unique dates (some overlap like EOY = EOQ = EOM = 2025-12-31)
```

**Assumptions:**
1. `dbo.v_business_date_classification` view correctly classifies dates
2. `@today` is based on `IClock.UtcNow` (testable via mock clock)
3. NULL policy values are treated as 0 (keep nothing)
4. Dates with multiple classifications (e.g., EOY is also EOQ/EOM/EOD) count toward all types

**Edge Cases:**
- **Policy all NULL**: Keep set is empty → all present dates are candidates
- **keep_last > available dates**: Keep all available (no error)
- **Future dates in table**: Not kept (query filters `<= @today`)
- **Overlapping types**: Date counted in each applicable type (e.g., 12/31 kept for EOY, EOQ, EOM, EOD)

---

## Business Date Rules

### Rule: Business Date Classification

**Business Logic:**
Business dates are classified into types based on their significance:
- **EOD** (End of Day) - Every business day
- **EOM** (End of Month) - Last business day of month
- **EOQ** (End of Quarter) - Last business day of quarter (Mar, Jun, Sep, Dec)
- **EOY** (End of Year) - Last business day of year (Dec 31)

**Source:**
View: `dbo.v_business_date_classification` (in source database)

**Expected Schema:**
```sql
CREATE VIEW dbo.v_business_date_classification AS
SELECT
  current_business_date DATE,
  date_type VARCHAR(4)  -- 'EOD', 'EOM', 'EOQ', 'EOY'
FROM dbo.business_date
-- Classification logic (business logic of source system)
```

**Implementation:**
File: `Archival.Infrastructure/SqlServer/SqlServerBusinessCalendar.cs`  
Method: `GetClassifiedDatesAsync()`

**Usage:**
- Used by RetentionService to select top N dates per type
- Used by handlers to determine date type for export metadata

**Assumptions:**
1. View exists and is maintained by source system
2. Each date has exactly one primary classification
3. Date ranges are inclusive of start, exclusive of end (`>= from AND < to`)

**Edge Cases:**
- **Missing view**: Query fails with SQL error
- **Invalid date_type values**: Treated as 'EOD' (fallback logic)
- **Non-business dates**: Not included in view (e.g., weekends, holidays)

---

### Rule: Present Date Discovery

**Business Logic:**
Find all distinct business dates that exist in a source table within a given date range.

**Implementation:**
File: `Archival.Infrastructure/SqlServer/SqlServerPresentDateFinder.cs`  
Method: `GetPresentBusinessDatesAsync()`

SQL Logic:
```sql
SELECT DISTINCT CAST(t.[business_date_column] AS date) AS as_of_date
FROM [schema].[table] t
JOIN dbo.business_date bd
  ON CAST(t.[business_date_column] AS date) = CAST(bd.current_business_date AS date)
WHERE t.[business_date_column] >= @from
  AND t.[business_date_column] < @to
ORDER BY as_of_date
```

**Why JOIN business_date?**
Ensures only valid business dates are returned (filters out non-business days if accidentally in table).

**Parameters:**
- `from`: Default is `DateTime.UtcNow.AddYears(-10)` (last 10 years)
- `to`: Default is `DateTime.UtcNow.AddDays(1)` (today + 1)

**Assumptions:**
1. Business date column contains dates (not timestamps with varying times)
2. `dbo.business_date` table exists and is complete (70-year calendar recommended)
3. Date range is wide enough to capture all relevant dates

**Edge Cases:**
- **Empty table**: Returns empty list (no error)
- **No business_date table**: Query fails
- **Timestamps with time component**: CAST to date handles this (compares date portion only)

---

## Exemption Rules

### Rule: Table Exemptions

**Business Logic:**
Specific dates can be exempted from archival for a table configuration. Exempted dates are never archived, even if not in the keep set.

**Configuration:**
```sql
archival_table_exemption:
  - table_configuration_id (int, FK)
  - as_of_date (date)
  - reason (nvarchar, optional)
```

**Implementation:**
File: `Archival.Data/Stores/ExemptionsStore.cs`  
Method: `GetTableExemptionsAsync()`

SQL:
```sql
SELECT table_configuration_id, as_of_date
FROM archival_table_exemption
WHERE table_configuration_id = @tableConfigId
```

**Usage:**
```csharp
candidates = presentDates
  .Where(d => !keepSet.Contains(d))
  .Where(d => !exemptions.Any(e => e.AsOfDate == d))
  .ToList();
```

**Assumptions:**
1. Exemptions are permanent (unless manually removed from DB)
2. Reason is for documentation only (not enforced)

**Edge Cases:**
- **No exemptions**: Empty set, all non-keep dates are candidates
- **Exempted date not present in table**: No effect
- **Duplicate exemptions**: Deduplicated by DISTINCT in query

---

### Rule: Blob Exemptions

**Business Logic:**
Specific date folders can be exempted from lifecycle operations for a blob configuration.

**Configuration:**
```sql
archival_blob_exemption:
  - blob_configuration_id (int, FK)
  - as_of_date (date)
  - container_name (nvarchar)
  - prefix (nvarchar)
  - reason (nvarchar, optional)
```

**Implementation:**
File: `Archival.Data/Repositories/ConfigurationRepository.cs`  
Method: `GetFileExemptionsAsync()`

**Note:** Currently loaded but **not actively enforced** in ExecuteBlobLifecycleHandler.

**Assumption:**
Intended for future use to skip specific date folders from lifecycle operations.

**Edge Case:**
Current implementation does not check exemptions before processing blobs.

**⚠️ Finding:** Blob exemptions are not implemented in lifecycle handler. See [Review Findings](review_findings.md#blob-exemptions-not-enforced).

---

## Archive Path Rules

### Rule: Archive Path Format

**Business Logic:**
Archive path template specifies where to store exported Parquet files.

**Configuration:**
```sql
archival_table_configuration.archive_path_template (nvarchar(400))
```

**Current Implementation:**
File: `Archival.Application/Features/TableArchival/BuildTableArchivalPlan/BuildTableArchivalPlanHandler.cs`

Logic:
```csharp
BaseBlobPrefix = tableConfig.ArchivePathTemplate ?? $"{tableConfig.SchemaName}/{tableConfig.TableName}/"
```

**Usage:**
File: `Archival.Application/Features/TableArchival/ExecuteTableArchival/ExecuteTableArchivalHandler.cs`

```csharp
var blobPrefix = $"{plan.BaseBlobPrefix}{command.BusinessDate:yyyy-MM-dd}/";
// Example: "dbo/Transactions/2026-01-15/"
```

**Assumptions:**
1. Template is a simple string path (no token expansion currently)
2. Template should end with `/` to create a directory structure
3. Date is appended in `yyyy-MM-dd` format

**Edge Cases:**
- **NULL template**: Uses default `{schema}/{table}/`
- **Template without trailing slash**: Date added anyway (might create bad path)
- **Template with special chars**: No validation (could cause upload errors)

**⚠️ Finding:** Template expansion logic (`{database}`, `{schema}`, `{table}`, `{yyyy}`, `{MM}`, `{dd}`) exists in `ArchivePathTemplateExpander` but is **not used**. See [Review Findings](review_findings.md#unused-template-expander).

---

### Rule: Parquet Part Naming

**Business Logic:**
Multi-part Parquet exports are named sequentially.

**Implementation:**
File: `Archival.Infrastructure/Parquet/ParquetPartWriter.cs`

Naming:
```csharp
blobName = $"{blobPrefix}part-{partNumber:D4}.parquet"
// Example: "dbo/Transactions/2026-01-15/part-0000.parquet"
//          "dbo/Transactions/2026-01-15/part-0001.parquet"
```

**Assumptions:**
1. Part numbering starts at 0
2. 4-digit zero-padded format (`D4`) supports up to 9,999 parts
3. Prefix includes trailing slash

**Edge Cases:**
- **> 9,999 parts**: Still works (5-digit numbers like `part-10000.parquet`)
- **Single part export**: Named `part-0000.parquet` (not `data.parquet`)

---

## Parquet Export Rules

### Rule: Row Batching

**Business Logic:**
Export processes rows in batches to manage memory usage.

**Configuration:**
Hardcoded: 10,000 rows per batch

**Implementation:**
File: `Archival.Infrastructure/SqlServer/SqlServerArchivalExporter.cs`

Logic:
```csharp
const int batchSize = 10_000;

while (await reader.ReadAsync(ct)) {
  batch.Add(row);
  
  if (batch.Count >= batchSize) {
    await partWriter.WritePartAsync(batch, ...);
    batch.Clear();
    partNumber++;
  }
}

// Final partial batch
if (batch.Count > 0) {
  await partWriter.WritePartAsync(batch, ...);
}
```

**Assumptions:**
1. 10,000 rows fit comfortably in memory
2. Each row is a List<object> (one element per column)

**Edge Cases:**
- **< 10,000 rows**: Single part file
- **Exactly N × 10,000 rows**: N parts, no empty final batch
- **Large row size**: May cause memory pressure (not handled)

**Performance:**
- 10,000 rows is a balance between memory and part count
- Too small: many parts (slow upload)
- Too large: memory issues

---

### Rule: Schema Inference

**Business Logic:**
Parquet schema is inferred from SQL table schema.

**Implementation:**
File: `Archival.Infrastructure/Parquet/ParquetSchemaBuilder.cs`  
Method: `BuildSchemaAsync()`

Mapping:
```
SQL Type → Parquet Type
-------------------------------
int, smallint, tinyint → Int32
bigint → Int64
decimal, numeric, money → Decimal
float, real → Double
varchar, nvarchar, char, nchar, text, ntext → String
date, datetime, datetime2, datetimeoffset, smalldatetime → Timestamp (DateTimeOffset)
bit → Boolean
uniqueidentifier → String (GUID as string)
binary, varbinary, image → ByteArray
```

**Assumptions:**
1. SQL types are standard (no custom types)
2. Nullable columns map to nullable Parquet fields
3. All columns in SELECT are included in schema

**Edge Cases:**
- **Unsupported SQL type**: May throw exception (not tested)
- **User-defined types**: Likely fails
- **Computed columns**: Included if in SELECT

---

### Rule: Date Range Export

**Business Logic:**
Export includes rows where business date is >= businessDate AND < businessDate + 1 day.

**Implementation:**
File: `Archival.Infrastructure/SqlServer/SqlServerArchivalExporter.cs`

```csharp
var rangeUtc = new BusinessDateRange(
  businessDate.ToDateTime(TimeOnly.MinValue),      // Start: 2026-01-15 00:00:00
  businessDate.ToDateTime(TimeOnly.MinValue).AddDays(1) // End: 2026-01-16 00:00:00
);

SQL:
WHERE [business_date_column] >= @StartInclusiveUtc
  AND [business_date_column] < @EndExclusiveUtc
```

**Rationale:**
Inclusive start, exclusive end ensures no overlap between date ranges.

**Assumptions:**
1. Business date column is a datetime or date type
2. Rows have uniform date (all rows for a date fit in one query)

**Edge Cases:**
- **Rows with timestamps**: Included if date portion matches
- **Rows at midnight next day**: Excluded (< comparison)

---

## Lifecycle Policy Rules

### Rule: Age-Based Tiering

**Business Logic:**
Blobs are tiered based on age thresholds defined in the lifecycle policy.

**Configuration:**
```sql
archival_blob_policy:
  - cold_min_age_days (nullable int)
  - archive_min_age_days (nullable int)
  - delete_min_age_days (nullable int)
```

**Implementation:**
File: `Archival.Application/Features/BlobLifecycle/ExecuteBlobLifecycle/ExecuteBlobLifecycleHandler.cs`

Logic (priority order):
```csharp
if (ageDays >= deleteMinAgeDays) {
  action = Delete;
} else if (ageDays >= archiveMinAgeDays) {
  action = SupportsArchiveTier ? SetArchive : SetCold;
} else if (ageDays >= coldMinAgeDays) {
  action = SetCold;
} else {
  action = Skip;
}
```

**Priority:**
Delete > Archive > Cold > Skip

**Example:**
```
Policy: cold=30, archive=90, delete=365

Blob age 20 days  → Skip (too young)
Blob age 45 days  → SetCold
Blob age 120 days → SetArchive (or SetCold if not supported)
Blob age 400 days → Delete
```

**Assumptions:**
1. Age thresholds are mutually exclusive (delete > archive > cold)
2. NULL threshold means "don't apply this tier"
3. Age is calculated in days (not hours/minutes)

**Edge Cases:**
- **All thresholds NULL**: All blobs skipped
- **delete < cold**: Delete takes precedence (follows priority order)
- **Archive not supported**: Falls back to Cold tier

---

### Rule: Age Calculation

**Business Logic:**
Blob age is calculated from either extracted date or creation date.

**Implementation:**
File: `Archival.Application/Features/BlobLifecycle/ExecuteBlobLifecycle/ExecuteBlobLifecycleHandler.cs`

Logic:
```csharp
// Try to extract date from path (e.g., "archive/2025/01/15/data.parquet")
if (blobInventory.TryExtractDateFromPath(blob.Name, config.Prefix, out blobDate)) {
  // Use extracted date
} else {
  // Fallback to blob creation date
  blobDate = DateOnly.FromDateTime(blob.CreatedAtUtc);
}

ageDays = (int)(clock.Today.DayNumber - blobDate.DayNumber);
```

**Date Extraction:**
File: `Archival.Infrastructure/AzureBlob/BlobBusinessDateExtractor.cs`

Patterns (priority):
1. `yyyy-MM-dd` (e.g., "2026-02-15")
2. `yyyy/MM/dd` (e.g., "2026/02/15")
3. `yyyyMMdd` (e.g., "20260215")

**Assumptions:**
1. Date pattern appears in blob path after prefix
2. First matched pattern is used
3. Invalid dates fall back to creation date (no error)

**Edge Cases:**
- **No date in path**: Uses blob.CreatedAtUtc
- **Multiple dates in path**: First match used
- **Invalid date format**: Falls back to creation date
- **Future date in path**: Negative age (treated as 0? Not clear from code)

---

### Rule: Archive Tier Fallback

**Business Logic:**
If blob configuration does not support Archive tier, fall back to Cold tier.

**Configuration:**
```sql
archival_blob_configuration.supports_archive_tier (bit)
```

**Implementation:**
```csharp
else if (ageDays >= archiveMinAgeDays) {
  action = config.SupportsArchiveTier ? SetArchive : SetCold;
}
```

**Rationale:**
Some storage accounts don't support Archive tier (e.g., premium storage).

**Assumptions:**
1. Configuration correctly reflects account capabilities
2. Cold tier is always supported

**Edge Cases:**
- **supports_archive_tier = 0**: Archive-aged blobs go to Cold instead
- **Manual archive tier change**: System won't revert to Cold

---

## Idempotency Rules

### Rule: Dataset Existence Check

**Business Logic:**
Before exporting, check if dataset already exists. If exists, skip export.

**Implementation:**
File: `Archival.Application/Features/TableArchival/RunTableArchival/RunTableArchivalHandler.cs`

```csharp
if (await datasetStore.DatasetExistsAsync(table.Id, businessDate, ct)) {
  logger.LogDebug("Dataset already archived");
  continue; // Skip this date
}
```

SQL:
```sql
SELECT 1
FROM archival_dataset
WHERE table_configuration_id = @tableConfigId
  AND as_of_date = @asOfDate
```

**Guarantee:**
Safe to re-run command; won't duplicate exports.

**Assumptions:**
1. Dataset record is created before export starts
2. Failed exports leave Pending/Failed record (won't re-export)

**Edge Cases:**
- **Failed export**: Record exists with status='Failed' → Won't retry (limitation)
- **Partial export**: Record exists → Won't complete (limitation)

**⚠️ Finding:** Failed datasets are not automatically retried. Manual cleanup required. See [Review Findings](review_findings.md#failed-datasets-not-retried).

---

### Rule: Dataset Status Tracking

**Business Logic:**
Dataset status transitions: (none) → Pending → Succeeded/Failed

**Implementation:**
Files:
- `Archival.Data/Stores/DatasetStore.cs`
- `Archival.Application/Features/TableArchival/ExecuteTableArchival/ExecuteTableArchivalHandler.cs`

Flow:
```csharp
1. CreateDatasetAsync() → status='Pending'
   SQL: INSERT INTO archival_dataset (..., status) VALUES (..., 'Pending')

2a. Export succeeds:
    MarkDatasetSucceededAsync() → status='Succeeded'
    SQL: UPDATE archival_dataset SET status='Succeeded', part_count=@parts,
         row_count=@rows, total_bytes=@bytes, completed_at=GETUTCDATE()

2b. Export fails:
    MarkDatasetFailedAsync() → status='Failed'
    SQL: UPDATE archival_dataset SET status='Failed', error_summary=@error,
         completed_at=GETUTCDATE()
```

**Allowed Transitions:**
- Pending → Succeeded ✅
- Pending → Failed ✅
- Succeeded → * ❌ (final state)
- Failed → * ❌ (final state, requires manual cleanup)

**Edge Cases:**
- **Process killed during export**: Dataset left in 'Pending' state (orphaned)
- **Multiple concurrent runs**: UNIQUE constraint prevents duplicate datasets

---

## Run Status Transition Rules

### Rule: Run Lifecycle

**Business Logic:**
Run status transitions: (none) → Running → Succeeded/Failed/PartiallySucceeded

**Implementation:**
Files:
- `Archival.Application/Features/Runs/StartRun/StartRunHandler.cs`
- `Archival.Application/Features/Runs/CompleteRun/CompleteRunHandler.cs`

Flow:
```csharp
1. StartRunHandler → status='Running'
   SQL: INSERT INTO archival_run (run_type, started_at, status)
        VALUES (@runType, GETUTCDATE(), 'Running')

2. CompleteRunHandler → status='Succeeded'/'Failed'/'PartiallySucceeded'
   SQL: UPDATE archival_run
        SET status=@status, ended_at=GETUTCDATE(), note=@note
        WHERE id=@runId
```

**Status Determination:**
```csharp
if (anyFailed) {
  status = successCount > 0 ? PartiallySucceeded : Failed;
} else {
  status = Succeeded;
}
```

**Guaranteed Completion:**
Try-finally ensures run is always completed:
```csharp
try {
  // Process items
} catch {
  completeRunHandler.HandleAsync(runId, Failed, ex.Message);
}
```

**Assumptions:**
1. Run is created before any processing
2. Run is completed even on exception
3. Cancellation may leave run in 'Running' state

**Edge Cases:**
- **Process killed**: Run left in 'Running' state (orphaned)
- **All items skipped**: status='Succeeded' (no failures)
- **Some succeed, some fail**: status='PartiallySucceeded'

---

### Rule: Run Item Recording

**Business Logic:**
Each operation (dataset archive or prefix lifecycle) is recorded as a run item.

**Implementation:**
File: `Archival.Data/Stores/RunItemsStore.cs`

```csharp
AddRunItemAsync(
  runId,
  itemType: Dataset or Prefix,
  status: Succeeded/Failed/Skipped,
  tableConfigurationId: (for Dataset),
  blobConfigurationId: (for Prefix),
  asOfDate: (optional),
  rowsAffected,
  bytesAffected,
  error,
  ct
)

SQL:
INSERT INTO archival_run_item
(run_id, item_type, item_key, action, status, rows_affected,
 bytes_affected, error_message, created_at)
VALUES (...)
```

**Item Key Format:**
- Dataset: `{schema}.{table}:{date}` (e.g., "dbo.Transactions:2026-01-15")
- Prefix: `{container}/{prefix}` (e.g., "archive/dbo/Transactions/")

**Assumptions:**
1. Run items are append-only (never updated)
2. Each operation creates exactly one run item
3. Failed operations still create a run item (with error message)

**Edge Cases:**
- **Duplicate items**: Allowed (no UNIQUE constraint)
- **NULL error for failed item**: Possible (should always have error message)

---

## Business Rule Summary Table

| Rule | File | Key Method | Configurable | Edge Cases Handled |
|------|------|------------|--------------|-------------------|
| Retention Policy | RetentionService.cs | CalculateKeepDatesAsync | Yes (DB policy) | NULL values, overlapping types |
| Business Date Classification | SqlServerBusinessCalendar.cs | GetClassifiedDatesAsync | No (view) | Invalid types fallback |
| Present Date Discovery | SqlServerPresentDateFinder.cs | GetPresentBusinessDatesAsync | No (SQL join) | Empty table, timestamps |
| Table Exemptions | ExemptionsStore.cs | GetTableExemptionsAsync | Yes (DB exemptions) | Duplicates, non-present dates |
| Blob Exemptions | ConfigurationRepository.cs | GetFileExemptionsAsync | Yes (DB exemptions) | ⚠️ NOT ENFORCED |
| Archive Path | BuildTableArchivalPlanHandler.cs | HandleAsync | Yes (template) | NULL template, ⚠️ tokens unused |
| Parquet Naming | ParquetPartWriter.cs | WritePartAsync | No (hardcoded) | > 9999 parts |
| Row Batching | SqlServerArchivalExporter.cs | ExportByBusinessDateRangeAsync | No (10k rows) | Large rows |
| Schema Inference | ParquetSchemaBuilder.cs | BuildSchemaAsync | No (auto) | Unsupported types |
| Date Range Export | SqlServerArchivalExporter.cs | ExportByBusinessDateRangeAsync | No (inclusive/exclusive) | Midnight boundary |
| Age-Based Tiering | ExecuteBlobLifecycleHandler.cs | HandleAsync | Yes (DB policy) | NULL thresholds, priority |
| Age Calculation | ExecuteBlobLifecycleHandler.cs | HandleAsync | No (regex + fallback) | No date in path, invalid dates |
| Archive Tier Fallback | ExecuteBlobLifecycleHandler.cs | HandleAsync | Yes (supports_archive_tier) | Always falls back to Cold |
| Dataset Existence | RunTableArchivalHandler.cs | HandleAsync | No (DB check) | ⚠️ Failed datasets not retried |
| Dataset Status | DatasetStore.cs | Multiple | No (state machine) | Orphaned Pending, concurrent runs |
| Run Status | StartRun/CompleteRunHandler.cs | HandleAsync | No (state machine) | Orphaned Running, cancellation |
| Run Item Recording | RunItemsStore.cs | AddRunItemAsync | No (audit log) | Duplicates allowed, NULL errors |

---

## Next Steps

- **[Data Model](data_model.md)** - Database schema and relationships
- **[Operational Guide](operational_guides.md)** - Production deployment and troubleshooting
- **[Review Findings](review_findings.md)** - Known issues and recommendations

