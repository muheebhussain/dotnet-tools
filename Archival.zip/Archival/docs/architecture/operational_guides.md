﻿# Operational Guide

This document provides guidance for deploying, monitoring, and troubleshooting the Archival system in production environments (Linux containers, Kubernetes, Azure).

## Table of Contents
- [Production Deployment](#production-deployment)
- [Environment Variables](#environment-variables)
- [Secrets Management](#secrets-management)
- [Logging and Monitoring](#logging-and-monitoring)
- [Troubleshooting](#troubleshooting)
- [Performance Considerations](#performance-considerations)
- [Disaster Recovery](#disaster-recovery)

---

## Production Deployment

### Kubernetes CronJob Deployment

The system is designed to run as Kubernetes CronJobs in Azure Kubernetes Service (AKS).

**Recommended Schedule:**
```yaml
# Table Archival - Run nightly at 2 AM UTC
apiVersion: batch/v1
kind: CronJob
metadata:
  name: archival-table
  namespace: data-ops
spec:
  schedule: "0 2 * * *"  # Daily at 2 AM
  concurrencyPolicy: Forbid  # Don't run concurrent jobs
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 3
  jobTemplate:
    spec:
      backoffLimit: 0  # Don't retry on failure
      template:
        spec:
          restartPolicy: Never
          containers:
          - name: archival
            image: your-registry/archival:latest
            command: ["dotnet", "Archival.App.dll", "table", "--all-active"]
            env:
            - name: ARCHIVAL_METADATA_DB
              valueFrom:
                secretKeyRef:
                  name: archival-secrets
                  key: metadata-connection-string
            volumeMounts:
            - name: secrets
              mountPath: /secrets
              readOnly: true
          volumes:
          - name: secrets
            csi:
              driver: secrets-store.csi.k8s.io
              readOnly: true
              volumeAttributes:
                secretProviderClass: archival-secrets-provider

---
# Blob Lifecycle - Run hourly
apiVersion: batch/v1
kind: CronJob
metadata:
  name: archival-blob-lifecycle
  namespace: data-ops
spec:
  schedule: "0 * * * *"  # Hourly
  concurrencyPolicy: Forbid
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 3
  jobTemplate:
    spec:
      backoffLimit: 0
      template:
        spec:
          restartPolicy: Never
          containers:
          - name: archival
            image: your-registry/archival:latest
            command: ["dotnet", "Archival.App.dll", "blob", "--all-targets"]
            env:
            - name: ARCHIVAL_METADATA_DB
              valueFrom:
                secretKeyRef:
                  name: archival-secrets
                  key: metadata-connection-string
            volumeMounts:
            - name: secrets
              mountPath: /secrets
              readOnly: true
          volumes:
          - name: secrets
            csi:
              driver: secrets-store.csi.k8s.io
              readOnly: true
              volumeAttributes:
                secretProviderClass: archival-secrets-provider
```

**Key Configuration:**
- `concurrencyPolicy: Forbid` - Prevents overlapping runs (important for idempotency)
- `backoffLimit: 0` - Don't retry (manual investigation required for failures)
- `restartPolicy: Never` - Don't restart failed pods
- CSI Secrets Store - Mount secrets from Azure Key Vault

### Docker Image Build

**Dockerfile:**
```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:10.0-alpine AS base
WORKDIR /app

FROM mcr.microsoft.com/dotnet/sdk:10.0-alpine AS build
WORKDIR /src
COPY ["src/Archival.App/Archival.App.csproj", "Archival.App/"]
COPY ["src/Archival.Application/Archival.Application.csproj", "Archival.Application/"]
COPY ["src/Archival.Data/Archival.Data.csproj", "Archival.Data/"]
COPY ["src/Archival.Infrastructure/Archival.Infrastructure.csproj", "Archival.Infrastructure/"]
RUN dotnet restore "Archival.App/Archival.App.csproj"

COPY src/ .
RUN dotnet build "Archival.App/Archival.App.csproj" -c Release -o /app/build
RUN dotnet publish "Archival.App/Archival.App.csproj" -c Release -o /app/publish

FROM base AS final
WORKDIR /app
COPY --from=build /app/publish .
ENTRYPOINT ["dotnet", "Archival.App.dll"]
```

**Build and push:**
```bash
docker build -t your-registry/archival:latest .
docker push your-registry/archival:latest
```

### CSI Secrets Store Configuration

**SecretProviderClass for Azure Key Vault:**
```yaml
apiVersion: secrets-store.csi.x-k8s.io/v1
kind: SecretProviderClass
metadata:
  name: archival-secrets-provider
  namespace: data-ops
spec:
  provider: azure
  parameters:
    usePodIdentity: "false"
    useVMManagedIdentity: "true"
    userAssignedIdentityID: "your-managed-identity-client-id"
    keyvaultName: "your-keyvault-name"
    tenantId: "your-tenant-id"
    objects: |
      array:
        - |
          objectName: archival-db-connections
          objectType: secret
          objectVersion: ""
        - |
          objectName: archival-storage-connections
          objectType: secret
          objectVersion: ""
```

**Mounted files in pod:**
- `/secrets/archival-db-connections` (JSON)
- `/secrets/archival-storage-connections` (JSON)

---

## Environment Variables

### Required Variables

| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `ARCHIVAL_METADATA_DB` | **Yes** | Metadata database connection string | `Server=sql.database.windows.net;Database=archival_meta;User ID=archival_user;Password=***;Encrypt=True;TrustServerCertificate=False;` |

### Optional Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ARCHIVAL_SECRETS_PATH` | No | `/secrets/` | Path to secrets directory |

### Kubernetes Secret for ARCHIVAL_METADATA_DB

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: archival-secrets
  namespace: data-ops
type: Opaque
stringData:
  metadata-connection-string: "Server=sql.database.windows.net;Database=archival_meta;User ID=archival_user;Password=YourStrongPassword;Encrypt=True;TrustServerCertificate=False;"
```

---

## Secrets Management

### Secret Files Structure

**File: `/secrets/archival-db-connections.json`**
```json
{
  "SourceDB1": "Server=sourcedb1.database.windows.net;Database=SourceDB1;User ID=reader;Password=***;Encrypt=True;TrustServerCertificate=False;",
  "TradingDB": "Server=tradingdb.database.windows.net;Database=TradingDB;User ID=reader;Password=***;Encrypt=True;TrustServerCertificate=False;",
  "AnalyticsDB": "Server=analyticsdb.database.windows.net;Database=AnalyticsDB;User ID=reader;Password=***;Encrypt=True;TrustServerCertificate=False;"
}
```

**File: `/secrets/archival-storage-connections.json`**
```json
{
  "storageaccount1": "DefaultEndpointsProtocol=https;AccountName=storageaccount1;AccountKey=***;EndpointSuffix=core.windows.net",
  "archivestorage": "DefaultEndpointsProtocol=https;AccountName=archivestorage;AccountKey=***;EndpointSuffix=core.windows.net"
}
```

### Local Development Secrets

For local development, use template files:

```bash
# Copy templates
cp secrets/archival-db-connections.template.json secrets/archival-db-connections.json
cp secrets/archival-storage-connections.template.json secrets/archival-storage-connections.json

# Edit files with your connection strings
nano secrets/archival-db-connections.json
nano secrets/archival-storage-connections.json

# Run with local secrets
export ARCHIVAL_METADATA_DB="Server=localhost;Database=archival_meta;..."
dotnet run --project src/Archival.App -- table --all-active --secrets-path ./secrets
```

**Security:** Add `secrets/*.json` to `.gitignore` (templates are checked in, actual secrets are not).

### Azure Key Vault Integration

**Best practice:** Store secrets in Azure Key Vault, mount via CSI driver.

**Alternative:** Use Managed Identity for SQL and Storage (no connection strings needed).

---

## Logging and Monitoring

### Logging Configuration

**Serilog** is used for structured logging.

**Default configuration** (in `Startup.cs`):
```csharp
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss}] [{Level:u3}] {Message:lj}{NewLine}{Exception}")
    .Enrich.FromLogContext()
    .ReadFrom.Configuration(builder.Configuration)
    .CreateLogger();
```

**Log output:**
```
[2026-02-15 02:00:01] [INF] Starting table archival run
[2026-02-15 02:00:02] [INF] Archive run started: RunId=42
[2026-02-15 02:00:03] [INF] Processing 3 table(s)
[2026-02-15 02:00:04] [INF] Processing table: Schema=dbo, Table=Transactions, ConfigId=1
[2026-02-15 02:00:05] [INF] Found 120 distinct dates in table dbo.Transactions
[2026-02-15 02:00:06] [INF] Keep set calculated: 30 dates to retain for table dbo.Transactions
[2026-02-15 02:00:07] [INF] Archive candidates: 90 date(s) for table dbo.Transactions
[2026-02-15 02:00:08] [INF] Archiving: Table=dbo.Transactions, Date=2025-01-15
[2026-02-15 02:01:45] [INF] Successfully archived: Table=dbo.Transactions, Date=2025-01-15, Rows=12500, Bytes=2457600
...
[2026-02-15 02:30:22] [INF] Archive run completed: RunId=42, Status=Succeeded, Success=90, Failed=False
```

**Kubernetes log collection:**
```bash
# View CronJob logs
kubectl logs -n data-ops job/archival-table-28476800 -f

# View last run logs
kubectl logs -n data-ops -l job-name --tail=100

# Stream logs to Azure Log Analytics or similar
# (configure via Azure Monitor agent or Fluent Bit)
```

### Monitoring Metrics

**Key metrics to monitor:**

1. **Run Success Rate**
   ```sql
   SELECT
     CAST(started_at AS DATE) AS run_date,
     run_type,
     COUNT(*) AS total_runs,
     SUM(CASE WHEN status = 'Succeeded' THEN 1 ELSE 0 END) AS succeeded,
     SUM(CASE WHEN status = 'Failed' THEN 1 ELSE 0 END) AS failed,
     SUM(CASE WHEN status = 'PartiallySucceeded' THEN 1 ELSE 0 END) AS partial
   FROM archival_run
   WHERE started_at >= DATEADD(DAY, -7, GETUTCDATE())
   GROUP BY CAST(started_at AS DATE), run_type
   ORDER BY run_date DESC, run_type;
   ```

2. **Failed Run Items**
   ```sql
   SELECT TOP 20
     r.id AS run_id,
     r.run_type,
     r.started_at,
     ri.item_key,
     ri.error_message
   FROM archival_run_item ri
   JOIN archival_run r ON ri.run_id = r.id
   WHERE ri.status = 'Failed'
     AND ri.created_at >= DATEADD(DAY, -7, GETUTCDATE())
   ORDER BY ri.created_at DESC;
   ```

3. **Run Duration**
   ```sql
   SELECT
     run_type,
     AVG(DATEDIFF(SECOND, started_at, ended_at)) / 60.0 AS avg_duration_minutes,
     MAX(DATEDIFF(SECOND, started_at, ended_at)) / 60.0 AS max_duration_minutes
   FROM archival_run
   WHERE ended_at IS NOT NULL
     AND started_at >= DATEADD(DAY, -30, GETUTCDATE())
   GROUP BY run_type;
   ```

4. **Storage Growth**
   ```sql
   SELECT
     tc.schema_name + '.' + tc.table_name AS table_name,
     COUNT(*) AS dataset_count,
     SUM(d.row_count) AS total_rows,
     SUM(d.total_bytes) / 1024 / 1024 / 1024.0 AS total_gb
   FROM archival_dataset d
   JOIN archival_table_configuration tc ON d.table_configuration_id = tc.id
   WHERE d.status = 'Succeeded'
   GROUP BY tc.schema_name, tc.table_name
   ORDER BY total_gb DESC;
   ```

### Alerting Recommendations

**Azure Monitor Alerts:**
1. **Failed Runs** - Alert when `status='Failed'`
2. **Long-Running Runs** - Alert when run duration > 2 hours
3. **Orphaned Runs** - Alert when run in 'Running' state for > 3 hours
4. **Disk Space** - Alert when metadata DB size > 80% capacity

---

## Troubleshooting

### Common Issues

#### Issue 1: Run Fails with "ARCHIVAL_METADATA_DB env var required"

**Cause:** Environment variable not set.

**Solution:**
```bash
# Check if variable is set
echo $ARCHIVAL_METADATA_DB

# Set variable (Linux/Mac)
export ARCHIVAL_METADATA_DB="Server=...;Database=archival_meta;..."

# Set variable (Kubernetes)
# Add to pod spec:
env:
- name: ARCHIVAL_METADATA_DB
  valueFrom:
    secretKeyRef:
      name: archival-secrets
      key: metadata-connection-string
```

#### Issue 2: "Required secret file not found"

**Cause:** Secret files not mounted or wrong path.

**Solution:**
```bash
# Check if files exist
ls -la /secrets/

# Expected files:
# /secrets/archival-db-connections.json
# /secrets/archival-storage-connections.json

# If using CSI, check SecretProviderClass is correctly configured
kubectl describe secretproviderclass archival-secrets-provider -n data-ops

# Check pod has secrets mounted
kubectl describe pod <pod-name> -n data-ops
```

#### Issue 3: "Connection string not found for database: SourceDB1"

**Cause:** Database name in configuration doesn't match key in secrets file.

**Solution:**
```sql
-- Check database name in config
SELECT database_name FROM archival_table_configuration WHERE id = 1;

-- Verify key exists in secrets file
cat /secrets/archival-db-connections.json | jq '.keys'

-- Keys are case-insensitive but must match exactly
```

#### Issue 4: Run Stuck in 'Running' Status

**Cause:** Process killed before run could complete (SIGKILL, node failure).

**Solution:**
```sql
-- Manually complete the run
UPDATE archival_run
SET status = 'Failed',
    ended_at = GETUTCDATE(),
    note = 'Manually marked as failed - process interrupted'
WHERE id = <run_id> AND status = 'Running';
```

#### Issue 5: "View 'dbo.v_business_date_classification' does not exist"

**Cause:** Source database missing required business calendar view.

**Solution:**
1. Create `dbo.business_date` table (70-year calendar)
2. Create `dbo.v_business_date_classification` view
3. See source system documentation for view definition

#### Issue 6: Export Fails with "Out of Memory"

**Cause:** Table has extremely large rows (blob columns, large varchars).

**Solution:**
1. **Short-term:** Increase pod memory limit
2. **Long-term:** Reduce batch size (requires code change - currently hardcoded at 10,000)

```yaml
resources:
  requests:
    memory: "2Gi"
    cpu: "1000m"
  limits:
    memory: "4Gi"
    cpu: "2000m"
```

#### Issue 7: Blob Lifecycle Takes Hours

**Cause:** Too many blobs under prefix (Azure list API pagination).

**Solution:**
1. Split blob configurations into smaller prefixes
2. Run lifecycle more frequently (reduce per-run scope)
3. Consider Azure Blob lifecycle management policies as alternative

---

## Performance Considerations

### Table Archival Performance

**Factors affecting speed:**
1. **Table size** - Larger tables take longer to query
2. **Network speed** - Slow upload to blob storage
3. **SQL Server load** - Queries compete with production workload
4. **Delete batch size** - Smaller batches = more round trips

**Optimization tips:**
```sql
-- Add index on business date column (improves query performance)
CREATE INDEX ix_transactions_trade_date ON dbo.Transactions(trade_date);

-- Use read-only replica for archival queries (reduce prod impact)
-- Configure connection string with ApplicationIntent=ReadOnly
```

**Expected performance:**
- 10,000 rows: ~30 seconds (query + export + upload)
- 100,000 rows: ~5 minutes
- 1,000,000 rows: ~30 minutes

### Blob Lifecycle Performance

**Factors affecting speed:**
1. **Blob count** - More blobs = longer listing time
2. **Azure API rate limits** - Tier operations throttled
3. **Blob tier** - Archive tier has slower operations

**Optimization tips:**
- Limit scope: Process one date folder at a time (requires code change)
- Use smaller prefixes: Split large containers into multiple configs
- Consider Azure native lifecycle policies for predictable patterns

**Expected performance:**
- 1,000 blobs: ~5 minutes
- 10,000 blobs: ~30 minutes
- 100,000 blobs: ~3 hours

### Concurrent Execution

**⚠️ Warning:** Do NOT run multiple instances concurrently.

**Why:**
- Duplicate exports (idempotency check has race condition)
- Duplicate run items
- Resource contention (SQL, blob storage)

**Kubernetes setting:**
```yaml
concurrencyPolicy: Forbid  # Critical setting
```

---

## Disaster Recovery

### Metadata Database Backup

**Critical:** Metadata DB contains audit trail and prevents duplicate exports.

**Backup strategy:**
```sql
-- Azure SQL: Automated backups (7-35 days retention)
-- Point-in-time restore available

-- Manual backup
BACKUP DATABASE archival_meta
TO DISK = 'C:\Backups\archival_meta_20260215.bak'
WITH COMPRESSION, CHECKSUM;
```

### Recovering from Failed Run

**Scenario:** Run failed due to transient error, need to retry.

**Steps:**
1. Investigate failure:
   ```sql
   SELECT * FROM archival_run WHERE id = <run_id>;
   SELECT * FROM archival_run_item WHERE run_id = <run_id> AND status = 'Failed';
   ```

2. If safe to retry, manually mark failed datasets:
   ```sql
   -- Delete failed dataset records (allows retry)
   DELETE FROM archival_dataset WHERE status = 'Failed' AND id IN (...);
   ```

3. Re-run command (will skip already-exported dates)

### Recovering Orphaned Datasets

**Scenario:** Dataset left in 'Pending' status after crash.

**Investigation:**
```sql
SELECT * FROM archival_dataset WHERE status = 'Pending';
```

**Recovery:**
```sql
-- Option 1: Mark as failed (requires manual cleanup)
UPDATE archival_dataset SET status = 'Failed', error_summary = 'Orphaned - process interrupted', completed_at = GETUTCDATE()
WHERE status = 'Pending' AND created_at < DATEADD(HOUR, -3, GETUTCDATE());

-- Option 2: Delete record (will retry export)
DELETE FROM archival_dataset WHERE status = 'Pending' AND created_at < DATEADD(HOUR, -3, GETUTCDATE());
```

---

## Next Steps

- **[Security](security.md)** - Secrets management and permissions
- **[Review Findings](review_findings.md)** - Known issues and recommendations

