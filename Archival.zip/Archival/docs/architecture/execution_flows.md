﻿# Execution Flows

This document traces the complete execution paths for both table archival and blob lifecycle commands, from CLI entry to external system interactions.

## Table of Contents
- [Table Archival Flow](#table-archival-flow)
- [Blob Lifecycle Flow](#blob-lifecycle-flow)
- [Run Management Flow](#run-management-flow)
- [Error Handling Patterns](#error-handling-patterns)

---

## Table Archival Flow

### Command: `archival table --all-active`

This flow archives SQL table data to Parquet files for all active table configurations.

#### Flow Diagram

```
CLI Input
   ↓
Program.cs (cancellation setup)
   ↓
CliParser.ParseArgs() → ParsedArgs
   ↓
Startup.BuildHost() → DI Container
   ↓
TableCommandHandler.ExecuteAsync()
   ↓
RunTableArchivalHandler.HandleAsync()
   ├─→ StartRunHandler (create run record)
   │
   ├─→ For each active table config:
   │   ├─→ ITableArchiver.GetPresentDatesAsync() [finds dates in source table]
   │   ├─→ IRetentionCalculator.CalculateKeepDatesAsync() [retention policy]
   │   ├─→ IExemptionsStore.GetTableExemptionsAsync() [skip dates]
   │   ├─→ Calculate candidates = present - keep - exemptions - archived
   │   │
   │   └─→ For each candidate date:
   │       ├─→ IDatasetStore.DatasetExistsAsync() [idempotency check]
   │       ├─→ ExecuteTableArchivalHandler.HandleAsync()
   │       │   ├─→ BuildTableArchivalPlanHandler [get config]
   │       │   ├─→ IDatasetStore.CreateDatasetAsync() [mark as Pending]
   │       │   ├─→ ITableArchiver.ExportToParquetAsync()
   │       │   │   ├─→ SqlServerArchivalExporter
   │       │   │   │   ├─→ Query source table by date range
   │       │   │   │   ├─→ ParquetSchemaBuilder (build schema)
   │       │   │   │   ├─→ ParquetPartWriter (write parts)
   │       │   │   │   └─→ Upload parts to blob storage
   │       │   │   └─→ Return ExportResult (row count, bytes)
   │       │   ├─→ IDatasetStore.MarkDatasetSucceededAsync()
   │       │   ├─→ If delete_after_export:
   │       │   │   └─→ ITableArchiver.DeleteRowsAsync()
   │       │   │       └─→ SqlServerSourceDeleter (batched deletes)
   │       │   └─→ Return ExecuteTableArchivalResponse
   │       │
   │       └─→ IRunItemsStore.AddRunItemAsync() [record result]
   │
   └─→ CompleteRunHandler (mark run as Succeeded/Failed/PartiallySucceeded)
```

#### Detailed Step-by-Step

**Phase 1: Initialization**

1. **Program.cs** - Entry point
   ```csharp
   - Sets up CancellationTokenSource
   - Registers Ctrl+C and SIGTERM handlers
   - Calls CliParser.ParseArgs(args)
   ```

2. **CliParser** - Parse command line
   ```csharp
   Input: ["table", "--all-active", "--secrets-path", "./secrets"]
   Output: ParsedArgs { Command = Commands.Table, AllActive = true, SecretsPath = "./secrets" }
   ```

3. **Startup.BuildHost()** - DI container setup
   ```csharp
   - Reads ARCHIVAL_METADATA_DB env var
   - Registers services from Data, Infrastructure, Application layers
   - Returns IHost with all dependencies configured
   ```

4. **TableCommandHandler.ExecuteAsync()**
   ```csharp
   - Validates args (requires --all-active OR --table-config-id)
   - Resolves RunTableArchivalHandler from DI
   - Invokes handler with cancellation token
   ```

**Phase 2: Run Start**

5. **RunTableArchivalHandler** - Main orchestrator
   ```csharp
   Variables:
   - runId = -1L (will be set after StartRun)
   - anyFailed = false
   - successCount = 0
   
   Try-catch wrapper ensures run is always completed (even on failure)
   ```

6. **StartRunHandler.HandleAsync()**
   ```csharp
   Input: RunType.Archive
   SQL: INSERT INTO archival_run (run_type, started_at, status, note)
        VALUES ('Archive', GETUTCDATE(), 'Running', NULL)
   Output: RunId (e.g., 42)
   
   File: Archival.Application/Features/Runs/StartRun/StartRunHandler.cs
   ```

**Phase 3: Table Discovery**

7. **Get Table Configurations**
   ```csharp
   If --all-active:
     tables = tableConfigStore.GetActiveTableConfigurationsAsync()
     → Queries: SELECT * FROM archival_table_configuration WHERE is_active = 1
   
   If --table-config-id <id>:
     tables = [tableConfigStore.GetTableConfigurationAsync(id)]
   
   File: Archival.Data/Stores/TableConfigurationStore.cs
   ```

**Phase 4: Process Each Table**

For each table configuration:

8. **Resolve Source Connection**
   ```csharp
   sourceConn = connectionResolver.ResolveSourceConnection(table.DatabaseName)
   
   Loads: secrets/archival-db-connections.json
   Looks up: table.DatabaseName (e.g., "SourceDB1")
   Returns: "Server=...;Database=SourceDB1;..."
   
   File: Archival.Infrastructure/Secrets/ConnectionStringResolver.cs
   ```

9. **Find Present Dates in Table**
   ```csharp
   presentDates = tableArchiver.GetPresentDatesAsync(
     sourceConn,
     table.SchemaName,
     table.TableName,
     table.BusinessDateColumnName,
     from: DateTime.UtcNow.AddYears(-10),
     to: DateTime.UtcNow.AddDays(1),
     ct
   )
   
   SQL: SELECT DISTINCT CAST([as_of_date_column] AS date) AS as_of_date
        FROM [schema].[table] t
        JOIN dbo.business_date bd
          ON CAST(t.[as_of_date_column] AS date) = CAST(bd.current_business_date AS date)
        WHERE t.[as_of_date_column] >= @from AND t.[as_of_date_column] < @to
        ORDER BY as_of_date
   
   Returns: List of DateOnly (e.g., [2025-01-15, 2025-01-16, ...])
   
   File: Archival.Infrastructure/SqlServer/SqlServerPresentDateFinder.cs
   ```

10. **Calculate Retention Policy (Keep Set)**
    ```csharp
    keepSet = retentionCalculator.CalculateKeepDatesAsync(table.Id, presentDates, ct)
    
    SQL: Complex query using CTEs:
    - Loads retention policy (keep_last_eod, keep_last_eom, keep_last_eoq, keep_last_eoy)
    - Joins dbo.v_business_date_classification to get date types
    - Selects TOP N dates for each type (EOD/EOM/EOQ/EOY)
    - UNIONs all keep dates with table exemptions
    
    Returns: HashSet<DateOnly> of dates to KEEP in source table
    
    File: Archival.Infrastructure/Retention/RetentionService.cs
    ```

11. **Get Exemptions**
    ```csharp
    exemptions = exemptionsStore.GetTableExemptionsAsync(table.Id, ct)
    
    SQL: SELECT table_configuration_id, as_of_date
         FROM archival_table_exemption
         WHERE table_configuration_id = @tableConfigId
    
    Returns: Set of (TableConfigurationId, AsOfDate)
    
    File: Archival.Data/Stores/ExemptionsStore.cs
    ```

12. **Calculate Archive Candidates**
    ```csharp
    candidates = presentDates
      .Where(d => !keepSet.Contains(d))           // Not in retention policy
      .Where(d => !exemptions.Any(e => e.AsOfDate == d))  // Not exempted
      .ToList()
    
    Logic: Archive = Present - Keep - Exemptions
    ```

**Phase 5: Archive Each Candidate Date**

For each candidate date:

13. **Check Idempotency**
    ```csharp
    if (await datasetStore.DatasetExistsAsync(table.Id, businessDate, ct))
      skip (already archived)
    
    SQL: SELECT 1 FROM archival_dataset
         WHERE table_configuration_id = @tableConfigId
           AND as_of_date = @asOfDate
    
    File: Archival.Data/Stores/DatasetStore.cs
    ```

14. **Execute Table Archival**
    ```csharp
    archiveResult = executeTableArchivalHandler.HandleAsync(
      new ExecuteTableArchivalCommand(table.Id, businessDate), ct
    )
    
    File: Archival.Application/Features/TableArchival/ExecuteTableArchival/ExecuteTableArchivalHandler.cs
    ```

15. **Build Archival Plan**
    ```csharp
    plan = buildPlanHandler.HandleAsync(new BuildTableArchivalPlanQuery(table.Id), ct)
    
    Loads: Table configuration from metadata DB
    Returns: TableArchivalPlan with:
      - SchemaName, TableName, BusinessDateColumnName
      - StorageAccountName, ContainerName
      - BaseBlobPrefix (from archive_path_template)
      - DeleteAfterExport, BatchDeleteSize
    
    File: Archival.Application/Features/TableArchival/BuildTableArchivalPlan/BuildTableArchivalPlanHandler.cs
    ```

16. **Create Dataset Record (Pending)**
    ```csharp
    datasetId = datasetStore.CreateDatasetAsync(
      tableConfigId,
      businessDate,
      DateType.EOD,
      storageAccountName,
      containerName,
      blobPrefix,
      ct
    )
    
    SQL: INSERT INTO archival_dataset
         (table_configuration_id, as_of_date, date_type, storage_account_name,
          container_name, blob_prefix, part_count, status, created_at)
         VALUES (@tableConfigId, @asOfDate, 'EOD', @storageAccount, @container,
                 @blobPrefix, 0, 'Pending', GETUTCDATE())
    
    Returns: Dataset ID (e.g., 1001)
    
    File: Archival.Data/Stores/DatasetStore.cs
    ```

17. **Export to Parquet**
    ```csharp
    exportResult = tableArchiver.ExportToParquetAsync(
      sourceConn,
      schemaName,
      tableName,
      businessDateColumn,
      businessDate,
      storageConn,
      containerName,
      blobPrefix,
      ct
    )
    
    Steps:
    a) SqlServerArchivalExporter.ExportByBusinessDateRangeAsync()
       - Builds date range (businessDate to businessDate + 1 day)
       - Queries source table schema
       - ParquetSchemaBuilder builds Parquet schema
       - Reads data in batches (10,000 rows)
       - ParquetPartWriter writes multi-part Parquet files
       - Uploads to blob storage (part-0000.parquet, part-0001.parquet, ...)
    
    Returns: ExportResult { PartCount, RowCount, TotalBytes }
    
    File: Archival.Infrastructure/SqlServer/SqlServerArchivalExporter.cs
    ```

18. **Mark Dataset Succeeded**
    ```csharp
    datasetStore.MarkDatasetSucceededAsync(datasetId, partCount, rowCount, totalBytes, ct)
    
    SQL: UPDATE archival_dataset
         SET status = 'Succeeded',
             part_count = @partCount,
             row_count = @rowCount,
             total_bytes = @totalBytes,
             completed_at = GETUTCDATE()
         WHERE id = @datasetId
    
    File: Archival.Data/Stores/DatasetStore.cs
    ```

19. **Optional: Delete Rows from Source**
    ```csharp
    if (plan.DeleteAfterExport) {
      deleteResult = tableArchiver.DeleteRowsAsync(
        sourceConn,
        schemaName,
        tableName,
        businessDateColumn,
        businessDate,
        batchSize,
        ct
      )
      
      Steps:
      - SqlServerSourceDeleter.DeleteByBusinessDateRangeAsync()
      - Deletes in batches: DELETE TOP (@batchSize) FROM [schema].[table]
                            WHERE [businessDateColumn] >= @start
                              AND [businessDateColumn] < @end
      - Repeats until no more rows deleted
      
      Returns: Result<long> (total rows deleted)
      
      File: Archival.Infrastructure/SqlServer/SqlServerSourceDeleter.cs
    }
    ```

20. **Record Run Item**
    ```csharp
    runItemsStore.AddRunItemAsync(
      runId,
      RunItemType.Dataset,
      itemStatus: Succeeded or Failed,
      tableConfigurationId: table.Id,
      asOfDate: businessDate,
      rowsAffected: archiveResult.Value?.RowsArchived,
      bytesAffected: archiveResult.Value?.BytesArchived,
      error: null or errorMessage,
      ct
    )
    
    SQL: INSERT INTO archival_run_item
         (run_id, item_type, item_key, action, status, rows_affected,
          bytes_affected, error_message, created_at)
         VALUES (@runId, 'Dataset', '<table>:<date>', 'Archive', @status,
                 @rowsAffected, @bytesAffected, @error, GETUTCDATE())
    
    File: Archival.Data/Stores/RunItemsStore.cs
    ```

**Phase 6: Run Completion**

21. **Complete Run**
    ```csharp
    finalStatus = anyFailed ? (successCount > 0 ? PartiallySucceeded : Failed) : Succeeded
    
    completeRunHandler.HandleAsync(
      new CompleteRunCommand(runId, finalStatus, note), ct
    )
    
    SQL: UPDATE archival_run
         SET status = @status,
             ended_at = GETUTCDATE(),
             note = @note
         WHERE id = @runId
    
    File: Archival.Application/Features/Runs/CompleteRun/CompleteRunHandler.cs
    ```

**Phase 7: Return to CLI**

22. **Exit Code**
    ```csharp
    return result.Ok ? ExitCode.Success : ExitCode.RuntimeError
    
    ExitCode.Success = 0
    ExitCode.RuntimeError = 1
    ```

---

## Blob Lifecycle Flow

### Command: `archival blob --all-targets`

This flow manages blob storage lifecycle operations (tiering and deletion) for all enabled blob configurations.

#### Flow Diagram

```
CLI Input
   ↓
Program.cs (cancellation setup)
   ↓
CliParser.ParseArgs() → ParsedArgs
   ↓
Startup.BuildHost() → DI Container
   ↓
BlobCommandHandler.ExecuteAsync()
   ↓
RunBlobLifecycleHandler.HandleAsync()
   ├─→ StartRunHandler (create run record)
   │
   ├─→ For each enabled blob config:
   │   ├─→ ExecuteBlobLifecycleHandler.HandleAsync()
   │   │   ├─→ IBlobConfigurationStore.GetBlobConfigurationAsync()
   │   │   ├─→ IBlobPolicyStore.GetLifecyclePolicyAsync()
   │   │   ├─→ IBlobInventory.ListBlobsAsync() [list blobs under prefix]
   │   │   │
   │   │   └─→ For each blob:
   │   │       ├─→ Extract date from blob name or use CreatedAt
   │   │       ├─→ Calculate age in days
   │   │       ├─→ Determine action (Skip/Cold/Archive/Delete) based on policy
   │   │       ├─→ IBlobLifecycleExecutor.TrySetColdAsync() or
   │   │       │   IBlobLifecycleExecutor.TrySetArchiveAsync() or
   │   │       │   IBlobLifecycleExecutor.TryDeleteAsync()
   │   │       └─→ Count successful actions
   │   │
   │   └─→ IRunItemsStore.AddRunItemAsync() [record result]
   │
   └─→ CompleteRunHandler (mark run as Succeeded/Failed/PartiallySucceeded)
```

#### Detailed Step-by-Step

**Phase 1-4: Same as Table Archival** (Program.cs → CLI parsing → DI → BlobCommandHandler)

**Phase 5: Run Start**

5. **RunBlobLifecycleHandler** - Main orchestrator
   ```csharp
   Variables:
   - runId = -1L
   - anyFailed = false
   - totalScanned, totalCold, totalArchive, totalDelete = 0
   
   File: Archival.Application/Features/BlobLifecycle/RunBlobLifecycle/RunBlobLifecycleHandler.cs
   ```

6. **StartRunHandler.HandleAsync()**
   ```csharp
   Input: RunType.Lifecycle
   SQL: INSERT INTO archival_run (run_type, started_at, status)
        VALUES ('Lifecycle', GETUTCDATE(), 'Running')
   ```

**Phase 6: Blob Configuration Discovery**

7. **Get Blob Configurations**
   ```csharp
   If --all-targets:
     configs = blobConfigStore.GetEnabledBlobConfigurationsAsync()
     → SQL: SELECT * FROM archival_blob_configuration WHERE is_enabled = 1
   
   If --target-id <id>:
     configs = [blobConfigStore.GetBlobConfigurationAsync(id)]
   
   Returns: List of BlobConfigurationDto
   
   File: Archival.Data/Stores/BlobConfigurationStore.cs
   ```

**Phase 7: Process Each Blob Configuration**

For each blob configuration:

8. **Execute Blob Lifecycle**
   ```csharp
   lifecycleResult = executeBlobLifecycleHandler.HandleAsync(
     new ExecuteBlobLifecycleCommand(config.Id, DateOnly.FromDateTime(DateTime.UtcNow)),
     ct
   )
   
   File: Archival.Application/Features/BlobLifecycle/ExecuteBlobLifecycle/ExecuteBlobLifecycleHandler.cs
   ```

9. **Load Configuration and Policy**
   ```csharp
   config = blobConfigStore.GetBlobConfigurationAsync(configId, ct)
   policy = blobPolicyStore.GetLifecyclePolicyAsync(config.BlobPolicyId, ct)
   
   Validate: policy.IsActive must be true
   
   Configuration includes:
   - StorageAccountName, ContainerName, Prefix
   - SupportsArchiveTier (bool)
   - IncludePattern, ExcludePattern (regex, optional)
   
   Policy includes:
   - ColdMinAgeDays (nullable int)
   - ArchiveMinAgeDays (nullable int)
   - DeleteMinAgeDays (nullable int)
   ```

10. **Resolve Storage Connection**
    ```csharp
    storageConn = connectionResolver.ResolveStorageConnection(config.StorageAccountName)
    
    Loads: secrets/archival-storage-connections.json
    Looks up: config.StorageAccountName (e.g., "storageaccount1")
    Returns: "DefaultEndpointsProtocol=https;AccountName=storageaccount1;..."
    
    File: Archival.Infrastructure/Secrets/ConnectionStringResolver.cs
    ```

11. **List Blobs Under Prefix**
    ```csharp
    blobs = blobInventory.ListBlobsAsync(storageConn, config.ContainerName, config.Prefix, ct)
    
    Azure SDK call:
    - Creates BlobContainerClient
    - Calls GetBlobsAsync(prefix: config.Prefix)
    - Filters by IncludePattern/ExcludePattern if configured
    
    Returns: List of BlobItem { Name, ContentLength, CreatedAtUtc, LastModifiedUtc, AccessTier }
    
    File: Archival.Infrastructure/BlobStorage/AzureBlobInventory.cs
    ```

**Phase 8: Process Each Blob**

For each blob:

12. **Determine Blob Date and Age**
    ```csharp
    // Try to extract date from blob name (e.g., "archive/2025/01/15/data.parquet")
    if (blobInventory.TryExtractDateFromPathSegment(blob.Name, config.Prefix, out blobDate)) {
      // Use extracted date
    } else {
      // Fallback to blob creation date
      blobDate = DateOnly.FromDateTime(blob.CreatedAtUtc)
    }
    
    ageDays = (int)(clock.Today.DayNumber - blobDate.DayNumber)
    
    File: Archival.Infrastructure/BlobStorage/AzureBlobInventory.cs
         Uses: Archival.Infrastructure/AzureBlob/BlobBusinessDateExtractor.cs
    ```

13. **Determine Lifecycle Action**
    ```csharp
    Logic (priority order):
    
    if (policy.DeleteMinAgeDays.HasValue && ageDays >= policy.DeleteMinAgeDays) {
      action = LifecycleAction.Delete
    }
    else if (policy.ArchiveMinAgeDays.HasValue && ageDays >= policy.ArchiveMinAgeDays) {
      if (config.SupportsArchiveTier) {
        action = LifecycleAction.SetArchive
      } else {
        action = LifecycleAction.SetCold  // Fallback if Archive not supported
      }
    }
    else if (policy.ColdMinAgeDays.HasValue && ageDays >= policy.ColdMinAgeDays) {
      action = LifecycleAction.SetCold
    }
    else {
      action = LifecycleAction.Skip
    }
    
    Example:
    - Policy: ColdMinAgeDays=30, ArchiveMinAgeDays=90, DeleteMinAgeDays=365
    - Blob age=45 days → SetCold
    - Blob age=120 days → SetArchive (or SetCold if not supported)
    - Blob age=400 days → Delete
    ```

14. **Execute Lifecycle Action**
    ```csharp
    success = action switch {
      LifecycleAction.SetCold => 
        blobLifecycleExecutor.TrySetColdAsync(storageConn, containerName, blobName, ct),
      
      LifecycleAction.SetArchive => 
        blobLifecycleExecutor.TrySetArchiveAsync(storageConn, containerName, blobName, ct),
      
      LifecycleAction.Delete => 
        blobLifecycleExecutor.TryDeleteAsync(storageConn, containerName, blobName, ct),
      
      _ => true  // Skip action
    }
    
    Azure SDK operations:
    - SetCold: BlobClient.SetAccessTierAsync(AccessTier.Cool)
    - SetArchive: BlobClient.SetAccessTierAsync(AccessTier.Archive)
    - Delete: BlobClient.DeleteAsync()
    
    Returns: bool (success/failure)
    
    File: Archival.Infrastructure/BlobStorage/AzureBlobLifecycleExecutor.cs
    ```

15. **Count Actions**
    ```csharp
    if (success) {
      switch (action) {
        case LifecycleAction.SetCold: coldCount++; break;
        case LifecycleAction.SetArchive: archiveCount++; break;
        case LifecycleAction.Delete: deleteCount++; break;
      }
    }
    ```

**Phase 9: Record Results**

16. **Record Run Item**
    ```csharp
    runItemsStore.AddRunItemAsync(
      runId,
      RunItemType.Prefix,
      itemStatus: Succeeded or Failed,
      blobConfigurationId: config.Id,
      error: null or errorMessage,
      ct
    )
    
    SQL: INSERT INTO archival_run_item
         (run_id, item_type, item_key, action, status, error_message, created_at)
         VALUES (@runId, 'Prefix', '<container>/<prefix>', 'Lifecycle', @status,
                 @error, GETUTCDATE())
    
    File: Archival.Data/Stores/RunItemsStore.cs
    ```

**Phase 10: Run Completion**

17. **Complete Run**
    ```csharp
    finalStatus = anyFailed ? (totalScanned > 0 ? PartiallySucceeded : Failed) : Succeeded
    
    note = $"Scanned {totalScanned} blobs: {totalCold} cold, {totalArchive} archive, {totalDelete} deleted"
    
    completeRunHandler.HandleAsync(new CompleteRunCommand(runId, finalStatus, note), ct)
    
    SQL: UPDATE archival_run
         SET status = @status, ended_at = GETUTCDATE(), note = @note
         WHERE id = @runId
    ```

---

## Run Management Flow

### Start Run

```csharp
StartRunHandler.HandleAsync(new StartRunCommand(RunType.Archive))

SQL:
  INSERT INTO archival_run (run_type, started_at, status, note)
  VALUES (@runType, GETUTCDATE(), 'Running', NULL)
  
  SELECT CAST(SCOPE_IDENTITY() AS BIGINT)

Returns: StartRunResponse { RunId }

Status Transition: (none) → Running
```

### Complete Run

```csharp
CompleteRunHandler.HandleAsync(new CompleteRunCommand(runId, RunStatus.Succeeded, note))

SQL:
  UPDATE archival_run
  SET status = @status,
      ended_at = GETUTCDATE(),
      note = @note
  WHERE id = @runId

Status Transition: Running → Succeeded/Failed/PartiallySucceeded
```

### Record Run Item

```csharp
RunItemsStore.AddRunItemAsync(
  runId,
  itemType: RunItemType.Dataset or RunItemType.Prefix,
  status: RunItemStatus.Succeeded/Failed/Skipped,
  tableConfigurationId: (for Dataset items),
  blobConfigurationId: (for Prefix items),
  asOfDate: (optional),
  rowsAffected: (optional),
  bytesAffected: (optional),
  error: (optional),
  ct
)

SQL:
  INSERT INTO archival_run_item
  (run_id, item_type, item_key, action, status, rows_affected,
   bytes_affected, error_message, created_at)
  VALUES (@runId, @itemType, @itemKey, @action, @status,
          @rowsAffected, @bytesAffected, @error, GETUTCDATE())
```

---

## Error Handling Patterns

### Try-Finally Pattern for Run Completion

Both orchestration handlers use try-finally to ensure run completion:

```csharp
var runId = -1L;
try {
  // Start run
  runId = await startRunHandler.HandleAsync(...);
  
  // Process items
  foreach (var item in items) {
    try {
      // Process item
    } catch (Exception ex) {
      // Log error, mark item as failed
      anyFailed = true;
    }
  }
  
  // Complete run (success or partial)
  var status = anyFailed ? PartiallySucceeded : Succeeded;
  await completeRunHandler.HandleAsync(runId, status, ...);
}
catch (Exception ex) {
  // Complete run (failed)
  if (runId > 0) {
    try {
      await completeRunHandler.HandleAsync(runId, RunStatus.Failed, ex.Message);
    } catch {
      // Log but don't throw (best effort)
    }
  }
  return Result.Fail(...);
}
```

**Guarantees:**
- ✅ Run is always completed (never left in 'Running' state)
- ✅ Individual item failures don't stop processing other items
- ✅ Partial success is recorded (some succeeded, some failed)

### Cancellation Token Propagation

Cancellation tokens flow from top to bottom:

```
Program.cs CancellationTokenSource
   ↓ (passed to)
Handler.HandleAsync(command, ct)
   ↓ (passed to)
Store/Repository methods (..., ct)
   ↓ (passed to)
SQL/Azure SDK operations (..., ct)
```

**Behavior on cancellation:**
- Operation stops at next async await point
- Throws OperationCanceledException
- Caught by Program.cs, logs "Canceled", returns exit code 1
- Run may be left in 'Running' state (limitation)

### Idempotency Checks

**Table Archival:**
```csharp
if (await datasetStore.DatasetExistsAsync(tableConfigId, asOfDate, ct)) {
  skip (already archived)
}
```

**Result:** Safe to re-run; won't duplicate exports.

**Blob Lifecycle:**
- No explicit idempotency check
- Azure SDK tier operations are idempotent (setting same tier is no-op)
- Delete is idempotent (deleting non-existent blob returns success)

---

## Performance Characteristics

### Table Archival

**Time per date:**
- Query time: depends on table size and date range selectivity
- Export time: depends on row count (10,000 rows per batch)
- Upload time: depends on part size and network
- Delete time: depends on batch size and row count

**Typical:** 1-5 minutes per date for tables with 10,000-1,000,000 rows.

**Bottlenecks:**
- Large tables: slow SQL queries
- Network: slow uploads to blob storage
- Delete: slow batched deletes

### Blob Lifecycle

**Time per config:**
- List time: depends on blob count under prefix (Azure API pagination)
- Tier operations: 100-500ms per blob (API call)

**Typical:** 5-30 minutes for 10,000 blobs.

**Bottlenecks:**
- Blob count: listing thousands of blobs is slow
- API rate limits: Azure throttles tier operations

---

## Next Steps

- **[Business Rules](business_rules.md)** - Understand retention, lifecycle, and exemption logic
- **[Data Model](data_model.md)** - Database schema and relationships
- **[Operational Guide](operational_guides.md)** - Production deployment and troubleshooting

