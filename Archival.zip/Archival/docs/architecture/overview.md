﻿# Architecture Overview

## Table of Contents
- [Architecture Style](#architecture-style)
- [Project Boundaries](#project-boundaries)
- [Dependency Direction](#dependency-direction)
- [Major Components](#major-components)
- [Configuration Resolution](#configuration-resolution)

---

## Architecture Style

This system implements **Vertical Slice Architecture (VSA)** with clean separation between Application, Data, and Infrastructure layers.

### Vertical Slice Architecture (VSA)

Each feature is organized as a self-contained "slice" that includes:
- **Command/Query** - Input model
- **Handler** - Business logic orchestration
- **Response** - Output model
- **Contracts** - Interface dependencies (stores, services)

**Benefits:**
- ✅ Features are isolated - changes don't ripple across the codebase
- ✅ Easy to add new features without touching existing code
- ✅ Clear dependencies - handlers declare exactly what they need
- ✅ Testable - mock only the contracts a handler uses

### Example Slice

```
Archival.Application/
└── Features/
    └── TableArchival/
        └── ExecuteTableArchival/
            ├── ExecuteTableArchivalCommand.cs      # Input
            ├── ExecuteTableArchivalHandler.cs      # Logic
            └── ExecuteTableArchivalResponse.cs     # Output
```

---

## Project Boundaries

The solution consists of 4 projects with strict dependency rules:

```
┌─────────────────────────────────────────────────┐
│             Archival.App (CLI)                  │
│  - Program.cs (entry point)                     │
│  - Command handlers (Table, Blob)               │
│  - CLI parsing, startup, DI host                │
└──────────────┬──────────────────────────────────┘
               │ depends on ↓
┌──────────────▼──────────────────────────────────┐
│        Archival.Application                     │
│  - Feature handlers (VSA slices)                │
│  - Contracts (interfaces)                       │
│  - Shared models (DTOs, Results, Enums)         │
└──────┬────────────────────┬─────────────────────┘
       │                    │
       │ depends on ↓       │ depends on ↓
   ┌───▼──────────┐    ┌───▼──────────────────┐
   │ Archival.Data│    │ Archival.Infrastructure│
   │  - EF Core   │    │  - Azure SDK          │
   │  - Stores    │    │  - Parquet            │
   │  - Repos     │    │  - SQL adapters       │
   └──────────────┘    └───────────────────────┘
```

### Archival.App
**Responsibility:** CLI entry point and command orchestration

**Key Files:**
- `Program.cs` - Entry point, cancellation handling (Ctrl+C, SIGTERM)
- `Startup.cs` - DI container setup
- `TableCommandHandler.cs` - Table archival command dispatcher
- `BlobCommandHandler.cs` - Blob lifecycle command dispatcher
- `Cli/CliParser.cs` - Command-line argument parsing

**Dependencies:** → Application, Data, Infrastructure (for DI registration)

### Archival.Application
**Responsibility:** Business logic and feature orchestration

**Key Components:**
- `Features/` - VSA slices organized by feature
  - `TableArchival/` - Table archival handlers
  - `BlobLifecycle/` - Blob lifecycle handlers
  - `Runs/` - Run management (start, complete, record items)
  - `Configurations/` - Configuration queries
- `Contracts/` - Interface definitions
  - `Persistence/` - Store interfaces (ITableConfigurationStore, IDatasetStore, etc.)
  - `Tables/` - Table archival contracts (ITableArchiver)
  - `Storage/` - Blob operations (IBlobInventory, IBlobLifecycleExecutor)
  - `Configuration/` - Connection string resolution
  - `Infrastructure/` - SQL adapters, business calendar
  - `Retention/` - Retention calculation
  - `Time/` - Clock abstraction
- `Shared/` - DTOs, Results, Enums

**Dependencies:** → NONE (only internal references)

**Critical Rule:** Application MUST NOT reference Data or Infrastructure projects directly.

### Archival.Data
**Responsibility:** Metadata database access and EF Core management

**Key Components:**
- `ArchivalDbContext.cs` - EF Core context
- `Entities/` - EF entity models (map to DB tables)
- `Stores/` - Implement Application.Contracts.Persistence interfaces
  - Convert EF entities → DTOs for Application layer
- `Repositories/` - Query EF context, return domain models
  - `ConfigurationRepository` - Query configurations
  - `RunRepository` - Query/insert runs and run items

**Dependencies:** → Application (for Contracts)

### Archival.Infrastructure
**Responsibility:** External system integrations

**Key Components:**
- `AzureBlob/` - Blob storage operations (Azure SDK)
- `BlobStorage/` - Blob inventory and lifecycle execution
- `Parquet/` - Parquet export and path template expansion
- `SqlServer/` - SQL Server adapters
  - `SqlServerArchivalExporter` - Export table data to Parquet
  - `SqlServerSourceDeleter` - Delete rows from source table
  - `SqlServerBusinessCalendar` - Query business date classification
  - `SqlServerPresentDateFinder` - Find dates present in table
- `Retention/` - Retention calculation implementation
- `Secrets/` - Secret file loading (connection string resolution)
- `Tables/` - Table archival orchestration
- `Time/` - SystemClock implementation

**Dependencies:** → Application (for Contracts), Data (for DbContext in RetentionService)

---

## Dependency Direction

The dependency flow follows **Clean Architecture** principles:

```
        ┌─────────────────┐
        │   Archival.App  │
        └────────┬────────┘
                 │
        ┌────────▼────────┐
        │  Application    │ ◄─── Defines Contracts (interfaces)
        └────────┬────────┘
                 │
        ┌────────┴────────┐
        │                 │
   ┌────▼────┐      ┌────▼────────────┐
   │  Data   │      │ Infrastructure  │ ◄─── Implement Contracts
   └─────────┘      └─────────────────┘
```

**Key Rules:**
1. **Application** defines interfaces (Contracts)
2. **Data** and **Infrastructure** implement those interfaces
3. **Application** NEVER imports Data or Infrastructure types directly
4. **App** wires everything together via DI

**Example Flow:**

```csharp
// Application defines:
public interface IDatasetStore {
    Task<long> CreateDatasetAsync(...);
}

// Data implements:
public class DatasetStore : IDatasetStore {
    // EF Core implementation
}

// App registers:
services.AddScoped<IDatasetStore, DatasetStore>();

// Handler uses:
public ExecuteTableArchivalHandler(IDatasetStore datasetStore) {
    // Handler only knows about interface
}
```

---

## Major Components

### 1. Feature Handlers (Application Layer)

**Orchestration Handlers:**
- `RunTableArchivalHandler` - Orchestrates table archival for all/specific tables
- `RunBlobLifecycleHandler` - Orchestrates blob lifecycle for all/specific targets

**Execution Handlers:**
- `ExecuteTableArchivalHandler` - Archives a single table date
- `ExecuteBlobLifecycleHandler` - Processes lifecycle for a single blob config

**Run Management:**
- `StartRunHandler` - Creates a run record, returns run ID
- `CompleteRunHandler` - Marks run as Succeeded/Failed/PartiallySucceeded
- `RecordRunItemHandler` - Records individual operation results

### 2. Stores (Data Layer)

Focused stores implement Application contracts:

| Store | Responsibility | Methods |
|-------|---------------|---------|
| `TableConfigurationStore` | Table configs | GetActiveTableConfigurationsAsync, GetTableConfigurationAsync |
| `TablePolicyStore` | Retention policies | GetTableRetentionPolicyAsync |
| `BlobConfigurationStore` | Blob targets | GetEnabledBlobConfigurationsAsync, GetBlobConfigurationAsync |
| `BlobPolicyStore` | Lifecycle policies | GetLifecyclePolicyAsync |
| `DatasetStore` | Dataset tracking | DatasetExistsAsync, CreateDatasetAsync, MarkDatasetSucceededAsync, MarkDatasetFailedAsync |
| `ExemptionsStore` | Exemptions | GetTableExemptionsAsync, GetBlobExemptionsAsync |
| `RunsStore` | Run tracking | CreateRunAsync, CompleteRunAsync, GetSucceededDatasetsAsync |
| `RunItemsStore` | Run item tracking | AddRunItemAsync |

### 3. Infrastructure Adapters

**Table Archival:**
- `SqlTableArchiver` - Coordinates export and delete
- `SqlServerArchivalExporter` - Exports SQL → Parquet (multi-part)
- `SqlServerSourceDeleter` - Deletes rows in batches

**Blob Lifecycle:**
- `AzureBlobInventory` - Lists blobs, extracts dates from paths
- `AzureBlobLifecycleExecutor` - Sets blob tiers (Cold/Archive), deletes blobs

**Business Logic:**
- `RetentionService` - Calculates keep dates based on policy
- `SqlServerBusinessCalendar` - Queries business date classification
- `SqlServerPresentDateFinder` - Finds dates present in source table

**Parquet:**
- `ParquetSchemaBuilder` - Builds Parquet schema from SQL schema
- `ParquetPartWriter` - Writes Parquet parts (handles batching)
- `ArchivePathTemplateExpander` - Expands path templates (unused in current implementation)

**Secrets:**
- `ConnectionStringResolver` - Loads connection strings from JSON files

---

## Configuration Resolution

### Configuration Sources

The system uses **3 configuration sources**:

1. **Metadata Database** (archival_* tables)
   - Table configurations
   - Blob configurations
   - Retention policies
   - Lifecycle policies
   - Exemptions
   
2. **Environment Variables**
   - `ARCHIVAL_METADATA_DB` - Metadata DB connection (required)
   - `ARCHIVAL_SECRETS_PATH` - Path to secrets directory (default: `/secrets/`)

3. **Secret Files** (JSON format)
   - `archival-db-connections.json` - Source DB connections keyed by database name
   - `archival-storage-connections.json` - Storage connections keyed by account name

### Configuration Flow

```
┌─────────────────────────────────────────────────┐
│  1. Startup reads ARCHIVAL_METADATA_DB          │
│     Creates ArchivalDbContext                   │
└──────────────────┬──────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────┐
│  2. Handler queries metadata DB via Stores      │
│     Gets table/blob configurations              │
└──────────────────┬──────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────┐
│  3. ConnectionStringResolver loads secrets      │
│     Reads JSON files from secrets directory     │
└──────────────────┬──────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────┐
│  4. Handler uses resolved connections           │
│     Connects to source DB or storage account    │
└─────────────────────────────────────────────────┘
```

### Secret File Format

**archival-db-connections.json:**
```json
{
  "SourceDB1": "Server=...;Database=SourceDB1;...",
  "SourceDB2": "Server=...;Database=SourceDB2;...",
  "AnotherDB": "Server=...;Database=AnotherDB;..."
}
```

**archival-storage-connections.json:**
```json
{
  "storageaccount1": "DefaultEndpointsProtocol=https;AccountName=storageaccount1;AccountKey=...;EndpointSuffix=core.windows.net",
  "storageaccount2": "DefaultEndpointsProtocol=https;AccountName=storageaccount2;AccountKey=...;EndpointSuffix=core.windows.net"
}
```

### Connection Resolution Example

```csharp
// Table config has database_name = "SourceDB1"
var config = await tableConfigStore.GetTableConfigurationAsync(id, ct);

// Resolve connection string from secrets file
var connString = connectionResolver.ResolveSourceConnection(config.DatabaseName);
// Returns: "Server=...;Database=SourceDB1;..."

// Use connection
var dates = await tableArchiver.GetPresentDatesAsync(connString, ...);
```

---

## Metadata Database Structure

The metadata database contains:

**Configuration Tables:**
- `archival_table_configuration` - Which tables to archive
- `archival_table_policy` - Retention policies (keep last N EOD/EOM/EOQ/EOY)
- `archival_blob_configuration` - Which blob prefixes to manage
- `archival_blob_policy` - Lifecycle policies (cold/archive/delete age thresholds)
- `archival_table_exemption` - Dates to skip for table archival
- `archival_blob_exemption` - Blobs to skip for lifecycle

**Audit/Tracking Tables:**
- `archival_run` - Run records (Archive or Lifecycle)
- `archival_run_item` - Individual operation results
- `archival_dataset` - Tracked exported datasets (prevents re-export)

**See [Data Model](data_model.md) for detailed schema.**

---

## Key Architectural Decisions

### 1. Why VSA Instead of Traditional Layers?

**Traditional layered architecture problems:**
- Services grow into "god classes" with dozens of methods
- Hard to understand what a feature actually does (spread across many files)
- Changes ripple through multiple layers

**VSA benefits:**
- Each feature is self-contained in its folder
- Easy to find all code related to a feature
- Adding features doesn't affect existing features
- Handlers are small and focused

### 2. Why Separate Stores from Repositories?

**Stores** (Data layer):
- Implement Application contracts
- Return DTOs (Application.Shared.Models)
- Act as anti-corruption layer

**Repositories** (Data layer):
- Encapsulate EF queries
- Return domain models (Application.Configuration)
- Isolate EF from stores

**Benefit:** Application handlers never see EF entities or EF types. Clean separation.

### 3. Why Keep Infrastructure Separate from Data?

**Data layer:**
- EF Core and metadata DB only
- No Azure SDK dependencies
- No external API dependencies

**Infrastructure layer:**
- Azure SDK (BlobClient, etc.)
- Parquet.NET
- SQL Server queries (non-EF)

**Benefit:** Can test business logic without Azure dependencies. Can swap implementations easily.

### 4. Why Use Contracts Instead of Direct References?

**Without contracts:**
```csharp
// Handler directly uses store implementation
public Handler(TableConfigurationStore store) { }
```
**Problem:** Handler is coupled to concrete implementation, can't test without real DB.

**With contracts:**
```csharp
// Handler uses interface
public Handler(ITableConfigurationStore store) { }
```
**Benefit:** Can mock interface in tests. Can swap implementations without changing handler.

---

## Next Steps

- **[Execution Flows](execution_flows.md)** - Trace step-by-step command execution
- **[Business Rules](business_rules.md)** - Understand retention, exemptions, lifecycle rules
- **[Data Model](data_model.md)** - Database schema details

