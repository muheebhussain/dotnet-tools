namespace Archival.Data.Entities;

public sealed class ArchivalBlobExemptionEntity
{
    public int Id { get; set; }
    public int BlobConfigurationId { get; set; }
    public ArchivalBlobConfigurationEntity BlobConfiguration { get; set; } = null!;
    public DateOnly AsOfDate { get; set; }
    public string ContainerName { get; set; } = null!;
    public string Prefix { get; set; } = null!;
    public string? Reason { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
}
