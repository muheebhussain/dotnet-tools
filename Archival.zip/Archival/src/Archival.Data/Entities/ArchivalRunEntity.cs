using Archival.Application.Shared.Models;

namespace Archival.Data.Entities;

public sealed class ArchivalRunEntity
{
    public long Id { get; set; }
    public RunType RunType { get; set; }
    public DateTime StartedAt { get; set; }
    public DateTime? EndedAt { get; set; }
    public RunStatus Status { get; set; }
    public string? Note { get; set; }

    public ICollection<ArchivalRunItemEntity> Items { get; set; } = new List<ArchivalRunItemEntity>();
}
