using Archival.Application.Shared.Models;

namespace Archival.Data.Entities;

public sealed class ArchivalBlobConfigurationEntity
{
    public int Id { get; set; }
    public bool IsEnabled { get; set; }

    public string StorageAccountName { get; set; } = null!;
    public string ContainerName { get; set; } = null!;
    public string Prefix { get; set; } = null!;
    public string? IncludePattern { get; set; }
    public string? ExcludePattern { get; set; }
    public bool SupportsArchiveTier { get; set; } = true;

    public BusinessDateSource BusinessDateSource { get; set; } = BusinessDateSource.FromFileName;

    public int BlobPolicyId { get; set; }
    public ArchivalBlobPolicyEntity BlobPolicy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    public ICollection<ArchivalBlobExemptionEntity> BlobExemptions { get; set; } = new List<ArchivalBlobExemptionEntity>();
}

