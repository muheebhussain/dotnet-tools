namespace Archival.Data.Entities;

public sealed class ArchivalBlobPolicyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public bool IsActive { get; set; }

    // vNext model: single set of age-based thresholds (no date-type differentiation)
    public int? ColdMinAgeDays { get; set; }
    public int? ArchiveMinAgeDays { get; set; }
    public int? DeleteMinAgeDays { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

