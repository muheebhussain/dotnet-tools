using Archival.Application.Shared.Models;

namespace Archival.Data.Entities;

public sealed class ArchivalDatasetEntity
{
    public long Id { get; set; }

    public int TableConfigurationId { get; set; }
    public ArchivalTableConfigurationEntity TableConfiguration { get; set; } = null!;

    public DateOnly AsOfDate { get; set; }
    public DateType DateType { get; set; }

    public string StorageAccountName { get; set; } = null!;
    public string ContainerName { get; set; } = null!;
    public string BlobPrefix { get; set; } = null!; // folder ending with .parquet/

    public int PartCount { get; set; }
    public long? TotalBytes { get; set; }
    public long? RowCount { get; set; }

    public DatasetStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string? ErrorSummary { get; set; }
}
