namespace Archival.Data.Entities;

public sealed class ArchivalTableExemptionEntity
{
    public int Id { get; set; }
    public int TableConfigurationId { get; set; }
    public ArchivalTableConfigurationEntity TableConfiguration { get; set; } = null!;
    public DateOnly AsOfDate { get; set; }
    public string? Reason { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
}
