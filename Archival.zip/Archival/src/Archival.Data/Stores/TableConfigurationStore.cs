﻿﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Validators;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Store for table configuration operations.
/// </summary>
public sealed class TableConfigurationStore(IConfigurationRepository configRepo) : ITableConfigurationStore
{
    public async Task<IReadOnlyList<TableConfigurationDto>> GetActiveTableConfigurationsAsync(CancellationToken ct)
    {
        var configs = await configRepo.GetActiveTableConfigurationsAsync(ct);
        var dtos = configs.Select(c => new TableConfigurationDto(
            c.Id, c.IsActive, c.DatabaseName, c.SchemaName, c.TableName, c.BusinessDateColumnName,
            c.TablePolicyId, c.BlobPolicyId, c.ArchivePathTemplate, c.DeleteAfterExport, c.BatchDeleteSize))
            .ToList();

        // Validate each configuration
        foreach (var dto in dtos)
        {
            var validationResult = ConfigurationValidator.ValidateTableConfiguration(dto);
            if (!validationResult.Ok)
                throw new InvalidOperationException($"Invalid table configuration (ID={dto.Id}): {validationResult.Error}");
        }

        return dtos;
    }

    public async Task<TableConfigurationDto?> GetTableConfigurationAsync(int id, CancellationToken ct)
    {
        var config = await configRepo.GetTableConfigurationAsync(id, ct);
        if (config is null)
            return null;

        var dto = new TableConfigurationDto(
            config.Id, config.IsActive, config.DatabaseName, config.SchemaName, config.TableName, config.BusinessDateColumnName,
            config.TablePolicyId, config.BlobPolicyId, config.ArchivePathTemplate, config.DeleteAfterExport, config.BatchDeleteSize);

        // Validate configuration
        var validationResult = ConfigurationValidator.ValidateTableConfiguration(dto);
        if (!validationResult.Ok)
            throw new InvalidOperationException($"Invalid table configuration (ID={id}): {validationResult.Error}");

        return dto;
    }
}

