﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Validators;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Store for blob configuration operations.
/// </summary>
public sealed class BlobConfigurationStore(IConfigurationRepository configRepo) : IBlobConfigurationStore
{
    public async Task<IReadOnlyList<BlobConfigurationDto>> GetEnabledBlobConfigurationsAsync(CancellationToken ct)
    {
        var configs = await configRepo.GetEnabledBlobConfigurationsAsync(ct);
        var dtos = configs.Select(c => new BlobConfigurationDto(
            c.Id, c.IsEnabled, c.StorageAccountName, c.ContainerName, c.Prefix, c.IncludePattern, c.ExcludePattern,
            c.SupportsArchiveTier, c.BusinessDateSource, c.BlobPolicyId))
            .ToList();

        // Validate each configuration
        foreach (var dto in dtos)
        {
            var validationResult = ConfigurationValidator.ValidateBlobConfiguration(dto);
            if (!validationResult.Ok)
                throw new InvalidOperationException($"Invalid blob configuration (ID={dto.Id}): {validationResult.Error}");
        }

        return dtos;
    }

    public async Task<BlobConfigurationDto?> GetBlobConfigurationAsync(int id, CancellationToken ct)
    {
        var configs = await GetEnabledBlobConfigurationsAsync(ct);
        return configs.FirstOrDefault(c => c.Id == id);
    }
}

