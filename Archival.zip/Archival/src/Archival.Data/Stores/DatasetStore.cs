﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Store for dataset operations.
/// </summary>
public sealed class DatasetStore(IRunRepository runRepo) : IDatasetStore
{
    public Task<bool> DatasetExistsAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct) =>
        runRepo.DatasetExistsAsync(tableConfigId, asOfDate, ct);

    public async Task<DatasetDetailDto?> GetDatasetAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct)
    {
        var result = await runRepo.GetDatasetAsync(tableConfigId, asOfDate, ct);
        if (result == null)
            return null;

        var (configId, date, status) = result.Value;
        // Return minimal detail - caller only needs status for retry logic
        return new DatasetDetailDto(0, date, DateType.EOD, "", "", "", status);
    }

    public Task<long> CreateDatasetAsync(int tableConfigId, DateOnly asOfDate, DateType dateType,
        string storageAccountName, string containerName, string blobPrefix, CancellationToken ct) =>
        runRepo.CreateDatasetAsync(tableConfigId, asOfDate, dateType, storageAccountName, containerName, blobPrefix, ct);

    public Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct) =>
        runRepo.MarkDatasetSucceededAsync(datasetId, partCount, rowCount, totalBytes, ct);

    public Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct) =>
        runRepo.MarkDatasetFailedAsync(datasetId, errorSummary, ct);

    public async Task<IReadOnlyList<DatasetDto>> GetSucceededDatasetsAsync(CancellationToken ct)
    {
        var datasets = await runRepo.GetSucceededDatasetsAsync(ct);
        return datasets.Select(d => new DatasetDto(
            d.DatasetId, d.AsOfDate, d.DateType, d.StorageAccountName, d.ContainerName, d.BlobPrefix))
            .ToList();
    }
}

