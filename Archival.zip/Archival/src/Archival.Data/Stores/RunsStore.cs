﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Models;
using Archival.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Stores;

public sealed class RunsStore(ArchivalDbContext db, IClock clock) : IRunsStore
{
    public async Task<RunDto> StartRunAsync(RunType runType, CancellationToken ct)
    {
        var entity = new ArchivalRunEntity
        {
            RunType = runType,
            StartedAt = clock.UtcNow,
            Status = RunStatus.Running
        };

        db.Runs.Add(entity);
        await db.SaveChangesAsync(ct);

        return new RunDto(
            entity.Id,
            runType,
            entity.StartedAt,
            entity.EndedAt,
            entity.Status,
            entity.Note);
    }

    public async Task CompleteRunAsync(long runId, RunStatus status, string? note, CancellationToken ct)
    {
        var run = await db.Runs.SingleAsync(r => r.Id == runId, ct);
        run.Status = status;
        run.Note = note;
        run.EndedAt = clock.UtcNow;
        await db.SaveChangesAsync(ct);
    }
}

