﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Store for blob lifecycle policy operations.
/// </summary>
public sealed class BlobPolicyStore(IConfigurationRepository configRepo) : IBlobPolicyStore
{
    public async Task<LifecyclePolicyDto?> GetLifecyclePolicyAsync(int id, CancellationToken ct)
    {
        var policy = await configRepo.GetLifecyclePolicyAsync(id, ct);
        return policy is null ? null : new LifecyclePolicyDto(
            policy.Id, policy.IsActive, policy.ColdMinAgeDays, policy.ArchiveMinAgeDays, policy.DeleteMinAgeDays);
    }
}

