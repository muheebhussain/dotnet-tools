﻿using Archival.Application.Contracts.Persistence;
using Archival.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Stores;

/// <summary>
/// Store for exemption operations.
/// </summary>
public sealed class ExemptionsStore(ArchivalDbContext db, IConfigurationRepository configRepo) : IExemptionsStore
{
    public async Task<IReadOnlySet<(int TableConfigurationId, DateOnly AsOfDate)>> GetTableExemptionsAsync(
        int tableConfigurationId, CancellationToken ct)
    {
        var exemptions = await db.TableExemptions
            .Where(e => e.TableConfigurationId == tableConfigurationId)
            .Select(e => new { e.TableConfigurationId, e.AsOfDate })
            .ToListAsync(ct);
        return exemptions.Select(e => (e.TableConfigurationId, e.AsOfDate)).ToHashSet();
    }

    public async Task<IReadOnlySet<(string Container, string Prefix, DateOnly Date)>> GetBlobExemptionsAsync(
        int blobConfigurationId, CancellationToken ct)
    {
        return await configRepo.GetFileExemptionsAsync(blobConfigurationId, ct);
    }
}

