﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Data.Repositories;

namespace Archival.Data.Stores;

/// <summary>
/// Store for table retention policy operations.
/// </summary>
public sealed class TablePolicyStore(IConfigurationRepository configRepo) : ITablePolicyStore
{
    public async Task<TableRetentionPolicyDto?> GetTableRetentionPolicyAsync(int id, CancellationToken ct)
    {
        var policy = await configRepo.GetTableRetentionPolicyAsync(id, ct);
        return policy is null ? null : new TableRetentionPolicyDto(
            policy.Id, policy.IsActive, policy.KeepLastEod, policy.KeepLastEom, policy.KeepLastEoq, policy.KeepLastEoy);
    }
}

