using System.Runtime.CompilerServices;
using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Files.DataLake;
using Microsoft.Extensions.Logging;
using AppBlobItem = Archival.Application.Shared.Models.BlobItem;

namespace Archival.Infrastructure.BlobStorage;

public sealed class AzureBlobLister : IBlobLister
{
    public async IAsyncEnumerable<AppBlobItem> ListBlobsAsync(
        string storageConn,
        string containerName,
        string prefix,
        [EnumeratorCancellation] CancellationToken ct)
    {
        var container = new BlobContainerClient(storageConn, containerName);

        await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: prefix, cancellationToken: ct))
        {
            var props = item.Properties;

            // CreatedOn isn't always available; we fall back to LastModified (your rule).
            var created = props.CreatedOn?.UtcDateTime ?? props.LastModified?.UtcDateTime ?? DateTime.UtcNow;
            var lastMod = props.LastModified?.UtcDateTime ?? created;

            yield return new AppBlobItem(
                Name: item.Name,
                ContentLength: props.ContentLength,
                CreatedAtUtc: created,
                LastModifiedUtc: lastMod,
                AccessTier: props.AccessTier?.ToString()
            );
        }
    }
}

public sealed class AzureBlobTierManager(ILogger<AzureBlobTierManager> logger) : IBlobTierManager
{
    public async Task<bool> TrySetColdAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            var blob = new BlobClient(storageConn, containerName, blobName);
            await blob.SetAccessTierAsync(AccessTier.Cold, cancellationToken: ct);
            return true;
        }
        catch { return false; }
    }

    public async Task<bool> TrySetArchiveAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            var blob = new BlobClient(storageConn, containerName, blobName);
            await blob.SetAccessTierAsync(AccessTier.Archive, cancellationToken: ct);
            return true;
        }
        catch { return false; }
    }

    public async Task<bool> TryDeleteAsync(string storageConn, string containerName, string blobName, CancellationToken ct)
    {
        try
        {
            var blob = new BlobClient(storageConn, containerName, blobName);
            await blob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, cancellationToken: ct);
            return true;
        }
        catch { return false; }
    }

    public async Task<Result<DateFolderDeletionResult>> DeleteDateFolderAsync(
        string storageConn,
        string containerName,
        string datePrefix,
        CancellationToken ct)
    {
        try
        {
            logger.LogInformation("Starting date folder deletion: Container={Container}, DatePrefix={DatePrefix}",
                containerName, datePrefix);

            var container = new BlobContainerClient(storageConn, containerName);

            // Step 1: List all blobs under datePrefix
            var blobsToDelete = new List<string>();
            await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: datePrefix, cancellationToken: ct))
            {
                blobsToDelete.Add(item.Name);
            }

            logger.LogInformation("Found {Count} blobs to delete under datePrefix={DatePrefix}",
                blobsToDelete.Count, datePrefix);

            // Step 2: Delete all blobs
            int deletedCount = 0;
            foreach (var blobName in blobsToDelete)
            {
                try
                {
                    var blob = container.GetBlobClient(blobName);
                    await blob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, cancellationToken: ct);
                    deletedCount++;
                }
                catch (Exception ex)
                {
                    logger.LogWarning(ex, "Failed to delete blob: {BlobName}", blobName);
                }
            }

            logger.LogInformation("Deleted {DeletedCount}/{TotalCount} blobs", deletedCount, blobsToDelete.Count);

            // Step 3: Attempt to delete directory marker blob (exact path with trailing slash)
            bool markerDeleted = false;
            var markerBlobName = datePrefix.TrimEnd('/') + "/";
            try
            {
                var markerBlob = container.GetBlobClient(markerBlobName);
                var response = await markerBlob.DeleteIfExistsAsync(cancellationToken: ct);
                markerDeleted = response.Value;

                if (markerDeleted)
                {
                    logger.LogInformation("Directory marker blob deleted: {MarkerBlobName}", markerBlobName);
                }
                else
                {
                    logger.LogDebug("No directory marker blob found: {MarkerBlobName}", markerBlobName);
                }
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Marker blob deletion attempt failed (may not exist): {MarkerBlobName}", markerBlobName);
            }

            // Step 4: Attempt HNS directory deletion (if hierarchical namespace is enabled)
            bool hnsDirectoryDeleted = false;
            bool hnsSupported = false;
            try
            {
                // Try to create DataLake client with same connection string
                var dataLakeServiceClient = new DataLakeServiceClient(storageConn);
                var fileSystem = dataLakeServiceClient.GetFileSystemClient(containerName);

                // Normalize directory path (remove trailing slash for DataLake API)
                var directoryPath = datePrefix.TrimEnd('/');

                var directoryClient = fileSystem.GetDirectoryClient(directoryPath);

                // Check if directory exists and delete it
                var exists = await directoryClient.ExistsAsync(ct);
                if (exists.Value)
                {
                    await directoryClient.DeleteAsync(recursive: true, cancellationToken: ct);
                    hnsDirectoryDeleted = true;
                    hnsSupported = true;
                    logger.LogInformation("HNS directory deleted: {DirectoryPath}", directoryPath);
                }
                else
                {
                    hnsSupported = true; // HNS is supported, but directory doesn't exist (already deleted via blobs)
                    logger.LogDebug("HNS directory does not exist: {DirectoryPath}", directoryPath);
                }
            }
            catch (RequestFailedException ex) when (ex.ErrorCode == "FeatureNotSupported" || ex.ErrorCode == "InvalidUri")
            {
                // HNS not enabled on this account
                hnsSupported = false;
                logger.LogDebug("HNS not supported on this storage account (expected for non-ADLS Gen2)");
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "HNS directory deletion failed: {DatePrefix}", datePrefix);
            }

            // Step 5: Verify no blobs remain under datePrefix
            var remainingCount = 0;
            await foreach (var item in container.GetBlobsAsync(traits: BlobTraits.None, states: BlobStates.None, prefix: datePrefix, cancellationToken: ct))
            {
                remainingCount++;
            }

            if (remainingCount > 0)
            {
                logger.LogWarning("Verification failed: {Count} blobs still remain under datePrefix={DatePrefix}",
                    remainingCount, datePrefix);
            }
            else
            {
                logger.LogInformation("Verification passed: No blobs remain under datePrefix={DatePrefix}", datePrefix);
            }

            var result = new DateFolderDeletionResult(
                BlobsDeleted: deletedCount,
                MarkerDeleted: markerDeleted,
                HnsDirectoryDeleted: hnsDirectoryDeleted,
                HnsSupported: hnsSupported);

            return Result<DateFolderDeletionResult>.Success(result);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Date folder deletion failed: Container={Container}, DatePrefix={DatePrefix}",
                containerName, datePrefix);
            return Result<DateFolderDeletionResult>.Fail($"Date folder deletion failed: {ex.Message}");
        }
    }
}
