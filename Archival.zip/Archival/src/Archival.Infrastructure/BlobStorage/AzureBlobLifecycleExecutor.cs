﻿using Archival.Application.Contracts.Storage;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Infrastructure.BlobStorage;

public sealed class AzureBlobLifecycleExecutor(AzureBlobTierManager tierManager) : IBlobLifecycleExecutor
{
    public Task<bool> TrySetColdAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct) =>
        tierManager.TrySetColdAsync(storageConnectionString, containerName, blobName, ct);

    public Task<bool> TrySetArchiveAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct) =>
        tierManager.TrySetArchiveAsync(storageConnectionString, containerName, blobName, ct);

    public Task<bool> TryDeleteAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct) =>
        tierManager.TryDeleteAsync(storageConnectionString, containerName, blobName, ct);

    public async Task<Result<DateFolderDeletionResultDto>> DeleteDateFolderAsync(
        string storageConnectionString,
        string containerName,
        string datePrefix,
        CancellationToken ct)
    {
        var result = await tierManager.DeleteDateFolderAsync(storageConnectionString, containerName, datePrefix, ct);

        if (!result.Ok)
            return Result<DateFolderDeletionResultDto>.Fail(result.Error ?? "Date folder deletion failed");

        return Result<DateFolderDeletionResultDto>.Success(new DateFolderDeletionResultDto(
            result.Value!.BlobsDeleted,
            result.Value.MarkerDeleted,
            result.Value.HnsDirectoryDeleted,
            result.Value.HnsSupported));
    }
}

