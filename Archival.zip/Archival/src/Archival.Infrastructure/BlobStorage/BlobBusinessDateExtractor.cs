﻿using System.Text.RegularExpressions;
using Archival.Application.Contracts.Infrastructure;

namespace Archival.Infrastructure.BlobStorage;

public sealed partial class BlobBusinessDateExtractor : IBlobBusinessDateExtractor
{
    // Pattern priority (most specific first):
    // 1. yyyy-MM-dd (e.g., 2026-02-15)
    // 2. yyyy/MM/dd (e.g., 2026/02/15)
    // 3. yyyyMMdd (e.g., 20260215)

    [GeneratedRegex(@"(\d{4})-(\d{2})-(\d{2})", RegexOptions.Compiled)]
    private static partial Regex DashPattern();

    [GeneratedRegex(@"(\d{4})/(\d{2})/(\d{2})", RegexOptions.Compiled)]
    private static partial Regex SlashPattern();

    [GeneratedRegex(@"(\d{8})", RegexOptions.Compiled)]
    private static partial Regex CompactPattern();

    public bool TryExtractDateFromPath(string blobName, out DateOnly date)
    {
        date = default;

        if (string.IsNullOrWhiteSpace(blobName))
            return false;

        // Try yyyy-MM-dd pattern first (most specific)
        var match = DashPattern().Match(blobName);
        if (match.Success && TryParseMatch(match, out date))
            return true;

        // Try yyyy/MM/dd pattern
        match = SlashPattern().Match(blobName);
        if (match.Success && TryParseMatch(match, out date))
            return true;

        // Try yyyyMMdd pattern (compact)
        match = CompactPattern().Match(blobName);
        if (match.Success && TryParseCompact(match, out date))
            return true;

        return false;
    }

    public bool TryExtractDateFromPathSegment(string blobName, string configuredPrefix, out DateOnly date)
    {
        date = default;

        if (string.IsNullOrWhiteSpace(blobName) || string.IsNullOrWhiteSpace(configuredPrefix))
            return false;

        // Normalize prefixes (remove leading/trailing slashes for comparison)
        var normalizedPrefix = configuredPrefix.Trim('/');
        var normalizedBlob = blobName.Trim('/');

        // Check if blob starts with the configured prefix
        if (!normalizedBlob.StartsWith(normalizedPrefix, StringComparison.OrdinalIgnoreCase))
            return false;

        // Get the remainder after the prefix
        var remainder = normalizedBlob.Substring(normalizedPrefix.Length).TrimStart('/');

        // Extract the first path segment (date folder)
        var firstSlash = remainder.IndexOf('/');
        var dateSegment = firstSlash >= 0 ? remainder.Substring(0, firstSlash) : remainder;

        // Try to parse as yyyy-MM-dd
        if (string.IsNullOrWhiteSpace(dateSegment))
            return false;

        var match = DashPattern().Match(dateSegment);
        if (match.Success && TryParseMatch(match, out date))
            return true;

        return false;
    }

    private static bool TryParseMatch(Match match, out DateOnly date)
    {
        date = default;

        if (!int.TryParse(match.Groups[1].Value, out var year) ||
            !int.TryParse(match.Groups[2].Value, out var month) ||
            !int.TryParse(match.Groups[3].Value, out var day))
            return false;

        try
        {
            date = new DateOnly(year, month, day);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseCompact(Match match, out DateOnly date)
    {
        date = default;

        var compact = match.Groups[1].Value;
        if (compact.Length != 8)
            return false;

        if (!int.TryParse(compact.Substring(0, 4), out var year) ||
            !int.TryParse(compact.Substring(4, 2), out var month) ||
            !int.TryParse(compact.Substring(6, 2), out var day))
            return false;

        try
        {
            date = new DateOnly(year, month, day);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
