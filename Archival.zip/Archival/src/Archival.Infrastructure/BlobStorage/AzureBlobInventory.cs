﻿using Archival.Application.Contracts.Storage;
using Archival.Application.Shared.Models;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace Archival.Infrastructure.BlobStorage;

public sealed class AzureBlobInventory(BlobBusinessDateExtractor dateExtractor) : IBlobInventory
{
    public async Task<IReadOnlyList<BlobItemDto>> ListBlobsAsync(
        string storageConnectionString,
        string containerName,
        string prefix,
        CancellationToken ct)
    {
        var container = new BlobContainerClient(storageConnectionString, containerName);
        var results = new List<BlobItemDto>();

        await foreach (var item in container.GetBlobsAsync(
            traits: BlobTraits.None,
            states: BlobStates.None,
            prefix: prefix,
            cancellationToken: ct))
        {
            var props = item.Properties;
            var created = props.CreatedOn?.UtcDateTime ?? props.LastModified?.UtcDateTime ?? DateTime.UtcNow;
            var lastMod = props.LastModified?.UtcDateTime ?? created;

            results.Add(new BlobItemDto(
                item.Name,
                props.ContentLength,
                created,
                lastMod,
                props.AccessTier?.ToString()));
        }

        return results;
    }

    public bool TryExtractDateFromPath(string blobName, out DateOnly date) =>
        dateExtractor.TryExtractDateFromPath(blobName, out date);

    public bool TryExtractDateFromPathSegment(string blobName, string configuredPrefix, out DateOnly date) =>
        dateExtractor.TryExtractDateFromPathSegment(blobName, configuredPrefix, out date);
}

