﻿using Archival.Infrastructure.BlobStorage;
using Microsoft.Extensions.Options;
using Archival.Application.Contracts.Infrastructure;
using Archival.Infrastructure.Parquet;
using Archival.Infrastructure.SqlServer;
using Microsoft.Extensions.DependencyInjection;

namespace Archival.Infrastructure;
/// <summary>
/// Extension methods for registering infrastructure layer services.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Adds infrastructure layer services to the dependency injection container.
    /// </summary>
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, string? secretsDirectory = null)
    {
        // Core infrastructure
        services.AddSingleton<Archival.Application.Contracts.Time.IClock, Time.SystemClock>();

        var secretsDir = secretsDirectory ?? "/secrets/";
        services.AddSingleton<Archival.Application.Contracts.Configuration.IConnectionStringResolver>(
            new Secrets.ConnectionStringResolver(secretsDir));

        // Storage contracts
        services.AddScoped<Application.Contracts.Storage.IBlobInventory, AzureBlobInventory>();
        services.AddScoped<Application.Contracts.Storage.IBlobLifecycleExecutor, AzureBlobLifecycleExecutor>();

        // Table contracts
        services.AddScoped<Archival.Application.Contracts.Tables.ITableArchiver, Tables.SqlTableArchiver>();

        // Retention contracts
        services.AddScoped<Archival.Application.Contracts.Retention.IRetentionCalculator, Retention.RetentionService>();

        // SQL Server adapters (interfaces from Contracts.Infrastructure)
        services.AddScoped<IBusinessCalendar, SqlServerBusinessCalendar>();
        services.AddScoped<IPresentDateFinder, SqlServerPresentDateFinder>();
        services.AddScoped<IArchivalExporter, SqlServerArchivalExporter>();
        services.AddScoped<ISourceDeleter, SqlServerSourceDeleter>();

        // Parquet processors
        services.AddScoped<IParquetSchemaBuilder, ParquetSchemaBuilder>();
        services.AddScoped<IParquetPartWriter, ParquetPartWriter>();
        services.AddScoped<IArchivePathTemplateExpander, ArchivePathTemplateExpander>();

        // Blob utilities
        services.AddScoped<BlobBusinessDateExtractor>();
        services.AddScoped<AzureBlobTierManager>();

        // Configuration validators
        services.AddSingleton<IValidateOptions<ParquetExportOptions>, ParquetExportOptionsValidator>();

        return services;
    }
}

