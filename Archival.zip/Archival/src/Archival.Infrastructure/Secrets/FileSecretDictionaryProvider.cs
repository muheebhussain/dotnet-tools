using System.Text.Json;
using Archival.Application.Contracts.Infrastructure;

namespace Archival.Infrastructure.Secrets;

internal sealed class FileSecretDictionaryProvider(string secretsPath)
{
    private Dictionary<string, string>? _db;
    private Dictionary<string, string>? _storage;

    public Dictionary<string, string> GetDbConnections()
    {
        _db ??= Load(Path.Combine(secretsPath, "archival-db-connections.json"));
        return _db;
    }

    public Dictionary<string, string> GetStorageConnections()
    {
        _storage ??= Load(Path.Combine(secretsPath, "archival-storage-connections.json"));
        return _storage;
    }

    private static Dictionary<string, string> Load(string file)
    {
        if (!File.Exists(file))
            throw new FileNotFoundException($"Required secret file not found: {file}");

        var json = File.ReadAllText(file);
        var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        if (dict is null || dict.Count == 0)
            throw new InvalidOperationException($"Secret dictionary is empty: {file}");

        // Normalize keys for stable lookups.
        return dict.ToDictionary(k => k.Key.Trim(), v => v.Value, StringComparer.OrdinalIgnoreCase);
    }
}

public sealed class ConnectionStringResolver(string secretsPath) :
    IConnectionStringResolver,
    Archival.Application.Contracts.Configuration.IConnectionStringResolver
{
    private readonly FileSecretDictionaryProvider _provider = new(secretsPath);

    // Legacy interface methods
    public string GetDatabaseConnection(string databaseName)
    {
        var dict = _provider.GetDbConnections();
        if (!dict.TryGetValue(databaseName, out var conn) || string.IsNullOrWhiteSpace(conn))
            throw new KeyNotFoundException($"Missing DB connection for database_name='{databaseName}' in archival-db-connections.json");
        return conn;
    }

    public string GetStorageConnection(string storageAccountName)
    {
        var dict = _provider.GetStorageConnections();
        if (!dict.TryGetValue(storageAccountName, out var conn) || string.IsNullOrWhiteSpace(conn))
            throw new KeyNotFoundException($"Missing storage connection for storage_account_name='{storageAccountName}' in archival-storage-connections.json");
        return conn;
    }

    // New VSA contract interface methods (delegate to legacy methods)
    string Archival.Application.Contracts.Configuration.IConnectionStringResolver.ResolveStorageConnection(string storageAccountName)
        => GetStorageConnection(storageAccountName);

    string Archival.Application.Contracts.Configuration.IConnectionStringResolver.ResolveSourceConnection(string databaseName)
        => GetDatabaseConnection(databaseName);
}
