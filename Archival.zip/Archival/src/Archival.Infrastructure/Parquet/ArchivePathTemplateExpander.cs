﻿using Archival.Application.Shared.Models;

namespace Archival.Infrastructure.Parquet;

public sealed record ArchivePathTemplateContext(
    string DatabaseName,
    string SchemaName,
    string TableName,
    DateOnly AsOfDate,
    DateType DateType);

public interface IArchivePathTemplateExpander
{
    string ExpandTemplate(string template, ArchivePathTemplateContext context);
    void ValidateTemplate(string template);
}

public sealed class ArchivePathTemplateExpander : IArchivePathTemplateExpander
{
    private static readonly string[] KnownTokens =
    {
        "{database}", "{schema}", "{table}",
        "{yyyy}", "{MM}", "{dd}",
        "{date}", "{date_type}"
    };

    public void ValidateTemplate(string template)
    {
        if (string.IsNullOrWhiteSpace(template))
            throw new ArgumentException("Archive path template cannot be empty", nameof(template));

        // Find all tokens in the template
        var tokens = System.Text.RegularExpressions.Regex.Matches(template, @"\{([^}]+)\}")
            .Select(m => m.Value.ToLowerInvariant())
            .Distinct()
            .ToList();

        // Check for unknown tokens
        var unknownTokens = tokens.Where(t => !KnownTokens.Contains(t, StringComparer.OrdinalIgnoreCase)).ToList();
        if (unknownTokens.Any())
            throw new ArgumentException($"Unknown tokens in archive path template: {string.Join(", ", unknownTokens)}. Known tokens: {string.Join(", ", KnownTokens)}");
    }

    public string ExpandTemplate(string template, ArchivePathTemplateContext context)
    {
        ValidateTemplate(template);

        var expanded = template
            .Replace("{database}", context.DatabaseName, StringComparison.OrdinalIgnoreCase)
            .Replace("{schema}", context.SchemaName, StringComparison.OrdinalIgnoreCase)
            .Replace("{table}", context.TableName, StringComparison.OrdinalIgnoreCase)
            .Replace("{yyyy}", context.AsOfDate.Year.ToString("D4"), StringComparison.OrdinalIgnoreCase)
            .Replace("{MM}", context.AsOfDate.Month.ToString("D2"), StringComparison.OrdinalIgnoreCase)
            .Replace("{dd}", context.AsOfDate.Day.ToString("D2"), StringComparison.OrdinalIgnoreCase)
            .Replace("{date}", context.AsOfDate.ToString("yyyy-MM-dd"), StringComparison.OrdinalIgnoreCase)
            .Replace("{date_type}", context.DateType.ToString(), StringComparison.OrdinalIgnoreCase);

        // Normalize path separators to forward slash (blob storage standard)
        expanded = expanded.Replace('\\', '/');

        // Trim leading slash (blob paths are relative)
        expanded = expanded.TrimStart('/');

        return expanded;
    }
}

