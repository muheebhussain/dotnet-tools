﻿using System.Data.Common;
using Parquet;
using Parquet.Data;
using Parquet.Schema;

namespace Archival.Infrastructure.Parquet;

public sealed record PartWriteResult(long RowCount, int ColumnCount, long SizeBytes, TimeSpan WriteDuration, bool HasMoreRows);

public interface IParquetPartWriter
{
    Task<(PartWriteResult Result, Stream ReadStream)> WritePartAsync(
        DbDataReader reader,
        List<DataField> fields,
        ParquetSchema schema,
        int maxRowsPerPart,
        long rowGroupTargetBytes,
        long spillThresholdBytes,
        CancellationToken ct);
}

public sealed class ParquetPartWriter : IParquetPartWriter
{
    public async Task<(PartWriteResult Result, Stream ReadStream)> WritePartAsync(
        DbDataReader reader,
        List<DataField> fields,
        ParquetSchema schema,
        int maxRowsPerPart,
        long rowGroupTargetBytes,
        long spillThresholdBytes,
        CancellationToken ct)
    {
        var rowsInPart = 0;
        var swWrite = System.Diagnostics.Stopwatch.StartNew();

        using var spill = new SpillableStream(spillThresholdBytes);

        // Create ParquetWriter without await using so we can control disposal manually
        var parquetWriter = await ParquetWriter.CreateAsync(schema, spill, cancellationToken: ct).ConfigureAwait(false);
        parquetWriter.CompressionMethod = CompressionMethod.Snappy;

        var columnBuffers = InitColumnBuffers(fields.Count);
        var rowsInRowGroup = 0;
        long bytesInRowGroup = 0;

        bool hasRow = await reader.ReadAsync(ct).ConfigureAwait(false);

        while (rowsInPart < maxRowsPerPart && hasRow)
        {
            ct.ThrowIfCancellationRequested();

            for (var i = 0; i < fields.Count; i++)
            {
                object? val = reader.IsDBNull(i) ? null : reader.GetValue(i);

                // If schema field is string and value is Guid, convert
                if (val is Guid g && IsStringField(fields[i]))
                    val = g.ToString();

                columnBuffers[i].Add(val);
                bytesInRowGroup += EstimateObjectSize(val);
            }

            rowsInRowGroup++;
            rowsInPart++;

            hasRow = await reader.ReadAsync(ct).ConfigureAwait(false);

            // flush row group based on bytes/rows thresholds
            if (bytesInRowGroup >= rowGroupTargetBytes || rowsInRowGroup >= Math.Max(1, rowGroupTargetBytes / 1024))
            {
                await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct).ConfigureAwait(false);
                columnBuffers = InitColumnBuffers(fields.Count);
                rowsInRowGroup = 0;
                bytesInRowGroup = 0;
            }
        }

        if (rowsInRowGroup > 0)
            await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct).ConfigureAwait(false);

        // Flush writer but do NOT dispose spill yet
        await parquetWriter.DisposeAsync().ConfigureAwait(false);
        await spill.FlushAsync(ct).ConfigureAwait(false);

        swWrite.Stop();

        var readStream = spill.GetReadStream();
        var partSizeBytes = readStream.CanSeek ? readStream.Length : -1;

        return (new PartWriteResult(
            RowCount: rowsInPart,
            ColumnCount: fields.Count,
            SizeBytes: partSizeBytes,
            WriteDuration: swWrite.Elapsed,
            HasMoreRows: hasRow
        ), readStream);
    }

    private static bool IsStringField(DataField f)
    {
        var t = Nullable.GetUnderlyingType(f.ClrType) ?? f.ClrType;
        return t == typeof(string);
    }

    private static List<List<object?>> InitColumnBuffers(int fieldCount)
    {
        var cols = new List<List<object?>>(fieldCount);
        for (var i = 0; i < fieldCount; i++) cols.Add(new List<object?>());
        return cols;
    }

    private static long EstimateObjectSize(object? o)
    {
        if (o is null) return 8;
        if (o is string s) return (long)s.Length * 2 + 8;
        if (o is byte[] b) return b.Length;
        if (o is int or long or double or decimal or float) return 8;
        if (o is DateTime) return 8;
        if (o is bool) return 1;
        return 16;
    }

    private static async Task WriteRowGroupAsync(ParquetWriter parquetWriter, List<DataField> fields, List<List<object?>> columnBuffers, CancellationToken ct)
    {
        using var rowGroup = parquetWriter.CreateRowGroup();

        for (var i = 0; i < fields.Count; i++)
        {
            var field = fields[i];
            var buffer = columnBuffers[i];
            var columnData = buffer.ToArray();
            var dataColumn = GetColumn(field, columnData);
            await rowGroup.WriteColumnAsync(dataColumn, ct).ConfigureAwait(false);
        }
    }

    private static DataColumn GetColumn(DataField columnSchema, object?[] columnData)
    {
        var clrType = Nullable.GetUnderlyingType(columnSchema.ClrType) ?? columnSchema.ClrType;
        var typeCode = Type.GetTypeCode(clrType);

        return typeCode switch
        {
            TypeCode.String => new DataColumn(columnSchema, columnData.Cast<string?>().ToArray()),
            TypeCode.Int32 => new DataColumn(columnSchema, columnData.Cast<int?>().ToArray()),
            TypeCode.Int64 => new DataColumn(columnSchema, columnData.Cast<long?>().ToArray()),
            TypeCode.Decimal => new DataColumn(columnSchema, columnData.Cast<decimal?>().ToArray()),
            TypeCode.Double => new DataColumn(columnSchema, columnData.Cast<double?>().ToArray()),
            TypeCode.Single => new DataColumn(columnSchema, columnData.Cast<float?>().ToArray()),
            TypeCode.DateTime => new DataColumn(columnSchema, columnData.Cast<DateTime?>().ToArray()),
            TypeCode.Boolean => new DataColumn(columnSchema, columnData.Cast<bool?>().ToArray()),
            TypeCode.Byte => new DataColumn(columnSchema, columnData.Cast<byte?>().ToArray()),
            _ => new DataColumn(columnSchema, columnData)
        };
    }
}

