﻿namespace Archival.Infrastructure.Parquet;

public sealed class ParquetExportOptions
{
    public const string SectionName = "ParquetExport";

    public int RowsPerPart { get; init; } = 50_000;
    public long RowGroupTargetBytes { get; init; } = 64L * 1024 * 1024;
    public long SpillThresholdBytes { get; init; } = 16L * 1024 * 1024;
}

