using Microsoft.IO;

namespace Archival.Infrastructure.Parquet;

/// <summary>
/// A write-only stream used as a target for ParquetWriter that buffers to a pooled memory stream
/// and automatically spills to a temp file when the configured threshold is exceeded.
/// After writing completes call <see cref="GetReadStream"/> to obtain a read stream for upload.
/// The caller is responsible for disposing the returned read stream. Disposing this SpillableStream
/// will clean up any remaining resources (temp file if used).
/// </summary>
public sealed class SpillableStream : Stream, IDisposable
{
    private static readonly RecyclableMemoryStreamManager DefaultManager = new();

    private readonly RecyclableMemoryStreamManager _manager;
    private readonly long _thresholdBytes;

    private MemoryStream? _mem;
    private FileStream? _fileWrite; // write-side file stream while writing after spill
    private string? _tempPath;

    private long _position;
    private bool _completed;
    private bool _readStreamTaken;

    public SpillableStream(long thresholdBytes = 16 * 1024 * 1024, RecyclableMemoryStreamManager? manager = null)
    {
        _manager = manager ?? DefaultManager;
        _thresholdBytes = Math.Max(1, thresholdBytes);
        _mem = _manager.GetStream();
        _position = 0;
    }

    public override bool CanRead => false;
    public override bool CanSeek => false;
    public override bool CanWrite => !_completed;
    public override long Length => _completed
        ? (_fileWrite != null ? new FileInfo(_tempPath!).Length : _mem?.Length ?? 0)
        : (_fileWrite != null ? _fileWrite.Length : _mem?.Length ?? 0);

    public override long Position
    {
        get => _position;
        set => throw new NotSupportedException();
    }

    public override void Flush() => FlushAsync(CancellationToken.None).GetAwaiter().GetResult();

    public override async Task FlushAsync(CancellationToken cancellationToken)
    {
        if (_fileWrite != null)
            await _fileWrite.FlushAsync(cancellationToken).ConfigureAwait(false);
        else if (_mem != null)
            await _mem.FlushAsync(cancellationToken).ConfigureAwait(false);
    }

    public override void Write(byte[] buffer, int offset, int count)
        => WriteAsync(buffer, offset, count, CancellationToken.None).GetAwaiter().GetResult();

    public override async Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
    {
        if (_completed) throw new InvalidOperationException("Stream already completed for writing.");
        ArgumentNullException.ThrowIfNull(buffer);

        // if not yet spilled and this write would exceed threshold, spill to file first
        if (_fileWrite is null && (_position + count) > _thresholdBytes)
        {
            _tempPath = Path.Combine(Path.GetTempPath(), $"parquet_spill_{Guid.NewGuid():N}.tmp");
            _fileWrite = new FileStream(_tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize: 1 << 16, useAsync: true);

            if (_mem is not null)
            {
                _mem.Position = 0;
                await _mem.CopyToAsync(_fileWrite, bufferSize: 81920, cancellationToken).ConfigureAwait(false);
                _mem.Dispose();
                _mem = null;
            }
        }

        if (_fileWrite is not null)
            await _fileWrite.WriteAsync(buffer.AsMemory(offset, count), cancellationToken).ConfigureAwait(false);
        else
            await _mem!.WriteAsync(buffer.AsMemory(offset, count), cancellationToken).ConfigureAwait(false);

        _position += count;
    }

    /// <summary>
    /// Finalize writing and return a read-only stream for uploading.
    /// The returned stream takes ownership of the underlying data and this SpillableStream will not
    /// attempt to dispose it again. Caller must dispose the returned stream after upload.
    /// </summary>
    public Stream GetReadStream()
    {
        if (_readStreamTaken) throw new InvalidOperationException("GetReadStream already called.");
        _completed = true;

        if (_fileWrite != null)
        {
            // Close write handle and open a read handle for upload
            _fileWrite.Dispose();
            _fileWrite = null;

            var readFs = new FileStream(_tempPath!, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize: 1 << 16, useAsync: true);
            _readStreamTaken = true;
            return readFs;
        }

        if (_mem != null)
        {
            _mem.Position = 0;
            var readMem = _mem;
            _mem = null; // ownership transfer
            _readStreamTaken = true;
            return readMem;
        }

        _readStreamTaken = true;
        return new MemoryStream(Array.Empty<byte>(), writable: false);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            try { _mem?.Dispose(); } catch { /* ignore */ }
            try { _fileWrite?.Dispose(); } catch { /* ignore */ }

            if (_tempPath is not null)
            {
                try { File.Delete(_tempPath); } catch { /* ignore */ }
                _tempPath = null;
            }
        }
        base.Dispose(disposing);
    }

    // Not supported operations
    public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
    public override void SetLength(long value) => throw new NotSupportedException();
}
