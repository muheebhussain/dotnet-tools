﻿using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.SqlServer;

public sealed class SqlServerSourceDeleter(ILogger<SqlServerSourceDeleter> logger) : ISourceDeleter
{
    public async Task<Result<long>> DeleteByBusinessDateRangeAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        BusinessDateRange rangeUtc,
        int batchSize,
        CancellationToken ct)
    {
        try
        {
            var fullTable = $"[{schemaName}].[{tableName}]";
            var col = $"[{businessDateColumnName}]";

            // Batched delete loop
            var sql = $@"
WITH cte AS (
  SELECT TOP (@batch) *
  FROM {fullTable}
  WHERE {col} >= @start AND {col} < @end
)
DELETE FROM cte;
";

            long total = 0;
            await using var conn = new SqlConnection(sourceDbConn);
            await conn.OpenAsync(ct);

            while (true)
            {
                await using var cmd = new SqlCommand(sql, conn);
                cmd.CommandTimeout = 0;
                cmd.Parameters.AddWithValue("@batch", batchSize);
                cmd.Parameters.AddWithValue("@start", rangeUtc.StartInclusiveUtc);
                cmd.Parameters.AddWithValue("@end", rangeUtc.EndExclusiveUtc);

                var affected = await cmd.ExecuteNonQueryAsync(ct);
                if (affected <= 0) break;
                total += affected;
            }

            logger.LogInformation("Delete completed: {RowsDeleted} rows deleted from {Schema}.{Table}",
                total, schemaName, tableName);

            return Result<long>.Success(total);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Delete failed for {Schema}.{Table}, Date Range: {StartDate} to {EndDate}",
                schemaName, tableName, rangeUtc.StartInclusiveUtc, rangeUtc.EndExclusiveUtc);
            return Result<long>.Fail($"Delete failed: {ex.Message}");
        }
    }
}