using Archival.Application.Shared.Models;
using Archival.Application.Contracts.Infrastructure;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace Archival.Infrastructure.SqlServer;

public sealed class SqlServerBusinessCalendar(ILogger<SqlServerBusinessCalendar> logger) : IBusinessCalendar
{
    public async Task<IReadOnlyList<ClassifiedBusinessDate>> GetClassifiedDatesAsync(string sourceDbConn, DateOnly from, DateOnly to, CancellationToken ct)
    {
        // Inclusive range for dates.
        var sql = @"
SELECT date_type, current_business_date
FROM dbo.v_business_date_classification
WHERE current_business_date >= @from AND current_business_date < @to
ORDER BY current_business_date;
";
        await using var conn = new SqlConnection(sourceDbConn);
        await conn.OpenAsync(ct);

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@from", from.ToDateTime(TimeOnly.MinValue));
        cmd.Parameters.AddWithValue("@to", to.ToDateTime(TimeOnly.MinValue));

        var list = new List<ClassifiedBusinessDate>();
        await using var reader = await cmd.ExecuteReaderAsync(ct);

        while (await reader.ReadAsync(ct))
        {
            var dt = reader.GetString(0);
            var date = reader.GetDateTime(1);
            var dateOnly = DateOnly.FromDateTime(date);

            var type = dt switch
            {
                "EOY" => DateType.EOY,
                "EOQ" => DateType.EOQ,
                "EOM" => DateType.EOM,
                "EOD" => DateType.EOD,
                _ => DateType.EOD
            };

            // Log warning for unknown types
            if (!new[] { "EOY", "EOQ", "EOM", "EOD" }.Contains(dt))
            {
                logger.LogWarning("Unknown date_type: {DateType}, defaulting to EOD", dt);
            }

            list.Add(new ClassifiedBusinessDate(new BusinessDate(dateOnly), type));
        }

        return list;
    }
}

public sealed class SqlServerPresentDateFinder : IPresentDateFinder
{
    public async Task<IReadOnlyList<BusinessDate>> GetPresentBusinessDatesAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        DateOnly from,
        DateOnly to,
        CancellationToken ct)
    {
        // Join business_date to target table on date-truncated datetime.
        // Assumption: business_date.current_business_date is midnight or comparable.
        var fullTable = $"[{schemaName}].[{tableName}]";
        var col = $"[{businessDateColumnName}]";

        var sql = $@"
SELECT DISTINCT CAST(t.{col} AS date) AS as_of_date
FROM {fullTable} t
JOIN dbo.business_date bd
  ON CAST(t.{col} AS date) = CAST(bd.current_business_date AS date)
WHERE t.{col} >= @from AND t.{col} < @to
ORDER BY as_of_date;
";

        await using var conn = new SqlConnection(sourceDbConn);
        await conn.OpenAsync(ct);

        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@from", from.ToDateTime(TimeOnly.MinValue));
        cmd.Parameters.AddWithValue("@to", to.ToDateTime(TimeOnly.MinValue));

        var list = new List<BusinessDate>();
        await using var reader = await cmd.ExecuteReaderAsync(ct);

        while (await reader.ReadAsync(ct))
        {
            var date = reader.GetDateTime(0);
            list.Add(new BusinessDate(DateOnly.FromDateTime(date)));
        }
        return list;
    }
}
