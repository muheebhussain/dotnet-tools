using System.Data;
using Archival.Application.Shared.Models;
using Archival.Application.Contracts.Infrastructure;
using Archival.Application.Shared.Results;
using Archival.Infrastructure.Parquet;
using Azure.Storage.Blobs;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Archival.Infrastructure.SqlServer;

public sealed class SqlServerArchivalExporter(
    IParquetSchemaBuilder schemaBuilder,
    IParquetPartWriter partWriter,
    IOptions<ParquetExportOptions> options,
    ILogger<SqlServerArchivalExporter> logger) : IArchivalExporter
{
    private readonly ParquetExportOptions _options = options.Value;

    public async Task<Result<ExportResult>> ExportToMultipartParquetAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        BusinessDateRange rangeUtc,
        string storageConn,
        string containerName,
        string blobPrefix,
        CancellationToken ct)
    {
        try
        {
            logger.LogInformation("Starting export: Schema={Schema}, Table={Table}, BlobPrefix={Prefix}, DateRange={StartDate} to {EndDate}",
                schemaName, tableName, blobPrefix, rangeUtc.StartInclusiveUtc, rangeUtc.EndExclusiveUtc);

            // Query all columns from source table.
            var fullTable = $"[{schemaName}].[{tableName}]";
            var col = $"[{businessDateColumnName}]";
            var sql = $@"
SELECT *
FROM {fullTable}
WHERE {col} >= @start AND {col} < @end
ORDER BY {col};
";

            await using var conn = new SqlConnection(sourceDbConn);
            await conn.OpenAsync(ct);

            await using var cmd = new SqlCommand(sql, conn);
            cmd.CommandTimeout = 0;
            cmd.Parameters.AddWithValue("@start", rangeUtc.StartInclusiveUtc);
            cmd.Parameters.AddWithValue("@end", rangeUtc.EndExclusiveUtc);

            await using var reader = await cmd.ExecuteReaderAsync(CommandBehavior.SequentialAccess, ct);

            // Prepare blob container
            var container = new BlobContainerClient(storageConn, containerName);
            await container.CreateIfNotExistsAsync(cancellationToken: ct);

            if (!reader.HasRows)
            {
                logger.LogInformation("No rows found for export: {Prefix}", blobPrefix);
                return Result<ExportResult>.Success(new ExportResult(0, 0, 0, containerName, blobPrefix));
            }

            var (fields, schema) = schemaBuilder.BuildSchema(reader);
            logger.LogInformation("Schema built with {ColumnCount} columns", fields.Count);

            long totalRows = 0;
            long totalBytes = 0;
            int partNumber = 0;
            var hasMoreRows = true;

            // Normalize prefix: remove trailing slashes, will add one before filename
            var normalizedPrefix = blobPrefix.TrimEnd('/');

            while (hasMoreRows)
            {
                var (result, readStream) = await partWriter.WritePartAsync(
                    reader,
                    fields,
                    schema,
                    _options.RowsPerPart,
                    _options.RowGroupTargetBytes,
                    _options.SpillThresholdBytes,
                    ct);

                if (result.RowCount <= 0)
                {
                    readStream.Dispose();
                    logger.LogDebug("No more rows to write");
                    break;
                }

                partNumber++;
                var baseName = Path.GetFileNameWithoutExtension(normalizedPrefix);
                var fileName = $"{baseName}-part-{partNumber:D5}.parquet";
                var blobName = $"{normalizedPrefix}/{fileName}";

                var blobClient = container.GetBlobClient(blobName);

                await using (readStream)
                {
                    await blobClient.UploadAsync(readStream, overwrite: true, cancellationToken: ct);
                    logger.LogInformation("Part uploaded: {PartNumber}, {BlobName}, {RowCount} rows",
                        partNumber, blobName, result.RowCount);
                }

                var props = await blobClient.GetPropertiesAsync(cancellationToken: ct);
                totalBytes += props.Value.ContentLength;
                totalRows += result.RowCount;

                hasMoreRows = result.HasMoreRows;
            }

            // Write _SUCCESS marker to indicate all parts uploaded successfully
            var successBlobName = $"{normalizedPrefix}/_SUCCESS";
            var successBlobClient = container.GetBlobClient(successBlobName);
            await using (var successStream = new MemoryStream(Array.Empty<byte>()))
            {
                await successBlobClient.UploadAsync(successStream, overwrite: true, cancellationToken: ct);
                logger.LogInformation("_SUCCESS marker written: {SuccessBlobName}", successBlobName);
            }

            logger.LogInformation("Export completed successfully: {PartCount} parts, {TotalRows} rows, {TotalBytes} bytes",
                partNumber, totalRows, totalBytes);

            // Validate row count to detect partial exports
            var expectedRowCount = await GetExpectedRowCountAsync(sourceDbConn, schemaName, tableName, businessDateColumnName, rangeUtc, ct);
            if (totalRows != expectedRowCount)
            {
                logger.LogError("Row count mismatch: exported {ExportedRows}, expected {ExpectedRows}",
                    totalRows, expectedRowCount);
                return Result<ExportResult>.Fail($"Row count mismatch: exported {totalRows}, expected {expectedRowCount}");
            }

            return Result<ExportResult>.Success(new ExportResult(totalRows, partNumber, totalBytes, containerName, blobPrefix));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Export failed for {Schema}.{Table}, Date Range: {StartDate} to {EndDate}",
                schemaName, tableName, rangeUtc.StartInclusiveUtc, rangeUtc.EndExclusiveUtc);
            return Result<ExportResult>.Fail($"Export failed: {ex.Message}");
        }
    }

    private async Task<long> GetExpectedRowCountAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        BusinessDateRange rangeUtc,
        CancellationToken ct)
    {
        var fullTable = $"[{schemaName}].[{tableName}]";
        var col = $"[{businessDateColumnName}]";
        var sql = $"SELECT COUNT(*) FROM {fullTable} WHERE {col} >= @start AND {col} < @end";

        await using var conn = new SqlConnection(sourceDbConn);
        await conn.OpenAsync(ct);

        await using var cmd = new SqlCommand(sql, conn);
        cmd.CommandTimeout = 0;
        cmd.Parameters.AddWithValue("@start", rangeUtc.StartInclusiveUtc);
        cmd.Parameters.AddWithValue("@end", rangeUtc.EndExclusiveUtc);

        var result = await cmd.ExecuteScalarAsync(ct);
        return result is int intValue ? intValue : (result is long longValue ? longValue : 0L);
    }
}