﻿namespace Archival.Application.Shared.Models;

public enum RunType { Archive = 1, Lifecycle = 2 }
public enum RunStatus { Running = 1, Succeeded = 2, Failed = 3, PartiallySucceeded = 4 }
public enum DatasetStatus { Pending = 1, Succeeded = 2, Failed = 3, Partial = 4 }
public enum RunItemType { Dataset = 1, Prefix = 2 }
public enum RunItemStatus { Pending = 1, Succeeded = 2, Failed = 3, Skipped = 4 }
public enum LifecycleAction { None = 0, SetCold = 1, SetArchive = 2, Delete = 3, Skip = 4 }
public enum DateType { EOD = 1, EOM = 2, EOQ = 3, EOY = 4 }
public enum BusinessDateSource { FromFileName = 1, CreatedOn = 2, LastModified = 3 }

// Value Objects (shared domain types)
public sealed record BusinessDate(DateOnly Value)
{
    public override string ToString() => Value.ToString("yyyy-MM-dd");
}

public sealed record BusinessDateRange(DateTime StartInclusiveUtc, DateTime EndExclusiveUtc);

public sealed record BlobItem(
    string Name,
    long? ContentLength,
    DateTime CreatedAtUtc,
    DateTime LastModifiedUtc,
    string? AccessTier);

public sealed record DateFolderDeletionResult(
    int BlobsDeleted,
    bool MarkerDeleted,
    bool HnsDirectoryDeleted,
    bool HnsSupported);
