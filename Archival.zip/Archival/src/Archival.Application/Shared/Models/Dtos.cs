﻿﻿namespace Archival.Application.Shared.Models;

public sealed record RunDto(
    long Id,
    RunType RunType,
    DateTime StartedAt,
    DateTime? EndedAt,
    RunStatus Status,
    string? Note);

public sealed record TableConfigurationDto(
    int Id,
    bool IsActive,
    string DatabaseName,
    string SchemaName,
    string TableName,
    string BusinessDateColumnName,
    int TablePolicyId,
    int BlobPolicyId,
    string ArchivePathTemplate,
    bool DeleteAfterExport,
    int BatchDeleteSize);

public sealed record TableRetentionPolicyDto(
    int Id,
    bool IsActive,
    int? KeepLastEod,
    int? KeepLastEom,
    int? KeepLastEoq,
    int? KeepLastEoy);

public sealed record BlobConfigurationDto(
    int Id,
    bool IsEnabled,
    string StorageAccountName,
    string ContainerName,
    string Prefix,
    string? IncludePattern,
    string? ExcludePattern,
    bool SupportsArchiveTier,
    BusinessDateSource BusinessDateSource,
    int BlobPolicyId);

public sealed record LifecyclePolicyDto(
    int Id,
    bool IsActive,
    int? ColdMinAgeDays,
    int? ArchiveMinAgeDays,
    int? DeleteMinAgeDays);

public sealed record BlobItemDto(
    string Name,
    long? ContentLength,
    DateTime CreatedAtUtc,
    DateTime LastModifiedUtc,
    string? AccessTier);

public sealed record DateFolderDeletionResultDto(
    int BlobsDeleted,
    bool MarkerDeleted,
    bool HnsDirectoryDeleted,
    bool HnsSupported);

public sealed record ExportResultDto(
    int PartCount,
    long RowCount,
    long TotalBytes);

public sealed record DatasetDto(
    long DatasetId,
    DateOnly AsOfDate,
    DateType DateType,
    string StorageAccountName,
    string ContainerName,
    string BlobPrefix);

public sealed record DatasetDetailDto(
    long DatasetId,
    DateOnly AsOfDate,
    DateType DateType,
    string StorageAccountName,
    string ContainerName,
    string BlobPrefix,
    DatasetStatus Status);

