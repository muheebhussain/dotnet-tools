﻿namespace Archival.Application.Shared.Results;

public sealed class Result
{
    public bool Ok { get; init; }
    public string? Error { get; init; }

    public static Result Success() => new() { Ok = true };
    public static Result Fail(string error) => new() { Ok = false, Error = error };
}

public sealed class Result<T>
{
    public bool Ok { get; init; }
    public T? Value { get; init; }
    public string? Error { get; init; }

    public static Result<T> Success(T value) => new() { Ok = true, Value = value };
    public static Result<T> Fail(string error) => new() { Ok = false, Error = error };
}

