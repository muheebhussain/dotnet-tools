﻿namespace Archival.Application.Contracts.Configuration;

/// <summary>
/// Contract for resolving connection strings by storage account name.
/// </summary>
public interface IConnectionStringResolver
{
    string ResolveStorageConnection(string storageAccountName);
    string ResolveSourceConnection(string databaseName);
}

