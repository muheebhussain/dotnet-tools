﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Infrastructure;

public interface IBlobLister
{
    IAsyncEnumerable<BlobItem> ListBlobsAsync(string storageConn, string containerName, string prefix, CancellationToken ct);
}

public interface IBlobTierManager
{
    Task<bool> TrySetColdAsync(string storageConn, string containerName, string blobName, CancellationToken ct);
    Task<bool> TrySetArchiveAsync(string storageConn, string containerName, string blobName, CancellationToken ct);
    Task<bool> TryDeleteAsync(string storageConn, string containerName, string blobName, CancellationToken ct);
    Task<Result<DateFolderDeletionResult>> DeleteDateFolderAsync(string storageConn, string containerName, string datePrefix, CancellationToken ct);
}

public interface IBlobBusinessDateExtractor
{
    bool TryExtractDateFromPath(string blobName, out DateOnly date);
    bool TryExtractDateFromPathSegment(string blobName, string configuredPrefix, out DateOnly date);
}

