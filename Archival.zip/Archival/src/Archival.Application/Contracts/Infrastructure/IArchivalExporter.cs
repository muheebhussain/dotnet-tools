﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Infrastructure;

public sealed record ExportResult(long RowCount, int PartCount, long TotalBytes, string BlobContainer, string BlobPrefix);

public interface IArchivalExporter
{
    Task<Result<ExportResult>> ExportToMultipartParquetAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        BusinessDateRange rangeUtc,
        string storageConn,
        string containerName,
        string blobPrefix,
        CancellationToken ct);
}

public interface ISourceDeleter
{
    Task<Result<long>> DeleteByBusinessDateRangeAsync(
        string sourceDbConn,
        string schemaName,
        string tableName,
        string businessDateColumnName,
        BusinessDateRange rangeUtc,
        int batchSize,
        CancellationToken ct);
}

