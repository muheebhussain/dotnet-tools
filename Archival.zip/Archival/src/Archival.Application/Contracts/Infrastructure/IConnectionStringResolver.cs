﻿namespace Archival.Application.Contracts.Infrastructure;

public interface IConnectionStringResolver
{
    string GetDatabaseConnection(string databaseName);
    string GetStorageConnection(string storageAccountName);
}

