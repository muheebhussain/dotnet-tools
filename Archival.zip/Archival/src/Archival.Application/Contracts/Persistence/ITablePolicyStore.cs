﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for table policy/retention configuration access.
/// </summary>
public interface ITablePolicyStore
{
    Task<TableRetentionPolicyDto?> GetTableRetentionPolicyAsync(int id, CancellationToken ct);
}

