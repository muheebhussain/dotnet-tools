﻿﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for dataset tracking and lifecycle management.
/// </summary>
public interface IDatasetStore
{
    Task<bool> DatasetExistsAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct);
    Task<DatasetDetailDto?> GetDatasetAsync(int tableConfigId, DateOnly asOfDate, CancellationToken ct);
    Task<long> CreateDatasetAsync(int tableConfigId, DateOnly asOfDate, DateType dateType, string storageAccountName, string containerName, string blobPrefix, CancellationToken ct);
    Task MarkDatasetSucceededAsync(long datasetId, int partCount, long rowCount, long totalBytes, CancellationToken ct);
    Task MarkDatasetFailedAsync(long datasetId, string errorSummary, CancellationToken ct);
    Task<IReadOnlyList<DatasetDto>> GetSucceededDatasetsAsync(CancellationToken ct);
}

