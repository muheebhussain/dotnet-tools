﻿namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for exemption access (table and blob exemptions).
/// </summary>
public interface IExemptionsStore
{
    Task<IReadOnlySet<(int TableConfigurationId, DateOnly AsOfDate)>> GetTableExemptionsAsync(int tableConfigurationId, CancellationToken ct);
    Task<IReadOnlySet<(string Container, string Prefix, DateOnly Date)>> GetBlobExemptionsAsync(int blobConfigurationId, CancellationToken ct);
}

