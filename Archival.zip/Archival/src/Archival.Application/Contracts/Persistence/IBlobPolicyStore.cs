﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for blob policy/lifecycle configuration access.
/// </summary>
public interface IBlobPolicyStore
{
    Task<LifecyclePolicyDto?> GetLifecyclePolicyAsync(int id, CancellationToken ct);
}

