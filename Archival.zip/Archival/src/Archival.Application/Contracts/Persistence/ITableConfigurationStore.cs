﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Contracts.Persistence;

/// <summary>
/// Contract for accessing table configuration data from the metadata database.
/// Provides operations to retrieve table archival settings.
/// </summary>
public interface ITableConfigurationStore
{
    /// <summary>
    /// Retrieves all active table configurations that are enabled for archival.
    /// </summary>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>List of active table configurations.</returns>
    Task<IReadOnlyList<TableConfigurationDto>> GetActiveTableConfigurationsAsync(CancellationToken ct);

    /// <summary>
    /// Retrieves a specific table configuration by its ID.
    /// </summary>
    /// <param name="id">Table configuration ID.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Table configuration DTO, or null if not found.</returns>
    Task<TableConfigurationDto?> GetTableConfigurationAsync(int id, CancellationToken ct);
}

