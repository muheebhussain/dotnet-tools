﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Tables;

/// <summary>
/// Contract for archiving table data (export to parquet + optional deletion).
/// </summary>
public interface ITableArchiver
{
    Task<IReadOnlyList<DateOnly>> GetPresentDatesAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken ct);

    Task<Result<ExportResultDto>> ExportToParquetAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateOnly businessDate,
        string storageConnectionString,
        string containerName,
        string blobPrefix,
        CancellationToken ct);

    Task<Result> DeleteRowsAsync(
        string connectionString,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateOnly businessDate,
        int batchSize,
        CancellationToken ct);
}

