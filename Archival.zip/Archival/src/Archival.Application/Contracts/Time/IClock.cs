﻿namespace Archival.Application.Contracts.Time;

/// <summary>
/// Provides access to current system time for testability.
/// </summary>
public interface IClock
{
    DateTime UtcNow { get; }
    DateTime Now { get; }
    DateOnly Today { get; }
}

