﻿using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;

namespace Archival.Application.Contracts.Storage;

/// <summary>
/// Contract for executing blob lifecycle actions in Azure Blob Storage.
/// Provides operations to change blob access tiers and delete blobs/folders.
/// </summary>
public interface IBlobLifecycleExecutor
{
    /// <summary>
    /// Attempts to change a blob's access tier to Cool (Cold).
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if tier change succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TrySetColdAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Attempts to change a blob's access tier to Archive.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if tier change succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TrySetArchiveAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Attempts to delete a blob.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the blob.</param>
    /// <param name="blobName">Full blob path.</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>True if deletion succeeded, false if blob not found or operation failed.</returns>
    Task<bool> TryDeleteAsync(string storageConnectionString, string containerName, string blobName, CancellationToken ct);

    /// <summary>
    /// Deletes all blobs under a date-based folder prefix and the folder marker itself.
    /// Handles both flat namespace and hierarchical namespace (ADLS Gen2) storage.
    /// </summary>
    /// <param name="storageConnectionString">Azure Storage connection string.</param>
    /// <param name="containerName">Container containing the folder.</param>
    /// <param name="datePrefix">Date folder prefix (e.g., "archive/2026-02-15/").</param>
    /// <param name="ct">Cancellation token to cancel the operation.</param>
    /// <returns>Result containing deletion statistics (blobs deleted, marker deleted, HNS directory deleted).</returns>
    Task<Result<DateFolderDeletionResultDto>> DeleteDateFolderAsync(string storageConnectionString, string containerName, string datePrefix, CancellationToken ct);
}

