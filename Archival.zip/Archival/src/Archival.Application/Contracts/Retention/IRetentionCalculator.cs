﻿namespace Archival.Application.Contracts.Retention;

/// <summary>
/// Contract for calculating which dates to retain based on retention policy.
/// </summary>
public interface IRetentionCalculator
{
    Task<IReadOnlySet<DateOnly>> CalculateKeepDatesAsync(
        int tableConfigurationId,
        IReadOnlyList<DateOnly> presentDates,
        CancellationToken ct);
}

