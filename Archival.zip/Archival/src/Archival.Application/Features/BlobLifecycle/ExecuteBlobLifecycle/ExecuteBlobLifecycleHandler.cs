﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Storage;
using Archival.Application.Contracts.Time;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.BlobLifecycle.ExecuteBlobLifecycle;

public sealed class ExecuteBlobLifecycleHandler(
    IBlobConfigurationStore blobConfigurationStore,
    IBlobPolicyStore blobPolicyStore,
    IExemptionsStore exemptionsStore,
    IConnectionStringResolver connectionStringResolver,
    IBlobInventory blobInventory,
    IBlobLifecycleExecutor blobLifecycleExecutor,
    IClock clock,
    ILogger<ExecuteBlobLifecycleHandler> logger)
{
    public async Task<Result<ExecuteBlobLifecycleResponse>> HandleAsync(ExecuteBlobLifecycleCommand command, CancellationToken ct)
    {
        logger.LogInformation("Executing blob lifecycle: BlobConfigId={BlobConfigId}, Date={Date}",
            command.BlobConfigurationId, command.BusinessDate);

        // Load configuration
        var config = await blobConfigurationStore.GetBlobConfigurationAsync(command.BlobConfigurationId, ct);
        if (config is null)
            return Result<ExecuteBlobLifecycleResponse>.Fail($"Blob configuration {command.BlobConfigurationId} not found");

        var policy = await blobPolicyStore.GetLifecyclePolicyAsync(config.BlobPolicyId, ct);
        if (policy is null || !policy.IsActive)
            return Result<ExecuteBlobLifecycleResponse>.Fail($"Lifecycle policy {config.BlobPolicyId} not found or inactive");

        var storageConn = connectionStringResolver.ResolveStorageConnection(config.StorageAccountName);

        // Load blob exemptions once for this configuration
        var exemptions = await exemptionsStore.GetBlobExemptionsAsync(command.BlobConfigurationId, ct);
        logger.LogInformation("Loaded {ExemptionCount} blob exemptions for config {ConfigId}",
            exemptions.Count, command.BlobConfigurationId);

        // List blobs
        var blobs = await blobInventory.ListBlobsAsync(storageConn, config.ContainerName, config.Prefix, ct);

        logger.LogInformation("Found {Count} blobs under prefix {Prefix}", blobs.Count, config.Prefix);

        int coldCount = 0, archiveCount = 0, deleteCount = 0;
        int exemptedCount = 0;

        // Process each blob
        foreach (var blob in blobs)
        {
            // Extract date and calculate age
            if (!blobInventory.TryExtractDateFromPathSegment(blob.Name, config.Prefix, out var blobDate))
                blobDate = DateOnly.FromDateTime(blob.CreatedAtUtc);

            // Check if blob matches any exemption
            if (IsExempted(blob.Name, config.ContainerName, blobDate, exemptions))
            {
                logger.LogDebug("Blob exempted: Container={Container}, BlobName={BlobName}, ConfigId={ConfigId}",
                    config.ContainerName, blob.Name, command.BlobConfigurationId);
                exemptedCount++;
                continue; // Skip this blob
            }

            var ageDays = (int)(clock.Today.DayNumber - blobDate.DayNumber);

            // Skip blobs with future dates (anomaly in path parsing or system clock)
            if (ageDays < 0)
            {
                logger.LogWarning("Blob has future date: {BlobName}, Date={Date}", blob.Name, blobDate);
                continue;
            }

            // Determine action based on policy
            LifecycleAction action = LifecycleAction.Skip;

            if (policy.DeleteMinAgeDays.HasValue && ageDays >= policy.DeleteMinAgeDays.Value)
                action = LifecycleAction.Delete;
            else if (policy.ArchiveMinAgeDays.HasValue && ageDays >= policy.ArchiveMinAgeDays.Value)
                action = config.SupportsArchiveTier ? LifecycleAction.SetArchive : LifecycleAction.SetCold;
            else if (policy.ColdMinAgeDays.HasValue && ageDays >= policy.ColdMinAgeDays.Value)
                action = LifecycleAction.SetCold;

            // Execute action
            bool success = action switch
            {
                LifecycleAction.SetCold => await blobLifecycleExecutor.TrySetColdAsync(storageConn, config.ContainerName, blob.Name, ct),
                LifecycleAction.SetArchive => await blobLifecycleExecutor.TrySetArchiveAsync(storageConn, config.ContainerName, blob.Name, ct),
                LifecycleAction.Delete => await blobLifecycleExecutor.TryDeleteAsync(storageConn, config.ContainerName, blob.Name, ct),
                _ => true
            };

            if (success)
            {
                switch (action)
                {
                    case LifecycleAction.SetCold: coldCount++; break;
                    case LifecycleAction.SetArchive: archiveCount++; break;
                    case LifecycleAction.Delete: deleteCount++; break;
                }
            }
        }

        logger.LogInformation("Blob lifecycle completed: Scanned={Scanned}, Exempted={Exempted}, Cold={Cold}, Archive={Archive}, Delete={Delete}",
            blobs.Count, exemptedCount, coldCount, archiveCount, deleteCount);

        return Result<ExecuteBlobLifecycleResponse>.Success(new ExecuteBlobLifecycleResponse(blobs.Count, coldCount, archiveCount, deleteCount));
    }

    /// <summary>
    /// Checks if a blob matches any exemption rule.
    ///
    /// Matching criteria:
    /// 1. Container name must match
    /// 2. Blob name must start with exemption prefix
    /// 3. If exemption has a date constraint, blob date must match
    /// </summary>
    private static bool IsExempted(
        string blobName,
        string containerName,
        DateOnly blobDate,
        IReadOnlySet<(string Container, string Prefix, DateOnly Date)> exemptions)
    {
        foreach (var (exemptContainer, exemptPrefix, exemptDate) in exemptions)
        {
            // Container must match exactly
            if (!string.Equals(exemptContainer, containerName, StringComparison.OrdinalIgnoreCase))
                continue;

            // Blob name must start with exemption prefix
            if (!blobName.StartsWith(exemptPrefix, StringComparison.OrdinalIgnoreCase))
                continue;

            // Date must match (exemption is specific to a date)
            if (blobDate != exemptDate)
                continue;

            // All criteria matched
            return true;
        }

        return false;
    }
}

