﻿namespace Archival.Application.Features.BlobLifecycle.ExecuteBlobLifecycle;

public sealed record ExecuteBlobLifecycleCommand(
    int BlobConfigurationId,
    DateOnly BusinessDate);

public sealed record ExecuteBlobLifecycleResponse(
    int BlobsScanned,
    int ColdCount,
    int ArchiveCount,
    int DeleteCount);

