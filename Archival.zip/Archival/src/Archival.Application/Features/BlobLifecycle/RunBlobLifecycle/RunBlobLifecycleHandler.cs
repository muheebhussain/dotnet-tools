﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.BlobLifecycle.RunBlobLifecycle;

public sealed class RunBlobLifecycleHandler(
    IRunItemsStore runItemsStore,
    IBlobConfigurationStore blobConfigStore,
    IDatasetStore datasetStore,
    Runs.StartRun.StartRunHandler startRunHandler,
    Runs.CompleteRun.CompleteRunHandler completeRunHandler,
    ExecuteBlobLifecycle.ExecuteBlobLifecycleHandler executeBlobLifecycleHandler,
    ILogger<RunBlobLifecycleHandler> logger)
{
    public async Task<Result> HandleAsync(RunBlobLifecycleCommand command, CancellationToken ct)
    {
        var runId = -1L;
        bool anyFailed = false;
        int totalScanned = 0;
        int totalCold = 0;
        int totalArchive = 0;
        int totalDelete = 0;

        try
        {
            // Start run
            logger.LogInformation("Starting blob lifecycle run");
            var startResult = await startRunHandler.HandleAsync(
                new Runs.StartRun.StartRunCommand(RunType.Lifecycle), ct);

            if (!startResult.Ok || startResult.Value is null)
            {
                logger.LogError("Failed to start run: {Error}", startResult.Error);
                return Result.Fail(startResult.Error ?? "Failed to start run");
            }

            runId = startResult.Value.RunId;
            logger.LogInformation("Lifecycle run started: RunId={RunId}", runId);

            // Get blob configurations
            var blobConfigs = command.TargetId.HasValue
                ? new[] { await blobConfigStore.GetBlobConfigurationAsync(command.TargetId.Value, ct) }
                    .Where(t => t is not null).ToList()!
                : (await blobConfigStore.GetEnabledBlobConfigurationsAsync(ct)).ToList();

            logger.LogInformation("Processing {Count} blob configuration(s)", blobConfigs.Count);

            foreach (var config in blobConfigs)
            {
                if (!config.IsEnabled)
                {
                    logger.LogDebug("Skipping disabled blob configuration: {ConfigId}", config.Id);
                    continue;
                }

                logger.LogInformation("Processing blob configuration: ConfigId={ConfigId}, Container={Container}, Prefix={Prefix}",
                    config.Id, config.ContainerName, config.Prefix);

                try
                {
                    // Get succeeded datasets to process as well
                    var datasets = await datasetStore.GetSucceededDatasetsAsync(ct);

                    // Process the configured prefix
                    logger.LogInformation("Executing lifecycle for prefix: {Prefix}", config.Prefix);

                    // Execute lifecycle without specific date (processes all blobs under prefix)
                    var lifecycleResult = await executeBlobLifecycleHandler.HandleAsync(
                        new ExecuteBlobLifecycle.ExecuteBlobLifecycleCommand(
                            config.Id,
                            DateOnly.FromDateTime(DateTime.UtcNow)), ct);

                    if (lifecycleResult.Ok && lifecycleResult.Value is not null)
                    {
                        totalScanned += lifecycleResult.Value.BlobsScanned;
                        totalCold += lifecycleResult.Value.ColdCount;
                        totalArchive += lifecycleResult.Value.ArchiveCount;
                        totalDelete += lifecycleResult.Value.DeleteCount;

                        logger.LogInformation("Lifecycle completed for prefix: Scanned={Scanned}, Cold={Cold}, Archive={Archive}, Delete={Delete}",
                            lifecycleResult.Value.BlobsScanned,
                            lifecycleResult.Value.ColdCount,
                            lifecycleResult.Value.ArchiveCount,
                            lifecycleResult.Value.DeleteCount);

                        // Record run item
                        await runItemsStore.AddRunItemAsync(
                            runId,
                            RunItemType.Prefix,
                            RunItemStatus.Succeeded,
                            blobConfigurationId: config.Id,
                            itemKey: $"{config.ContainerName}/{config.Prefix}",
                            ct: ct);
                    }
                    else
                    {
                        anyFailed = true;
                        logger.LogError("Lifecycle failed for prefix: {Prefix}, Error={Error}",
                            config.Prefix, lifecycleResult.Error);

                        await runItemsStore.AddRunItemAsync(
                            runId,
                            RunItemType.Prefix,
                            RunItemStatus.Failed,
                            blobConfigurationId: config.Id,
                            itemKey: $"{config.ContainerName}/{config.Prefix}",
                            error: lifecycleResult.Error,
                            ct: ct);
                    }

                    // Process succeeded datasets (archived data that now needs lifecycle management)
                    foreach (var dataset in datasets.Where(d => d.ContainerName == config.ContainerName &&
                                                                 d.BlobPrefix.StartsWith(config.Prefix)))
                    {
                        logger.LogInformation("Processing dataset lifecycle: DatasetId={DatasetId}, Date={Date}, Prefix={Prefix}",
                            dataset.DatasetId, dataset.AsOfDate, dataset.BlobPrefix);

                        var datasetLifecycleResult = await executeBlobLifecycleHandler.HandleAsync(
                            new ExecuteBlobLifecycle.ExecuteBlobLifecycleCommand(config.Id, dataset.AsOfDate), ct);

                        if (datasetLifecycleResult.Ok && datasetLifecycleResult.Value is not null)
                        {
                            totalScanned += datasetLifecycleResult.Value.BlobsScanned;
                            totalCold += datasetLifecycleResult.Value.ColdCount;
                            totalArchive += datasetLifecycleResult.Value.ArchiveCount;
                            totalDelete += datasetLifecycleResult.Value.DeleteCount;

                            await runItemsStore.AddRunItemAsync(
                                runId,
                                RunItemType.Prefix,
                                RunItemStatus.Succeeded,
                                blobConfigurationId: config.Id,
                                asOfDate: dataset.AsOfDate,
                                itemKey: dataset.BlobPrefix,
                                ct: ct);
                        }
                    }
                }
                catch (Exception ex)
                {
                    anyFailed = true;
                    logger.LogError(ex, "Error processing blob configuration: ConfigId={ConfigId}", config.Id);

                    await runItemsStore.AddRunItemAsync(
                        runId,
                        RunItemType.Prefix,
                        RunItemStatus.Failed,
                        blobConfigurationId: config.Id,
                        itemKey: $"{config.ContainerName}/{config.Prefix}",
                        error: ex.Message,
                        ct: ct);
                }
            }

            // Complete run
            var finalStatus = anyFailed
                ? (totalScanned > 0 ? RunStatus.PartiallySucceeded : RunStatus.Failed)
                : RunStatus.Succeeded;

            await completeRunHandler.HandleAsync(
                new Runs.CompleteRun.CompleteRunCommand(runId, finalStatus,
                    $"Scanned {totalScanned} blobs: {totalCold} cold, {totalArchive} archive, {totalDelete} deleted"), ct);

            logger.LogInformation("Lifecycle run completed: RunId={RunId}, Status={Status}, Scanned={Scanned}, Cold={Cold}, Archive={Archive}, Delete={Delete}",
                runId, finalStatus, totalScanned, totalCold, totalArchive, totalDelete);

            return anyFailed ? Result.Fail("Some blob configurations failed") : Result.Success();
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            logger.LogWarning("Blob lifecycle was cancelled");

            // Try to complete the run if it was started
            if (runId > 0)
            {
                try
                {
                    await completeRunHandler.HandleAsync(
                        new Runs.CompleteRun.CompleteRunCommand(runId, RunStatus.Failed,
                            "Cancelled by user"), ct: default); // Use default ct to avoid cancellation during cleanup
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after cancellation");
                }
            }

            return Result.Fail("Blob lifecycle cancelled by user");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Blob lifecycle orchestration failed");

            // Try to complete the run if it was started
            if (runId > 0)
            {
                try
                {
                    await completeRunHandler.HandleAsync(
                        new Runs.CompleteRun.CompleteRunCommand(runId, RunStatus.Failed, ex.Message), ct);
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after error");
                }
            }

            return Result.Fail($"Blob lifecycle failed: {ex.Message}");
        }
    }
}

