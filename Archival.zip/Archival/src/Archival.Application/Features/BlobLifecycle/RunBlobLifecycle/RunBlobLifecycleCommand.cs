﻿namespace Archival.Application.Features.BlobLifecycle.RunBlobLifecycle;

public sealed record RunBlobLifecycleCommand(
    bool AllTargets,
    int? TargetId = null);

