﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.BuildTableArchivalPlan;

public sealed class BuildTableArchivalPlanHandler(
    ITableConfigurationStore tableConfigStore,
    ITablePolicyStore tablePolicyStore,
    ILogger<BuildTableArchivalPlanHandler> logger)
{
    public async Task<Result<TableArchivalPlan>> HandleAsync(BuildTableArchivalPlanQuery query, CancellationToken ct)
    {
        logger.LogInformation("Building table archival plan: TableConfigId={ConfigId}", query.TableConfigurationId);

        // Load table configuration
        var tableConfig = await tableConfigStore.GetTableConfigurationAsync(query.TableConfigurationId, ct);
        if (tableConfig is null)
            return Result<TableArchivalPlan>.Fail($"Table configuration {query.TableConfigurationId} not found");

        // Load table policy for retention/date type information (if needed in future)
        var tablePolicy = await tablePolicyStore.GetTableRetentionPolicyAsync(tableConfig.TablePolicyId, ct);

        // Build plan from configuration with explicit defaults
        var plan = new TableArchivalPlan(
            TableConfigurationId: tableConfig.Id,
            SchemaName: tableConfig.SchemaName,
            TableName: tableConfig.TableName,
            BusinessDateColumnName: tableConfig.BusinessDateColumnName,
            // Storage/container configuration (currently defaults, could be extended to config in future)
            StorageAccountName: "default", // Could come from table config in future
            ContainerName: "archive",       // Could come from table config in future
            BaseBlobPrefix: tableConfig.ArchivePathTemplate ?? $"{tableConfig.SchemaName}/{tableConfig.TableName}/",
            // Date type (currently hardcoded to EOD, could be derived from policy)
            DateType: DateType.EOD,        // Could come from table policy or business logic in future
                                           // Delete behavior from config
            DeleteAfterExport: tableConfig.DeleteAfterExport,
            BatchDeleteSize: tableConfig.BatchDeleteSize);

        logger.LogInformation(
            "Plan built: Schema={Schema}, Table={Table}, Storage={Account}/{Container}, DeleteAfterExport={Delete}",
            plan.SchemaName, plan.TableName, plan.StorageAccountName, plan.ContainerName, plan.DeleteAfterExport);

        return Result<TableArchivalPlan>.Success(plan);
    }
}

