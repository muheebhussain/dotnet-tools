﻿namespace Archival.Application.Features.TableArchival.BuildTableArchivalPlan;

public sealed record BuildTableArchivalPlanQuery(
    int TableConfigurationId);

