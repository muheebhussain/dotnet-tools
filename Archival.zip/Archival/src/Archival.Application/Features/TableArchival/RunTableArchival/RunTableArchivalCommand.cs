﻿namespace Archival.Application.Features.TableArchival.RunTableArchival;

public sealed record RunTableArchivalCommand(
    bool AllActive,
    int? TableConfigId = null);

