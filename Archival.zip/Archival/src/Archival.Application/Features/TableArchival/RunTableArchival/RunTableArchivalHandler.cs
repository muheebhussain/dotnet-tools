﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Retention;
using Archival.Application.Contracts.Tables;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.RunTableArchival;

public sealed class RunTableArchivalHandler(
    IRunItemsStore runItemsStore,
    ITableConfigurationStore tableConfigStore,
    IExemptionsStore exemptionsStore,
    IDatasetStore datasetStore,
    IRetentionCalculator retentionCalculator,
    ITableArchiver tableArchiver,
    IConnectionStringResolver connectionResolver,
    Runs.StartRun.StartRunHandler startRunHandler,
    Runs.CompleteRun.CompleteRunHandler completeRunHandler,
    ExecuteTableArchival.ExecuteTableArchivalHandler executeTableArchivalHandler,
    ILogger<RunTableArchivalHandler> logger)
{
    public async Task<Result> HandleAsync(RunTableArchivalCommand command, CancellationToken ct)
    {
        var runId = -1L;
        bool anyFailed = false;
        int successCount = 0;

        try
        {
            // Start run
            logger.LogInformation("Starting table archival run");
            var startResult = await startRunHandler.HandleAsync(
                new Runs.StartRun.StartRunCommand(RunType.Archive), ct);

            if (!startResult.Ok || startResult.Value is null)
            {
                logger.LogError("Failed to start run: {Error}", startResult.Error);
                return Result.Fail(startResult.Error ?? "Failed to start run");
            }

            runId = startResult.Value.RunId;
            logger.LogInformation("Archive run started: RunId={RunId}", runId);

            // Get table configurations
            var tables = command.TableConfigId.HasValue
                ? new[] { await tableConfigStore.GetTableConfigurationAsync(command.TableConfigId.Value, ct) }
                    .Where(t => t is not null).ToList()!
                : (await tableConfigStore.GetActiveTableConfigurationsAsync(ct)).ToList();

            logger.LogInformation("Processing {Count} table(s)", tables.Count);

            foreach (var table in tables)
            {
                if (!table.IsActive)
                {
                    logger.LogDebug("Skipping inactive table: {Schema}.{Table}", table.SchemaName, table.TableName);
                    continue;
                }

                logger.LogInformation("Processing table: Schema={Schema}, Table={Table}, ConfigId={ConfigId}",
                    table.SchemaName, table.TableName, table.Id);

                try
                {
                    // Get connection string
                    var sourceConn = connectionResolver.ResolveSourceConnection(table.DatabaseName);

                    // Get present dates from the table (all available dates, no time window limit)
                    var from = DateOnly.MinValue;
                    var to = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(1));
                    var presentDates = await tableArchiver.GetPresentDatesAsync(
                        sourceConn, table.SchemaName, table.TableName, table.BusinessDateColumnName, from.ToDateTime(TimeOnly.MinValue), to.ToDateTime(TimeOnly.MinValue), ct);

                    logger.LogInformation("Found {Count} distinct dates in table {Schema}.{Table}",
                        presentDates.Count, table.SchemaName, table.TableName);

                    if (presentDates.Count > 10000)
                    {
                        logger.LogWarning("Unusually large number of distinct dates found: {Count} for table {Schema}.{Table}. " +
                            "This may impact performance.", presentDates.Count, table.SchemaName, table.TableName);
                    }

                    // Calculate keep set using retention calculator
                    var keepSet = await retentionCalculator.CalculateKeepDatesAsync(table.Id, presentDates, ct);
                    logger.LogInformation("Keep set calculated: {KeepCount} dates to retain for table {Schema}.{Table}",
                        keepSet.Count, table.SchemaName, table.TableName);

                    // Get exemptions
                    var exemptions = await exemptionsStore.GetTableExemptionsAsync(table.Id, ct);
                    logger.LogInformation("Found {Count} exemption(s) for table {Schema}.{Table}",
                        exemptions.Count, table.SchemaName, table.TableName);

                    // Calculate candidates (present dates - keep dates - exemptions - already archived)
                    var candidates = presentDates
                        .Where(d => !keepSet.Contains(d))
                        .Where(d => !exemptions.Any(e => e.TableConfigurationId == table.Id && e.AsOfDate == d))
                        .ToList();

                    logger.LogInformation("Archive candidates: {Count} date(s) for table {Schema}.{Table}",
                        candidates.Count, table.SchemaName, table.TableName);

                    // Process each candidate date
                    foreach (var businessDate in candidates)
                    {
                        // Check if already successfully archived (allow retry of failed datasets)
                        var existingDataset = await datasetStore.GetDatasetAsync(table.Id, businessDate, ct);
                        if (existingDataset?.Status == DatasetStatus.Succeeded)
                        {
                            logger.LogDebug("Dataset already successfully archived: Table={Schema}.{Table}, Date={Date}",
                                table.SchemaName, table.TableName, businessDate);
                            continue;
                        }

                        if (existingDataset?.Status == DatasetStatus.Failed)
                        {
                            logger.LogInformation("Retrying previously failed dataset: Table={Schema}.{Table}, Date={Date}",
                                table.SchemaName, table.TableName, businessDate);
                        }

                        logger.LogInformation("Archiving: Table={Schema}.{Table}, Date={Date}",
                            table.SchemaName, table.TableName, businessDate);

                        // Execute archival for this date
                        var archiveResult = await executeTableArchivalHandler.HandleAsync(
                            new ExecuteTableArchival.ExecuteTableArchivalCommand(table.Id, businessDate), ct);

                        // Record run item
                        var itemStatus = archiveResult.Ok
                            ? RunItemStatus.Succeeded
                            : RunItemStatus.Failed;

                        await runItemsStore.AddRunItemAsync(
                            runId,
                            RunItemType.Dataset,
                            itemStatus,
                            tableConfigurationId: table.Id,
                            asOfDate: businessDate,
                            rowsAffected: archiveResult.Ok ? archiveResult.Value?.RowsArchived : null,
                            bytesAffected: archiveResult.Ok ? archiveResult.Value?.BytesArchived : null,
                            error: archiveResult.Ok ? null : archiveResult.Error,
                            ct: ct);

                        if (archiveResult.Ok)
                        {
                            successCount++;
                            logger.LogInformation("Successfully archived: Table={Schema}.{Table}, Date={Date}, Rows={Rows}, Bytes={Bytes}",
                                table.SchemaName, table.TableName, businessDate,
                                archiveResult.Value?.RowsArchived ?? 0, archiveResult.Value?.BytesArchived ?? 0);
                        }
                        else
                        {
                            anyFailed = true;
                            logger.LogError("Failed to archive: Table={Schema}.{Table}, Date={Date}, Error={Error}",
                                table.SchemaName, table.TableName, businessDate, archiveResult.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    anyFailed = true;
                    logger.LogError(ex, "Error processing table: {Schema}.{Table}", table.SchemaName, table.TableName);

                    await runItemsStore.AddRunItemAsync(
                        runId,
                        RunItemType.Dataset,
                        RunItemStatus.Failed,
                        tableConfigurationId: table.Id,
                        error: ex.Message,
                        ct: ct);
                }
            }

            // Complete run
            var finalStatus = anyFailed
                ? (successCount > 0 ? RunStatus.PartiallySucceeded : RunStatus.Failed)
                : RunStatus.Succeeded;

            await completeRunHandler.HandleAsync(
                new Runs.CompleteRun.CompleteRunCommand(runId, finalStatus,
                    $"Processed {tables.Count} table(s), {successCount} successful archive(s)"), ct);

            logger.LogInformation("Archive run completed: RunId={RunId}, Status={Status}, Success={Success}, Failed={Failed}",
                runId, finalStatus, successCount, anyFailed);

            return anyFailed ? Result.Fail("Some tables failed to archive") : Result.Success();
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            logger.LogWarning("Table archival was cancelled");

            // Try to complete the run if it was started
            if (runId > 0)
            {
                try
                {
                    await completeRunHandler.HandleAsync(
                        new Runs.CompleteRun.CompleteRunCommand(runId, RunStatus.Failed,
                            "Cancelled by user"), ct: default); // Use default ct to avoid cancellation during cleanup
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after cancellation");
                }
            }

            return Result.Fail("Table archival cancelled by user");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Table archival orchestration failed");

            // Try to complete the run if it was started
            if (runId > 0)
            {
                try
                {
                    await completeRunHandler.HandleAsync(
                        new Runs.CompleteRun.CompleteRunCommand(runId, RunStatus.Failed, ex.Message), ct);
                }
                catch (Exception completeEx)
                {
                    logger.LogError(completeEx, "Failed to complete run after error");
                }
            }

            return Result.Fail($"Table archival failed: {ex.Message}");
        }
    }
}

