﻿using Archival.Application.Contracts.Configuration;
using Archival.Application.Contracts.Persistence;
using Archival.Application.Contracts.Tables;
using Archival.Application.Features.TableArchival.BuildTableArchivalPlan;
using Archival.Application.Shared.Models;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.TableArchival.ExecuteTableArchival;

public sealed class ExecuteTableArchivalHandler(
    IDatasetStore datasetStore,
    IConnectionStringResolver connectionStringResolver,
    ITableArchiver tableArchiver,
    BuildTableArchivalPlanHandler buildPlanHandler,
    ILogger<ExecuteTableArchivalHandler> logger)
{
    public async Task<Result<ExecuteTableArchivalResponse>> HandleAsync(ExecuteTableArchivalCommand command, CancellationToken ct)
    {
        logger.LogInformation("Executing table archival: TableConfigId={TableConfigId}, BusinessDate={BusinessDate}",
            command.TableConfigurationId, command.BusinessDate);

        // Build execution plan from configuration
        var planResult = await buildPlanHandler.HandleAsync(
            new BuildTableArchivalPlanQuery(command.TableConfigurationId), ct);

        if (!planResult.Ok)
            return Result<ExecuteTableArchivalResponse>.Fail(planResult.Error ?? "Failed to build archival plan");

        var plan = planResult.Value!;

        // Get connection strings
        var sourceConn = connectionStringResolver.ResolveSourceConnection(plan.SchemaName.Split('.')[0]); // TODO: get db name from config
        var storageConn = connectionStringResolver.ResolveStorageConnection(plan.StorageAccountName);

        // Check if already successfully exported (skip only succeeded datasets, allow retry of failed)
        var existingDataset = await datasetStore.GetDatasetAsync(command.TableConfigurationId, command.BusinessDate, ct);
        if (existingDataset?.Status == DatasetStatus.Succeeded)
        {
            logger.LogWarning("Dataset already successfully exists: TableConfigId={TableConfigId}, Date={Date}",
                command.TableConfigurationId, command.BusinessDate);
            return Result<ExecuteTableArchivalResponse>.Success(new ExecuteTableArchivalResponse(false, false, 0, 0));
        }

        long datasetId;
        if (existingDataset?.Status == DatasetStatus.Succeeded)
        {
            logger.LogWarning("Dataset already successfully exists: TableConfigId={TableConfigId}, Date={Date}",
                command.TableConfigurationId, command.BusinessDate);
            return Result<ExecuteTableArchivalResponse>.Success(new ExecuteTableArchivalResponse(false, false, 0, 0));
        }

        if (existingDataset?.Status == DatasetStatus.Failed)
        {
            // Reuse existing failed dataset record (will update its status)
            datasetId = existingDataset.DatasetId;
            logger.LogInformation("Retrying previously failed dataset: TableConfigId={TableConfigId}, Date={Date}, DatasetId={DatasetId}",
                command.TableConfigurationId, command.BusinessDate, datasetId);
        }
        else
        {
            // Create new dataset record
            datasetId = await datasetStore.CreateDatasetAsync(
                command.TableConfigurationId,
                command.BusinessDate,
                plan.DateType,
                plan.StorageAccountName,
                plan.ContainerName,
                "", // temporary, will be set below
                ct);
        }

        // Build blob prefix for this date (will use template expansion in BuildTableArchivalPlanHandler)
        var blobPrefix = $"{plan.BaseBlobPrefix}{command.BusinessDate:yyyy-MM-dd}/";

        // Export using plan configuration
        var exportResult = await tableArchiver.ExportToParquetAsync(
            sourceConn,
            plan.SchemaName,
            plan.TableName,
            plan.BusinessDateColumnName,
            command.BusinessDate,
            storageConn,
            plan.ContainerName,
            blobPrefix,
            ct);

        if (!exportResult.Ok)
        {
            await datasetStore.MarkDatasetFailedAsync(datasetId, exportResult.Error ?? "Export failed", ct);
            return Result<ExecuteTableArchivalResponse>.Fail($"Export failed: {exportResult.Error}");
        }

        await datasetStore.MarkDatasetSucceededAsync(
            datasetId,
            exportResult.Value!.PartCount,
            exportResult.Value.RowCount,
            exportResult.Value.TotalBytes,
            ct);

        // Delete if configured in plan
        var deleteSucceeded = false;
        if (plan.DeleteAfterExport)
        {
            var deleteResult = await tableArchiver.DeleteRowsAsync(
                sourceConn,
                plan.SchemaName,
                plan.TableName,
                plan.BusinessDateColumnName,
                command.BusinessDate,
                plan.BatchDeleteSize,
                ct);

            deleteSucceeded = deleteResult.Ok;
            if (!deleteResult.Ok)
            {
                logger.LogWarning("Delete failed: {Error}", deleteResult.Error);
            }
        }

        logger.LogInformation("Table archival completed: Rows={Rows}, Bytes={Bytes}, Parts={Parts}, Deleted={Deleted}",
            exportResult.Value.RowCount, exportResult.Value.TotalBytes, exportResult.Value.PartCount, deleteSucceeded);

        return Result<ExecuteTableArchivalResponse>.Success(new ExecuteTableArchivalResponse(
            true,
            deleteSucceeded,
            exportResult.Value.RowCount,
            exportResult.Value.TotalBytes));
    }
}

