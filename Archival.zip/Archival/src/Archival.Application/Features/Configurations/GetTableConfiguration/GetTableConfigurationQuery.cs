﻿namespace Archival.Application.Features.Configurations.GetTableConfiguration;

public sealed record GetTableConfigurationQuery(int TableConfigurationId);

public sealed record GetTableConfigurationResponse(
    int Id,
    string DatabaseName,
    string SchemaName,
    string TableName,
    string BusinessDateColumnName,
    int TablePolicyId,
    int BlobPolicyId,
    string ArchivePathTemplate,
    bool DeleteAfterExport,
    int BatchDeleteSize,
    int? KeepLastEod,
    int? KeepLastEom,
    int? KeepLastEoq,
    int? KeepLastEoy);

