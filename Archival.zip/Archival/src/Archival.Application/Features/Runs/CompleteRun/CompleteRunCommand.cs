﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Features.Runs.CompleteRun;

public sealed record CompleteRunCommand(
    long RunId,
    RunStatus Status,
    string? Note = null);

