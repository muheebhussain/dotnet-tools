﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.Runs.CompleteRun;

public sealed class CompleteRunHandler(
    IRunsStore runsStore,
    ILogger<CompleteRunHandler> logger)
{
    public async Task<Result> HandleAsync(CompleteRunCommand command, CancellationToken ct)
    {
        logger.LogInformation("Completing run: RunId={RunId}, Status={Status}",
            command.RunId, command.Status);

        await runsStore.CompleteRunAsync(command.RunId, command.Status, command.Note, ct);

        logger.LogInformation("Run completed: RunId={RunId}", command.RunId);

        return Result.Success();
    }
}

