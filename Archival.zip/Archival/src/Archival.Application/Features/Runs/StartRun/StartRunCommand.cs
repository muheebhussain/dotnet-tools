﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Features.Runs.StartRun;

public sealed record StartRunCommand(RunType RunType);

public sealed record StartRunResponse(long RunId, DateTime StartedAt);

