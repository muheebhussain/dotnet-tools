﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.Runs.StartRun;

public sealed class StartRunHandler(
    IRunsStore runsStore,
    ILogger<StartRunHandler> logger)
{
    public async Task<Result<StartRunResponse>> HandleAsync(StartRunCommand command, CancellationToken ct)
    {
        logger.LogInformation("Starting {RunType} run", command.RunType);

        var run = await runsStore.StartRunAsync(command.RunType, ct);

        logger.LogInformation("Run started: RunId={RunId}, Type={RunType}", run.Id, run.RunType);

        return Result<StartRunResponse>.Success(new StartRunResponse(run.Id, run.StartedAt));
    }
}

