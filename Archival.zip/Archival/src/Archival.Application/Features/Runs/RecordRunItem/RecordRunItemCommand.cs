﻿using Archival.Application.Shared.Models;

namespace Archival.Application.Features.Runs.RecordRunItem;

public sealed record RecordRunItemCommand(
    long RunId,
    RunItemType ItemType,
    RunItemStatus Status,
    int? TableConfigurationId = null,
    DateOnly? AsOfDate = null,
    int? BlobConfigurationId = null,
    LifecycleAction? Action = null,
    long? RowsAffected = null,
    long? BytesAffected = null,
    string? ItemKey = null,
    string? Error = null);

