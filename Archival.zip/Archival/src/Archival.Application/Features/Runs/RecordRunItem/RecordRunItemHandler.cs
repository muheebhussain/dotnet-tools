﻿using Archival.Application.Contracts.Persistence;
using Archival.Application.Shared.Results;
using Microsoft.Extensions.Logging;

namespace Archival.Application.Features.Runs.RecordRunItem;

public sealed class RecordRunItemHandler(
    IRunItemsStore runItemsStore,
    ILogger<RecordRunItemHandler> logger)
{
    public async Task<Result> HandleAsync(RecordRunItemCommand command, CancellationToken ct)
    {
        logger.LogDebug("Recording run item: RunId={RunId}, ItemType={ItemType}, Status={Status}",
            command.RunId, command.ItemType, command.Status);

        await runItemsStore.AddRunItemAsync(
            command.RunId,
            command.ItemType,
            command.Status,
            command.TableConfigurationId,
            command.AsOfDate,
            command.BlobConfigurationId,
            command.Action,
            command.RowsAffected,
            command.BytesAffected,
            command.ItemKey,
            command.Error,
            ct);

        return Result.Success();
    }
}

