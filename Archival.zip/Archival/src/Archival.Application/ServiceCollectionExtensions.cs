﻿using Archival.Application.Features.BlobLifecycle.ExecuteBlobLifecycle;
using Archival.Application.Features.BlobLifecycle.RunBlobLifecycle;
using Archival.Application.Features.Configurations.GetTableConfiguration;
using Archival.Application.Features.Runs.CompleteRun;
using Archival.Application.Features.Runs.RecordRunItem;
using Archival.Application.Features.Runs.StartRun;
using Archival.Application.Features.TableArchival.BuildTableArchivalPlan;
using Archival.Application.Features.TableArchival.ExecuteTableArchival;
using Archival.Application.Features.TableArchival.RunTableArchival;

namespace Archival.Application;

using Microsoft.Extensions.DependencyInjection;

/// <summary>
/// Extension methods for registering application layer services.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Adds application feature handlers to the dependency injection container.
    /// </summary>
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        // Orchestration handlers
        services.AddScoped<RunTableArchivalHandler>();
        services.AddScoped<RunBlobLifecycleHandler>();

        // Run management handlers
        services.AddScoped<StartRunHandler>();
        services.AddScoped<CompleteRunHandler>();
        services.AddScoped<RecordRunItemHandler>();

        // Configuration handlers
        services.AddScoped<GetTableConfigurationHandler>();

        // Table archival execution handlers
        services.AddScoped<BuildTableArchivalPlanHandler>();
        services.AddScoped<ExecuteTableArchivalHandler>();

        // Blob lifecycle execution handlers
        services.AddScoped<ExecuteBlobLifecycleHandler>();

        return services;
    }
}

