﻿using Archival.Application;
using Archival.Data;
using Archival.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace Archival.App;

/// <summary>
/// Factory for building the DI container host.
/// Delegates service registration to project-specific extensions.
/// </summary>
public static class Startup
{
    public static IHost BuildHost(string? secretsPath)
    {
        var builder = Host.CreateApplicationBuilder();

        ConfigureConfiguration(builder);
        ConfigureLogging(builder);
        var env = ConfigureEnvironment(builder, secretsPath);
        ConfigureServices(builder.Services, env);

        return builder.Build();
    }

    private static void ConfigureConfiguration(HostApplicationBuilder builder)
    {
        builder.Configuration.AddJsonFile("appsettings.json", optional: true);
    }

    private static void ConfigureLogging(HostApplicationBuilder builder)
    {
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss}] [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .Enrich.FromLogContext()
            .ReadFrom.Configuration(builder.Configuration)
            .CreateLogger();

        builder.Services.AddLogging(x => x.AddSerilog(Log.Logger));
    }

    private static EnvironmentConfig ConfigureEnvironment(HostApplicationBuilder builder, string? secretsPath)
    {
        var metadataConn = Environment.GetEnvironmentVariable("ARCHIVAL_METADATA_DB")
            ?? throw new InvalidOperationException("ARCHIVAL_METADATA_DB env var required");

        var secretsDir = secretsPath ?? Environment.GetEnvironmentVariable("ARCHIVAL_SECRETS_PATH") ?? "/secrets/";

        var env = new EnvironmentConfig(metadataConn, secretsDir);
        builder.Services.AddSingleton(env);

        return env;
    }

    private static void ConfigureServices(IServiceCollection services, EnvironmentConfig env)
    {
        // Register services from each project via their extensions
        services.AddDataServices(env.MetadataConnection, services.BuildServiceProvider());
        services.AddInfrastructureServices(env.SecretsDirectory);
        services.AddApplicationServices();
    }
}