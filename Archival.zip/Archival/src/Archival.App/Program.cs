﻿using Archival.App;
using Archival.App.Cli;

using var cts = new CancellationTokenSource();

// Ctrl+C
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;     // don’t kill process immediately
    cts.Cancel();
};

// SIGTERM (Linux containers / Kubernetes)
AppDomain.CurrentDomain.ProcessExit += (_, _) => cts.Cancel();

try
{
    var parsed = CliParser.ParseArgs(args);

    if (!parsed.Ok)
        return CliErrorHandler.Error($"Failed to parse arguments: {parsed.Error}");

    if (parsed.Command is null or Commands.Help)
    {
        CliHelp.Print();
        return ExitCode.Success;
    }

    using var host = Startup.BuildHost(parsed.SecretsPath);

    return parsed.Command switch
    {
        Commands.Table => await TableCommandHandler.ExecuteAsync(host.Services, parsed, cts.Token),
        Commands.Blob => await BlobCommandHandler.ExecuteAsync(host.Services, parsed, cts.Token),
        _ => CliErrorHandler.Error($"Unknown command: {parsed.Command}")
    };
}
catch (OperationCanceledException) when (cts.IsCancellationRequested)
{
    Console.Error.WriteLine("Cancelled.");
    return ExitCode.RuntimeError;
}
catch (Exception ex)
{
    Console.Error.WriteLine("Fatal error:");
    Console.Error.WriteLine(ex);
    return ExitCode.RuntimeError;
}