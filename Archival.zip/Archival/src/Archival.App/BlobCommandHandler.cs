﻿using Archival.App.Cli;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Archival.App;

/// <summary>
/// Handles command execution for blob lifecycle.
/// </summary>
public static class BlobCommandHandler
{
    public static async Task<int> ExecuteAsync(IServiceProvider services, ParsedArgs args, CancellationToken cancellationToken)
    {
        if (!args.AllTargets && args.TargetId is null)
            return CliErrorHandler.Error("blob command requires --all-targets or --target-id");

        try
        {
            var handler = services.GetRequiredService<Application.Features.BlobLifecycle.RunBlobLifecycle.RunBlobLifecycleHandler>();
            var result = await handler.HandleAsync(
                new Application.Features.BlobLifecycle.RunBlobLifecycle.RunBlobLifecycleCommand(args.AllTargets, args.TargetId),
                cancellationToken);

            return result.Ok ? ExitCode.Success : ExitCode.RuntimeError;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // Cancellation was requested - handler should have completed any running run
            // but log for visibility
            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.blob")
                .LogInformation("Blob lifecycle cancelled by user");
            return ExitCode.RuntimeError;
        }
        catch (Exception ex)
        {
            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.blob")
                .LogError(ex, "Blob lifecycle failed");
            return ExitCode.RuntimeError;
        }
    }
}

