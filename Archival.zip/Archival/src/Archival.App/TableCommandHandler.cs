﻿using Archival.App.Cli;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Archival.App;

/// <summary>
/// Handles command execution for table archival.
/// </summary>
public static class TableCommandHandler
{
    public static async Task<int> ExecuteAsync(IServiceProvider services, ParsedArgs args,
        CancellationToken cancellationToken)
    {
        if (!args.AllActive && args.TableConfigId is null)
            return CliErrorHandler.Error("table command requires --all-active or --table-config-id");

        try
        {
            var handler = services
                .GetRequiredService<Application.Features.TableArchival.RunTableArchival.RunTableArchivalHandler>();
            var result = await handler.HandleAsync(
                new Application.Features.TableArchival.RunTableArchival.RunTableArchivalCommand(args.AllActive,
                    args.TableConfigId),
                cancellationToken);

            return result.Ok ? ExitCode.Success : ExitCode.RuntimeError;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // Cancellation was requested - handler should have completed any running run
            // but log for visibility
            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.table")
                .LogInformation("Table archival cancelled by user");
            return ExitCode.RuntimeError;
        }
        catch (Exception ex)
        {
            services.GetRequiredService<ILoggerFactory>()
                .CreateLogger("archival.table")
                .LogError(ex, "Table archival failed");
            return ExitCode.RuntimeError;
        }
    }
}