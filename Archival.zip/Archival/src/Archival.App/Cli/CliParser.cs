﻿namespace Archival.App.Cli;

/// <summary>
/// Parses command-line arguments into structured format.
/// </summary>
public static class CliParser
{
    public static ParsedArgs ParseArgs(string[] args)
    {
        if (args.Length == 0)
            return new ParsedArgs { Ok = true };

        var cmd = args[0];
        if (cmd is "help" or "--help" or "-h")
            return new ParsedArgs { Ok = true, Command = "help" };

        if (cmd is not ("table" or "blob"))
            return new ParsedArgs { Ok = false, Error = $"Unknown command: {cmd}" };

        string? secrets = null;
        bool allActive = false, allTargets = false;
        int? tableId = null, targetId = null;

        for (int i = 1; i < args.Length; i++)
        {
            var arg = args[i];

            if (arg == "--secrets-path")
            {
                if (++i >= args.Length) return new ParsedArgs { Ok = false, Error = "Missing value for --secrets-path" };
                secrets = args[i];
            }
            else if (arg == "--all-active")
            {
                allActive = true;
            }
            else if (arg == "--table-config-id")
            {
                if (++i >= args.Length) return new ParsedArgs { Ok = false, Error = "Missing value for --table-config-id" };
                if (!int.TryParse(args[i], out int id)) return new ParsedArgs { Ok = false, Error = "Invalid --table-config-id: must be integer" };
                tableId = id;
            }
            else if (arg == "--all-targets")
            {
                allTargets = true;
            }
            else if (arg == "--target-id")
            {
                if (++i >= args.Length) return new ParsedArgs { Ok = false, Error = "Missing value for --target-id" };
                if (!int.TryParse(args[i], out int id)) return new ParsedArgs { Ok = false, Error = "Invalid --target-id: must be integer" };
                targetId = id;
            }
            else
            {
                return new ParsedArgs { Ok = false, Error = $"Unknown option: {arg}" };
            }
        }

        return new ParsedArgs
        {
            Ok = true,
            Command = cmd,
            SecretsPath = secrets,
            AllActive = allActive,
            TableConfigId = tableId,
            AllTargets = allTargets,
            TargetId = targetId,
        };
    }
}

/// <summary>
/// Represents parsed command-line arguments.
/// </summary>
public record struct ParsedArgs
{
    public bool Ok { get; init; }
    public string? Error { get; init; }
    public string? Command { get; init; }
    public string? SecretsPath { get; init; }
    public bool AllActive { get; init; }
    public int? TableConfigId { get; init; }
    public bool AllTargets { get; init; }
    public int? TargetId { get; init; }
}

