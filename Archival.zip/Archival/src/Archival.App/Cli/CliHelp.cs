﻿namespace Archival.App.Cli;

/// <summary>
/// Provides help text and documentation for CLI.
/// </summary>
public static class CliHelp
{
    public static void Print() => Console.WriteLine(HelpText);

    private const string HelpText = """
Archival – SQL to Parquet archiver + blob lifecycle cleanup

USAGE:
  archival <command> [options]

COMMANDS:
  table       Archive SQL table data by business date
  blob        Apply lifecycle policy to blobs under configured prefixes
  help        Show this help text

TABLE COMMAND:
  archival table [--secrets-path <path>] (--all-active | --table-config-id <id>)

  Examples:
    archival table --all-active
    archival table --table-config-id 5

BLOB COMMAND:
  archival blob [--secrets-path <path>] (--all-targets | --target-id <id>)

  Examples:
    archival blob --all-targets
    archival blob --target-id 3

OPTIONS:
  --secrets-path <path>      Path to secrets directory (default: /secrets/ or ARCHIVAL_SECRETS_PATH env)
  --all-active               Process all active table configurations (table command only)
  --table-config-id <id>     Process specific table configuration (table command only)
  --all-targets              Process all enabled blob targets (blob command only)
  --target-id <id>           Process specific blob target (blob command only)

ENVIRONMENT VARIABLES:
  ARCHIVAL_METADATA_DB       (Required) Metadata database connection string
  ARCHIVAL_SECRETS_PATH      (Optional) Default secrets path
""";
}

