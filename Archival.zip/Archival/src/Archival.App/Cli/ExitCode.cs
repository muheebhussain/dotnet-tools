﻿namespace Archival.App.Cli;

/// <summary>
/// Standard exit codes for CLI commands.
/// </summary>
public static class ExitCode
{
    public const int Success = 0;
    public const int RuntimeError = 1;
    public const int ValidationError = 2;
}

