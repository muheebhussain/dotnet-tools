# Archival (.NET 10) – SQL to Parquet Archiver + Blob Lifecycle

This solution contains a single CLI application that runs two scheduled workloads in AKS CronJobs:

- `archival archive` – archive SQL table data by business date (export multipart parquet + optional delete).
- `archival lifecycle` – tier/delete blobs under configured prefixes (external blobs + our archived datasets).

## Local run (Pattern A secrets)
1) Copy templates:
   - `secrets/archival-db-connections.template.json` -> `secrets/archival-db-connections.json`
   - `secrets/archival-storage-connections.template.json` -> `secrets/archival-storage-connections.json`

2) Set metadata DB connection (where Archival stores configs/runs/datasets).
   - Environment variable: `ARCHIVAL_METADATA_DB`
   - Example: `Server=localhost;Database=archival_meta;User ID=sa;Password=Your_password123;TrustServerCertificate=True;`

3) Run:
```bash
dotnet run --project src/Archival.App -- archive --all-active --secrets-path ./secrets
dotnet run --project src/Archival.App -- lifecycle --all-targets --secrets-path ./secrets
```

## AKS run (CSI secrets)
In AKS, mount CSI to `/secrets/` and do NOT pass `--secrets-path`.

Expected files inside the pod:
- `/secrets/archival-db-connections.json`
- `/secrets/archival-storage-connections.json`

## Database objects required in source DB
The archive workflow expects:
- `dbo.business_date` table (70-year business calendar)
- `dbo.v_business_date_classification` view (EOD/EOM/EOQ/EOY classification)

## Metadata DB schema
This repo uses EF Core for metadata DB. A SQL script is provided at `db/metadata_schema.sql` to create the tables.
(You can also generate EF migrations later with `dotnet ef`.)

## Notes
- Timestamps are stored as `created_at`, `updated_at`, etc. using `DateTime.UtcNow` (no `_utc` suffix).
- Lifecycle tiers: Hot → Cold → Archive → Delete.
- If a target does not support Archive tier, the system falls back to Cold for that target.

