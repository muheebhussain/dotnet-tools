﻿using Xunit;

namespace Archival.Application.Tests.Features.BlobLifecycle.ExecuteBlobLifecycle;

/// <summary>
/// Tests for blob exemption matching logic in ExecuteBlobLifecycleHandler.
/// </summary>
public class BlobExemptionTests
{
    /// <summary>
    /// Tests that a blob is exempted when container, prefix, and date all match.
    /// </summary>
    [Fact]
    public void IsExempted_AllCriteriaMismatch_ReturnsTrue()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("archive", "archive/2025/01/15/", new DateOnly(2025, 1, 15))
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.True(result, "Blob should be exempted when all criteria match");
    }

    /// <summary>
    /// Tests that a blob is not exempted when container does not match.
    /// </summary>
    [Fact]
    public void IsExempted_ContainerMismatch_ReturnsFalse()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("different-container", "archive/2025/01/15/", new DateOnly(2025, 1, 15))
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.False(result, "Blob should not be exempted when container does not match");
    }

    /// <summary>
    /// Tests that a blob is not exempted when prefix does not match.
    /// </summary>
    [Fact]
    public void IsExempted_PrefixMismatch_ReturnsFalse()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("archive", "other-prefix/2025/01/15/", new DateOnly(2025, 1, 15))
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.False(result, "Blob should not be exempted when prefix does not match");
    }

    /// <summary>
    /// Tests that a blob is not exempted when date does not match.
    /// </summary>
    [Fact]
    public void IsExempted_DateMismatch_ReturnsFalse()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("archive", "archive/2025/01/15/", new DateOnly(2025, 1, 16)) // Different date
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.False(result, "Blob should not be exempted when date does not match");
    }

    /// <summary>
    /// Tests that a blob is exempted when blob name starts with exemption prefix (case-insensitive).
    /// </summary>
    [Fact]
    public void IsExempted_PrefixMatch_CaseInsensitive_ReturnsTrue()
    {
        // Arrange
        var blobName = "Archive/2025/01/15/data.parquet"; // Capital A
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("ARCHIVE", "archive/2025/01/15/", new DateOnly(2025, 1, 15)) // Capital container, lowercase prefix
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.True(result, "Blob should be exempted with case-insensitive matching");
    }

    /// <summary>
    /// Tests that no exemptions returns false.
    /// </summary>
    [Fact]
    public void IsExempted_NoExemptions_ReturnsFalse()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>();

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.False(result, "Blob should not be exempted when there are no exemptions");
    }

    /// <summary>
    /// Tests that multiple exemptions are checked and first match is found.
    /// </summary>
    [Fact]
    public void IsExempted_MultipleExemptions_FirstMatchFound_ReturnsTrue()
    {
        // Arrange
        var blobName = "archive/2025/01/15/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("other-container", "other-prefix/", new DateOnly(2024, 12, 31)),
            ("archive", "archive/2025/01/15/", new DateOnly(2025, 1, 15)), // This one matches
            ("archive", "archive/2025/02/", new DateOnly(2025, 2, 1))
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.True(result, "Blob should be exempted when any exemption matches");
    }

    /// <summary>
    /// Tests blob name that starts with exemption prefix (not exact match of path segments).
    /// </summary>
    [Fact]
    public void IsExempted_BlobNameStartsWithPrefix_ReturnsTrue()
    {
        // Arrange
        var blobName = "archive/2025/01/15/subfolder/data.parquet";
        var containerName = "archive";
        var blobDate = new DateOnly(2025, 1, 15);
        var exemptions = new HashSet<(string Container, string Prefix, DateOnly Date)>
        {
            ("archive", "archive/2025/01/15/", new DateOnly(2025, 1, 15))
        };

        // Act
        var result = ExecuteBlobLifecycleHandlerTestHelper.IsExempted(blobName, containerName, blobDate, exemptions);

        // Assert
        Assert.True(result, "Blob should be exempted when name starts with prefix, even with subdirectories");
    }
}

/// <summary>
/// Helper class to expose the private IsExempted method for testing.
/// This uses reflection to invoke the private method.
/// </summary>
public static class ExecuteBlobLifecycleHandlerTestHelper
{
    public static bool IsExempted(
        string blobName,
        string containerName,
        DateOnly blobDate,
        IReadOnlySet<(string Container, string Prefix, DateOnly Date)> exemptions)
    {
        var handlerType = typeof(ExecuteBlobLifecycleHandler);
        var method = handlerType.GetMethod(
            "IsExempted",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static,
            null,
            new[] { typeof(string), typeof(string), typeof(DateOnly), typeof(IReadOnlySet<(string, string, DateOnly)>) },
            null);

        if (method == null)
            throw new InvalidOperationException("Could not find IsExempted method via reflection");

        var result = method.Invoke(null, new object[] { blobName, containerName, blobDate, exemptions });
        return (bool)(result ?? false);
    }
}

