-- Archival metadata DB schema (vNext)
-- Note: uses snake_case tables, id PK, no _utc/_et suffixes.

CREATE TABLE archival_table_policy (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  is_active BIT NOT NULL,
  keep_last_eod INT NULL,
  keep_last_eom INT NULL,
  keep_last_eoq INT NULL,
  keep_last_eoy INT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL
);

CREATE TABLE archival_blob_policy (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  is_active BIT NOT NULL,
  cold_min_age_days INT NULL,
  archive_min_age_days INT NULL,
  delete_min_age_days INT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL
);

CREATE TABLE archival_table_configuration (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  is_active BIT NOT NULL,
  database_name NVARCHAR(128) NOT NULL,
  schema_name NVARCHAR(128) NOT NULL,
  table_name NVARCHAR(128) NOT NULL,
  as_of_date_column NVARCHAR(128) NOT NULL,
  archive_path_template NVARCHAR(400) NOT NULL,
  table_policy_id INT NOT NULL,
  blob_policy_id INT NOT NULL,
  delete_after_export BIT NOT NULL,
  batch_delete_size INT NOT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL,
  CONSTRAINT uq_archival_table_configuration_table UNIQUE (database_name, schema_name, table_name),
  CONSTRAINT fk_archival_table_configuration_table_policy FOREIGN KEY (table_policy_id)
    REFERENCES archival_table_policy(id),
  CONSTRAINT fk_archival_table_configuration_blob_policy FOREIGN KEY (blob_policy_id)
    REFERENCES archival_blob_policy(id)
);

CREATE TABLE archival_table_exemption (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  table_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  reason NVARCHAR(4000) NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_table_exemption_table FOREIGN KEY (table_configuration_id)
    REFERENCES archival_table_configuration(id)
);

CREATE TABLE archival_blob_configuration (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  is_enabled BIT NOT NULL,
  storage_account_name NVARCHAR(128) NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  prefix NVARCHAR(1024) NOT NULL,
  include_pattern NVARCHAR(2000) NULL,
  exclude_pattern NVARCHAR(2000) NULL,
  supports_archive_tier BIT NOT NULL,
  blob_policy_id INT NOT NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  updated_at DATETIME2(3) NULL,
  updated_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_blob_configuration_blob_policy FOREIGN KEY (blob_policy_id)
    REFERENCES archival_blob_policy(id)
);

CREATE TABLE archival_blob_exemption (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  blob_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  prefix NVARCHAR(1024) NOT NULL,
  reason NVARCHAR(4000) NULL,
  created_at DATETIME2(3) NOT NULL,
  created_by NVARCHAR(100) NULL,
  CONSTRAINT fk_archival_blob_exemption_blob_configuration FOREIGN KEY (blob_configuration_id)
    REFERENCES archival_blob_configuration(id),
  INDEX ix_archival_blob_exemption_config (blob_configuration_id, container_name, prefix, as_of_date)
);

CREATE TABLE archival_run (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  run_type NVARCHAR(20) NOT NULL,
  started_at DATETIME2(3) NOT NULL,
  ended_at DATETIME2(3) NULL,
  status NVARCHAR(20) NOT NULL,
  note NVARCHAR(4000) NULL
);

CREATE TABLE archival_run_item (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  run_id BIGINT NOT NULL,
  item_type NVARCHAR(20) NOT NULL,
  item_key NVARCHAR(1200) NOT NULL,
  action NVARCHAR(40) NOT NULL,
  status NVARCHAR(20) NOT NULL,
  rows_affected BIGINT NULL,
  bytes_affected BIGINT NULL,
  error_message NVARCHAR(MAX) NULL,
  created_at DATETIME2(3) NOT NULL,
  CONSTRAINT fk_archival_run_item_run FOREIGN KEY (run_id) REFERENCES archival_run(id)
);

CREATE TABLE archival_dataset (
  id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  table_configuration_id INT NOT NULL,
  as_of_date DATE NOT NULL,
  date_type NVARCHAR(4) NOT NULL,
  storage_account_name NVARCHAR(128) NOT NULL,
  container_name NVARCHAR(128) NOT NULL,
  blob_prefix NVARCHAR(1024) NOT NULL,
  part_count INT NOT NULL,
  total_bytes BIGINT NULL,
  row_count BIGINT NULL,
  status NVARCHAR(20) NOT NULL,
  created_at DATETIME2(3) NOT NULL,
  completed_at DATETIME2(3) NULL,
  error_summary NVARCHAR(MAX) NULL,
  CONSTRAINT uq_archival_dataset_table_date UNIQUE (table_configuration_id, as_of_date),
  CONSTRAINT fk_archival_dataset_table FOREIGN KEY (table_configuration_id) REFERENCES archival_table_configuration(id)
);
