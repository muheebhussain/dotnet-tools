﻿-- Migration: Simplify Table Policy Naming
-- Date: 2026-02-15
-- Purpose: Rename ArchivalTableRetentionPolicyConfiguration to ArchivalTablePolicy

-- ============================================================================
-- PART 1: Rename main table
-- ============================================================================

EXEC sp_rename 'dbo.archival_table_retention_policy_configuration', 'archival_table_policy';
GO

-- ============================================================================
-- PART 2: Rename columns in referencing tables
-- ============================================================================

-- Rename column in archival_table_configuration
EXEC sp_rename 'dbo.archival_table_configuration.table_retention_policy_configuration_id', 'table_policy_id', 'COLUMN';
GO

-- ============================================================================
-- PART 3: Rename foreign keys (drop and recreate)
-- ============================================================================

-- Drop old FK from archival_table_configuration (if exists)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_archival_table_configuration_retention')
BEGIN
    ALTER TABLE dbo.archival_table_configuration
    DROP CONSTRAINT fk_archival_table_configuration_retention;
END
GO

-- Create new FK with simplified name
ALTER TABLE dbo.archival_table_configuration ADD CONSTRAINT
    fk_archival_table_configuration_table_policy
    FOREIGN KEY (table_policy_id)
    REFERENCES dbo.archival_table_policy (id);
GO

-- ============================================================================
-- NOTES
-- ============================================================================
--
-- Renamed:
-- - Table: archival_table_retention_policy_configuration → archival_table_policy
-- - Column: table_retention_policy_configuration_id → table_policy_id
--
-- Entity: ArchivalTableRetentionPolicyConfigurationEntity → ArchivalTablePolicyEntity
-- DbSet: TableRetentionPolicies → TablePolicies
--
-- ============================================================================

