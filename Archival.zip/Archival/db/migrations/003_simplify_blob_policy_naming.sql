﻿-- Migration: Simplify Blob Policy Naming
-- Date: 2026-02-15
-- Purpose: Rename ArchivalBlobLifecyclePolicyConfiguration to ArchivalBlobPolicy

-- ============================================================================
-- PART 1: Rename table
-- ============================================================================

EXEC sp_rename 'dbo.archival_blob_lifecycle_policy_configuration', 'archival_blob_policy';
GO

-- ============================================================================
-- PART 2: Rename columns in referencing tables
-- ============================================================================

-- Rename column in archival_table_configuration
EXEC sp_rename 'dbo.archival_table_configuration.lifecycle_policy_configuration_id', 'blob_policy_id', 'COLUMN';
GO

-- Rename column in archival_blob_lifecycle_target_configuration
EXEC sp_rename 'dbo.archival_blob_lifecycle_target_configuration.lifecycle_policy_configuration_id', 'blob_policy_id', 'COLUMN';
GO

-- ============================================================================
-- PART 3: Rename foreign keys (drop and recreate)
-- ============================================================================

-- Drop old FK from archival_table_configuration (if exists)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_archival_table_configuration_lifecycle_policy')
BEGIN
    ALTER TABLE dbo.archival_table_configuration
    DROP CONSTRAINT FK_archival_table_configuration_lifecycle_policy;
END
GO

-- Create new FK with simplified name
ALTER TABLE dbo.archival_table_configuration ADD CONSTRAINT
    FK_archival_table_configuration_blob_policy
    FOREIGN KEY (blob_policy_id)
    REFERENCES dbo.archival_blob_policy (id);
GO

-- Drop old FK from archival_blob_lifecycle_target_configuration (if exists)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_archival_blob_lifecycle_target_lifecycle_policy')
BEGIN
    ALTER TABLE dbo.archival_blob_lifecycle_target_configuration
    DROP CONSTRAINT FK_archival_blob_lifecycle_target_lifecycle_policy;
END
GO

-- Create new FK with simplified name
ALTER TABLE dbo.archival_blob_lifecycle_target_configuration ADD CONSTRAINT
    FK_archival_blob_lifecycle_target_blob_policy
    FOREIGN KEY (blob_policy_id)
    REFERENCES dbo.archival_blob_policy (id);
GO

-- ============================================================================
-- NOTES
-- ============================================================================
--
-- Renamed:
-- - Table: archival_blob_lifecycle_policy_configuration → archival_blob_policy
-- - Column: lifecycle_policy_configuration_id → blob_policy_id
--
-- Entity: ArchivalBlobLifecyclePolicyConfigurationEntity → ArchivalBlobPolicyEntity
-- DbSet: LifecyclePolicies → BlobPolicies
--
-- ============================================================================

