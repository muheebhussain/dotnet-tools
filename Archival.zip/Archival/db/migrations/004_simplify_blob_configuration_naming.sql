﻿-- Migration: Simplify Blob Configuration Naming
-- Date: 2026-02-15
-- Purpose: Rename ArchivalBlobLifecycleTargetConfiguration to ArchivalBlobConfiguration

-- ============================================================================
-- PART 1: Rename main table
-- ============================================================================

EXEC sp_rename 'dbo.archival_blob_lifecycle_target_configuration', 'archival_blob_configuration';
GO

-- ============================================================================
-- PART 2: Rename columns in referencing tables
-- ============================================================================

-- Rename column in archival_blob_exemption
EXEC sp_rename 'dbo.archival_blob_exemption.lifecycle_target_configuration_id', 'blob_configuration_id', 'COLUMN';
GO

-- Rename column in archival_run_item
EXEC sp_rename 'dbo.archival_run_item.blob_lifecycle_target_configuration_id', 'blob_configuration_id', 'COLUMN';
GO

-- ============================================================================
-- PART 3: Rename foreign keys (drop and recreate)
-- ============================================================================

-- Drop old FK from archival_blob_exemption (if exists)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_archival_blob_exemption_lifecycle_target')
BEGIN
    ALTER TABLE dbo.archival_blob_exemption
    DROP CONSTRAINT FK_archival_blob_exemption_lifecycle_target;
END
GO

-- Create new FK with simplified name
ALTER TABLE dbo.archival_blob_exemption ADD CONSTRAINT
    FK_archival_blob_exemption_blob_configuration
    FOREIGN KEY (blob_configuration_id)
    REFERENCES dbo.archival_blob_configuration (id);
GO

-- Drop old FK from archival_run_item (if exists)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_archival_run_item_blob_lifecycle_target')
BEGIN
    ALTER TABLE dbo.archival_run_item
    DROP CONSTRAINT FK_archival_run_item_blob_lifecycle_target;
END
GO

-- Create new FK with simplified name
ALTER TABLE dbo.archival_run_item ADD CONSTRAINT
    FK_archival_run_item_blob_configuration
    FOREIGN KEY (blob_configuration_id)
    REFERENCES dbo.archival_blob_configuration (id);
GO

-- ============================================================================
-- PART 4: Rename indexes
-- ============================================================================

-- Rename index in archival_blob_exemption (if exists)
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_archival_blob_exemption')
BEGIN
    EXEC sp_rename 'dbo.archival_blob_exemption.ix_archival_blob_exemption',
                   'ix_archival_blob_exemption_config', 'INDEX';
END
GO

-- Recreate unique index in archival_run_item with new column name
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'uq_run_item_blob_date_folder')
BEGIN
    DROP INDEX uq_run_item_blob_date_folder ON dbo.archival_run_item;
END
GO

CREATE UNIQUE NONCLUSTERED INDEX uq_run_item_blob_date_folder
ON dbo.archival_run_item (run_id, item_type, blob_configuration_id, as_of_date)
WHERE blob_configuration_id IS NOT NULL AND as_of_date IS NOT NULL;
GO

-- ============================================================================
-- NOTES
-- ============================================================================
--
-- Renamed:
-- - Table: archival_blob_lifecycle_target_configuration → archival_blob_configuration
-- - Column: lifecycle_target_configuration_id → blob_configuration_id
-- - Column: blob_lifecycle_target_configuration_id → blob_configuration_id
--
-- Entity: ArchivalBlobLifecycleTargetConfigurationEntity → ArchivalBlobConfigurationEntity
-- DbSet: LifecycleTargets → BlobConfigurations
-- Model: LifecycleTargetConfiguration → BlobConfiguration
--
-- ============================================================================

