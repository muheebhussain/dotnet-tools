﻿-- Migration: vNext Run Items (Dataset & Date-Folder Granularity)
-- Date: 2026-02-15
-- Purpose: Add structured identity columns to run items for proper granularity

-- ============================================================================
-- PART 1: Add new columns
-- ============================================================================

-- Add structured identity columns
ALTER TABLE dbo.archival_run_item ADD
    table_configuration_id INT NULL,
    as_of_date DATE NULL,
    blob_lifecycle_target_configuration_id INT NULL;
GO

-- Make existing columns optional/nullable where appropriate
ALTER TABLE dbo.archival_run_item ALTER COLUMN item_key NVARCHAR(1200) NULL;
GO

-- ============================================================================
-- PART 2: Add foreign key constraints
-- ============================================================================

ALTER TABLE dbo.archival_run_item ADD CONSTRAINT
    FK_archival_run_item_table_configuration
    FOREIGN KEY (table_configuration_id)
    REFERENCES dbo.archival_table_configuration (id);
GO

ALTER TABLE dbo.archival_run_item ADD CONSTRAINT
    FK_archival_run_item_blob_lifecycle_target
    FOREIGN KEY (blob_lifecycle_target_configuration_id)
    REFERENCES dbo.archival_blob_lifecycle_target_configuration (id);
GO

-- ============================================================================
-- PART 3: Create unique indexes for idempotency
-- ============================================================================

-- Unique index for table datasets (one run item per table + as_of_date per run)
CREATE UNIQUE NONCLUSTERED INDEX uq_run_item_table_dataset
ON dbo.archival_run_item (run_id, item_type, table_configuration_id, as_of_date)
WHERE table_configuration_id IS NOT NULL AND as_of_date IS NOT NULL;
GO

-- Unique index for blob date folders (one run item per blob target + as_of_date per run)
CREATE UNIQUE NONCLUSTERED INDEX uq_run_item_blob_date_folder
ON dbo.archival_run_item (run_id, item_type, blob_lifecycle_target_configuration_id, as_of_date)
WHERE blob_lifecycle_target_configuration_id IS NOT NULL AND as_of_date IS NOT NULL;
GO

-- ============================================================================
-- NOTES
-- ============================================================================
--
-- Granularity After Migration:
-- - Table runs: One run item per (table_configuration_id + as_of_date)
-- - Blob lifecycle runs: One run item per (blob_target_id + as_of_date)
-- - No run items for individual parquet parts or individual blob files
--
-- ItemKey is now optional and used only for display/debug purposes
-- Status is now stored as enum string (Pending, Succeeded, Failed, Skipped)
-- Action is nullable (only populated for blob lifecycle items)
--
-- ============================================================================

