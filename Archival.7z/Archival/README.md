
# Archival (.NET 8 + Airflow)

A CLI‑driven archival platform designed to be orchestrated by **Apache Airflow**.  
Supports per‑table parallelism, SQL‑defined policies, **temp‑file → Blob** Parquet export, **50k batched deletes**, external file reconciliation, and lifecycle tiering/deletion with ETags.

## Projects

### Archival.Domain
Core record types and enums: `TableConfig`, `ArchivalFile`, `TableRetentionPolicy`, `FileLifecyclePolicy`, date types, run/log enums.

### Archival.Data
Dapper‑based data access for Azure SQL:
- Keep‑set calculation from `dbo.v_business_date_classification`
- Candidate discovery (present dates − keep − exemptions)
- Row counts, date‑type lookup
- Run & run‑detail logging
- PK discovery (`sys.indexes`), exemptions, effective file policy
- Lifecycle file fetch + status updates

### Archival.Blob
Azure Blob helpers (`Azure.Storage.Blobs`):
- Upload local temp files → blob (returns **ETag** & size)
- `SetAccessTier` with **If‑Match ETag**
- `DeleteIfExists` with **If‑Match ETag**
- List blobs by prefix

### Archival.Core
Utility helpers:
- `PathUtil.BuildPrefix(tableConfig, date)` expands `{db}/{schema}/{table}/{date}` tokens

### Archival.Export
Implements **archive** flow for SelfManaged tables:
- Builds **KEEP** set from policy
- Finds **candidates** by date
- Exports rows for each date to **typed Parquet** using `Parquet.Net`
  - Column type mapping for common SQL types (int, long, bool, decimal(38,18), DateTime, byte[], string/guid)
  - Writes each chunk to a **local temp file**, uploads to Blob, deletes temp
- Verifies counts (SQL vs Parquet rows written)
- Deletes in batches of **50,000**
  - Uses PK column if found; otherwise `DELETE TOP (n)` without `ORDER BY`
- Registers files in `archival_file` (path, ETag, bytes, rows)
- Logs `Export` and `Delete` phases

### Archival.Reconcile
Scans Blob storage and (idempotently) registers files into `archival_file`:
- Lists under `{db}/{schema}/{table}/`
- Parses `as_of_date=YYYY-MM-DD` from blob paths
- Classifies `date_type` via the business calendar view
- Upserts catalog rows and logs `Reconcile` details

### Archival.Lifecycle
Applies self‑managed lifecycle actions:
- Resolves **effective policy** (per‑file override → table default)
- Computes age in days from `created_at_et`
- Chooses highest applicable action: **Delete > Archive > Cool**
- Executes Blob actions with **If‑Match** ETags
- Updates `archival_file.status`/tier and logs `Lifecycle`

### Archival.Cli
Single executable with subcommands:
```
archival-cli archive 
  --table RetailDB.dbo.OrdersDaily
  [--since 2024-01-01]
  --batch-delete 50000
  --max-read-rows 5000000
  [--what-if]

archival-cli reconcile 
  --table RetailDB.dbo.OrdersDaily
  [--what-if]

archival-cli lifecycle 
  --batch 500
  [--what-if]
```

**Common configuration via env or flags**
- `ARCHIVAL_SQL_CXN` or `--connection-string-sql`
- `BLOB_URL` or `--blob-url` (e.g., `https://acct.blob.core.windows.net`)
- `BLOB_CONTAINER` or `--blob-container` (e.g., `archive`)

## Build & Run

```bash
dotnet build

export ARCHIVAL_SQL_CXN="Server=...;Database=...;User Id=...;Password=...;Encrypt=True;"
export BLOB_URL="https://<account>.blob.core.windows.net"
export BLOB_CONTAINER="archive"

# Archive a single table (per-table parallelism via Airflow)
dotnet run --project Archival.Cli -- archive   --table RetailDB.dbo.OrdersDaily   --batch-delete 50000   --max-read-rows 5000000

# Reconcile externally created files
dotnet run --project Archival.Cli -- reconcile --table RetailDB.dbo.OrdersDaily

# Apply lifecycle actions
dotnet run --project Archival.Cli -- lifecycle --batch 500
```

## Notes & Recommendations
- **Temp-file → Blob** is safer for large Parquet parts (seekable writer + low memory).
- Ensure each managed table has an index on `as_of_date` (and ideally `(as_of_date, <pk>)`).
- If a table has **no PK**, the delete still works via `DELETE TOP(n)` loops (slower).
- All timestamps use **Eastern Time** in SQL (consistent with your schema defaults).
- The blob path must include the token `as_of_date=YYYY-MM-DD` for reconciliation to work out of the box.

## Airflow (Option A: per-table parallel)
Use a Python task to query `archival_table_config` and map dynamically to `KubernetesPodOperator` (one per table), then a single `lifecycle` task. See earlier conversation for a DAG sketch.
