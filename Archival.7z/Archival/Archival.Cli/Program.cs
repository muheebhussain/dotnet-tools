using Azure.Identity;
using Azure.Storage.Blobs;
using Archival.Blob;
using Archival.Core;
using Archival.Data;
using Archival.Data.Repositories;
using Archival.Export;
using Archival.Lifecycle;
using Archival.Reconcile;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Serilog;

static string Env(string key, string fallback = "") =>
    Environment.GetEnvironmentVariable(key) ?? fallback;

// Build configuration
var config = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables()
    .Build();

// Configure Serilog (simple console for CLI)
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();
Log.Information("Starting Archival CLI");
try
{
    // Build DI container
    var services = new ServiceCollection();
    ConfigureServices(services, config);
    await using var serviceProvider = services.BuildServiceProvider();

    // Resolve ArchivalOptions once
    var options = serviceProvider
        .GetRequiredService<IOptions<ArchivalOptions>>()
        .Value;

    var rawAction = Env("ACTION");
    var action = Env("ACTION").Trim().ToLowerInvariant();
    action = "lifecycle";

    if (string.IsNullOrWhiteSpace(action))
    {
        Log.Logger.Error("Missing ACTION environment variable. Expected 'archive', 'reconcile' or 'lifecycle'.");
        return 1;
    }
    Log.Information("Selected ACTION {Action} (raw='{RawAction}')", action, rawAction);
    switch (action)
    {
        case "archive":
            await RunArchiveAsync(serviceProvider, options);
            break;

        case "reconcile":
            await RunReconcileAsync(serviceProvider, options);
            break;

        case "lifecycle":
            await RunLifecycleAsync(serviceProvider, options);
            break;

        default:
            Log.Logger.Error("Unknown ACTION '{Action}'. Expected 'archive', 'reconcile' or 'lifecycle'.", action);
            return 1;
    }
    Log.Information("Archival CLI completed successfully.");
    return 0;
}
catch (Exception ex)
{
    Log.Logger.Error(ex, "Unhandled exception in Archival CLI.");
    return 1;
}

static void ConfigureServices(IServiceCollection services, IConfiguration config)
{
    // Options: bind from configuration first
    services.Configure<ArchivalOptions>(config.GetSection("ArchivalOptions"));

    // PostConfigure to apply environment variable fallbacks
    services.PostConfigure<ArchivalOptions>(opt =>
    {
        // Fallbacks if not present in config
        if (string.IsNullOrWhiteSpace(opt.SqlConnectionString))
            opt.SqlConnectionString = Env("ARCHIVAL_SQL_CXN");

        if (string.IsNullOrWhiteSpace(opt.BlobUrl))
            opt.BlobUrl = Env("BLOB_URL");

        if (string.IsNullOrWhiteSpace(opt.BlobContainer))
            opt.BlobContainer = Env("BLOB_CONTAINER");

        if (string.IsNullOrWhiteSpace(opt.SqlConnectionString))
            throw new ArgumentException("Missing SQL connection", nameof(opt.SqlConnectionString));

        if (string.IsNullOrWhiteSpace(opt.BlobUrl))
            throw new ArgumentException("Missing Blob URL", nameof(opt.BlobUrl));

        if (string.IsNullOrWhiteSpace(opt.BlobContainer))
            throw new ArgumentException("Missing Blob Container", nameof(opt.BlobContainer));
    });

    // BlobService options (could be bound from config in future)
    services.AddSingleton(new BlobStorageOptions
    {
        AutoCreateContainers = false,
        MaximumConcurrency = 8,
        MaximumTransferLength = (int?)(8L * 1024 * 1024)
    });

    // Logging
    services.AddSingleton<ILogger>(Log.Logger);

    // Core infrastructure
    services.AddSingleton<ISqlFactory>(sp =>
    {
        var opts = sp.GetRequiredService<IOptions<ArchivalOptions>>().Value;
        return new SqlFactory(opts.SqlConnectionString);
    });

    services.AddArchivalData(config);

    services.AddSingleton<BlobServiceClient>(sp =>
    {
        var opts = sp.GetRequiredService<IOptions<ArchivalOptions>>().Value;
        return new BlobServiceClient(opts.StorageConnectionString);
        //return new BlobServiceClient(new Uri(opts.BlobUrl), new DefaultAzureCredential());
    });

    services.AddSingleton<IBlobService>(sp =>
    {
        var client = sp.GetRequiredService<BlobServiceClient>();
        var blobOpts = sp.GetRequiredService<BlobStorageOptions>();
        var logger = sp.GetRequiredService<ILogger>();
        return new BlobService(client, blobOpts);
    });

    services.AddTransient<ArchivePlanner>();
    services.AddTransient<TableArchiveExecutor>();
    // Runners
    services.AddTransient<ArchiveRunner>();
    services.AddTransient<ReconcileRunner>();
    services.AddTransient<LifecycleRunner>(sp =>
    {
        var sqlFactory = sp.GetRequiredService<ISqlFactory>();
        var repo = sp.GetRequiredService<IArchivalRepository>();
        var blob = sp.GetRequiredService<IBlobService>();
        var opts = sp.GetRequiredService<IOptions<ArchivalOptions>>().Value;
        var logger = sp.GetRequiredService<ILogger>();
        var fileRepository = sp.GetRequiredService<IArchivalFileRepository>();
        var runDetailRepository = sp.GetRequiredService<IArchivalRunDetailRepository>();
        return new LifecycleRunner(sqlFactory, repo, blob, opts.BlobContainer, logger, fileRepository,runDetailRepository);
    });
}

static async Task RunArchiveAsync(IServiceProvider sp, ArchivalOptions options)
{
    if (string.IsNullOrWhiteSpace(options.TableName))
    {
        Log.Logger.Error("ArchivalOptions.TableName is required for ACTION=archive.");
        return;
    }

    var runner = sp.GetRequiredService<ArchiveRunner>();

    var dry = ParseBool(options.WhatIf);
    DateOnly? sinceDate = null;
    if (options.Since > DateTime.MinValue)
    {
        sinceDate = DateOnly.FromDateTime(options.Since);
    }

    Log.Information(
        "Running ARCHIVE for table {Table}, batchDelete={BatchDelete}, maxReadRows={MaxRead}, since={Since}, dryRun={Dry}",
        options.TableName,
        options.BatchDeleteSize,
        options.MaxReadRows,
        sinceDate,
        dry);

    await runner.RunArchiveAsync(
        options.TableName,
        options.BatchDeleteSize,
        options.MaxReadRows,
        dry,
        sinceDate);
}

static async Task RunReconcileAsync(IServiceProvider sp, ArchivalOptions options)
{
    if (string.IsNullOrWhiteSpace(options.TableName))
    {
        Log.Logger.Error("ArchivalOptions.TableName is required for ACTION=reconcile.");
        return;
    }
    var dry = ParseBool(options.WhatIf);
    Log.Information(
        "Running RECONCILE for table {Table}, dryRun={Dry}",
        options.TableName,
        dry);

    var runner = sp.GetRequiredService<ReconcileRunner>();
    await runner.RunAsync(options.TableName, dry);
}

static async Task RunLifecycleAsync(IServiceProvider sp, ArchivalOptions options)
{
    var dry = ParseBool(options.WhatIf);

    Log.Information(
        "Running LIFECYCLE with batch={Batch}, dryRun={Dry}",
        options.MaxFilesBatch,
        dry);

    var runner = sp.GetRequiredService<LifecycleRunner>();


    await runner.RunAsync(options.MaxFilesBatch, dry);
}

static bool ParseBool(string value)
{
    if (string.IsNullOrWhiteSpace(value))
        return false;

    return bool.TryParse(value, out var b) && b;
}
