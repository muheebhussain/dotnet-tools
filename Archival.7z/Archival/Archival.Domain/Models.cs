
namespace Archival.Domain;

public enum ExportMode { SelfManaged, External }
public enum FileStatus { Created, Cool, Archive, Deleted, Failed }
public enum DateType { EOD, EOM, EOQ, EOY }
public enum RunPhase { Export, Delete, Reconcile, Lifecycle }
public enum RunStatus { Running, Success, Failed }
public enum DetailStatus { Success, Skipped, Failed }

public record TableRetentionPolicy(
    int Id, string Name, bool IsActive,
    int? KeepLastEod, int? KeepLastEom, int? KeepLastEoq, int? KeepLastEoy
);

public record FileLifecyclePolicy(
    int Id, string Name, bool IsActive,
    int? EodCool, int? EodArchive, int? EodDelete,
    int? EomCool, int? EomArchive, int? EomDelete,
    int? EoqCool, int? EoqArchive, int? EoqDelete,
    int? EoyCool, int? EoyArchive, int? EoyDelete,
    int? ExternalKeepEodDays
);

public record TableConfig(
    int Id,
    string DatabaseName, string SchemaName, string TableName, string AsOfDateColumn,
    ExportMode ExportMode, string ArchivePathTemplate,
    int TableRetentionPolicyId, int FileLifecyclePolicyId
)
{
    public string FullName => $"{DatabaseName}.{SchemaName}.{TableName}";
}

public record ArchivalFile(
    long Id, int TableConfigId, DateOnly AsOfDate, DateType DateType,
    string FilePath, string? ETag, long? FileSizeBytes, long? RowCount,
    FileStatus Status, DateTime CreatedAtEt, string? CurrentAccessTier, DateTime? LastTierCheckAtEt,
    int? OverrideFileLifecyclePolicyId
);

public record Exemption(int Id, int TableConfigId, DateOnly AsOfDate, string Scope, string? Reason);

public record ArchivalRun(long Id, DateTime StartedAtEt, DateTime? EndedAtEt, string Status, string? Note);
public record ArchivalRunDetail(long Id, long RunId, int TableConfigId, DateOnly AsOfDate, DateType DateType,
    RunPhase Phase, DetailStatus Status, long? RowsAffected, string? FilePath, string? ErrorMessage, DateTime CreatedAtEt);

public record UploadedPart(string Path, string ETag, long Bytes, long Rows);
