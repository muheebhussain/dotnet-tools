﻿using Archival.Domain;

namespace Archival.Export;

public sealed record ArchivePlanItem(
    TableConfig TableConfig,
    DateOnly AsOfDate,
    string DateType,
    int SourceRowCount);
