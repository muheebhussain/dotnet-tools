﻿using Archival.Data;
using Archival.Domain;
using Serilog;

namespace Archival.Export;

/// <summary>
/// Computes which dates should be archived for a given table,
/// including keep-set filtering, exemptions, row counts and date types,
/// using batched repository calls where possible.
/// </summary>
public sealed class ArchivePlanner(ISqlFactory sqlFactory, IArchivalRepository repo, ILogger log)
{
    private readonly ISqlFactory _sqlFactory = sqlFactory ?? throw new ArgumentNullException(nameof(sqlFactory));
    private readonly IArchivalRepository _repo = repo ?? throw new ArgumentNullException(nameof(repo));
    private readonly ILogger _log = log ?? throw new ArgumentNullException(nameof(log));

    public async Task<IReadOnlyList<ArchivePlanItem>> BuildPlanAsync(
        TableConfig tableConfig,
        DateOnly? since = null)
    {
        // 1. Compute keep set and candidates (relational logic is already efficient in SQL)
        var keep = await _repo.GetKeepSetAsync(tableConfig.Id);
        var candidates = (await _repo.GetCandidatesAsync(tableConfig, keep)).ToList();

        if (since.HasValue)
            candidates = candidates.Where(d => d >= since.Value).ToList();

        if (candidates.Count == 0)
        {
            _log.Information("No archive candidates found for table {Table}.", tableConfig.FullName);
            return Array.Empty<ArchivePlanItem>();
        }

        // 2. Batch row counts and date types for all candidates
        var rowCounts = await _repo.GetRowCountsForDatesAsync(tableConfig, candidates);
        var dateTypes = await _repo.GetDateTypesForDatesAsync(candidates);

        // 3. Cache per-date exemptions at table scope
        var exemptionCache = new Dictionary<DateOnly, bool>();
        var plan = new List<ArchivePlanItem>(candidates.Count);

        foreach (var d in candidates)
        {
            if (!rowCounts.TryGetValue(d, out var srcCount) || srcCount == 0)
                continue;

            if (!exemptionCache.TryGetValue(d, out var isExempt))
            {
                isExempt = await SqlExtensions.HasExemptionAsync(_sqlFactory, tableConfig.Id, d, "table");
                exemptionCache[d] = isExempt;
            }

            if (isExempt)
            {
                _log.Warning("Exempted table deletion for {Date}", d);
                continue;
            }

            var dt = dateTypes.TryGetValue(d, out var dtValue) ? dtValue : "EOD";

            plan.Add(new ArchivePlanItem(
                TableConfig: tableConfig,
                AsOfDate: d,
                DateType: dt,
                SourceRowCount: srcCount));
        }

        return plan;
    }
}
