using Archival.Core;
using Archival.Data;
using Archival.Data.Repositories;
using Archival.Domain;
using Microsoft.Extensions.Options;
using Serilog;

namespace Archival.Export;

/// <summary>
/// High-level orchestration for archive runs:
///  - starts/ends run
///  - builds plan
///  - invokes per-date executor (export + delete)
///  - aggregates run-detail logs.
/// </summary>
public sealed class ArchiveRunner
{
    private readonly IArchivalRepository _repo;
    private readonly IArchivalRunDetailRepository _runDetailRepo;
    private readonly ArchivePlanner _planner;
    private readonly TableArchiveExecutor _executor;
    private readonly ILogger _log;
    private readonly ArchivalOptions _options;

    public ArchiveRunner(
        IArchivalRepository repo,
        IArchivalRunDetailRepository runDetailRepo,
        ArchivePlanner planner,
        TableArchiveExecutor executor,
        ILogger log,
        IOptions<ArchivalOptions> options)
    {
        _repo          = repo ?? throw new ArgumentNullException(nameof(repo));
        _runDetailRepo = runDetailRepo ?? throw new ArgumentNullException(nameof(runDetailRepo));
        _planner       = planner ?? throw new ArgumentNullException(nameof(planner));
        _executor      = executor ?? throw new ArgumentNullException(nameof(executor));
        _log           = log ?? throw new ArgumentNullException(nameof(log));
        _options       = options?.Value ?? throw new ArgumentNullException(nameof(options));
    }

    public async Task RunArchiveAsync(
        string tableFullName,
        int batchDelete,
        int maxReadRows,
        bool dryRun,
        DateOnly? since = null)
    {
        var runId = await _repo.StartRunAsync($"archive {tableFullName}");
        var detailLogs = new List<RunDetailLog>();

        try
        {
            var tc = await _repo.GetTableConfigAsync(tableFullName)
                     ?? throw new InvalidOperationException($"table not found: {tableFullName}");

            if (tc.ExportMode != ExportMode.SelfManaged)
            {
                _log.Information("Table {Table} is External; skipping archive.", tableFullName);
                await _repo.EndRunAsync(runId, "Success");
                return;
            }

            var plan = await _planner.BuildPlanAsync(tc, since);
            if (plan.Count == 0)
            {
                await _repo.EndRunAsync(runId, "Success");
                return;
            }

            var pk       = await SqlExtensions.TryGetPrimaryKeyColumnAsync(_executor.SqlFactory, tc);
            var colsMeta = await _executor.ReadColumnsAsync(tc);

            foreach (var item in plan)
            {
                if (dryRun)
                {
                    _log.Information("[DRY] Would export+delete {Table} for {Date} rows={Rows}",
                        tc.FullName, item.AsOfDate, item.SourceRowCount);
                    continue;
                }

                // 1. Export
                var exported = await _executor.ExportAsync(
                    item,
                    maxReadRows,
                    colsMeta,
                    dryRun: false);

                if (exported != item.SourceRowCount)
                {
                    detailLogs.Add(new RunDetailLog(
                        RunId: runId,
                        TableConfigId: tc.Id,
                        AsOfDate: item.AsOfDate,
                        DateType: item.DateType,
                        Phase: "Export",
                        Status: "Failed",
                        Rows: exported,
                        Path: PathUtil.BuildPrefix(tc, item.AsOfDate),
                        Error: $"Row mismatch src={item.SourceRowCount} dst={exported}"));

                    continue;
                }

                var prefix = PathUtil.BuildPrefix(tc, item.AsOfDate);

                detailLogs.Add(new RunDetailLog(
                    RunId: runId,
                    TableConfigId: tc.Id,
                    AsOfDate: item.AsOfDate,
                    DateType: item.DateType,
                    Phase: "Export",
                    Status: "Success",
                    Rows: exported,
                    Path: prefix,
                    Error: null));

                // 2. Delete
                var deleted = await _executor.DeleteAsync(
                    item,
                    batchDelete,
                    pk,
                    dryRun: false);

                detailLogs.Add(new RunDetailLog(
                    RunId: runId,
                    TableConfigId: tc.Id,
                    AsOfDate: item.AsOfDate,
                    DateType: item.DateType,
                    Phase: "Delete",
                    Status: "Success",
                    Rows: deleted,
                    Path: prefix,
                    Error: null));
            }

            if (detailLogs.Count > 0)
            {
                await _runDetailRepo.BulkLogDetailsAsync(detailLogs);
            }

            await _repo.EndRunAsync(runId, "Success");
        }
        catch (Exception ex)
        {
            await _repo.EndRunAsync(runId, "Failed");
            _log.Error(ex, "Archive failed");
        }
    }
}
