﻿using Parquet;
using Parquet.Data;
using Parquet.Schema;
using Archival.Blob;
using Archival.Core;
using Archival.Data;
using Archival.Domain;
using Serilog;

namespace Archival.Export;

/// <summary>
/// Handles export of a single table/date to Parquet + Blob,
/// and deletion of source rows, using data-layer abstractions
/// for all SQL.
/// </summary>
public sealed class TableArchiveExecutor(
    ITableArchiveData tableData,
    IArchivalRepository repo,
    IBlobService blob,
    ArchivalOptions options,
    ISqlFactory sqlFactory,
    ILogger log)
{
    private readonly ITableArchiveData _tableData = tableData ?? throw new ArgumentNullException(nameof(tableData));
    private readonly IArchivalRepository _repo    = repo ?? throw new ArgumentNullException(nameof(repo));
    private readonly IBlobService _blob          = blob ?? throw new ArgumentNullException(nameof(blob));
    private readonly ArchivalOptions _options    = options ?? throw new ArgumentNullException(nameof(options));
    private readonly ILogger _log                = log ?? throw new ArgumentNullException(nameof(log));
    public ISqlFactory SqlFactory { get; } = sqlFactory ?? throw new ArgumentNullException(nameof(sqlFactory));

    /// <summary>
    /// Exports all rows for the given plan item (table/date) to Parquet and Blob storage,
    /// and upserts archival_file metadata. Returns the number of exported rows.
    /// </summary>
    public async Task<long> ExportAsync(
        ArchivePlanItem planItem,
        int maxReadRows,
        List<(string Name, Type Type)> colsMeta,
        bool dryRun)
    {
        var tc       = planItem.TableConfig;
        var d        = planItem.AsOfDate;
        var dt       = planItem.DateType;
        var srcCount = planItem.SourceRowCount;

        if (dryRun)
        {
            _log.Information("[DRY] Would export {Table} for {Date} rows={Rows}",
                tc.FullName, d, srcCount);
            return 0;
        }

        var prefix     = PathUtil.BuildPrefix(tc, d);
        long totalRows = 0;
        int  partIndex = 0;
        int  offset    = 0;

        while (true)
        {
            var (rows, cont) = await _tableData.ReadChunkAsync(tc, d, offset, maxReadRows);
            if (rows.Count == 0)
                break;

            offset += rows.Count;

            var tmp = Path.Combine(
                Path.GetTempPath(),
                $"export_{tc.Id}_{d:yyyyMMdd}_{partIndex:0000}.parquet");

            await WriteParquetChunkAsync(tmp, rows, colsMeta);

            var blobPath = $"{prefix}/part-{partIndex:0000}.parquet";

            var (etag, bytes) = await _blob.UploadAsync(_options.BlobContainer, blobPath, tmp);
            await _repo.UpsertArchivalFileAsync(tc.Id, d, dt, blobPath, etag, bytes, rows.Count);

            try { File.Delete(tmp); } catch { /* ignore */ }

            totalRows += rows.Count;
            partIndex++;

            _log.Information("Exported {Rows} rows to {BlobPath}", rows.Count, blobPath);

            if (!cont)
                break;
        }

        return totalRows;
    }

    /// <summary>
    /// Deletes all source rows for the given plan item (table/date) using batched deletes.
    /// Returns the number of deleted rows.
    /// </summary>
    public async Task<long> DeleteAsync(
        ArchivePlanItem planItem,
        int batchDeleteSize,
        string? pkColumn,
        bool dryRun)
    {
        var tc = planItem.TableConfig;
        var d  = planItem.AsOfDate;

        if (dryRun)
        {
            _log.Information("[DRY] Would delete rows for {Table} {Date}",
                tc.FullName, d);
            return 0;
        }

        var deleted = await _tableData.DeleteBatchedAsync(tc, d, batchDeleteSize, pkColumn);
        _log.Information("Deleted {Rows} rows from {Table} for {Date}", deleted, tc.FullName, d);
        return deleted;
    }

    public Task<List<(string Name, Type Type)>> ReadColumnsAsync(TableConfig tc) =>
        _tableData.ReadColumnsAsync(tc);

    // ---------- Parquet writer (no SQL) ----------

    private async Task WriteParquetChunkAsync(
        string filePath,
        List<Dictionary<string, object>> rows,
        List<(string Name, Type Type)> colsMeta)
    {
        var fields = new List<Field>();
        foreach (var (name, type) in colsMeta)
        {
            fields.Add(type switch
            {
                Type t when t == typeof(int)      => new DataField<int?>(name),
                Type t when t == typeof(long)     => new DataField<long?>(name),
                Type t when t == typeof(short)    => new DataField<short?>(name),
                Type t when t == typeof(byte)     => new DataField<int?>(name),
                Type t when t == typeof(bool)     => new DataField<bool?>(name),
                Type t when t == typeof(double)   => new DataField<double?>(name),
                Type t when t == typeof(float)    => new DataField<float?>(name),
                Type t when t == typeof(decimal)  => new DecimalDataField(name, 38, 18),
                Type t when t == typeof(DateTime) => new DateTimeDataField(name, DateTimeFormat.DateAndTime, true),
                Type t when t == typeof(Guid)     => new DataField<string>(name),
                Type t when t == typeof(byte[])   => new DataField<byte[]>(name),
                _                                 => new DataField<string>(name)
            });
        }

        var schema = new ParquetSchema(fields.ToArray());

        await using var fs     = File.Create(filePath);
        await using var writer = await ParquetWriter.CreateAsync(schema, fs);
        using var rg           = writer.CreateRowGroup();

        foreach (var field in fields)
        {
            Array data;

            if (field is DataField<int?> fi)
                data = rows.Select(r => ToNullable<int>(r, fi.Name, Convert.ToInt32)).ToArray();
            else if (field is DataField<long?> fl)
                data = rows.Select(r => ToNullable<long>(r, fl.Name, Convert.ToInt64)).ToArray();
            else if (field is DataField<short?> fsn)
                data = rows.Select(r => ToNullable<short>(r, fsn.Name, Convert.ToInt16)).ToArray();
            else if (field is DataField<bool?> fb)
                data = rows.Select(r => ToNullable<bool>(r, fb.Name, Convert.ToBoolean)).ToArray();
            else if (field is DataField<double?> fd)
                data = rows.Select(r => ToNullable<double>(r, fd.Name, Convert.ToDouble)).ToArray();
            else if (field is DataField<float?> ff)
                data = rows.Select(r => ToNullable<float>(r, ff.Name, Convert.ToSingle)).ToArray();
            else if (field is DecimalDataField fdec)
                data = rows.Select(r => ToNullable<decimal>(r, fdec.Name, Convert.ToDecimal)).ToArray();
            else if (field is DateTimeDataField fdt)
            {
                data = rows.Select(r =>
                {
                    if (!r.TryGetValue(fdt.Name, out var v) || v is null || v == DBNull.Value)
                        return DateTime.MinValue;
                    return Convert.ToDateTime(v);
                }).ToArray();
            }
            else if (field is DataField<byte[]> fbarr)
                data = rows.Select(r => r.TryGetValue(fbarr.Name, out var v) && v != DBNull.Value ? (byte[])v : null).ToArray();
            else
                data = rows.Select(r => r.TryGetValue(field.Name, out var v) && v != DBNull.Value ? v?.ToString() : null).ToArray();

            await rg.WriteColumnAsync(new DataColumn((DataField)field, data));
        }
    }

    private static T? ToNullable<T>(
        Dictionary<string, object> row,
        string name,
        Func<object, T> convert) where T : struct
    {
        if (!row.TryGetValue(name, out var v) || v is null || v == DBNull.Value)
            return null;
        return convert(v);
    }
}
