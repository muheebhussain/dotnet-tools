# 📦 ARCHIVAL SYSTEM

*A complete data archival and lifecycle management framework.*

Designed for **Azure SQL**, **Azure Blob Storage**, **.NET**, and **Apache Airflow**.

## 📑 1. Overview

The Archival System manages long-term storage of large SQL tables using a business-date–aware retention strategy.

It supports:
*   Controlled SQL data retention (EOD / EOM / EOQ / EOY business dates)
*   Exporting old data to Parquet files in Azure Blob Storage
*   Reconciling external Parquet files
*   Applying file lifecycle rules (Cool → Archive → Delete)
*   Full audit history of every archival run
*   Safe parallelization through Apache Airflow

This README explains:
*   How the system works
*   What each SQL table and column means
*   The architecture
*   The retention and lifecycle logic
*   The archival workflow

This document is intended for developers, business analysts, solution architects, and future teams.

## 🧠 2. Big Picture: How the System Works

The archival system has three major responsibilities:

### A) Decide what SQL data to keep vs archive

Uses:
*   ✔ Business date calendar
*   ✔ Retention policy
*   ✔ Exemption rules

### B) Export archive files (Parquet) to Blob Storage

Then registers them in the `archival_file` table.

### C) Manage lifecycle of archived files

Moves files through tiers: Cool Tier → Archive Tier → Delete.

## 🏗️ 3. High-level Architecture Diagram (Mermaid)

```mermaid
flowchart LR
    subgraph Airflow[Apache Airflow Orchestration]
        DAG[Archival DAG]
        A1[archive]
        A2[reconcile]
        A3[lifecycle]
        DAG --> A1
        DAG --> A2
        DAG --> A3
    end

    subgraph DotNet[.NET Archival Solution]
        CLI[Archival.Cli]
        EXPORT[ArchiveRunner\n(SelfManaged)]
        RECON[ReconcileRunner]
        LIFE[LifecycleRunner]
        DATA[Archival.Data\n(SqlRepo, SqlEx)]
        BLOB[Archival.Blob\n(BlobService)]
        CORE[Archival.Core]
        CLI --> EXPORT
        CLI --> RECON
        CLI --> LIFE
        EXPORT --> DATA
        EXPORT --> BLOB
        RECON --> DATA
        RECON --> BLOB
        LIFE --> DATA
        LIFE --> BLOB
    end

    subgraph SQL[Azure SQL Database]
        CFG[archival_table_config]
        POL1[archival_table_retention_policy]
        POL2[archival_file_lifecycle_policy]
        FILES[archival_file]
        EXEMPT[archival_exemption]
        RUN[archival_run]
        DETAIL[archival_run_detail]
        BDView[v_business_date_classification]
    end

    subgraph Storage[Blob Storage]
        PARQUET[Parquet Files]
    end

    A1 --> CLI
    A2 --> CLI
    A3 --> CLI

    EXPORT --> PARQUET
    RECON --> PARQUET
    LIFE --> PARQUET

    DATA <---> SQL
```

## 📘 4. Table-by-Table and Column-by-Column Explanation

This section is key to understanding the project. The database has 7 important archival tables, grouped as follows:

### 🧠 A. RETENTION & LIFECYCLE TABLES (The "Brain")

#### 1️⃣ `archival_table_retention_policy`

| Purpose | Defines how much history to keep in SQL before archiving. Used by `.NET ArchiveRunner`. |
| :--- | :--- |
| **Memory Trick** | "This defines how many SQL rows we keep before exporting." |

| Column | Meaning | Example |
| :--- | :--- | :--- |
| `keep_last_eod` | Keep last X End-of-Day (EOD) business dates | Keep 90 days |
| `keep_last_eom` | Keep last X End-of-Month (EOM) dates | Keep 24 months |
| `keep_last_eoq` | Keep last X End-of-Quarter (EOQ) dates | Keep 12 quarters |
| `keep_last_eoy` | Keep last X End-of-Year (EOY) dates | Keep 5 years |

#### 2️⃣ `archival_file_lifecycle_policy`

| Purpose | Defines what happens to Parquet files after they have been created. |
| :--- | :--- |
| **Memory Trick** | "SQL retention cleans tables. Lifecycle cleans Blob Storage." |

| Column | Meaning |
| :--- | :--- |
| `eod_cool_days` | When to move EOD file → Cool Tier |
| `eod_archive_days` | When to move EOD file → Archive Tier |
| `eod_delete_days` | When to delete EOD file |
| `external_keep_eod_days` | Retention for externally produced Parquet files |
| *(Same pattern for EOM/EOQ/EOY)* | |

#### 3️⃣ `archival_table_config`

| Purpose | Defines **how** each SQL table is archived. This is the master configuration. |
| :--- | :--- |
| **Memory Trick** | "This is the master config for each archived table." |

| Column | Meaning |
| :--- | :--- |
| `database_name` | DB name |
| `schema_name` | Schema |
| `table_name` | Table |
| `as_of_date_column` | The business-date column |
| `export_mode` | `SelfManaged` / `External` |
| `archive_path_template` | Blob path format |
| `table_retention_policy_id` | Which SQL retention rule to use |
| `file_lifecycle_policy_id` | Which file lifecycle rule to use |

#### 4️⃣ `archival_exemption`

| Purpose | Protects specific dates from archival or lifecycle deletion. |
| :--- | :--- |
| **Memory Trick** | "The Do-Not-Touch list." |

| Scope | Meaning | Example |
| :--- | :--- | :--- |
| `table` | Don't delete SQL rows | `2022-12-31`, scope=`both` (Year-end audits) |
| `file` | Don’t lifecycle the Parquet file | `2023-09-30`, scope=`file` (Legal retention) |
| `both` | Protect both SQL rows and Parquet file | |

### 📁 B. FILE CATALOG TABLE (The "Inventory")

#### 5️⃣ `archival_file`

| Purpose | Represents **each** Parquet file stored in Blob Storage. |
| :--- | :--- |
| **Memory Trick** | "This is the inventory of all archived files." |

| Column | Meaning |
| :--- | :--- |
| `table_config_id` | Which table this file belongs to |
| `as_of_date` | Business date for file's data |
| `date_type` | EOD / EOM / EOQ / EOY |
| `file_path` | Blob path |
| `etag` | Used for tiering / deletion with `If-Match` |
| `file_size_bytes` | Size |
| `row_count` | SQL rows in the file |
| `status` | `Created` / `Cool` / `Archive` / `Deleted` / `Failed` |
| `override_file_lifecycle_policy_id` | (Optional) override lifecycle rule |

### 📜 C. RUN LOGGING TABLES (The "Black Box Recorder")

#### 6️⃣ `archival_run`

| Purpose | One row per execution of archive, reconcile, or lifecycle. |
| :--- | :--- |
| **Memory Trick** | "Each run = one Airflow task execution." |

| Column | Meaning |
| :--- | :--- |
| `started_at_et` | Start time |
| `ended_at_et` | End time |
| `status` | `Running` / `Success` / `Failed` |
| `note` | Optional comment |

#### 7️⃣ `archival_run_detail`

| Purpose | Detailed logging of what happened for each date and phase. |
| :--- | :--- |
| **Memory Trick** | "Your black-box flight recorder for debugging & audit." |

| Column | Meaning |
| :--- | :--- |
| `run_id` | Link to `archival_run` |
| `table_config_id` | Table |
| `as_of_date` | The date being processed |
| `phase` | `Export` / `Delete` / `Reconcile` / `Lifecycle` |
| `status` | `Success` / `Failed` / `Skipped` |
| `rows_affected` | SQL deletes |
| `file_path` | Parquet file path |
| `error_message` | Any failure |

## 🧠 5. How the Archival System Decides What to Keep

The system determines the **KEEP SET** of dates using:
*   Business calendar (`v_business_date_classification`)
*   Table retention policy (`archival_table_retention_policy`)
*   Exemptions (`archival_exemption`)

The **KEEP SET** rules are:
*   Keep last X EOD business dates
*   Keep last X EOM dates
*   Keep last X EOQ dates
*   Keep last X EOY dates
*   **PLUS** all exempted dates

Everything else is a candidate for archival.

## 📦 6. Archive Workflow (`SelfManaged`)

1.  Determine **KEEP** dates.
2.  Determine **candidate** dates.
3.  For each candidate date:
    *   Optional skip if exemption is found.
    *   Read SQL data in chunks.
    *   Write Parquet to a temp file.
    *   Upload to Blob Storage.
    *   Register file in `archival_file`.
    *   Verify row counts.
    *   Delete table rows in batches (50k).
    *   Log `run_detail` for `Export` and `Delete` phases.

## 🔍 7. Reconcile Workflow

Used when Parquet files are produced externally, or to re-sync the catalog.

1.  Scan Blob storage.
2.  Extract date from path (e.g., `as_of_date=YYYY-MM-DD`).
3.  Map date to `date_type` using the business calendar.
4.  Upsert into `archival_file`.
5.  Log `run_detail`.

## ❄️ 8. Lifecycle Workflow (Cool → Archive → Delete)

1.  For each file in `archival_file`:
    *   Skip if exempt.
    *   Determine effective lifecycle policy.
    *   Compute `age_in_days`.
    *   Compare age against policy:
        *   Age ≥ `delete_days` → **Delete**
        *   Age ≥ `archive_days` → Move to **Archive** Tier
        *   Age ≥ `cool_days` → Move to **Cool** Tier
    *   Update `status`, `current_access_tier`, and `last_tier_check_at_et`.
    *   Log `run_detail`.

## 🛠️ 9. .NET Solution Structure

*   `Archival.Cli`: CLI entry point
*   `Archival.Export`: Contains `ArchiveRunner`
*   `Archival.Reconcile`: Contains `ReconcileRunner`
*   `Archival.Lifecycle`: Contains `LifecycleRunner`
*   `Archival.Data`: SQL repositories and retention logic
*   `Archival.Blob`: Blob storage operations
*   `Archival.Core`: Shared utilities
*   `Archival.Tests`: Unit tests

## 🎯 10. Key Mental Models to Always Remember

1.  **SQL retention cleans SQL**
    → `archival_table_retention_policy`
2.  **File lifecycle cleans Blob**
    → `archival_file_lifecycle_policy`
3.  **Table configuration directs everything**
    → `archival_table_config`
4.  **Exemptions override all rules**
    → `archival_exemption`
5.  **Parquet files = real assets**
    → `archival_file`
6.  **Every run is fully logged**
    → `archival_run` + `archival_run_detail`
