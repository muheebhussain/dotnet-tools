
using Dapper;
using Archival.Domain;

namespace Archival.Data;

public static class SqlExtensions
{
    public static async Task<string?> TryGetPrimaryKeyColumnAsync(ISqlFactory factory, TableConfig tc)
    {
        using var db = await factory.OpenAsync();
        var sql = $@"
        SELECT TOP 1 c.name
        FROM [{tc.DatabaseName}].sys.indexes i
        JOIN [{tc.DatabaseName}].sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.key_ordinal = 1
        JOIN [{tc.DatabaseName}].sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE i.object_id = OBJECT_ID(@obj) AND i.is_primary_key = 1
        ORDER BY ic.key_ordinal;";
        return await db.ExecuteScalarAsync<string?>(sql, new { obj = $"[{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]" });
    }

    public static async Task<bool> HasExemptionAsync(ISqlFactory factory, int tableConfigId, DateOnly d, string scope)
    {
        using var db = await factory.OpenAsync();
        var sql = "SELECT 1 FROM dbo.archival_exemption WHERE table_config_id=@t AND as_of_date=@d AND scope IN (@s, 'both');";
        var val = await db.ExecuteScalarAsync<int?>(sql, new { t = tableConfigId, d = d.ToDateTime(TimeOnly.MinValue), s = scope });
        return val.HasValue;
    }

    public static async Task UpdateFileStatusAsync(ISqlFactory factory, long fileId, string status, string? tier, string? newEtag)
    {
        using var db = await factory.OpenAsync();
        var sql = @"UPDATE dbo.archival_file
                    SET status=@s, current_access_tier = COALESCE(@tier, current_access_tier),
                        etag = COALESCE(@etag, etag),
                        last_tier_check_at_et = CAST(SYSDATETIMEOFFSET() AT TIME ZONE 'Eastern Standard Time' AS datetime2(3))
                    WHERE id=@id;";
        await db.ExecuteAsync(sql, new { id = fileId, s = status, tier, etag = newEtag });
    }

    public static async Task<IEnumerable<(ArchivalFile File, TableConfig Tc)>> GetFilesForLifecycleAsync(ISqlFactory factory, int take)
    {
        using var db = await factory.OpenAsync();
        var sql = @"
        SELECT TOP (@take)
            f.id, f.table_config_id, CAST(f.as_of_date AS date) AS AsOfDate, f.date_type AS DateType,
            f.file_path, f.etag, f.file_size_bytes, f.row_count,
            f.status, f.created_at_et AS CreatedAtEt, f.current_access_tier, f.last_tier_check_at_et,
            f.override_file_lifecycle_policy_id,
            tc.id AS TcId, tc.database_name AS DatabaseName, tc.schema_name AS SchemaName, tc.table_name AS TableName,
            tc.as_of_date_column AS AsOfDateColumn,
            CASE tc.export_mode WHEN 'SelfManaged' THEN 0 ELSE 1 END AS ExportMode,
            tc.archive_path_template AS ArchivePathTemplate,
            tc.table_retention_policy_id AS TableRetentionPolicyId, tc.file_lifecycle_policy_id AS FileLifecyclePolicyId
        FROM dbo.archival_file f
        JOIN dbo.archival_table_config tc ON tc.id = f.table_config_id
        WHERE f.status IN ('Created','Cool','Archive')
        ORDER BY f.created_at_et;";
        var rows = await db.QueryAsync(sql, new { take });

        var list = new List<(ArchivalFile, TableConfig)>();
        foreach (var r in rows)
        {
            var file = new ArchivalFile(
                (long)r.id, (int)r.table_config_id, DateOnly.FromDateTime((DateTime)r.AsOfDate),
                Enum.Parse<DateType>((string)r.DateType),
                (string)r.file_path, (string?)r.etag, (long?)r.file_size_bytes, (long?)r.row_count,
                Enum.Parse<FileStatus>((string)r.status), (DateTime)r.CreatedAtEt,
                (string?)r.current_access_tier, (DateTime?)r.last_tier_check_at_et,
                (int?)r.override_file_lifecycle_policy_id
            );
            var tc = new TableConfig(
                (int)r.TcId, (string)r.DatabaseName, (string)r.SchemaName, (string)r.TableName, (string)r.AsOfDateColumn,
                (ExportMode)r.ExportMode, (string)r.ArchivePathTemplate, (int)r.TableRetentionPolicyId, (int)r.FileLifecyclePolicyId
            );
            list.Add((file, tc));
        }
        return list;
    }

    public static async Task<FileLifecyclePolicy?> GetEffectiveLifecyclePolicyAsync(ISqlFactory factory, ArchivalFile f, TableConfig tc)
    {
        using var db = await factory.OpenAsync();
        var sql = @"
        SELECT TOP 1 id as Id, name as Name, is_active as IsActive,
          eod_cool_days AS EodCool, eod_archive_days AS EodArchive, eod_delete_days AS EodDelete,
          eom_cool_days AS EomCool, eom_archive_days AS EomArchive, eom_delete_days AS EomDelete,
          eoq_cool_days AS EoqCool, eoq_archive_days AS EoqArchive, eoq_delete_days AS EoqDelete,
          eoy_cool_days AS EoyCool, eoy_archive_days AS EoyArchive, eoy_delete_days AS EoyDelete,
          external_keep_eod_days AS ExternalKeepEodDays
        FROM dbo.archival_file_lifecycle_policy
        WHERE id = ISNULL(@overrideId, @tablePolicyId);";
        return await db.QueryFirstOrDefaultAsync<FileLifecyclePolicy>(sql, new { overrideId = f.OverrideFileLifecyclePolicyId, tablePolicyId = tc.FileLifecyclePolicyId });
    }
}
