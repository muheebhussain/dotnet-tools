﻿using Archival.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Repositories;

public interface IArchivalFileRepository
{
    /// <summary>
    /// Bulk update file status values for the given file ids.
    /// </summary>
    Task BulkUpdateStatusAsync(IEnumerable<FileStatusUpdate> updates, CancellationToken cancellationToken = default);
}

public sealed class ArchivalFileRepository(ArchivalContext context) : IArchivalFileRepository
{
    private readonly ArchivalContext _context = context ?? throw new ArgumentNullException(nameof(context));

    public async Task BulkUpdateStatusAsync(IEnumerable<FileStatusUpdate> updates, CancellationToken cancellationToken = default)
    {
        var items = updates?
            .Where(u => !string.IsNullOrWhiteSpace(u.Status))
            .ToList() ?? new List<FileStatusUpdate>();

        if (items.Count == 0)
            return;

        // Group by target status so we can use a single UPDATE per status value
        var groups = items
            .GroupBy(u => u.Status, StringComparer.OrdinalIgnoreCase)
            .ToList();

        foreach (var group in groups)
        {
            var status = group.Key;
            var ids = group.Select(u => u.FileId).Distinct().ToList();

            if (ids.Count == 0)
                continue;

            // Single SQL UPDATE per status group:
            // UPDATE archival_file SET status = {status}
            // WHERE id IN ( ...ids... )
            await _context.ArchivalFiles
                .Where(f => ids.Contains(f.Id))
                .ExecuteUpdateAsync(
                    s => s.SetProperty(
                        f => f.Status,
                        _ => status),
                    cancellationToken);
        }
    }
}
