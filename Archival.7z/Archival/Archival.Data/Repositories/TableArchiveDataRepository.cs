﻿using System.Data;
using Archival.Domain;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Archival.Data.Repositories;

/// <summary>
/// Dapper-based implementation of ITableArchiveData.
/// Responsible only for SQL I/O, not business logic.
/// </summary>
public sealed class TableArchiveDataRepository(ISqlFactory sqlFactory) : ITableArchiveData
{
    private readonly ISqlFactory _sqlFactory = sqlFactory ?? throw new ArgumentNullException(nameof(sqlFactory));

    public async Task<List<(string Name, Type Type)>> ReadColumnsAsync(TableConfig tc)
    {
        using var db = await _sqlFactory.OpenAsync();
        using var cmd = db.CreateCommand();
        cmd.CommandText = $@"SELECT TOP(1) * FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]";

        if (cmd is SqlCommand sqlCmd)
        {
            await using var reader = await sqlCmd.ExecuteReaderAsync(CommandBehavior.SchemaOnly);
            var schema = reader.GetColumnSchema();
            return schema.Select(s => (s.ColumnName!, s.DataType ?? typeof(string))).ToList();
        }

        throw new NotSupportedException("ReadColumnsAsync requires SqlCommand to access GetColumnSchema.");
    }

    public async Task<(List<Dictionary<string, object>> Rows, bool Continue)> ReadChunkAsync(
        TableConfig tc,
        DateOnly asOfDate,
        int offset,
        int take)
    {
        using var conn = await _sqlFactory.OpenAsync();
        var qry = $@"
            SELECT * FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]
            WHERE [{tc.AsOfDateColumn}] = @d
            ORDER BY (SELECT NULL)
            OFFSET {offset} ROWS FETCH NEXT {take} ROWS ONLY;";

        var rows = await conn.QueryAsync(qry, new { d = asOfDate.ToDateTime(TimeOnly.MinValue) });

        var list = new List<Dictionary<string, object>>();
        foreach (var r in rows)
        {
            var dict = new Dictionary<string, object>();
            foreach (var p in (IDictionary<string, object>)r)
                dict[p.Key] = p.Value ?? DBNull.Value;
            list.Add(dict);
        }

        return (list, list.Count == take);
    }

    public async Task<int> DeleteBatchedAsync(
        TableConfig tc,
        DateOnly asOfDate,
        int batchSize,
        string? pkColumn)
    {
        using var db = await _sqlFactory.OpenAsync();
        var total = 0;

        while (true)
        {
            string sql;
            if (!string.IsNullOrWhiteSpace(pkColumn))
            {
                sql = $@"
                    WITH cte AS (
                      SELECT TOP ({batchSize}) [{pkColumn}]
                      FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]
                      WHERE [{tc.AsOfDateColumn}] = @d
                      ORDER BY [{pkColumn}]
                    )
                    DELETE t
                    FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}] t
                    JOIN cte ON cte.[{pkColumn}] = t.[{pkColumn}];
                    SELECT @@ROWCOUNT;";
            }
            else
            {
                sql = $@"
                    DELETE TOP ({batchSize}) FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]
                    WHERE [{tc.AsOfDateColumn}] = @d;
                    SELECT @@ROWCOUNT;";
            }

            var affected = await db.ExecuteScalarAsync<int>(
                sql,
                new { d = asOfDate.ToDateTime(TimeOnly.MinValue) });

            if (affected == 0)
                break;

            total += affected;
        }

        return total;
    }
}
