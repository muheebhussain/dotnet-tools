﻿using Archival.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Archival.Data.Repositories;

public interface IArchivalRunDetailRepository
{
    Task BulkLogDetailsAsync(IEnumerable<RunDetailLog> logs, CancellationToken cancellationToken = default);
}

public sealed class ArchivalRunDetailRepository(ArchivalContext context) : IArchivalRunDetailRepository
{
    private readonly ArchivalContext _context = context ?? throw new ArgumentNullException(nameof(context));

    public async Task BulkLogDetailsAsync(IEnumerable<RunDetailLog> logs, CancellationToken cancellationToken = default)
    {
        var items = logs?.ToList() ?? new List<RunDetailLog>();
        if (items.Count == 0)
            return;

        var entities = new List<ArchivalRunDetail>(items.Count);
        entities.AddRange(items.Select(l => new ArchivalRunDetail
        {
            RunId = l.RunId,
            TableConfigId = l.TableConfigId,
            AsOfDate = l.AsOfDate,
            DateType = l.DateType,
            Phase = l.Phase,
            Status = l.Status,
            RowsAffected = l.Rows,
            FilePath = l.Path,
            ErrorMessage = l.Error
        }));

        await _context.ArchivalRunDetails.AddRangeAsync(entities, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);
    }
}
