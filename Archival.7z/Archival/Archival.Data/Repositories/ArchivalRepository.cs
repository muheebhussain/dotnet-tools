﻿using Archival.Domain;
using Dapper;

namespace Archival.Data.Repositories;

public sealed class ArchivalRepository(ISqlFactory factory) : IArchivalRepository
{
    private readonly ISqlFactory _factory = factory ?? throw new ArgumentNullException(nameof(factory));

    public async Task<TableConfig?> GetTableConfigAsync(string fullName)
    {
        using var db = await _factory.OpenAsync();
        var sql = @"
            SELECT id, database_name AS DatabaseName, schema_name AS SchemaName, table_name AS TableName,
                   as_of_date_column AS AsOfDateColumn,
                   CASE export_mode WHEN 'SelfManaged' THEN 0 ELSE 1 END AS ExportMode,
                   archive_path_template AS ArchivePathTemplate,
                   table_retention_policy_id AS TableRetentionPolicyId,
                   file_lifecycle_policy_id AS FileLifecyclePolicyId
            FROM dbo.archival_table_config
            WHERE CONCAT(database_name,'.',schema_name,'.',table_name) = @full;";
        return await db.QueryFirstOrDefaultAsync<TableConfig>(sql, new { full = fullName });
    }

    public async Task<IEnumerable<DateOnly>> GetKeepSetAsync(int tableConfigId)
    {
        using var db = await _factory.OpenAsync();
        var sql = @"
            DECLARE @today DATE = CAST(SYSDATETIMEOFFSET() AT TIME ZONE 'Eastern Standard Time' AS DATE);

            DECLARE @keep_eod INT, @keep_eom INT, @keep_eoq INT, @keep_eoy INT;
            SELECT @keep_eod = trp.keep_last_eod, @keep_eom = trp.keep_last_eom,
                   @keep_eoq = trp.keep_last_eoq, @keep_eoy = trp.keep_last_eoy
            FROM dbo.archival_table_config tc
            JOIN dbo.archival_table_retention_policy trp ON trp.id = tc.table_retention_policy_id
            WHERE tc.id = @tcid;

            WITH k_eod AS (
              SELECT TOP (ISNULL(@keep_eod,0)) current_business_date d
              FROM dbo.v_business_date_classification
              WHERE date_type='EOD' AND current_business_date<=@today
              ORDER BY current_business_date DESC
            ), k_eom AS (
              SELECT TOP (ISNULL(@keep_eom,0)) current_business_date d
              FROM dbo.v_business_date_classification
              WHERE date_type='EOM' AND current_business_date<=@today
              ORDER BY current_business_date DESC
            ), k_eoq AS (
              SELECT TOP (ISNULL(@keep_eoq,0)) current_business_date d
              FROM dbo.v_business_date_classification
              WHERE date_type='EOQ' AND current_business_date<=@today
              ORDER BY current_business_date DESC
            ), k_eoy AS (
              SELECT TOP (ISNULL(@keep_eoy,0)) current_business_date d
              FROM dbo.v_business_date_classification
              WHERE date_type='EOY' AND current_business_date<=@today
              ORDER BY current_business_date DESC
            )
            SELECT CAST(d AS date) FROM (
              SELECT d FROM k_eod
              UNION SELECT d FROM k_eom
              UNION SELECT d FROM k_eoq
              UNION SELECT d FROM k_eoy
            ) u;";
        var rows = await db.QueryAsync<DateTime>(sql, new { tcid = tableConfigId });
        return rows.Select(DateOnly.FromDateTime);
    }

    public async Task<IEnumerable<DateOnly>> GetCandidatesAsync(TableConfig tc, IEnumerable<DateOnly> keepSet)
    {
        using var db = await _factory.OpenAsync();

        await db.ExecuteAsync(
            "IF OBJECT_ID('tempdb..#keep') IS NOT NULL DROP TABLE #keep; CREATE TABLE #keep(d date PRIMARY KEY);");

        foreach (var d in keepSet)
        {
            await db.ExecuteAsync("INSERT #keep(d) VALUES (@d);",
                new { d = d.ToDateTime(TimeOnly.MinValue) });
        }

        var sql = $@"
            WITH present AS (
                SELECT DISTINCT CAST([{tc.AsOfDateColumn}] AS date) AS as_of_date
                FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}]
            )
            SELECT p.as_of_date
            FROM present p
            LEFT JOIN dbo.archival_exemption x
              ON x.table_config_id = @tcid AND x.as_of_date = p.as_of_date AND x.scope IN ('table','both')
            LEFT JOIN #keep k ON k.d = p.as_of_date
            WHERE x.as_of_date IS NULL AND k.d IS NULL
            ORDER BY p.as_of_date;";
        var rows = await db.QueryAsync<DateTime>(sql, new { tcid = tc.Id });
        return rows.Select(DateOnly.FromDateTime);
    }

    public async Task<int> GetRowCountForDateAsync(TableConfig tc, DateOnly d)
    {
        using var db = await _factory.OpenAsync();
        var sql = $@"
            SELECT COUNT(*) 
            FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}] WITH (NOLOCK)
            WHERE [{tc.AsOfDateColumn}] = @d;";
        return await db.ExecuteScalarAsync<int>(sql, new { d = d.ToDateTime(TimeOnly.MinValue) });
    }

    public async Task<string?> GetDateTypeAsync(DateOnly d)
    {
        using var db = await _factory.OpenAsync();
        var sql = @"SELECT TOP 1 date_type FROM dbo.v_business_date_classification WHERE current_business_date = @d;";
        return await db.ExecuteScalarAsync<string?>(sql, new { d = d.ToDateTime(TimeOnly.MinValue) });
    }

    // NEW: batched row counts
    public async Task<IDictionary<DateOnly, int>> GetRowCountsForDatesAsync(TableConfig tc, IEnumerable<DateOnly> dates)
    {
        var list = dates.Distinct().ToList();
        if (list.Count == 0)
            return new Dictionary<DateOnly, int>();

        using var db = await _factory.OpenAsync();

        var sql = $@"
            SELECT CAST([{tc.AsOfDateColumn}] AS date) AS as_of_date,
                   COUNT(*) AS cnt
            FROM [{tc.DatabaseName}].[{tc.SchemaName}].[{tc.TableName}] WITH (NOLOCK)
            WHERE CAST([{tc.AsOfDateColumn}] AS date) IN @ds
            GROUP BY CAST([{tc.AsOfDateColumn}] AS date);";

        var raw = await db.QueryAsync<(DateTime as_of_date, int cnt)>(
            sql,
            new { ds = list.Select(d => d.ToDateTime(TimeOnly.MinValue)) });

        return raw.ToDictionary(
            x => DateOnly.FromDateTime(x.as_of_date),
            x => x.cnt);
    }

    // NEW: batched date types
    public async Task<IDictionary<DateOnly, string>> GetDateTypesForDatesAsync(IEnumerable<DateOnly> dates)
    {
        var list = dates.Distinct().ToList();
        if (list.Count == 0)
            return new Dictionary<DateOnly, string>();

        using var db = await _factory.OpenAsync();

        var sql = @"
            SELECT CAST(current_business_date AS date) AS d,
                   date_type
            FROM dbo.v_business_date_classification
            WHERE CAST(current_business_date AS date) IN @ds;";

        var raw = await db.QueryAsync<(DateTime d, string date_type)>(
            sql,
            new { ds = list.Select(d => d.ToDateTime(TimeOnly.MinValue)) });

        return raw.ToDictionary(
            x => DateOnly.FromDateTime(x.d),
            x => x.date_type);
    }

    public async Task UpsertArchivalFileAsync(
        int tcid,
        DateOnly d,
        string dateType,
        string filePath,
        string? etag,
        long bytes,
        long? rows)
    {
        using var db = await _factory.OpenAsync();
        var sql = @"
            IF NOT EXISTS (SELECT 1 FROM dbo.archival_file WHERE table_config_id=@tcid AND as_of_date=@d AND file_path=@p)
            BEGIN
                INSERT dbo.archival_file (table_config_id, as_of_date, date_type, file_path, etag, file_size_bytes, row_count, status)
                VALUES (@tcid, @d, @dt, @p, @e, @b, @r, 'Created');
            END
            ELSE
            BEGIN
                UPDATE dbo.archival_file
                   SET etag=@e, file_size_bytes=@b, row_count=@r
                 WHERE table_config_id=@tcid AND as_of_date=@d AND file_path=@p;
            END";
        await db.ExecuteAsync(sql, new
        {
            tcid,
            d = d.ToDateTime(TimeOnly.MinValue),
            dt = dateType,
            p = filePath,
            e = etag,
            b = bytes,
            r = rows
        });
    }

    public async Task<long> StartRunAsync(string note)
    {
        using var db = await _factory.OpenAsync();
        var id = await db.ExecuteScalarAsync<long>(
            "INSERT dbo.archival_run (status, note) OUTPUT INSERTED.id VALUES ('Running', @n)",
            new { n = note });
        return id;
    }

    public async Task EndRunAsync(long runId, string status)
    {
        using var db = await _factory.OpenAsync();
        await db.ExecuteAsync(
            "UPDATE dbo.archival_run SET status=@s, ended_at_et = CAST(SYSDATETIMEOFFSET() AT TIME ZONE 'Eastern Standard Time' AS datetime2(3)) WHERE id=@id",
            new { s = status, id = runId });
    }

    public async Task LogDetailAsync(
        long runId,
        int tcid,
        DateOnly d,
        string dt,
        string phase,
        string status,
        long? rows,
        string? path,
        string? err)
    {
        using var db = await _factory.OpenAsync();
        var sql = @"
            INSERT dbo.archival_run_detail (run_id, table_config_id, as_of_date, date_type, phase, status, rows_affected, file_path, error_message)
            VALUES (@rid, @tcid, @d, @dt, @ph, @st, @rows, @path, @err);";
        await db.ExecuteAsync(sql, new
        {
            rid = runId,
            tcid,
            d = d.ToDateTime(TimeOnly.MinValue),
            dt,
            ph = phase,
            st = status,
            rows,
            path,
            err
        });
    }
}
