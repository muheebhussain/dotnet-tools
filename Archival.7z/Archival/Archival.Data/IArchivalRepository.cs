﻿using Archival.Domain;

namespace Archival.Data;

public interface IArchivalRepository
{
    Task<TableConfig?> GetTableConfigAsync(string fullName);
    Task<IEnumerable<DateOnly>> GetKeepSetAsync(int tableConfigId);
    Task<IEnumerable<DateOnly>> GetCandidatesAsync(TableConfig tc, IEnumerable<DateOnly> keepSet);

    // Existing scalar methods
    Task<int> GetRowCountForDateAsync(TableConfig tc, DateOnly d);
    Task<string?> GetDateTypeAsync(DateOnly d);

    // New batched methods
    Task<IDictionary<DateOnly, int>> GetRowCountsForDatesAsync(TableConfig tc, IEnumerable<DateOnly> dates);
    Task<IDictionary<DateOnly, string>> GetDateTypesForDatesAsync(IEnumerable<DateOnly> dates);

    Task UpsertArchivalFileAsync(
        int tcid,
        DateOnly d,
        string dateType,
        string filePath,
        string? etag,
        long bytes,
        long? rows);

    Task<long> StartRunAsync(string note);
    Task EndRunAsync(long runId, string status);
    Task LogDetailAsync(
        long runId,
        int tcid,
        DateOnly d,
        string dt,
        string phase,
        string status,
        long? rows,
        string? path,
        string? err);
}

public sealed record FileStatusUpdate(
    long FileId,
    string Status,
    string? LifecycleStatus,
    long? RowsAffected);

public sealed record RunDetailLog(
    long RunId,
    int TableConfigId,
    DateOnly AsOfDate,
    string DateType,
    string Phase,
    string Status,
    long? Rows,
    string? Path,
    string? Error);
