﻿using Archival.Domain;

namespace Archival.Data;

/// <summary>
/// Low-level data access for exporting and deleting table rows for archival.
/// </summary>
public interface ITableArchiveData
{
    Task<List<(string Name, Type Type)>> ReadColumnsAsync(TableConfig tc);

    Task<(List<Dictionary<string, object>> Rows, bool Continue)> ReadChunkAsync(
        TableConfig tc,
        DateOnly asOfDate,
        int offset,
        int take);

    Task<int> DeleteBatchedAsync(
        TableConfig tc,
        DateOnly asOfDate,
        int batchSize,
        string? pkColumn);
}
