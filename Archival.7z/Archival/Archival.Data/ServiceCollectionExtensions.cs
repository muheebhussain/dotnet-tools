﻿using Archival.Data.Models;
using Archival.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Archival.Data;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddArchivalData(this IServiceCollection services, IConfiguration configuration)
    {
        var dbConnectionString = configuration.GetConnectionString("Default");
        if (string.IsNullOrEmpty(dbConnectionString))
            throw new ArgumentNullException(nameof(dbConnectionString), "ConnectionString:Default cannot be null or empty");

        // Register ArchivalContext with logging and no-tracking
        services.AddDbContext<ArchivalContext>((sp, options) =>
        {
            // Use the application's logger factory if it has been registered
            var loggerFactory = sp.GetService<ILoggerFactory>();
            if (loggerFactory is not null)
            {
                options.UseLoggerFactory(loggerFactory);
            }

            options.UseSqlServer(dbConnectionString);

            // Default to no tracking – this is typically what you want in read-heavy/reporting scenarios
            options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

#if DEBUG
            // In debug, turn on detailed EF diagnostics, including parameter values
            options.EnableDetailedErrors();
            options.EnableSensitiveDataLogging();
#endif
        });
        //Needs to update
        services.AddSingleton<IArchivalRepository, ArchivalRepository>();
        services.AddScoped<ITableArchiveData, TableArchiveDataRepository>();
        services.AddScoped<IArchivalFileRepository, ArchivalFileRepository>();
        services.AddScoped<IArchivalRunDetailRepository, ArchivalRunDetailRepository>();
        return services;
    }
}
