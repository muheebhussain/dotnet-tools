
using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;
using Archival.Domain;

namespace Archival.Data;

public interface ISqlFactory
{
    IDbConnection Create();
    Task<IDbConnection> OpenAsync();
}

public sealed class SqlFactory(string connectionString) : ISqlFactory
{
    public IDbConnection Create() => new SqlConnection(connectionString);
    public async Task<IDbConnection> OpenAsync()
    {
        var c = new SqlConnection(connectionString);
        await c.OpenAsync();
        return c;
    }
}

