
using System.Text.RegularExpressions;
using Azure;
using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Archival.Data;
using Archival.Domain;
using Archival.Core;
using Archival.Blob;
using Microsoft.Extensions.Options;
using Serilog;

namespace Archival.Reconcile;

public sealed class ReconcileRunner(
    ISqlFactory sqlFactory,
    IArchivalRepository repo,
    IBlobService blob,
    IOptions<ArchivalOptions> options,
    ILogger log)
{
    private readonly ISqlFactory _sqlFactory = sqlFactory;
    private readonly ArchivalOptions _options = options.Value;

    private static readonly Regex AsOfRegex = new(@"as_of_date_(\d{4}-\d{2}-\d{2})", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public async Task RunAsync(string tableFullName, bool dryRun)
    {
        var runId = await repo.StartRunAsync($"reconcile {tableFullName}");
        try
        {
            var tc = await repo.GetTableConfigAsync(tableFullName)
                     ?? throw new InvalidOperationException($"table not found: {tableFullName}");

            var basePrefix = tc.ArchivePathTemplate
                .Replace("{db}", tc.DatabaseName)
                .Replace("{schema}", tc.SchemaName)
                .Replace("{table}", tc.TableName);

            var cut = basePrefix.IndexOf("as_of_date_", StringComparison.OrdinalIgnoreCase);
            var listPrefix = cut >= 0 ? basePrefix[..cut] : basePrefix;

            await foreach (var blobItem in blob.ListAsync(_options.BlobContainer, listPrefix))
            {
                var m = AsOfRegex.Match(blobItem.Name);
                if (!m.Success) continue;
                if (!DateOnly.TryParse(m.Groups[1].Value, out var asOf)) continue;

                var dt = await repo.GetDateTypeAsync(asOf) ?? "EOD";
                if (dryRun)
                {
                    log.Information("[DRY] Would register {Blob}", blobItem.Name);
                    continue;
                }

                await repo.UpsertArchivalFileAsync(
                    tc.Id,
                    asOf,
                    dt,
                    blobItem.Name,
                    blobItem.Properties.ETag?.ToString(),
                    blobItem.Properties.ContentLength ?? 0,
                    null);

                await repo.LogDetailAsync(
                    runId,
                    tc.Id,
                    asOf,
                    dt,
                    "Reconcile",
                    "Success",
                    null,
                    blobItem.Name,
                    null);
            }

            await repo.EndRunAsync(runId, "Success");
        }
        catch (Exception ex)
        {
            await repo.EndRunAsync(runId, "Failed");
            log.Error(ex, "Reconcile failed");
        }
    }
}
