using Azure.Storage.Blobs.Models;
using Archival.Data;
using Archival.Domain;
using Archival.Blob;
using Archival.Data.Repositories;
using Serilog;

namespace Archival.Lifecycle;

public sealed class LifecycleRunner(
    ISqlFactory sqlFactory,
    IArchivalRepository repo,
    IBlobService blob,
    string container,
    ILogger log,
    IArchivalFileRepository fileRepository,
    IArchivalRunDetailRepository archivalRunDetailRepository)
{
    public async Task RunAsync(int batch, bool dryRun)
    {
        var runId = await repo.StartRunAsync("lifecycle");
        var totalProcessed = 0;
        var batchNumber = 0;

        // Cache to avoid repeating DB calls for same (tableConfigId, asOfDate, scope)
        var exemptionCache = new Dictionary<(int TcId, DateOnly AsOf, string Scope), bool>();

        // Cache to avoid repeating DB calls for same (tableConfigId, DateType)
        var policyCache = new Dictionary<(int TcId, DateType Type), FileLifecyclePolicy?>();

        // Use a single "today" for the whole run so decisions are consistent
        var today = DateOnly.FromDateTime(DateTime.Now);

        try
        {
            while (true)
            {
                batchNumber++;
                log.Information("Lifecycle batch {Batch} starting, size={BatchSize}", batchNumber, batch);

                var files = (await SqlExtensions
                        .GetFilesForLifecycleAsync(sqlFactory, batch)
                        .ConfigureAwait(false))
                    .ToList();

                if (files.Count == 0)
                {
                    log.Information(
                        "No more lifecycle candidates found after {Batches} batches, total processed={Total}.",
                        batchNumber - 1,
                        totalProcessed);
                    break;
                }

                log.Information(
                    "Lifecycle batch {Batch} loaded {Count} candidate files.",
                    batchNumber,
                    files.Count);

                // Collect DB work to flush after processing the batch
                var statusUpdates = new List<FileStatusUpdate>();
                var detailLogs = new List<RunDetailLog>();

                foreach (var (file, tc) in files)
                {
                    // 1. Exemption check with cache
                    var exKey = (tc.Id, file.AsOfDate, Scope: "file");
                    if (!exemptionCache.TryGetValue(exKey, out var isExempt))
                    {
                        isExempt = await SqlExtensions.HasExemptionAsync(sqlFactory, tc.Id, file.AsOfDate, "file");
                        exemptionCache[exKey] = isExempt;
                    }

                    if (isExempt)
                    {
                        log.Information("Skipping exempted file {Path}", file.FilePath);
                        continue;
                    }

                    // 2. Lifecycle policy with cache
                    var polKey = (tc.Id, file.DateType);
                    if (!policyCache.TryGetValue(polKey, out var policy))
                    {
                        policy = await SqlExtensions.GetEffectiveLifecyclePolicyAsync(sqlFactory, file, tc);
                        policyCache[polKey] = policy;
                    }

                    if (policy is null || !policy.IsActive)
                    {
                        log.Information("No active policy for file {Path}", file.FilePath);
                        continue;
                    }

                    // 3. Decide action
                    var ageDays = today.DayNumber - file.AsOfDate.DayNumber;
                    var action = Decide(policy, file.DateType, ageDays);

                    if (action is LifecycleAction.None)
                        continue;

                    totalProcessed++;

                    if (dryRun)
                    {
                        log.Information("[DRY] Would {Action} {Path} (ageDays={Age})", action, file.FilePath, ageDays);
                        continue;
                    }

                    try
                    {
                        string statusText;
                        string? lifecycleStatus;
                        switch (action)
                        {
                            case LifecycleAction.Cool:
                                await blob.SetTierAsync(container, file.FilePath, AccessTier.Cool, file.ETag!);
                                statusText = "Cool";
                                lifecycleStatus = "Cool";
                                break;

                            case LifecycleAction.Archive:
                                await blob.SetTierAsync(container, file.FilePath, AccessTier.Archive, file.ETag!);
                                statusText = "Archive";
                                lifecycleStatus = "Archive";
                                break;

                            case LifecycleAction.Delete:
                                var deleted = await blob.DeleteAsync(container, file.FilePath, file.ETag!);
                                statusText = deleted ? "Deleted" : "Failed";
                                lifecycleStatus = null;
                                break;

                            default:
                                continue;
                        }

                        // Defer DB writes
                        statusUpdates.Add(new FileStatusUpdate(
                            FileId: file.Id,
                            Status: statusText,
                            LifecycleStatus: lifecycleStatus,
                            RowsAffected: null));

                        detailLogs.Add(new RunDetailLog(
                            RunId: runId,
                            TableConfigId: tc.Id,
                            AsOfDate: file.AsOfDate,
                            DateType: file.DateType.ToString(),
                            Phase: "Lifecycle",
                            Status: "Success",
                            Rows: null,
                            Path: file.FilePath,
                            Error: null));

                        log.Information("Lifecycle {Action} succeeded for {Path}", action, file.FilePath);
                    }
                    catch (Exception ex)
                    {
                        detailLogs.Add(new RunDetailLog(
                            RunId: runId,
                            TableConfigId: tc.Id,
                            AsOfDate: file.AsOfDate,
                            DateType: file.DateType.ToString(),
                            Phase: "Lifecycle",
                            Status: "Failed",
                            Rows: null,
                            Path: file.FilePath,
                            Error: ex.Message));

                        log.Error(ex, "Lifecycle {Action} failed for {Path}", action, file.FilePath);
                    }
                }

                // Flush batched DB updates for this batch
                if (dryRun) continue;
                if (statusUpdates.Count > 0)
                    await fileRepository.BulkUpdateStatusAsync(statusUpdates);

                if (detailLogs.Count > 0)
                    await archivalRunDetailRepository.BulkLogDetailsAsync(detailLogs);
            }

            await repo.EndRunAsync(runId, "Success");
            log.Information(
                "Lifecycle run {RunId} completed successfully. Total processed={TotalProcessed}.",
                runId,
                totalProcessed);
        }
        catch (Exception ex)
        {
            await repo.EndRunAsync(runId, "Failed");
            log.Error(
                ex,
                "Lifecycle run {RunId} failed after processing {TotalProcessed} files.",
                runId,
                totalProcessed);
        }
    }

    private enum LifecycleAction { None, Cool, Archive, Delete }

    private static LifecycleAction Decide(FileLifecyclePolicy p, DateType t, int ageDays)
    {
        int? cool = null, arch = null, del = null;

        switch (t)
        {
            case DateType.EOD:
                cool = p.EodCool; arch = p.EodArchive; del = p.EodDelete;
                break;
            case DateType.EOM:
                cool = p.EomCool; arch = p.EomArchive; del = p.EomDelete;
                break;
            case DateType.EOQ:
                cool = p.EoqCool; arch = p.EoqArchive; del = p.EoqDelete;
                break;
            case DateType.EOY:
                cool = p.EoyCool; arch = p.EoyArchive; del = p.EoyDelete;
                break;
        }

        if (del.HasValue  && ageDays >= del.Value)  return LifecycleAction.Delete;
        if (arch.HasValue && ageDays >= arch.Value) return LifecycleAction.Archive;
        if (cool.HasValue && ageDays >= cool.Value) return LifecycleAction.Cool;
        return LifecycleAction.None;
    }
}
