﻿namespace Archival.Blob;

/// <summary>
/// Domain-specific exception for blob storage issues, makes it easier for callers to handle.
/// </summary>
public sealed class BlobStorageException(string message, Exception innerException) : Exception(message, innerException);
