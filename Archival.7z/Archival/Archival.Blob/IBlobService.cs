﻿using Azure.Storage.Blobs.Models;

namespace Archival.Blob;

public interface IBlobService
{
    Task<(string etag, long bytes)> UploadAsync(string container, string blobPath, string localFile, CancellationToken cancellationToken = default);
    Task SetTierAsync(string container, string blobPath, AccessTier tier, string ifMatchETag, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(string container, string blobPath, string ifMatchETag, CancellationToken cancellationToken = default);
    Task<BlobProperties> GetPropsAsync(string container, string blobPath, CancellationToken cancellationToken = default);
    IAsyncEnumerable<BlobItem> ListAsync(string container, string? prefix, CancellationToken cancellationToken = default);
}
