﻿namespace Archival.Blob;

/// <summary>
/// Options for BlobService; DI-friendly and easy to extend.
/// Register it in your container and pass it to BlobService's constructor.
/// </summary>
public sealed class BlobStorageOptions
{
    /// <summary>
    /// Automatically create containers if they don't exist.
    /// </summary>
    public bool AutoCreateContainers { get; set; } = false;

    /// <summary>
    /// Maximum concurrent transfers for large uploads. Null = let SDK decide.
    /// </summary>
    public int? MaximumConcurrency { get; set; } = Math.Max(2, Environment.ProcessorCount / 2);

    /// <summary>
    /// Maximum transfer length per request in bytes. Null = SDK default.
    /// </summary>
    public int? MaximumTransferLength { get; set; } = (int?)(8L * 1024 * 1024); // 8 MB
}
