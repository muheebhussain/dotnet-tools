
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using Azure;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace Archival.Blob;

/// <summary>
/// Azure Blob implementation of IBlobService, designed for DI and reuse.
/// </summary>
public sealed class BlobService : IBlobService
{
    private readonly BlobServiceClient _svc;
    private readonly BlobStorageOptions _options;
    private readonly ConcurrentDictionary<string, Task> _containerInit = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Main constructor for DI. Register BlobServiceClient and BlobServiceOptions in your container.
    /// </summary>
    public BlobService(BlobServiceClient svc, BlobStorageOptions? options = null)
    {
        _svc = svc ?? throw new ArgumentNullException(nameof(svc));
        _options = options ?? new BlobStorageOptions();
    }

    public async Task<(string etag, long bytes)> UploadAsync(
        string container,
        string blobPath,
        string localFile,
        CancellationToken cancellationToken = default)
    {
        ValidateContainer(container);
        ValidateBlobPath(blobPath);
        ValidateLocalFile(localFile);

        var cont = _svc.GetBlobContainerClient(container);

        if (_options.AutoCreateContainers)
        {
            await EnsureContainerAsync(cont, cancellationToken).ConfigureAwait(false);
        }

        var blob = cont.GetBlobClient(blobPath);

        await using var fs = new FileStream(
            localFile,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            bufferSize: 1 << 16,
            options: FileOptions.Asynchronous);

        var transferOptions = new StorageTransferOptions
        {
            MaximumConcurrency = _options.MaximumConcurrency,
            MaximumTransferLength = _options.MaximumTransferLength
        };

        var uploadOptions = new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders
            {
                ContentType = ResolveContentType(localFile)
            },
            TransferOptions = transferOptions
        };

        await ExecuteWithContext(
            () => blob.UploadAsync(fs, uploadOptions, cancellationToken),
            "upload",
            container,
            blobPath,
            cancellationToken).ConfigureAwait(false);

        var props = await ExecuteWithContext(
            () => blob.GetPropertiesAsync(cancellationToken: cancellationToken),
            "get-properties",
            container,
            blobPath,
            cancellationToken).ConfigureAwait(false);

        return (props.Value.ETag.ToString(), props.Value.ContentLength);
    }

    public Task SetTierAsync(
        string container,
        string blobPath,
        AccessTier tier,
        string ifMatchETag,
        CancellationToken cancellationToken = default)
    {
        ValidateContainer(container);
        ValidateBlobPath(blobPath);
        ValidateETag(ifMatchETag);

        var blob = _svc.GetBlobContainerClient(container).GetBlobClient(blobPath);
        var conditions = new BlobRequestConditions { IfMatch = new ETag(ifMatchETag) };

        return ExecuteWithContext(
            () => blob.SetAccessTierAsync(tier, conditions: conditions, cancellationToken: cancellationToken),
            "set-tier",
            container,
            blobPath,
            cancellationToken);
    }

    public async Task<bool> DeleteAsync(
        string container,
        string blobPath,
        string ifMatchETag,
        CancellationToken cancellationToken = default)
    {
        ValidateContainer(container);
        ValidateBlobPath(blobPath);
        ValidateETag(ifMatchETag);

        var blob = _svc.GetBlobContainerClient(container).GetBlobClient(blobPath);
        var conditions = new BlobRequestConditions { IfMatch = new ETag(ifMatchETag) };

        var response = await ExecuteWithContext(
            () => blob.DeleteIfExistsAsync(conditions: conditions, cancellationToken: cancellationToken),
            "delete",
            container,
            blobPath,
            cancellationToken).ConfigureAwait(false);

        return response.Value;
    }

    public async Task<BlobProperties> GetPropsAsync(
        string container,
        string blobPath,
        CancellationToken cancellationToken = default)
    {
        ValidateContainer(container);
        ValidateBlobPath(blobPath);

        var blob = _svc.GetBlobContainerClient(container).GetBlobClient(blobPath);

        var props = await ExecuteWithContext(
            () => blob.GetPropertiesAsync(cancellationToken: cancellationToken),
            "get-properties",
            container,
            blobPath,
            cancellationToken).ConfigureAwait(false);

        return props.Value;
    }

    public async IAsyncEnumerable<BlobItem> ListAsync(
        string container,
        string? prefix,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        ValidateContainer(container);

        var cont = _svc.GetBlobContainerClient(container);

        // If listing on new containers is expected, you can opt-in to auto-creation here as well
        if (_options.AutoCreateContainers)
        {
            await EnsureContainerAsync(cont, cancellationToken).ConfigureAwait(false);
        }

        await foreach (var item in cont.GetBlobsAsync(prefix: prefix, cancellationToken: cancellationToken).ConfigureAwait(false))
        {
            yield return item;
        }
    }

    // ---------- Internal helpers ----------

    private Task EnsureContainerAsync(BlobContainerClient containerClient, CancellationToken cancellationToken)
    {
        return _containerInit.GetOrAdd(
            containerClient.Name,
            _ => containerClient.CreateIfNotExistsAsync(cancellationToken: cancellationToken));
    }

    private static void ValidateContainer(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Container name is required.", nameof(value));
    }

    private static void ValidateBlobPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Blob path is required.", nameof(path));
    }

    private static void ValidateETag(string? etag)
    {
        if (string.IsNullOrWhiteSpace(etag))
            throw new ArgumentException("ETag is required for this operation.", nameof(etag));
    }

    private static void ValidateLocalFile(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            throw new FileNotFoundException("Local file for upload was not found.", path);
    }

    private static async Task<T> ExecuteWithContext<T>(
        Func<Task<T>> action,
        string operation,
        string container,
        string blobPath,
        CancellationToken token)
    {
        try
        {
            return await action().ConfigureAwait(false);
        }
        catch (RequestFailedException ex) when (!token.IsCancellationRequested)
        {
            throw new BlobStorageException(
                $"Blob {operation} failed for '{container}/{blobPath}': {ex.Message}",
                ex);
        }
    }

    private static Task ExecuteWithContext(
        Func<Task> action,
        string operation,
        string container,
        string blobPath,
        CancellationToken token)
        => ExecuteWithContext(async () =>
        {
            await action().ConfigureAwait(false);
            return true;
        }, operation, container, blobPath, token);

    private static string ResolveContentType(string path)
    {
        var ext = Path.GetExtension(path);
        return ext?.ToLowerInvariant() switch
        {
            ".parquet" => "application/octet-stream",
            ".json"    => "application/json",
            ".csv"     => "text/csv",
            ".txt"     => "text/plain",
            ".xml"     => "application/xml",
            _          => "application/octet-stream"
        };
    }
}
