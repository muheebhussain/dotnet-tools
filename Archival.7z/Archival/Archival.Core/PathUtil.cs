
using Archival.Domain;

namespace Archival.Core;

public static class PathUtil
{
    public static string BuildPrefix(TableConfig tc, DateOnly d) =>
        tc.ArchivePathTemplate
          .Replace("{db}", tc.DatabaseName)
          .Replace("{schema}", tc.SchemaName)
          .Replace("{table}", tc.TableName)
          .Replace("{date}", d.ToString("yyyy-MM-dd"));
}
