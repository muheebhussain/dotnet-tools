﻿namespace Archival.Core;

public class ArchivalOptions
{
    public string SqlConnectionString { get; set; } = string.Empty;
    public string StorageConnectionString { get; set; } = string.Empty;
    public string BlobUrl { get; set; } = string.Empty;
    public string BlobContainer { get; set; } = string.Empty;

    public int BatchDeleteSize { get; set; } = 50000;
    public int MaxReadRows { get; set; } = 5_000_000;
    public int MaxFilesBatch { get; set; } = 500;
    public string TableName { get; set; } = string.Empty;
    public string WhatIf { get; set; } = string.Empty;
    public DateTime Since { get; set; } = DateTime.MinValue;
}
