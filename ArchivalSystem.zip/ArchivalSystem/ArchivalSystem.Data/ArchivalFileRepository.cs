﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data;

public interface IArchivalFileRepository
{
    /// <summary>
    /// Returns true if an archival_file exists for the given table configuration / date / dateType.
    /// </summary>
    Task<bool> ExistsForTableDateAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        DateType dateType,
        CancellationToken ct = default);

    /// <summary>
    /// Returns true when a TABLE-scoped exemption exists for the given table/date.
    /// </summary>
    Task<bool> IsTableExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default);

    /// <summary>
    /// Returns true when a FILE-scoped exemption exists for the given file/date.
    /// </summary>
    Task<bool> IsFileExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default);

    /// <summary>
    /// Returns archival_file by tableConfigurationId + blobPath or null.
    /// </summary>
    Task<ArchivalFileEntity?> GetByBlobPathAsync(
        int tableConfigurationId,
        string blobPath,
        CancellationToken ct = default);

    Task<List<ArchivalFileEntity>> GetByBlobPathsAsync(
        int tableConfigurationId,
        IEnumerable<string> blobPaths,
        CancellationToken ct = default);

    /// <summary>
    /// Inserts or updates the supplied archival file entity and persists changes.
    /// Returns the tracked/saved entity with Id populated.
    /// </summary>
    Task<ArchivalFileEntity> UpsertFileAsync(
        ArchivalFileEntity file,
        CancellationToken ct = default);

    /// <summary>
    /// Returns files for a given table. Caller can request tracked entities if they will be mutated.
    /// </summary>
    Task<List<ArchivalFileEntity>> GetByTableConfigurationIdAsync(
        int tableConfigurationId,
        bool asTracking = false,
        CancellationToken ct = default);

    Task<ArchivalFileEntity?> GetByIdAsync(
        long archivalFileId,
        CancellationToken ct = default);

    /// <summary>
    /// Persist changes for multiple files in a single SaveChanges call.
    /// The method will add new entities and attach/update existing ones.
    /// </summary>
    Task UpdateFilesAsync(IEnumerable<ArchivalFileEntity> files, CancellationToken ct = default);

    /// <summary>
    /// Bulk update ArchivalPolicyTag and LastTagsSyncAtEt for the provided file Ids using a server-side UPDATE.
    /// Returns number of rows affected.
    /// </summary>
    Task<int> BulkSetTagsAndSyncTimeAsync(
        IEnumerable<long> archivalFileIds,
        string? archivalPolicyTag,
        DateTime lastTagsSyncAtEt,
        CancellationToken ct = default);

    Task<HashSet<DateOnly>> GetFileExemptionDatesAsync(
        int tableConfigurationId,
        IEnumerable<DateOnly> dates,
        CancellationToken ct = default);
}

public class ArchivalFileRepository(ArchivalDbContext db) : IArchivalFileRepository
{
    private readonly ArchivalDbContext _db = db ?? throw new ArgumentNullException(nameof(db));

    public async Task<bool> ExistsForTableDateAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        DateType dateType,
        CancellationToken ct = default)
    {
        return await _db.ArchivalFiles.AnyAsync(
            f => f.TableConfigurationId == tableConfigurationId
                 && f.AsOfDate == asOfDate.Date
                 && f.DateType == dateType,
            ct);
    }

    public async Task<bool> IsTableExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default)
    {
        return await _db.ArchivalExemptions.AnyAsync(
            e => e.TableConfigurationId == tableConfigurationId
                 && e.AsOfDate == asOfDate.Date
                 && (e.Scope == ExemptionScope.Table || e.Scope == ExemptionScope.Both),
            ct);
    }

    public async Task<bool> IsFileExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default)
    {
        return await _db.ArchivalExemptions.AnyAsync(
            e => e.TableConfigurationId == tableConfigurationId
                 && e.AsOfDate == asOfDate.Date
                 && (e.Scope == ExemptionScope.File || e.Scope == ExemptionScope.Both),
            ct);
    }

    public async Task<ArchivalFileEntity?> GetByBlobPathAsync(
        int tableConfigurationId,
        string blobPath,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(blobPath)) return null;

        return await _db.ArchivalFiles
            .AsTracking()
            .FirstOrDefaultAsync(f => f.TableConfigurationId == tableConfigurationId
                                      && f.BlobPath == blobPath, ct);
    }

    public async Task<List<ArchivalFileEntity>> GetByBlobPathsAsync(
        int tableConfigurationId,
        IEnumerable<string> blobPaths,
        CancellationToken ct = default)
    {
        var paths = (blobPaths ?? Enumerable.Empty<string>()).Distinct().ToList();
        if (!paths.Any()) return new List<ArchivalFileEntity>();

        return await _db.ArchivalFiles
            .Where(f => f.TableConfigurationId == tableConfigurationId && paths.Contains(f.BlobPath))
            .ToListAsync(ct);
    }

    public async Task<ArchivalFileEntity> UpsertFileAsync(
        ArchivalFileEntity file,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(file);

        if (file.Id == 0)
        {
            _db.ArchivalFiles.Add(file);
        }
        else
        {
            // ensure the entity is tracked so subsequent changes are persisted
            var tracked = await _db.ArchivalFiles.FindAsync(new object[] { file.Id }, ct);
            if (tracked == null)
            {
                _db.ArchivalFiles.Update(file);
            }
            else
            {
                _db.Entry(tracked).CurrentValues.SetValues(file);
                file = tracked;
            }
        }

        await _db.SaveChangesAsync(ct);
        return file;
    }

    
    public async Task<List<ArchivalFileEntity>> GetByTableConfigurationIdAsync(
        int tableConfigurationId,
        bool asTracking = false,
        CancellationToken ct = default)
    {
        var query = _db.ArchivalFiles.Where(f => f.TableConfigurationId == tableConfigurationId);
        if (asTracking)
            return await query.ToListAsync(ct);

        return await query.AsNoTracking().ToListAsync(ct);
    }

    
    public async Task<ArchivalFileEntity?> GetByIdAsync(
        long archivalFileId,
        CancellationToken ct = default)
    {
        return await _db.ArchivalFiles
            .AsTracking()
            .FirstOrDefaultAsync(f => f.Id == archivalFileId, ct);
    }

    public async Task UpdateFilesAsync(IEnumerable<ArchivalFileEntity> files, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(files);

        // Ensure we work with a concrete list to avoid multiple enumerations
        var list = files.ToList();

        foreach (var file in list)
        {
            if (file == null) continue;

            if (file.Id == 0)
            {
                _db.ArchivalFiles.Add(file);
                continue;
            }

            // If entity is already tracked, update tracked values
            var trackedEntry = _db.ChangeTracker.Entries<ArchivalFileEntity>()
                .FirstOrDefault(e => e.Entity.Id == file.Id);

            if (trackedEntry != null)
            {
                trackedEntry.CurrentValues.SetValues(file);
                continue;
            }

            // Try to find it in the database; if found, update; otherwise attach as modified
            var existing = await _db.ArchivalFiles.FindAsync(new object[] { file.Id }, ct);
            if (existing != null)
            {
                _db.Entry(existing).CurrentValues.SetValues(file);
            }
            else
            {
                // Attach the provided instance and mark as modified
                _db.ArchivalFiles.Attach(file);
                _db.Entry(file).State = EntityState.Modified;
            }
        }

        await _db.SaveChangesAsync(ct);
    }

    public async Task<int> BulkSetTagsAndSyncTimeAsync(
        IEnumerable<long> archivalFileIds,
        string? archivalPolicyTag,
        DateTime lastTagsSyncAtEt,
        CancellationToken ct = default)
    {
        if (archivalFileIds == null) throw new ArgumentNullException(nameof(archivalFileIds));

        var ids = archivalFileIds.Distinct().ToList();
        if (!ids.Any()) return 0;

        // EF Core will translate Contains into a SQL IN clause - efficient for moderate list sizes.
        var query = _db.ArchivalFiles.Where(f => ids.Contains(f.Id));

        var affected = await query.ExecuteUpdateAsync(s => s
                .SetProperty(f => f.ArchivalPolicyTag, _ => archivalPolicyTag)
                .SetProperty(f => f.LastTagsSyncAtEt, _ => lastTagsSyncAtEt),
            cancellationToken: ct);

        return affected;
    }

    /// <summary>
    /// Returns the set of dates (DateOnly) that have FILE or BOTH exemptions for the given table.
    /// </summary>
    public async Task<HashSet<DateOnly>> GetFileExemptionDatesAsync(
        int tableConfigurationId,
        IEnumerable<DateOnly> dates,
        CancellationToken ct = default)
    {
        var dateList = dates?.Distinct().ToList() ?? new List<DateOnly>();
        if (!dateList.Any()) return new HashSet<DateOnly>();

        var dateTimes = dateList.Select(d => d.ToDateTime(TimeOnly.MinValue)).ToList();

        var rows = await _db.ArchivalExemptions
            .Where(e => e.TableConfigurationId == tableConfigurationId
                        && (e.Scope == ExemptionScope.File || e.Scope == ExemptionScope.Both)
                        && dateTimes.Contains(e.AsOfDate))
            .Select(e => e.AsOfDate) // AsOfDate is nullable in schema
            .ToListAsync(ct);

        return rows.Select(DateOnly.FromDateTime).ToHashSet();
    }
}