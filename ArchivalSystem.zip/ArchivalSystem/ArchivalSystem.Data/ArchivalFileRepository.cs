﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data;

public interface IArchivalFileRepository
{
    /// <summary>
    /// Returns true if an archival_file exists for the given table configuration / date / dateType.
    /// </summary>
    Task<bool> ExistsForTableDateAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        DateType dateType,
        CancellationToken ct = default);

    /// <summary>
    /// Returns true when a TABLE-scoped exemption exists for the given table/date.
    /// </summary>
    Task<bool> IsTableExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default);

    /// <summary>
    /// Returns true when a FILE-scoped exemption exists for the given file/date.
    /// </summary>
    Task<bool> IsFileExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default);

    /// <summary>
    /// Returns archival_file by tableConfigurationId + blobPath or null.
    /// </summary>
    Task<ArchivalFileEntity?> GetByBlobPathAsync(
        int tableConfigurationId,
        string blobPath,
        CancellationToken ct = default);

    Task<List<ArchivalFileEntity>> GetByBlobPathsAsync(
        int tableConfigurationId,
        IEnumerable<string> blobPaths,
        CancellationToken ct = default);

    /// <summary>
    /// Inserts or updates the supplied archival file entity and persists changes.
    /// Returns the tracked/saved entity with Id populated.
    /// </summary>
    Task<ArchivalFileEntity> UpsertFileAsync(
        ArchivalFileEntity file,
        CancellationToken ct = default);

    /// <summary>
    /// Returns files for a given table. Caller can request tracked entities if they will be mutated.
    /// </summary>
    Task<List<ArchivalFileEntity>> GetByTableConfigurationIdAsync(
        int tableConfigurationId,
        bool asTracking = false,
        CancellationToken ct = default);

    Task<ArchivalFileEntity?> GetByIdAsync(
        long archivalFileId,
        CancellationToken ct = default);

    /// <summary>
    /// Persist changes for multiple files in a single SaveChanges call.
    /// The method will add new entities and attach/update existing ones.
    /// </summary>
    Task UpdateFilesAsync(IEnumerable<ArchivalFileEntity> files, CancellationToken ct = default);

    /// <summary>
    /// Bulk update ArchivalPolicyTag and LastTagsSyncAtEt for the provided file Ids using a server-side UPDATE.
    /// Returns number of rows affected.
    /// </summary>
    Task<int> BulkSetTagsAndSyncTimeAsync(
        IEnumerable<long> archivalFileIds,
        string? archivalPolicyTag,
        DateTime lastTagsSyncAtEt,
        CancellationToken ct = default);

    Task<HashSet<DateOnly>> GetFileExemptionDatesAsync(
        int tableConfigurationId,
        IEnumerable<DateOnly> dates,
        CancellationToken ct = default);

    /// <summary>
    /// Return a set of archival files for a storage account (optionally narrowed to container/prefix)
    /// but only those that are plausible candidates for lifecycle actions:
    /// - files whose AsOfDate (or CreatedAtEt) is older than the minimum configured lifecycle threshold
    ///   across active policies (conservative server-side pruning), OR
    /// - files that have never been checked (LastTierCheckAtEt is null) OR
    /// - files whose LastTierCheckAtEt is older than minAgeBetweenChecks.
    ///
    /// This keeps the DB-driven enforcer from enumerating every single blob/file every run.
    /// </summary>
    Task<List<ArchivalFileEntity>> GetFilesForStorageAccountAsync(
        string storageAccountName,
        string? containerName = null,
        string? prefix = null,
        bool asTracking = false,
        int pageSize = 5000,
        TimeSpan? minAgeBetweenTierChecks = null,
        CancellationToken ct = default);
}

public class ArchivalFileRepository(ArchivalDbContext db) : IArchivalFileRepository
{
    private readonly ArchivalDbContext _db = db ?? throw new ArgumentNullException(nameof(db));

    public async Task<bool> ExistsForTableDateAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        DateType dateType,
        CancellationToken ct = default)
    {
        return await _db.ArchivalFiles.AnyAsync(
            f => f.TableConfigurationId == tableConfigurationId
                 && f.AsOfDate == asOfDate.Date
                 && f.DateType == dateType,
            ct);
    }

    public async Task<bool> IsTableExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default)
    {
        return await _db.ArchivalExemptions.AnyAsync(
            e => e.TableConfigurationId == tableConfigurationId
                 && e.AsOfDate == asOfDate.Date
                 && (e.Scope == ExemptionScope.Table || e.Scope == ExemptionScope.Both),
            ct);
    }

    public async Task<bool> IsFileExemptAsync(
        int tableConfigurationId,
        DateTime asOfDate,
        CancellationToken ct = default)
    {
        return await _db.ArchivalExemptions.AnyAsync(
            e => e.TableConfigurationId == tableConfigurationId
                 && e.AsOfDate == asOfDate.Date
                 && (e.Scope == ExemptionScope.File || e.Scope == ExemptionScope.Both),
            ct);
    }

    public async Task<ArchivalFileEntity?> GetByBlobPathAsync(
        int tableConfigurationId,
        string blobPath,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(blobPath)) return null;

        return await _db.ArchivalFiles
            .AsTracking()
            .FirstOrDefaultAsync(f => f.TableConfigurationId == tableConfigurationId
                                      && f.BlobPath == blobPath, ct);
    }

    public async Task<List<ArchivalFileEntity>> GetByBlobPathsAsync(
        int tableConfigurationId,
        IEnumerable<string> blobPaths,
        CancellationToken ct = default)
    {
        var paths = (blobPaths ?? Enumerable.Empty<string>()).Distinct().ToList();
        if (!paths.Any()) return new List<ArchivalFileEntity>();

        return await _db.ArchivalFiles
            .AsNoTracking()
            .Where(f => f.TableConfigurationId == tableConfigurationId && paths.Contains(f.BlobPath))
            .ToListAsync(ct);
    }

    public async Task<ArchivalFileEntity> UpsertFileAsync(
        ArchivalFileEntity file,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(file);

        if (file.Id == 0)
        {
            _db.ArchivalFiles.Add(file);
        }
        else
        {
            // ensure the entity is tracked so subsequent changes are persisted
            var tracked = await _db.ArchivalFiles.FindAsync(new object[] { file.Id }, ct);
            if (tracked == null)
            {
                _db.ArchivalFiles.Update(file);
            }
            else
            {
                _db.Entry(tracked).CurrentValues.SetValues(file);
                file = tracked;
            }
        }

        await _db.SaveChangesAsync(ct);
        return file;
    }

    
    public async Task<List<ArchivalFileEntity>> GetByTableConfigurationIdAsync(
        int tableConfigurationId,
        bool asTracking = false,
        CancellationToken ct = default)
    {
        var query = _db.ArchivalFiles.Where(f => f.TableConfigurationId == tableConfigurationId);
        if (asTracking)
            return await query.ToListAsync(ct);

        return await query.AsNoTracking().ToListAsync(ct);
    }

    
    public async Task<ArchivalFileEntity?> GetByIdAsync(
        long archivalFileId,
        CancellationToken ct = default)
    {
        return await _db.ArchivalFiles
            .AsTracking()
            .FirstOrDefaultAsync(f => f.Id == archivalFileId, ct);
    }

    public async Task UpdateFilesAsync(IEnumerable<ArchivalFileEntity> files, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(files);

        // Ensure we work with a concrete list to avoid multiple enumerations
        var list = files.ToList();

        foreach (var file in list)
        {
            if (file == null) continue;

            if (file.Id == 0)
            {
                _db.ArchivalFiles.Add(file);
                continue;
            }

            // If entity is already tracked, update tracked values
            var trackedEntry = _db.ChangeTracker.Entries<ArchivalFileEntity>()
                .FirstOrDefault(e => e.Entity.Id == file.Id);

            if (trackedEntry != null)
            {
                trackedEntry.CurrentValues.SetValues(file);
                continue;
            }

            // Try to find it in the database; if found, update; otherwise attach as modified
            var existing = await _db.ArchivalFiles.FindAsync(new object[] { file.Id }, ct);
            if (existing != null)
            {
                _db.Entry(existing).CurrentValues.SetValues(file);
            }
            else
            {
                // Attach the provided instance and mark as modified
                _db.ArchivalFiles.Attach(file);
                _db.Entry(file).State = EntityState.Modified;
            }
        }

        await _db.SaveChangesAsync(ct);
    }

    public async Task<int> BulkSetTagsAndSyncTimeAsync(
        IEnumerable<long> archivalFileIds,
        string? archivalPolicyTag,
        DateTime lastTagsSyncAtEt,
        CancellationToken ct = default)
    {
        if (archivalFileIds == null) throw new ArgumentNullException(nameof(archivalFileIds));

        var ids = archivalFileIds.Distinct().ToList();
        if (!ids.Any()) return 0;

        // EF Core will translate Contains into a SQL IN clause - efficient for moderate list sizes.
        var query = _db.ArchivalFiles.Where(f => ids.Contains(f.Id));

        var affected = await query.ExecuteUpdateAsync(s => s
                .SetProperty(f => f.ArchivalPolicyTag, _ => archivalPolicyTag)
                .SetProperty(f => f.LastTagsSyncAtEt, _ => lastTagsSyncAtEt),
            cancellationToken: ct);

        return affected;
    }

    /// <summary>
    /// Returns the set of dates (DateOnly) that have FILE or BOTH exemptions for the given table.
    /// </summary>
    public async Task<HashSet<DateOnly>> GetFileExemptionDatesAsync(
        int tableConfigurationId,
        IEnumerable<DateOnly> dates,
        CancellationToken ct = default)
    {
        var dateList = dates?.Distinct().ToList() ?? new List<DateOnly>();
        if (!dateList.Any()) return new HashSet<DateOnly>();

        var dateTimes = dateList.Select(d => d.ToDateTime(TimeOnly.MinValue)).ToList();

        var rows = await _db.ArchivalExemptions
            .Where(e => e.TableConfigurationId == tableConfigurationId
                        && (e.Scope == ExemptionScope.File || e.Scope == ExemptionScope.Both)
                        && dateTimes.Contains(e.AsOfDate))
            .Select(e => e.AsOfDate) // AsOfDate is nullable in schema
            .ToListAsync(ct);

        return rows.Select(DateOnly.FromDateTime).ToHashSet();
    }

    public async Task<List<ArchivalFileEntity>> GetFilesForStorageAccountAsync(
       string storageAccountName,
       string? containerName = null,
       string? prefix = null,
       bool asTracking = false,
       int pageSize = 5000,
       TimeSpan? minAgeBetweenTierChecks = null,
       CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(storageAccountName)) throw new ArgumentNullException(nameof(storageAccountName));

        var minCheckSpan = minAgeBetweenTierChecks ?? TimeSpan.FromDays(1);
        var now = DateTime.UtcNow;

        // Conservative server-side pruning: compute the smallest (earliest) threshold across all active policies.
        // Any file younger than this minimum cannot possibly qualify for any tier/delete action.
        var activePolicies = await _db.ArchivalFileLifecyclePolicies
            .Where(p => p.IsActive)
            .Select(p => new
            {
                p.EodCoolDays,
                p.EodArchiveDays,
                p.EodDeleteDays,
                p.EomCoolDays,
                p.EomArchiveDays,
                p.EomDeleteDays,
                p.EoqCoolDays,
                p.EoqArchiveDays,
                p.EoqDeleteDays,
                p.EoyCoolDays,
                p.EoyArchiveDays,
                p.EoyDeleteDays,
                p.ExternalCoolDays,
                p.ExternalArchiveDays,
                p.ExternalDeleteDays
            })
            .ToListAsync(ct);

        var candidateDayValues = new List<int>();
        foreach (var p in activePolicies)
        {
            void AddIf(int? v) { if (v.HasValue) candidateDayValues.Add(v.Value); }
            AddIf(p.EodCoolDays); AddIf(p.EodArchiveDays); AddIf(p.EodDeleteDays);
            AddIf(p.EomCoolDays); AddIf(p.EomArchiveDays); AddIf(p.EomDeleteDays);
            AddIf(p.EoqCoolDays); AddIf(p.EoqArchiveDays); AddIf(p.EoqDeleteDays);
            AddIf(p.EoyCoolDays); AddIf(p.EoyArchiveDays); AddIf(p.EoyDeleteDays);
            AddIf(p.ExternalCoolDays); AddIf(p.ExternalArchiveDays); AddIf(p.ExternalDeleteDays);
        }

        // If no thresholds at all, there is nothing to enforce; return empty.
        if (!candidateDayValues.Any())
            return new List<ArchivalFileEntity>(0);

        var minThresholdDays = candidateDayValues.Min();
        var cutoffDate = now.Date.AddDays(-minThresholdDays);

        // Base query: storage account (+ optional container/prefix), exclude deleted rows
        IQueryable<ArchivalFileEntity> q = _db.ArchivalFiles;

        if (!asTracking) q = q.AsNoTracking();

        q = q.Where(f => f.StorageAccountName == storageAccountName && f.Status != ArchivalFileStatus.Deleted);

        if (!string.IsNullOrWhiteSpace(containerName))
            q = q.Where(f => f.ContainerName == containerName);

        if (!string.IsNullOrWhiteSpace(prefix))
            q = q.Where(f => EF.Functions.Like(f.BlobPath, prefix.TrimStart('/') + "%"));

        // Conservative filter:
        // - include files whose AsOfDate (or CreatedAtEt if AsOfDate null) is on-or-before cutoffDate
        // - OR files never checked (LastTierCheckAtEt == null)
        // - OR files checked long enough ago (older than minCheckSpan)
        q = q.Where(f =>
            (f.AsOfDate.HasValue && f.AsOfDate.Value.Date <= cutoffDate)
            || (!f.AsOfDate.HasValue && f.CreatedAtEt.Date <= cutoffDate)
            || f.LastTierCheckAtEt == null
            || f.LastTierCheckAtEt <= now.Subtract(minCheckSpan));

        // include related table configuration and override policy to avoid N+1 in enforcer
        q = q.Include(f => f.TableConfiguration)
             .ThenInclude(t => t.FileLifecyclePolicy)
             .Include(f => f.OverrideFileLifecyclePolicy);

        // return pageSize at most — enforcer will run repeatedly, so batches are fine
        var list = await q.OrderBy(f => f.LastTierCheckAtEt ?? DateTime.MinValue)
                          .ThenBy(f => f.AsOfDate)
                          .Take(pageSize)
                          .ToListAsync(ct);

        return list;
    }
}