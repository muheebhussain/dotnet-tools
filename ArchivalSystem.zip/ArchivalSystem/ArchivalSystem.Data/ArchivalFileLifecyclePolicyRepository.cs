﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data;


public interface IArchivalFileLifecyclePolicyRepository
{
    Task<ArchivalFileLifecyclePolicyEntity?> GetByIdAsync(int id, CancellationToken ct = default);
    
    /// <summary>
    /// Returns active lifecycle policies whose Id is contained in the provided list.
    /// </summary>
    Task<List<ArchivalFileLifecyclePolicyEntity>> GetActiveByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken ct = default);

    /// <summary>
    /// Return policies by id (regardless of IsActive). Useful for override lookups in bulk.
    /// </summary>
    Task<Dictionary<int, ArchivalFileLifecyclePolicyEntity>> GetByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken ct = default);
}

public class ArchivalFileLifecyclePolicyRepository(ArchivalDbContext db) : IArchivalFileLifecyclePolicyRepository
{
    private readonly ArchivalDbContext _db = db ?? throw new System.ArgumentNullException(nameof(db));

    public async Task<ArchivalFileLifecyclePolicyEntity?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        return await _db.ArchivalFileLifecyclePolicies
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id, ct);
    }

    public async Task<List<ArchivalFileLifecyclePolicyEntity>> GetActiveByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken ct = default)
    {
        var idList = ids?.Distinct().ToList() ?? new List<int>();

        if (!idList.Any())
            return new List<ArchivalFileLifecyclePolicyEntity>();

        return await _db.ArchivalFileLifecyclePolicies
            .Where(p => p.IsActive && idList.Contains(p.Id))
            .ToListAsync(ct);
    }

    public async Task<Dictionary<int, ArchivalFileLifecyclePolicyEntity>> GetByIdsAsync(
        IEnumerable<int> ids,
        CancellationToken ct = default)
    {
        var idList = ids?.Distinct().ToList() ?? new List<int>();
        if (!idList.Any()) return new Dictionary<int, ArchivalFileLifecyclePolicyEntity>();

        var list = await _db.ArchivalFileLifecyclePolicies
            .Where(p => idList.Contains(p.Id))
            .AsNoTracking()
            .ToListAsync(ct);

        return list.ToDictionary(p => p.Id);
    }
}