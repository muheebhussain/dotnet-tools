﻿using ArchivalSystem.Abstraction;
using System.Data;

namespace ArchivalSystem.Data
{
    public interface ITargetTableRepository
    {
        /// <summary>
        /// Returns distinct as_of_date values from the target table (as DateOnly).
        /// The caller supplies the connection string for the target database.
        /// </summary>
        Task<IReadOnlyCollection<DateOnly>> GetDistinctAsOfDatesAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            CancellationToken ct = default);

        /// <summary>
        /// Deletes rows for the given as-of date in batches and returns total deleted count.
        /// The repository opens a connection for <paramref name="databaseName"/>.
        /// </summary>
        Task<long> DeleteByAsOfDateAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            DateTime asOfDate,
            int batchSize,
            CancellationToken ct = default);

        /// <summary>
        /// Execute a SELECT * FROM [schema].[table] WHERE [asOfDateColumn] = @asOfDate
        /// and return a TableQueryResult that owns the open connection and reader.
        /// Caller must dispose the result (await using).
        /// </summary>
        Task<TableQueryResult> ExecuteQueryAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            DateTime asOfDate,
            CancellationToken ct = default);
    }

    public class TargetTableRepository(IConnectionProvider connectionProvider) : ITargetTableRepository
    {
        private readonly IConnectionProvider _connectionProvider = connectionProvider ?? throw new ArgumentNullException(nameof(connectionProvider));
        public async Task<IReadOnlyCollection<DateOnly>> GetDistinctAsOfDatesAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(databaseName)) throw new ArgumentNullException(nameof(databaseName));
            if (string.IsNullOrWhiteSpace(schemaName)) throw new ArgumentNullException(nameof(schemaName));
            if (string.IsNullOrWhiteSpace(tableName)) throw new ArgumentNullException(nameof(tableName));
            if (string.IsNullOrWhiteSpace(asOfDateColumn)) throw new ArgumentNullException(nameof(asOfDateColumn));

            var sql = $@"
SELECT DISTINCT CAST([{asOfDateColumn}] AS date) AS as_of_date
FROM [{schemaName}].[{tableName}];";

            var results = new List<DateOnly>();

            await using var conn = await _connectionProvider.CreateOpenConnectionAsync(databaseName, ct);
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                var dt = reader.GetFieldValue<DateTime>(0); // CAST(... AS date) => DateTime
                results.Add(DateOnly.FromDateTime(dt));
            }

            return results.Distinct().ToArray();
        }

        public async Task<long> DeleteByAsOfDateAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            DateTime asOfDate,
            int batchSize,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(databaseName)) throw new ArgumentNullException(nameof(databaseName));
            if (string.IsNullOrWhiteSpace(schemaName)) throw new ArgumentNullException(nameof(schemaName));
            if (string.IsNullOrWhiteSpace(tableName)) throw new ArgumentNullException(nameof(tableName));
            if (string.IsNullOrWhiteSpace(asOfDateColumn)) throw new ArgumentNullException(nameof(asOfDateColumn));
            if (batchSize <= 0) throw new ArgumentOutOfRangeException(nameof(batchSize));

            var sql = $@"
DELETE TOP (@BatchSize)
FROM [{schemaName}].[{tableName}]
WHERE CAST([{asOfDateColumn}] AS date) = @AsOfDate;";

            long totalDeleted = 0;

            await using var conn = await _connectionProvider.CreateOpenConnectionAsync(databaseName, ct);

            await using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            var pBatch = cmd.CreateParameter();
            pBatch.ParameterName = "@BatchSize";
            pBatch.DbType = DbType.Int32;
            cmd.Parameters.Add(pBatch);

            var pDate = cmd.CreateParameter();
            pDate.ParameterName = "@AsOfDate";
            pDate.DbType = DbType.Date;
            cmd.Parameters.Add(pDate);

            while (true)
            {
                ct.ThrowIfCancellationRequested();

                pBatch.Value = batchSize;
                pDate.Value = asOfDate.Date;

                var affected = await cmd.ExecuteNonQueryAsync(ct);
                totalDeleted += affected;

                if (affected < batchSize)
                    break;
            }

            return totalDeleted;
        }

        public async Task<TableQueryResult> ExecuteQueryAsync(
            string databaseName,
            string schemaName,
            string tableName,
            string asOfDateColumn,
            DateTime asOfDate,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(databaseName)) throw new ArgumentNullException(nameof(databaseName));
            if (string.IsNullOrWhiteSpace(schemaName)) throw new ArgumentNullException(nameof(schemaName));
            if (string.IsNullOrWhiteSpace(tableName)) throw new ArgumentNullException(nameof(tableName));
            if (string.IsNullOrWhiteSpace(asOfDateColumn)) throw new ArgumentNullException(nameof(asOfDateColumn));

            var conn = await _connectionProvider.CreateOpenConnectionAsync(databaseName, ct);

            var sql = $@"
SELECT *
FROM [{schemaName}].[{tableName}]
WHERE [{asOfDateColumn}] = @asOfDate;";

            var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            var p = cmd.CreateParameter();
            p.ParameterName = "@asOfDate";
            p.DbType = DbType.Date;
            p.Value = asOfDate.Date;
            cmd.Parameters.Add(p);

            // ExecuteReaderAsync with SequentialAccess; caller must dispose the returned TableQueryResult (owns connection + reader)
            var reader = await cmd.ExecuteReaderAsync(CommandBehavior.SequentialAccess, ct);

            return new TableQueryResult(conn, reader);
        }
    }
}
