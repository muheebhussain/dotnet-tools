﻿namespace ArchivalSystem.Data.Entities;

public class ArchivalRunDetailEntity
{
    public long Id { get; set; }

    public long RunId { get; set; }
    public int TableConfigurationId { get; set; }
    public DateTime? AsOfDate { get; set; }
    public DateType? DateType { get; set; }

    public long? ArchivalFileId { get; set; }

    public RunDetailPhase Phase { get; set; }
    public RunDetailStatus Status { get; set; }

    public long? RowsAffected { get; set; }
    public string? FilePath { get; set; }
    public string? ErrorMessage { get; set; }

    public DateTime CreatedAtEt { get; set; }

    public ArchivalRunEntity Run { get; set; } = default!;
    public ArchivalTableConfigurationEntity TableConfiguration { get; set; } = default!;
    public ArchivalFileEntity? ArchivalFile { get; set; }
}