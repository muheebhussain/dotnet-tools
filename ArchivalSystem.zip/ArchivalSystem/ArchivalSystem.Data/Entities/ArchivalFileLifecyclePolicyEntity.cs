﻿namespace ArchivalSystem.Data.Entities;

public class ArchivalFileLifecyclePolicyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = default!;
    public bool IsActive { get; set; }

    public string? AzurePolicyTag { get; set; }

    public int? EodCoolDays { get; set; }
    public int? EodArchiveDays { get; set; }
    public int? EodDeleteDays { get; set; }

    public int? EomCoolDays { get; set; }
    public int? EomArchiveDays { get; set; }
    public int? EomDeleteDays { get; set; }

    public int? EoqCoolDays { get; set; }
    public int? EoqArchiveDays { get; set; }
    public int? EoqDeleteDays { get; set; }

    public int? EoyCoolDays { get; set; }
    public int? EoyArchiveDays { get; set; }
    public int? EoyDeleteDays { get; set; }

    public int? ExternalCoolDays { get; set; }
    public int? ExternalArchiveDays { get; set; }
    public int? ExternalDeleteDays { get; set; }

    public DateTime CreatedAtEt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAtEt { get; set; }
    public string? UpdatedBy { get; set; }

    public ICollection<ArchivalTableConfigurationEntity> TableConfigurations { get; set; }
        = new List<ArchivalTableConfigurationEntity>();

    public ICollection<ArchivalFileEntity> OverriddenFiles { get; set; }
        = new List<ArchivalFileEntity>();
}