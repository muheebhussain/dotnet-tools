﻿namespace ArchivalSystem.Data.Entities
{
    public class ArchivalTableRetentionPolicyEntity
    {
        public int Id { get; set; }
        public string Name { get; set; } = default!;
        public bool IsActive { get; set; }

        public int? KeepLastEod { get; set; }
        public int? KeepLastEom { get; set; }
        public int? KeepLastEoq { get; set; }
        public int? KeepLastEoy { get; set; }

        public DateTime CreatedAtEt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedAtEt { get; set; }
        public string? UpdatedBy { get; set; }

        public ICollection<ArchivalTableConfigurationEntity> TableConfigurations { get; set; }
            = new List<ArchivalTableConfigurationEntity>();
    }
}





