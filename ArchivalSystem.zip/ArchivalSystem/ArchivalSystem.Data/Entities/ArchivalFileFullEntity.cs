﻿namespace ArchivalSystem.Data.Entities;

/// <summary>
/// Read-only view entity mapped to dbo.v_archival_file_full.
/// </summary>
public class ArchivalFileFullEntity
{
    // From archival_file
    public long ArchivalFileId { get; set; }
    public int TableConfigurationId { get; set; }
    public DateTime? AsOfDate { get; set; }
    public string? DateType { get; set; }

    public string FileStorageAccountName { get; set; } = default!;
    public string FileContainerName { get; set; } = default!;
    public string BlobPath { get; set; } = default!;

    public string? Etag { get; set; }
    public string? ContentType { get; set; }
    public long? FileSizeBytes { get; set; }
    public long? RowCount { get; set; }

    public string FileStatus { get; set; } = default!;
    public DateTime FileCreatedAtEt { get; set; }

    public string? ArchivalPolicyTag { get; set; }
    public string? CurrentAccessTier { get; set; }
    public DateTime? LastTierCheckAtEt { get; set; }
    public int? OverrideFileLifecyclePolicyId { get; set; }
    public DateTime? LastTagsSyncAtEt { get; set; }

    // From archival_table_configuration
    public string DatabaseName { get; set; } = default!;
    public string SchemaName { get; set; } = default!;
    public string TableName { get; set; } = default!;
    public string? AsOfDateColumn { get; set; }
    public string ExportMode { get; set; } = default!;

    public string ConfigStorageAccountName { get; set; } = default!;
    public string ConfigContainerName { get; set; } = default!;
    public string ArchivePathTemplate { get; set; } = default!;
    public string? DiscoveryPathPrefix { get; set; }

    public int? TableRetentionPolicyId { get; set; }
    public int FileLifecyclePolicyId { get; set; }

    public bool TableConfigurationIsActive { get; set; }
    public DateTime TableConfigurationCreatedAtEt { get; set; }
    public string? TableConfigurationCreatedBy { get; set; }
    public DateTime? TableConfigurationUpdatedAtEt { get; set; }
    public string? TableConfigurationUpdatedBy { get; set; }

    // From archival_table_retention_policy
    public string? TableRetentionPolicyName { get; set; }
    public bool? TableRetentionPolicyIsActive { get; set; }
    public int? KeepLastEod { get; set; }
    public int? KeepLastEom { get; set; }
    public int? KeepLastEoq { get; set; }
    public int? KeepLastEoy { get; set; }

    // From archival_file_lifecycle_policy (primary)
    public int FileLifecyclePolicyIdResolved { get; set; }
    public string FileLifecyclePolicyName { get; set; } = default!;
    public bool FileLifecyclePolicyIsActive { get; set; }
    public string? FileLifecycleAzurePolicyTag { get; set; }

    public int? EodCoolDays { get; set; }
    public int? EodArchiveDays { get; set; }
    public int? EodDeleteDays { get; set; }

    public int? EomCoolDays { get; set; }
    public int? EomArchiveDays { get; set; }
    public int? EomDeleteDays { get; set; }

    public int? EoqCoolDays { get; set; }
    public int? EoqArchiveDays { get; set; }
    public int? EoqDeleteDays { get; set; }

    public int? EoyCoolDays { get; set; }
    public int? EoyArchiveDays { get; set; }
    public int? EoyDeleteDays { get; set; }

    public int? ExternalCoolDays { get; set; }
    public int? ExternalArchiveDays { get; set; }
    public int? ExternalDeleteDays { get; set; }

    // From override lifecycle policy (if present)
    public int? OverrideFileLifecyclePolicyIdResolved { get; set; }
    public string? OverrideFileLifecyclePolicyName { get; set; }
    public string? OverrideFileLifecycleAzurePolicyTag { get; set; }
}