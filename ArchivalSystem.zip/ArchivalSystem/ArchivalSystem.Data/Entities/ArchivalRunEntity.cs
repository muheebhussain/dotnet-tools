﻿namespace ArchivalSystem.Data.Entities;

public class ArchivalRunEntity
{
    public long Id { get; set; }

    public DateTime StartedAtEt { get; set; }
    public DateTime? EndedAtEt { get; set; }

    public RunStatus Status { get; set; }
    public string? Note { get; set; }

    public ICollection<ArchivalRunDetailEntity> Details { get; set; }
        = new List<ArchivalRunDetailEntity>();
}