﻿namespace ArchivalSystem.Data.Entities;

public class ArchivalExemptionEntity
{
    public int Id { get; set; }

    public int TableConfigurationId { get; set; }
    public DateTime AsOfDate { get; set; }

    public ExemptionScope Scope { get; set; }
    public string? Reason { get; set; }

    public DateTime CreatedAtEt { get; set; }
    public string? CreatedBy { get; set; }

    public ArchivalTableConfigurationEntity TableConfiguration { get; set; } = default!;
}