﻿namespace ArchivalSystem.Data.Entities;

public class ArchivalTableConfigurationEntity
{
    public int Id { get; set; }

    public string DatabaseName { get; set; } = default!;
    public string SchemaName { get; set; } = default!;
    public string TableName { get; set; } = default!;

    public string? AsOfDateColumn { get; set; }

    public ExportMode ExportMode { get; set; }

    public string StorageAccountName { get; set; } = default!;
    public string ContainerName { get; set; } = default!;

    public string ArchivePathTemplate { get; set; } = default!;
    public string? DiscoveryPathPrefix { get; set; }

    public int? TableRetentionPolicyId { get; set; }
    public int FileLifecyclePolicyId { get; set; }

    public bool IsActive { get; set; }
    public bool DeleteFromSource { get; set; } = true;
    public DateTime CreatedAtEt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAtEt { get; set; }
    public string? UpdatedBy { get; set; }

    public ArchivalTableRetentionPolicyEntity? TableRetentionPolicy { get; set; }
    public ArchivalFileLifecyclePolicyEntity FileLifecyclePolicy { get; set; } = default!;

    public ICollection<ArchivalFileEntity> Files { get; set; }
        = new List<ArchivalFileEntity>();

    public ICollection<ArchivalExemptionEntity> Exemptions { get; set; }
        = new List<ArchivalExemptionEntity>();

    public ICollection<ArchivalRunDetailEntity> RunDetails { get; set; }
        = new List<ArchivalRunDetailEntity>();
}