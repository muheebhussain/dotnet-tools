﻿using Microsoft.EntityFrameworkCore;
using System.Data;

namespace ArchivalSystem.Data
{
    public interface IRetentionRepository
    {
        /// <summary>
        /// Returns the KEEP set (distinct business dates) for the provided table configuration id.
        /// </summary>
        Task<IReadOnlyCollection<DateOnly>> GetKeepSetAsync(int tableConfigurationId, CancellationToken ct = default);

        /// <summary>
        /// Returns a map from business date -> DateType for the provided dates.
        /// </summary>
        Task<Dictionary<DateOnly, DateType>> GetDateTypesAsync(
            IEnumerable<DateOnly> dates,
            CancellationToken ct = default);
    }

    public class RetentionRepository(ArchivalDbContext db) : IRetentionRepository
    {
        private readonly ArchivalDbContext _db = db ?? throw new ArgumentNullException(nameof(db));

        public async Task<IReadOnlyCollection<DateOnly>> GetKeepSetAsync(int tableConfigurationId, CancellationToken ct = default)
        {
            const string sql = @"
DECLARE @today DATE = CAST(SYSDATETIMEOFFSET() AT TIME ZONE 'Eastern Standard Time' AS DATE);

DECLARE @keep_eod INT, @keep_eom INT, @keep_eoq INT, @keep_eoy INT;

SELECT 
    @keep_eod = trp.keep_last_eod,
    @keep_eom = trp.keep_last_eom,
    @keep_eoq = trp.keep_last_eoq,
    @keep_eoy = trp.keep_last_eoy
FROM dbo.archival_table_configuration tc
LEFT JOIN dbo.archival_table_retention_policy trp
    ON trp.id = tc.table_retention_policy_id
WHERE tc.id = @tcid;

WITH k_eod AS (
    SELECT TOP (ISNULL(@keep_eod, 0)) current_business_date AS d
    FROM dbo.v_business_date_classification
    WHERE date_type = 'EOD'
      AND current_business_date <= @today
    ORDER BY current_business_date DESC
),
k_eom AS (
    SELECT TOP (ISNULL(@keep_eom, 0)) current_business_date AS d
    FROM dbo.v_business_date_classification
    WHERE date_type = 'EOM'
      AND current_business_date <= @today
    ORDER BY current_business_date DESC
),
k_eoq AS (
    SELECT TOP (ISNULL(@keep_eoq, 0)) current_business_date AS d
    FROM dbo.v_business_date_classification
    WHERE date_type = 'EOQ'
      AND current_business_date <= @today
    ORDER BY current_business_date DESC
),
k_eoy AS (
    SELECT TOP (ISNULL(@keep_eoy, 0)) current_business_date AS d
    FROM dbo.v_business_date_classification
    WHERE date_type = 'EOY'
      AND current_business_date <= @today
    ORDER BY current_business_date DESC
),
keep_base AS (
    SELECT d FROM k_eod
    UNION
    SELECT d FROM k_eom
    UNION
    SELECT d FROM k_eoq
    UNION
    SELECT d FROM k_eoy
),
table_exempt AS (
    SELECT DISTINCT x.as_of_date AS d
    FROM dbo.archival_exemption x
    WHERE x.table_configuration_id = @tcid
      AND x.scope IN ('table','both')
),
keep_set AS (
    SELECT d FROM keep_base
    UNION
    SELECT d FROM table_exempt
)
SELECT CAST(d AS date) AS keep_date
FROM keep_set;
";

            var conn = _db.Database.GetDbConnection();
            await using (conn)
            {
                if (conn.State == ConnectionState.Closed) 
                    await conn.OpenAsync(ct);

                await using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;

                var p = cmd.CreateParameter();
                p.ParameterName = "@tcid";
                p.DbType = DbType.Int32;
                p.Value = tableConfigurationId;
                cmd.Parameters.Add(p);

                var result = new List<DateOnly>();
                await using var reader = await cmd.ExecuteReaderAsync(ct);
                while (await reader.ReadAsync(ct))
                {
                    // keep_date selected as CAST(d AS date) -> DateTime on reader
                    var dt = reader.GetFieldValue<DateTime>(0);
                    result.Add(DateOnly.FromDateTime(dt));
                }

                return result.Distinct().ToArray();
            }
        }

        public async Task<Dictionary<DateOnly, DateType>> GetDateTypesAsync(
            IEnumerable<DateOnly> dates,
            CancellationToken ct = default)
        {
            var dateList = dates?.Distinct().ToList() ?? new List<DateOnly>();
            if (dateList.Count == 0)
                return new Dictionary<DateOnly, DateType>();

            // Build IN clause with parameters (@d0,@d1,...)
            var paramNames = dateList.Select((d, i) => $"@d{i}").ToArray();
            var sql = $@"
SELECT current_business_date, date_type
FROM dbo.v_business_date_classification
WHERE current_business_date IN ({string.Join(", ", paramNames)});";

            var conn = _db.Database.GetDbConnection();
            await using (conn)
            {
                if (conn.State == ConnectionState.Closed) 
                    await conn.OpenAsync(ct);

                await using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;

                int idx = 0;
                foreach (var d in dateList)
                {
                    var p = cmd.CreateParameter();
                    p.ParameterName = $"@d{idx++}";
                    p.DbType = DbType.DateTime;
                    p.Value = d.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.Add(p);
                }

                var map = new Dictionary<DateOnly, DateType>();

                await using var reader = await cmd.ExecuteReaderAsync(ct);
                while (await reader.ReadAsync(ct))
                {
                    var dt = reader.GetFieldValue<DateTime>(0);
                    var typeStr = reader.GetString(1);

                    var dateOnly = DateOnly.FromDateTime(dt);
                    if (!Enum.TryParse<DateType>(typeStr, ignoreCase: false, out var dateType))
                    {
                        dateType = DateType.EOD;
                    }

                    map[dateOnly] = dateType;
                }

                return map;
            }
        }
    }
}
