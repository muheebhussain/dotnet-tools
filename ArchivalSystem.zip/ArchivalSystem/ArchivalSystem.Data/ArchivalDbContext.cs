﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data
{
    public class ArchivalDbContext : DbContext
    {
        public ArchivalDbContext(DbContextOptions<ArchivalDbContext> options)
            : base(options)
        {
        }

        public DbSet<ArchivalTableRetentionPolicyEntity> ArchivalTableRetentionPolicies => Set<ArchivalTableRetentionPolicyEntity>();
        public DbSet<ArchivalFileLifecyclePolicyEntity> ArchivalFileLifecyclePolicies => Set<ArchivalFileLifecyclePolicyEntity>();
        public DbSet<ArchivalTableConfigurationEntity> ArchivalTableConfigurations => Set<ArchivalTableConfigurationEntity>();
        public DbSet<ArchivalFileEntity> ArchivalFiles => Set<ArchivalFileEntity>();
        public DbSet<ArchivalExemptionEntity> ArchivalExemptions => Set<ArchivalExemptionEntity>();
        public DbSet<ArchivalRunEntity> ArchivalRuns => Set<ArchivalRunEntity>();
        public DbSet<ArchivalRunDetailEntity> ArchivalRunDetails => Set<ArchivalRunDetailEntity>();
        public DbSet<ArchivalFileFullEntity> ArchivalFileFull => Set<ArchivalFileFullEntity>();


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ============================================================
            // archival_table_retention_policy
            // ============================================================
            modelBuilder.Entity<ArchivalTableRetentionPolicyEntity>(entity =>
            {
                entity.ToTable("archival_table_retention_policy", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.IsActive)
                    .HasColumnName("is_active")
                    .IsRequired();

                entity.Property(e => e.KeepLastEod).HasColumnName("keep_last_eod");
                entity.Property(e => e.KeepLastEom).HasColumnName("keep_last_eom");
                entity.Property(e => e.KeepLastEoq).HasColumnName("keep_last_eoq");
                entity.Property(e => e.KeepLastEoy).HasColumnName("keep_last_eoy");

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(100);

                entity.Property(e => e.UpdatedAtEt).HasColumnName("updated_at_et");
                entity.Property(e => e.UpdatedBy)
                    .HasColumnName("updated_by")
                    .HasMaxLength(100);
            });

            // ============================================================
            // archival_file_lifecycle_policy
            // ============================================================
            modelBuilder.Entity<ArchivalFileLifecyclePolicyEntity>(entity =>
            {
                entity.ToTable("archival_file_lifecycle_policy", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.IsActive)
                    .HasColumnName("is_active")
                    .IsRequired();

                entity.Property(e => e.AzurePolicyTag)
                    .HasColumnName("azure_policy_tag")
                    .HasMaxLength(100);

                entity.Property(e => e.EodCoolDays).HasColumnName("eod_cool_days");
                entity.Property(e => e.EodArchiveDays).HasColumnName("eod_archive_days");
                entity.Property(e => e.EodDeleteDays).HasColumnName("eod_delete_days");

                entity.Property(e => e.EomCoolDays).HasColumnName("eom_cool_days");
                entity.Property(e => e.EomArchiveDays).HasColumnName("eom_archive_days");
                entity.Property(e => e.EomDeleteDays).HasColumnName("eom_delete_days");

                entity.Property(e => e.EoqCoolDays).HasColumnName("eoq_cool_days");
                entity.Property(e => e.EoqArchiveDays).HasColumnName("eoq_archive_days");
                entity.Property(e => e.EoqDeleteDays).HasColumnName("eoq_delete_days");

                entity.Property(e => e.EoyCoolDays).HasColumnName("eoy_cool_days");
                entity.Property(e => e.EoyArchiveDays).HasColumnName("eoy_archive_days");
                entity.Property(e => e.EoyDeleteDays).HasColumnName("eoy_delete_days");

                entity.Property(e => e.ExternalCoolDays).HasColumnName("external_cool_days");
                entity.Property(e => e.ExternalArchiveDays).HasColumnName("external_archive_days");
                entity.Property(e => e.ExternalDeleteDays).HasColumnName("external_delete_days");

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(100);

                entity.Property(e => e.UpdatedAtEt).HasColumnName("updated_at_et");
                entity.Property(e => e.UpdatedBy)
                    .HasColumnName("updated_by")
                    .HasMaxLength(100);

                entity.HasIndex(e => e.AzurePolicyTag)
                      .IsUnique()
                      .HasFilter("[azure_policy_tag] IS NOT NULL");

                entity.HasMany(e => e.TableConfigurations)
                      .WithOne(tc => tc.FileLifecyclePolicy)
                      .HasForeignKey(tc => tc.FileLifecyclePolicyId);

                entity.HasMany(e => e.OverriddenFiles)
                      .WithOne(f => f.OverrideFileLifecyclePolicy)
                      .HasForeignKey(f => f.OverrideFileLifecyclePolicyId);
            });

            // ============================================================
            // archival_table_configuration
            // ============================================================
            modelBuilder.Entity<ArchivalTableConfigurationEntity>(entity =>
            {
                entity.ToTable("archival_table_configuration", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DatabaseName)
                    .HasColumnName("database_name")
                    .HasMaxLength(128)
                    .IsRequired();

                entity.Property(e => e.SchemaName)
                    .HasColumnName("schema_name")
                    .HasMaxLength(128)
                    .IsRequired();

                entity.Property(e => e.TableName)
                    .HasColumnName("table_name")
                    .HasMaxLength(128)
                    .IsRequired();

                entity.Property(e => e.AsOfDateColumn)
                    .HasColumnName("as_of_date_column")
                    .HasMaxLength(128);

                entity.Property(e => e.ExportMode)
                    .HasColumnName("export_mode")
                    .HasConversion<string>()
                    .HasMaxLength(50)
                    .IsRequired();

                entity.Property(e => e.StorageAccountName)
                    .HasColumnName("storage_account_name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.ContainerName)
                    .HasColumnName("container_name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.ArchivePathTemplate)
                    .HasColumnName("archive_path_template")
                    .HasMaxLength(400)
                    .IsRequired();

                entity.Property(e => e.DiscoveryPathPrefix)
                    .HasColumnName("discovery_path_prefix")
                    .HasMaxLength(400);

                entity.Property(e => e.TableRetentionPolicyId)
                    .HasColumnName("table_retention_policy_id");

                entity.Property(e => e.FileLifecyclePolicyId)
                    .HasColumnName("file_lifecycle_policy_id");

                entity.Property(e => e.IsActive)
                    .HasColumnName("is_active")
                    .IsRequired();

                entity.Property(e => e.DeleteFromSource)
                    .HasColumnName("delete_from_source")
                    .HasDefaultValueSql("1")
                    .IsRequired();

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(100);

                entity.Property(e => e.UpdatedAtEt).HasColumnName("updated_at_et");
                entity.Property(e => e.UpdatedBy)
                    .HasColumnName("updated_by")
                    .HasMaxLength(100);

                entity.HasIndex(e => new { e.DatabaseName, e.SchemaName, e.TableName })
                      .IsUnique()
                      .HasDatabaseName("uq_archival_table_configuration_table");

                entity.HasOne(e => e.TableRetentionPolicy)
                      .WithMany(p => p.TableConfigurations)
                      .HasForeignKey(e => e.TableRetentionPolicyId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ============================================================
            // archival_file
            // ============================================================
            modelBuilder.Entity<ArchivalFileEntity>(entity =>
            {
                entity.ToTable("archival_file", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.TableConfigurationId)
                    .HasColumnName("table_configuration_id");

                entity.Property(e => e.AsOfDate)
                    .HasColumnName("as_of_date");

                entity.Property(e => e.DateType)
                    .HasColumnName("date_type")
                    .HasConversion<string>()
                    .HasMaxLength(4);

                entity.Property(e => e.StorageAccountName)
                    .HasColumnName("storage_account_name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.ContainerName)
                    .HasColumnName("container_name")
                    .HasMaxLength(200)
                    .IsRequired();

                entity.Property(e => e.BlobPath)
                    .HasColumnName("blob_path")
                    .HasMaxLength(1024)
                    .IsRequired();

                entity.Property(e => e.Etag)
                    .HasColumnName("etag")
                    .HasMaxLength(200);

                entity.Property(e => e.ContentType)
                    .HasColumnName("content_type")
                    .HasMaxLength(200);

                entity.Property(e => e.FileSizeBytes)
                    .HasColumnName("file_size_bytes");

                entity.Property(e => e.RowCount)
                    .HasColumnName("row_count");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasConversion<string>()
                    .HasMaxLength(20)
                    .IsRequired();

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.Property(e => e.ArchivalPolicyTag)
                    .HasColumnName("archival_policy_tag")
                    .HasMaxLength(100);

                entity.Property(e => e.CurrentAccessTier)
                    .HasColumnName("current_access_tier")
                    .HasMaxLength(50);

                entity.Property(e => e.LastTierCheckAtEt)
                    .HasColumnName("last_tier_check_at_et");

                entity.Property(e => e.OverrideFileLifecyclePolicyId)
                    .HasColumnName("override_file_lifecycle_policy_id");

                entity.Property(e => e.LastTagsSyncAtEt)
                    .HasColumnName("last_tags_sync_at_et");

                entity.HasOne(e => e.TableConfiguration)
                      .WithMany(tc => tc.Files)
                      .HasForeignKey(e => e.TableConfigurationId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(e => new { e.TableConfigurationId, e.AsOfDate, e.BlobPath })
                      .IsUnique()
                      .HasDatabaseName("ux_archival_file_unique");
            });

            // ============================================================
            // archival_exemption
            // ============================================================
            modelBuilder.Entity<ArchivalExemptionEntity>(entity =>
            {
                entity.ToTable("archival_exemption", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.TableConfigurationId)
                    .HasColumnName("table_configuration_id");

                entity.Property(e => e.AsOfDate)
                    .HasColumnName("as_of_date");

                entity.Property(e => e.Scope)
                    .HasColumnName("scope")
                    .HasConversion<string>()
                    .HasMaxLength(10)
                    .IsRequired();

                entity.Property(e => e.Reason)
                    .HasColumnName("reason");

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(100);

                entity.HasOne(e => e.TableConfiguration)
                      .WithMany(tc => tc.Exemptions)
                      .HasForeignKey(e => e.TableConfigurationId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(e => new { e.TableConfigurationId, e.AsOfDate })
                      .HasDatabaseName("ix_archival_exemption_table_date");
            });

            // ============================================================
            // archival_run
            // ============================================================
            modelBuilder.Entity<ArchivalRunEntity>(entity =>
            {
                entity.ToTable("archival_run", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.StartedAtEt)
                    .HasColumnName("started_at_et")
                    .IsRequired();

                entity.Property(e => e.EndedAtEt)
                    .HasColumnName("ended_at_et");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasConversion<string>()
                    .HasMaxLength(20)
                    .IsRequired();

                entity.Property(e => e.Note)
                    .HasColumnName("note");
            });

            // ============================================================
            // archival_run_detail
            // ============================================================
            modelBuilder.Entity<ArchivalRunDetailEntity>(entity =>
            {
                entity.ToTable("archival_run_detail", "dbo");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.RunId)
                    .HasColumnName("run_id");

                entity.Property(e => e.TableConfigurationId)
                    .HasColumnName("table_configuration_id");

                entity.Property(e => e.AsOfDate)
                    .HasColumnName("as_of_date");

                entity.Property(e => e.DateType)
                    .HasColumnName("date_type")
                    .HasConversion<string>()
                    .HasMaxLength(4);

                entity.Property(e => e.ArchivalFileId)
                    .HasColumnName("archival_file_id");

                entity.Property(e => e.Phase)
                    .HasColumnName("phase")
                    .HasConversion<string>()
                    .HasMaxLength(20)
                    .IsRequired();

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasConversion<string>()
                    .HasMaxLength(20)
                    .IsRequired();

                entity.Property(e => e.RowsAffected)
                    .HasColumnName("rows_affected");

                entity.Property(e => e.FilePath)
                    .HasColumnName("file_path")
                    .HasMaxLength(1024);

                entity.Property(e => e.ErrorMessage)
                    .HasColumnName("error_message");

                entity.Property(e => e.CreatedAtEt)
                    .HasColumnName("created_at_et")
                    .IsRequired();

                entity.HasOne(e => e.Run)
                      .WithMany(r => r.Details)
                      .HasForeignKey(e => e.RunId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.TableConfiguration)
                      .WithMany(tc => tc.RunDetails)
                      .HasForeignKey(e => e.TableConfigurationId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.ArchivalFile)
                      .WithMany(f => f.RunDetails)
                      .HasForeignKey(e => e.ArchivalFileId)
                      .OnDelete(DeleteBehavior.SetNull);

                entity.HasIndex(e => e.RunId)
                      .HasDatabaseName("ix_archival_run_detail_run");

                entity.HasIndex(e => new { e.TableConfigurationId, e.AsOfDate })
                      .HasDatabaseName("ix_archival_run_detail_table_date");
            });

            modelBuilder.Entity<ArchivalSystem.Data.Entities.ArchivalFileFullEntity>(entity =>
            {
                entity.ToView("v_archival_file_full", "dbo");   // map to view
                entity.HasKey(e => e.ArchivalFileId);           // key for tracking (read-only)

                // Mark as read-only (EF will not attempt INSERT/UPDATE/DELETE)
                //entity.Metadata.SetIsReadOnlyBeforeSave(true);
                //entity.Metadata.SetIsReadOnlyAfterSave(true);

                // Column mappings (PascalCase -> snake_case / exact column names)
                entity.Property(e => e.ArchivalFileId).HasColumnName("archival_file_id");
                entity.Property(e => e.TableConfigurationId).HasColumnName("table_configuration_id");
                entity.Property(e => e.AsOfDate).HasColumnName("as_of_date");
                entity.Property(e => e.DateType).HasColumnName("date_type");

                entity.Property(e => e.FileStorageAccountName).HasColumnName("file_storage_account_name");
                entity.Property(e => e.FileContainerName).HasColumnName("file_container_name");
                entity.Property(e => e.BlobPath).HasColumnName("blob_path");
                entity.Property(e => e.Etag).HasColumnName("etag");
                entity.Property(e => e.ContentType).HasColumnName("content_type");
                entity.Property(e => e.FileSizeBytes).HasColumnName("file_size_bytes");
                entity.Property(e => e.RowCount).HasColumnName("row_count");
                entity.Property(e => e.FileStatus).HasColumnName("file_status");
                entity.Property(e => e.FileCreatedAtEt).HasColumnName("file_created_at_et");
                entity.Property(e => e.ArchivalPolicyTag).HasColumnName("archival_policy_tag");
                entity.Property(e => e.CurrentAccessTier).HasColumnName("current_access_tier");
                entity.Property(e => e.LastTierCheckAtEt).HasColumnName("last_tier_check_at_et");
                entity.Property(e => e.OverrideFileLifecyclePolicyId).HasColumnName("override_file_lifecycle_policy_id");
                entity.Property(e => e.LastTagsSyncAtEt).HasColumnName("last_tags_sync_at_et");

                entity.Property(e => e.DatabaseName).HasColumnName("database_name");
                entity.Property(e => e.SchemaName).HasColumnName("schema_name");
                entity.Property(e => e.TableName).HasColumnName("table_name");
                entity.Property(e => e.AsOfDateColumn).HasColumnName("as_of_date_column");
                entity.Property(e => e.ExportMode).HasColumnName("export_mode");
                entity.Property(e => e.ConfigStorageAccountName).HasColumnName("config_storage_account_name");
                entity.Property(e => e.ConfigContainerName).HasColumnName("config_container_name");
                entity.Property(e => e.ArchivePathTemplate).HasColumnName("archive_path_template");
                entity.Property(e => e.DiscoveryPathPrefix).HasColumnName("discovery_path_prefix");
                entity.Property(e => e.TableRetentionPolicyId).HasColumnName("table_retention_policy_id");
                entity.Property(e => e.FileLifecyclePolicyId).HasColumnName("file_lifecycle_policy_id");
                entity.Property(e => e.TableConfigurationIsActive).HasColumnName("table_configuration_is_active");
                entity.Property(e => e.TableConfigurationCreatedAtEt).HasColumnName("table_configuration_created_at_et");
                entity.Property(e => e.TableConfigurationCreatedBy).HasColumnName("table_configuration_created_by");
                entity.Property(e => e.TableConfigurationUpdatedAtEt).HasColumnName("table_configuration_updated_at_et");
                entity.Property(e => e.TableConfigurationUpdatedBy).HasColumnName("table_configuration_updated_by");

                entity.Property(e => e.TableRetentionPolicyName).HasColumnName("table_retention_policy_name");
                entity.Property(e => e.TableRetentionPolicyIsActive).HasColumnName("table_retention_policy_is_active");
                entity.Property(e => e.KeepLastEod).HasColumnName("keep_last_eod");
                entity.Property(e => e.KeepLastEom).HasColumnName("keep_last_eom");
                entity.Property(e => e.KeepLastEoq).HasColumnName("keep_last_eoq");
                entity.Property(e => e.KeepLastEoy).HasColumnName("keep_last_eoy");

                entity.Property(e => e.FileLifecyclePolicyIdResolved).HasColumnName("file_lifecycle_policy_id_resolved");
                entity.Property(e => e.FileLifecyclePolicyName).HasColumnName("file_lifecycle_policy_name");
                entity.Property(e => e.FileLifecyclePolicyIsActive).HasColumnName("file_lifecycle_policy_is_active");
                entity.Property(e => e.FileLifecycleAzurePolicyTag).HasColumnName("file_lifecycle_azure_policy_tag");

                entity.Property(e => e.EodCoolDays).HasColumnName("eod_cool_days");
                entity.Property(e => e.EodArchiveDays).HasColumnName("eod_archive_days");
                entity.Property(e => e.EodDeleteDays).HasColumnName("eod_delete_days");

                entity.Property(e => e.EomCoolDays).HasColumnName("eom_cool_days");
                entity.Property(e => e.EomArchiveDays).HasColumnName("eom_archive_days");
                entity.Property(e => e.EomDeleteDays).HasColumnName("eom_delete_days");

                entity.Property(e => e.EoqCoolDays).HasColumnName("eoq_cool_days");
                entity.Property(e => e.EoqArchiveDays).HasColumnName("eoq_archive_days");
                entity.Property(e => e.EoqDeleteDays).HasColumnName("eoq_delete_days");

                entity.Property(e => e.EoyCoolDays).HasColumnName("eoy_cool_days");
                entity.Property(e => e.EoyArchiveDays).HasColumnName("eoy_archive_days");
                entity.Property(e => e.EoyDeleteDays).HasColumnName("eoy_delete_days");

                entity.Property(e => e.ExternalCoolDays).HasColumnName("external_cool_days");
                entity.Property(e => e.ExternalArchiveDays).HasColumnName("external_archive_days");
                entity.Property(e => e.ExternalDeleteDays).HasColumnName("external_delete_days");

                entity.Property(e => e.OverrideFileLifecyclePolicyIdResolved)
                      .HasColumnName("override_file_lifecycle_policy_id_resolved");
                entity.Property(e => e.OverrideFileLifecyclePolicyName)
                      .HasColumnName("override_file_lifecycle_policy_name");
                entity.Property(e => e.OverrideFileLifecycleAzurePolicyTag)
                      .HasColumnName("override_file_lifecycle_azure_policy_tag");
            });

        }
    }
}
