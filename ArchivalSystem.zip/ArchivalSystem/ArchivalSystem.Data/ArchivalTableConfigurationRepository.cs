﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data;

public interface IArchivalTableConfigurationRepository
{
    /// <summary>
    /// Returns the archival table configuration for the provided id, or null if not found.
    /// </summary>
    Task<ArchivalTableConfigurationEntity?> GetByIdAsync(int id, CancellationToken ct = default);

    /// <summary>
    /// Returns the archival table configuration for the provided id including commonly-needed related entities.
    /// </summary>
    Task<ArchivalTableConfigurationEntity?> GetWithRelatedAsync(int id, CancellationToken ct = default);

    /// <summary>
    /// Returns distinct FileLifecyclePolicyId values for active table configs that reference the provided storage account.
    /// </summary>
    Task<List<int>> GetDistinctActiveFileLifecyclePolicyIdsByStorageAccountAsync(
        string storageAccountName,
        CancellationToken ct = default);
}

public class ArchivalTableConfigurationRepository(ArchivalDbContext db) : IArchivalTableConfigurationRepository
{
    private readonly ArchivalDbContext _db = db ?? throw new System.ArgumentNullException(nameof(db));

    public async Task<ArchivalTableConfigurationEntity?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        return await _db.ArchivalTableConfigurations
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id, ct);
    }

    public async Task<ArchivalTableConfigurationEntity?> GetWithRelatedAsync(int id, CancellationToken ct = default)
    {
        return await _db.ArchivalTableConfigurations
            .AsNoTracking()
            .Include(tc => tc.TableRetentionPolicy)
            .Include(tc => tc.FileLifecyclePolicy)
            .FirstOrDefaultAsync(tc => tc.Id == id, ct);
    }

    public async Task<List<int>> GetDistinctActiveFileLifecyclePolicyIdsByStorageAccountAsync(
        string storageAccountName,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(storageAccountName)) return new List<int>();

        return await _db.ArchivalTableConfigurations
            .Where(tc => tc.IsActive && tc.StorageAccountName == storageAccountName)
            .Select(tc => tc.FileLifecyclePolicyId)
            .Distinct()
            .ToListAsync(ct);
    }
}