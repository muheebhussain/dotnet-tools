﻿using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArchivalSystem.Data
{
    public interface IArchivalRunRepository
    {
        Task<ArchivalRunEntity> StartRunAsync(string? note = null, CancellationToken ct = default);

        Task CompleteRunAsync(
            long runId,
            RunStatus status,
            string? note = null,
            CancellationToken ct = default);

        Task<long> LogDetailAsync(
            long runId,
            int tableConfigurationId,
            DateTime? asOfDate,
            DateType? dateType,
            RunDetailPhase phase,
            RunDetailStatus status,
            long? archivalFileId = null,
            long? rowsAffected = null,
            string? filePath = null,
            string? errorMessage = null,
            CancellationToken ct = default);

        /// <summary>
        /// Persist a batch of run-detail rows in a single SaveChanges call.
        /// </summary>
        Task ArchivalRunDetailBulkInsertAsync(IEnumerable<ArchivalRunDetailEntity> details, CancellationToken ct = default);
    }

    public class ArchivalRunRepository(ArchivalDbContext db) : IArchivalRunRepository
    {
        public async Task<ArchivalRunEntity> StartRunAsync(string? note = null, CancellationToken ct = default)
        {
            var run = new ArchivalRunEntity
            {
                StartedAtEt = DateTime.UtcNow, // could convert to ET if you want
                Status = RunStatus.Running,
                Note = note
            };

            db.ArchivalRuns.Add(run);
            await db.SaveChangesAsync(ct);

            return run;
        }

        public async Task CompleteRunAsync(
            long runId,
            RunStatus status,
            string? note = null,
            CancellationToken ct = default)
        {
            var run = await db.ArchivalRuns.FirstOrDefaultAsync(r => r.Id == runId, ct);
            if (run == null) return;

            run.Status = status;
            run.EndedAtEt = DateTime.UtcNow;
            if (!string.IsNullOrWhiteSpace(note))
            {
                run.Note = string.IsNullOrWhiteSpace(run.Note)
                    ? note
                    : $"{run.Note}{Environment.NewLine}{note}";
            }

            await db.SaveChangesAsync(ct);
        }

        public async Task<long> LogDetailAsync(
            long runId,
            int tableConfigurationId,
            DateTime? asOfDate,
            DateType? dateType,
            RunDetailPhase phase,
            RunDetailStatus status,
            long? archivalFileId = null,
            long? rowsAffected = null,
            string? filePath = null,
            string? errorMessage = null,
            CancellationToken ct = default)
        {
            var detail = new ArchivalRunDetailEntity
            {
                RunId = runId,
                TableConfigurationId = tableConfigurationId,
                AsOfDate = asOfDate,
                DateType = dateType,
                ArchivalFileId = archivalFileId,
                Phase = phase,
                Status = status,
                RowsAffected = rowsAffected,
                FilePath = filePath,
                ErrorMessage = errorMessage,
                CreatedAtEt = DateTime.UtcNow
            };

            db.ArchivalRunDetails.Add(detail);
            await db.SaveChangesAsync(ct);

            return detail.Id;
        }

        public async Task ArchivalRunDetailBulkInsertAsync(IEnumerable<ArchivalRunDetailEntity> details, CancellationToken ct = default)
        {
            if (details == null) throw new ArgumentNullException(nameof(details));

            var list = details.ToList();
            if (list.Count == 0) return;

            db.ArchivalRunDetails.AddRange(list);
            await db.SaveChangesAsync(ct);
        }
    }

    
}
