﻿namespace ArchivalSystem.Data
{
    public enum ExportMode
    {
        SelfManaged,
        External
    }

    public enum DateType
    {
        EOD,
        EOM,
        EOQ,
        EOY,
        EXT
    }

    public enum ArchivalFileStatus
    {
        Created,
        Active,
        ArchivePending,
        Deleted,
        Failed
    }

    public enum RunStatus
    {
        Running,
        Success,
        Failed,
        Partial
    }

    public enum RunDetailPhase
    {
        Export,
        Delete,
        Reconcile,
        Lifecycle,
        Discover
    }

    public enum RunDetailStatus
    {
        Success,
        Skipped,
        Failed
    }

    public enum ExemptionScope
    {
        Table,
        File,
        Both
    }
}