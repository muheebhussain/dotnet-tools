﻿using System.Data.Common;

namespace ArchivalSystem.Abstraction;

public interface IConnectionProvider
{
    /// <summary>
    /// Creates and opens a <see cref="DbConnection"/> for the provided database name.
    /// The returned connection is opened and the caller takes ownership (dispose/close).
    /// </summary>
    Task<DbConnection> CreateOpenConnectionAsync(string databaseName, CancellationToken ct = default);
}