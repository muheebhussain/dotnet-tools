﻿using System.Data.Common;

namespace ArchivalSystem.Abstraction;

/// <summary>
/// Holds an open connection and reader returned from a query. Disposing this will dispose both.
/// </summary>
public sealed class TableQueryResult(DbConnection connection, DbDataReader reader) : IAsyncDisposable
{
    public DbConnection Connection { get; } = connection ?? throw new ArgumentNullException(nameof(connection));
    public DbDataReader Reader { get; } = reader ?? throw new ArgumentNullException(nameof(reader));

    public async ValueTask DisposeAsync()
    {
        // Dispose reader first, then connection.
        try
        {
            await Reader.DisposeAsync();
        }
        catch
        {
            // swallow to ensure connection disposal is attempted
        }

        try
        {
            await Connection.DisposeAsync();
        }
        catch
        {
            // swallow
        }
    }
}