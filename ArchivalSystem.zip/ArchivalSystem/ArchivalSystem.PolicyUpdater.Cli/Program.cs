﻿using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application;
using ArchivalSystem.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

internal class Program
{
    public static async Task<int> Main(string[] args)
    {
        try
        {
            // Expected usage:
            //   ArchivalLifecycleCli --subscriptionId <sub> --resourceGroup <rg> --storageAccount <account>
            if (args.Length == 0)
            {
                Console.Error.WriteLine(
                    "Usage: ArchivalLifecycleCli " +
                    "--subscriptionId <sub> --resourceGroup <rg> --storageAccount <account>");
                return 1;
            }

            string? subscriptionId = null;
            string? resourceGroup = null;
            string? storageAccount = null;

            for (int i = 0; i < args.Length - 1; i++)
            {
                switch (args[i])
                {
                    case "--subscriptionId":
                        subscriptionId = args[i + 1];
                        break;
                    case "--resourceGroup":
                        resourceGroup = args[i + 1];
                        break;
                    case "--storageAccount":
                        storageAccount = args[i + 1];
                        break;
                }
            }

            if (string.IsNullOrWhiteSpace(subscriptionId) ||
                string.IsNullOrWhiteSpace(resourceGroup) ||
                string.IsNullOrWhiteSpace(storageAccount))
            {
                Console.Error.WriteLine(
                    "Usage: ArchivalLifecycleCli " +
                    "--subscriptionId <sub> --resourceGroup <rg> --storageAccount <account>");
                return 1;
            }

            using var cts = new CancellationTokenSource();

            var host = Host.CreateDefaultBuilder()
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: false);
                    config.AddEnvironmentVariables();
                })
                .ConfigureServices((ctx, services) =>
                {
                    var configuration = ctx.Configuration;

                    // Archival metadata DB
                    services.AddDbContext<ArchivalDbContext>(options =>
                        options.UseSqlServer(configuration.GetConnectionString("ArchivalDb")));

                    // HTTP client for Azure Management API
                    services.AddHttpClient("AzureMgmt");

                    // Our updater
                    services.AddScoped<AzureStorageLifecycleManagementPolicyUpdater>();

                })
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.AddConsole();
                })
                .Build();

            using (host)
            {
                await host.StartAsync(cts.Token);

                var updater = host.Services.GetRequiredService<AzureStorageLifecycleManagementPolicyUpdater>();
                await updater.SyncForStorageAccountAsync(
                    subscriptionId,
                    resourceGroup,
                    storageAccount,
                    cts.Token);

                await host.StopAsync(cts.Token);
            }

            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("Fatal error in ArchivalLifecycleCli: " + ex);
            return 1;
        }
    }
}
