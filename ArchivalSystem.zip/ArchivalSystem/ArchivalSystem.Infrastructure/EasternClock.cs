﻿using ArchivalSystem.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArchivalSystem.Infrastructure
{
    /// <summary>
    /// Clock that returns current time in the US Eastern time zone.
    /// Tries platform-specific TZ identifiers ("Eastern Standard Time" on Windows,
    /// "America/New_York" on Linux/macOS) and fails fast (throws) if not available.
    /// This ensures misconfigured hosts fail early rather than producing silent timezone drift.
    /// </summary>
    public sealed class EasternClock : IClock
    {
        private readonly TimeZoneInfo _easternZone = ResolveEasternTimeZone()
                                                     ?? throw new InvalidOperationException("Eastern time zone not found on this host. " +
                                                         "Expected either the Windows ID 'Eastern Standard Time' or the IANA ID 'America/New_York'. " +
                                                         "Please configure the host time zone data or supply a configured TimeZoneInfo for Eastern time.");

        public DateTimeOffset Now
        {
            get
            {
                var utc = DateTimeOffset.UtcNow;
                return TimeZoneInfo.ConvertTime(utc, _easternZone);
            }
        }

        public DateOnly Today => DateOnly.FromDateTime(Now.DateTime);

        private static TimeZoneInfo? ResolveEasternTimeZone()
        {
            // Preferred Windows ID, then IANA
            var candidates = new[] { "Eastern Standard Time", "America/New_York" };

            foreach (var id in candidates)
            {
                try
                {
                    return TimeZoneInfo.FindSystemTimeZoneById(id);
                }
                catch
                {
                    // ignore and try next
                }
            }

            // Could not find Eastern zone on this system -> fail fast in constructor
            return null;
        }
    }
}
