﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Infrastructure;

public interface IFileEntityFactory
{
    ArchivalFileEntity CreateOrUpdateManifestEntity(
        ArchivalFileEntity? existing,
        ArchivalBlobInfo blobInfo,
        int tableConfigurationId,
        string? azurePolicyTag,
        DateTime now,
        ArchivalTableConfigurationEntity tableConfig);

    ArchivalFileEntity CreateOrUpdatePartEntity(
        ArchivalFileEntity? existing,
        ArchivalBlobInfo partBlob,
        int tableConfigurationId,
        DateTime? asOfDate,
        DateType? dateType,
        string? azurePolicyTag);
}
public sealed class FileEntityFactory : IFileEntityFactory
{
    public ArchivalFileEntity CreateOrUpdateManifestEntity(
        ArchivalFileEntity? existing,
        ArchivalBlobInfo blobInfo,
        int tableConfigurationId,
        string? azurePolicyTag,
        DateTime now,
        ArchivalTableConfigurationEntity tableConfig)
    {
        if (existing == null)
        {
            return new ArchivalFileEntity
            {
                TableConfigurationId = tableConfigurationId,
                AsOfDate = null,
                DateType = DateType.EXT,
                StorageAccountName = tableConfig.StorageAccountName,
                ContainerName = tableConfig.ContainerName,
                BlobPath = blobInfo.BlobPath,
                Etag = blobInfo.ETag,
                ContentType = blobInfo.ContentType,
                FileSizeBytes = blobInfo.ContentLength,
                Status = ArchivalFileStatus.Created,
                CreatedAtEt = now,
                ArchivalPolicyTag = azurePolicyTag,
                LastTagsSyncAtEt = now
            };
        }

        existing.Etag = blobInfo.ETag;
        existing.ContentType = blobInfo.ContentType;
        existing.FileSizeBytes = blobInfo.ContentLength;
        existing.ArchivalPolicyTag = azurePolicyTag;
        existing.LastTagsSyncAtEt = now;
        return existing;
    }

    public ArchivalFileEntity CreateOrUpdatePartEntity(
        ArchivalFileEntity? existing,
        ArchivalBlobInfo partBlob,
        int tableConfigurationId,
        DateTime? asOfDate,
        DateType? dateType,
        string? azurePolicyTag)
    {
        if (existing == null)
        {
            return new ArchivalFileEntity
            {
                TableConfigurationId = tableConfigurationId,
                AsOfDate = asOfDate?.Date,
                DateType = dateType,
                StorageAccountName = partBlob.StorageAccountName,
                ContainerName = partBlob.ContainerName,
                BlobPath = partBlob.BlobPath,
                Etag = partBlob.ETag,
                ContentType = partBlob.ContentType,
                FileSizeBytes = partBlob.ContentLength,
                Status = ArchivalFileStatus.Created,
                CreatedAtEt = DateTime.UtcNow,
                ArchivalPolicyTag = azurePolicyTag,
                LastTagsSyncAtEt = null
            };
        }

        existing.AsOfDate = asOfDate?.Date;
        existing.DateType = dateType;
        existing.Etag = partBlob.ETag;
        existing.ContentType = partBlob.ContentType;
        existing.FileSizeBytes = partBlob.ContentLength;
        existing.ArchivalPolicyTag = azurePolicyTag;
        return existing;
    }
}