﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace ArchivalSystem.Infrastructure;

public class SourceExporter(
    IParquetExportService parquetExportService,
    IArchivalRunRepository archivalRunRepository,
    ILifecyclePolicyResolver lifecyclePolicyResolver,
    IArchivalFileRepository archivalFileRepository,
    IBlobStorageService blobStorage,
    ILogger<SourceExporter> logger)
    : ISourceExporter
{
    private readonly IParquetExportService _parquetExportService = parquetExportService ?? throw new ArgumentNullException(nameof(parquetExportService));
    private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
    private readonly ILifecyclePolicyResolver _lifecyclePolicyResolver = lifecyclePolicyResolver ?? throw new ArgumentNullException(nameof(lifecyclePolicyResolver));
    private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
    private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
    private readonly ILogger<SourceExporter> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    // Default rows per part; tuneable.
    private const int DefaultMaxRowsPerPart = 250_000;

    public async Task<ParquetExportResult> ExportAsync(
        ArchivalTableConfigurationDto tableConfig,
        DateTime asOfDate,
        DateType dateType,
        long runId,
        CancellationToken ct = default)
    {
        if (tableConfig == null) throw new ArgumentNullException(nameof(tableConfig));
        if (string.IsNullOrWhiteSpace(tableConfig.AsOfDateColumn))
            throw new InvalidOperationException($"Table configuration {tableConfig.Id} has no as_of_date_column defined.");

        var blobPathBase = BlobStorageHelper.BuildBlobPath(tableConfig, asOfDate, dateType);

        var (policy, azurePolicyTag) = await _lifecyclePolicyResolver.ResolvePolicyForTableAsync(tableConfig.Id, ct);
        var isFileExempt = await _archivalFileRepository.IsFileExemptAsync(tableConfig.Id, asOfDate, ct);

        var baseTags = new Dictionary<string, string>
        {
            ["archival_table_configuration_id"] = tableConfig.Id.ToString(),
            ["archival_date"] = asOfDate.ToString("yyyy-MM-dd"),
            ["archival_date_type"] = dateType.ToString(),
            ["archival_policy"] = azurePolicyTag ?? string.Empty,
            ["archival_exempt"] = isFileExempt ? "true" : "false"
        };

        var now = DateTime.UtcNow;
        var runDetails = new List<ArchivalRunDetailEntity>();
        var partBlobInfos = new List<ArchivalBlobInfo>();
        var aggregatedRows = 0L;
        var aggregatedSize = 0L;
        int columnCount = 0;

        try
        {
            // uploadPartAsync will be called by ParquetExportService for each part.
            async Task<ArchivalBlobInfo> UploadPartAsync(int partIndex, Func<Stream, CancellationToken, Task> writer, CancellationToken ctPart)
            {
                var partPath = $"{blobPathBase}.part-{partIndex:D5}.parquet";

                // Prepare initial DB row for the part so we have an Id for run-detail.
                var partEntity = new ArchivalFileEntity
                {
                    TableConfigurationId = tableConfig.Id,
                    AsOfDate = asOfDate.Date,
                    DateType = dateType,
                    StorageAccountName = tableConfig.StorageAccountName,
                    ContainerName = tableConfig.ContainerName,
                    BlobPath = partPath,
                    Etag = null,
                    ContentType = "application/octet-stream",
                    FileSizeBytes = null,
                    RowCount = null,
                    Status = ArchivalFileStatus.Created,
                    CreatedAtEt = DateTime.UtcNow,
                    ArchivalPolicyTag = azurePolicyTag,
                    LastTagsSyncAtEt = null,
                    OverrideFileLifecyclePolicyId = tableConfig.FileLifecyclePolicyId
                };

                // Persist initial entity to obtain Id for run details and idempotency
                ArchivalFileEntity savedEntity = await _archivalFileRepository.UpsertFileAsync(partEntity, ctPart);

                // Part-specific tags (extend baseTags)
                var partTags = new Dictionary<string, string>(baseTags)
                {
                    ["archival_part_index"] = partIndex.ToString()
                };

                ArchivalBlobInfo blobInfo;
                try
                {
                    // Upload part; UploadFromStreamAsync will call the writer to stream parquet bytes.
                    blobInfo = await _blobStorage.UploadFromStreamAsync(
                        tableConfig.StorageAccountName,
                        tableConfig.ContainerName,
                        partPath,
                        contentType: "application/octet-stream",
                        writer: writer,
                        tags: partTags,
                        overwrite: true,
                        ct: ctPart);

                    // Update savedEntity with final properties and mark tags sync
                    savedEntity.Etag = blobInfo.ETag;
                    savedEntity.ContentType = blobInfo.ContentType;
                    savedEntity.FileSizeBytes = blobInfo.ContentLength;
                    savedEntity.LastTagsSyncAtEt = DateTime.UtcNow;
                    savedEntity.ArchivalPolicyTag = azurePolicyTag;
                    savedEntity.Status = ArchivalFileStatus.Active;

                    await _archivalFileRepository.UpsertFileAsync(savedEntity, ctPart);

                    // Buffer run detail success
                    runDetails.Add(new ArchivalRunDetailEntity
                    {
                        RunId = runId,
                        TableConfigurationId = tableConfig.Id,
                        AsOfDate = asOfDate.Date,
                        DateType = dateType,
                        Phase = RunDetailPhase.Export,
                        Status = RunDetailStatus.Success,
                        ArchivalFileId = savedEntity.Id,
                        FilePath = savedEntity.BlobPath,
                        ErrorMessage = null,
                        CreatedAtEt = DateTime.UtcNow
                    });
                }
                catch (OperationCanceledException)
                {
                    // propagate cancellation
                    throw;
                }
                catch (Exception ex)
                {
                    // mark entity as failed and persist update
                    savedEntity.Status = ArchivalFileStatus.Failed;
                    savedEntity.LastTagsSyncAtEt = DateTime.UtcNow;
                    await _archivalFileRepository.UpsertFileAsync(savedEntity, CancellationToken.None);

                    runDetails.Add(new ArchivalRunDetailEntity
                    {
                        RunId = runId,
                        TableConfigurationId = tableConfig.Id,
                        AsOfDate = asOfDate.Date,
                        DateType = dateType,
                        Phase = RunDetailPhase.Export,
                        Status = RunDetailStatus.Failed,
                        ArchivalFileId = savedEntity.Id,
                        FilePath = savedEntity.BlobPath,
                        ErrorMessage = ex.ToString(),
                        CreatedAtEt = DateTime.UtcNow
                    });

                    throw;
                }

                return blobInfo;
            }

            // Call parquet service to stream parts; it will call our UploadPartAsync for each part.
            var partsResult = await _parquetExportService.ExportTableToPartsAsync(
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName,
                tableConfig.AsOfDateColumn!,
                asOfDate.Date,
                async (partIndex, writer, ctPart) => await UploadPartAsync(partIndex, writer, ctPart),
                maxRowsPerPart: DefaultMaxRowsPerPart,
                ct: ct);

            // Collect per-part info, aggregate metrics and prepare run-details/bulk updates.
            foreach (var pr in partsResult)
            {
                partBlobInfos.Add(pr.BlobInfo);
                aggregatedRows += pr.Metrics?.RowCount ?? 0;
                aggregatedSize += pr.Metrics?.SizeBytes ?? 0;
                columnCount = pr.Metrics?.ColumnCount ?? columnCount;
            }

            // Bulk insert run details (if any)
            if (runDetails.Count > 0)
            {
                await _archivalRunRepository.ArchivalRunDetailBulkInsertAsync(runDetails, ct);
            }

            // If single part, return single-file result. For multi-part we return Parts populated and BlobInfo = null
            if (partBlobInfos.Count == 1)
            {
                var singleBlob = partBlobInfos[0];
                var singleMetrics = new ParquetExportMetrics
                {
                    RowCount = aggregatedRows,
                    ColumnCount = columnCount,
                    SizeBytes = aggregatedSize
                };

                // Log one success run detail for the overall export (already logged per-part)
                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Success,
                    rowsAffected: singleMetrics.RowCount,
                    filePath: singleBlob.BlobPath,
                    errorMessage: null,
                    ct: ct);

                return new ParquetExportResult
                {
                    Metrics = singleMetrics,
                    BlobInfo = singleBlob,
                    Parts = new[] { singleBlob },
                    AzurePolicyTag = azurePolicyTag
                };
            }
            else
            {
                // Multi-part: aggregate metrics and upload a small manifest is optional.
                // We do NOT create a manifest here; DB contains per-part rows (saved in UploadPartAsync).
                var aggregate = new ParquetExportMetrics
                {
                    RowCount = aggregatedRows,
                    ColumnCount = columnCount,
                    SizeBytes = aggregatedSize
                };

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Success,
                    rowsAffected: aggregate.RowCount,
                    filePath: null, // no single canonical file
                    errorMessage: null,
                    ct: ct);

                return new ParquetExportResult
                {
                    Metrics = aggregate,
                    BlobInfo = null,
                    Parts = partBlobInfos,
                    AzurePolicyTag = azurePolicyTag
                };
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Export cancelled for TableConfig {Id} date {Date}.", tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Export failed for TableConfig {Id} ({Db}.{Schema}.{Table}) on {Date}.",
                tableConfig.Id,
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName,
                asOfDate.ToString("yyyy-MM-dd"));

            // Log failure at run level
            await _archivalRunRepository.LogDetailAsync(
                runId,
                tableConfig.Id,
                asOfDate,
                dateType,
                RunDetailPhase.Export,
                RunDetailStatus.Failed,
                rowsAffected: null,
                filePath: null,
                errorMessage: ex.ToString(),
                ct: ct);

            // Also persist any buffered runDetails
            if (runDetails.Count > 0)
            {
                try { await _archivalRunRepository.ArchivalRunDetailBulkInsertAsync(runDetails, CancellationToken.None); } catch { /* swallow */ }
            }

            throw;
        }
    }
}