﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure
{
    public class SourceExporter(
        IParquetExportService parquetExportService,
        IArchivalRunRepository archivalRunRepository,
        ILifecyclePolicyResolver lifecyclePolicyResolver,
        IArchivalFileRepository archivalFileRepository,
        IBlobStorageService blobStorage,
        ILogger<SourceExporter> logger)
        : ISourceExporter
    {
        private readonly IParquetExportService _parquetExportService = parquetExportService ?? throw new ArgumentNullException(nameof(parquetExportService));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILifecyclePolicyResolver _lifecyclePolicyResolver = lifecyclePolicyResolver ?? throw new ArgumentNullException(nameof(lifecyclePolicyResolver));
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
        private readonly ILogger<SourceExporter> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task<ParquetExportResult> ExportAsync(
            ArchivalTableConfigurationDto tableConfig,
            DateTime asOfDate,
            DateType dateType,
            long runId,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(tableConfig.AsOfDateColumn))
                throw new InvalidOperationException(
                    $"Table configuration {tableConfig.Id} has no as_of_date_column defined.");

            // Build blob path 
            var blobPath = BlobStorageHelper.BuildBlobPath(tableConfig, asOfDate, dateType);

            // Resolve lifecycle policy & Azure policy tag
            var (policy, azurePolicyTag) =
                await _lifecyclePolicyResolver.ResolvePolicyForTableAsync(tableConfig.Id, ct);

            // File-level exemption (scope = 'file' or 'both')
            var isFileExempt = await _archivalFileRepository.IsFileExemptAsync(
                tableConfig.Id, asOfDate, ct);

            var tags = new Dictionary<string, string>
            {
                ["archival_table_configuration_id"] = tableConfig.Id.ToString(),
                ["archival_date"] = asOfDate.ToString("yyyy-MM-dd"),
                ["archival_date_type"] = dateType.ToString(),
                ["archival_policy"] = azurePolicyTag ?? string.Empty,
                ["archival_exempt"] = isFileExempt ? "true" : "false"
            };

            try
            {
                ParquetExportMetrics? metrics = null;

                var blobInfo = await _blobStorage.UploadFromStreamAsync(
                    tableConfig.StorageAccountName,
                    tableConfig.ContainerName,
                    blobPath,
                    contentType: "application/octet-stream",
                    writer: async (stream, token) =>
                    {
                        metrics = await _parquetExportService.ExportTableToStreamAsync(
                            tableConfig.DatabaseName,
                            tableConfig.SchemaName,
                            tableConfig.TableName,
                            tableConfig.AsOfDateColumn!,
                            asOfDate.Date,
                            stream,
                            token);
                    },
                    tags: tags,
                    overwrite: true,
                    ct: ct);

                _logger.LogInformation(
                    "Exported data to blob {Account}/{Container}/{Path} (ETag={ETag}, Size={Size}).",
                    tableConfig.StorageAccountName,
                    tableConfig.ContainerName,
                    blobPath,
                    blobInfo.ETag,
                    blobInfo.ContentLength);

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Success,
                    rowsAffected: metrics?.RowCount,
                    filePath: blobPath,
                    errorMessage: null,
                    ct: ct);

                return new ParquetExportResult
                {
                    Metrics = metrics == null ? null : new ParquetExportMetrics
                    {
                        RowCount = metrics.RowCount,
                        ColumnCount = metrics.ColumnCount,
                        SizeBytes = metrics.SizeBytes
                    },
                    BlobInfo = blobInfo,
                    AzurePolicyTag = azurePolicyTag
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Export failed for TableConfig {Id} ({Db}.{Schema}.{Table}) on {Date}.",
                    tableConfig.Id,
                    tableConfig.DatabaseName,
                    tableConfig.SchemaName,
                    tableConfig.TableName,
                    asOfDate.ToString("yyyy-MM-dd"));

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Failed,
                    rowsAffected: null,
                    filePath: null,
                    errorMessage: ex.ToString(),
                    ct: ct);

                throw;
            }
        }
    }
}