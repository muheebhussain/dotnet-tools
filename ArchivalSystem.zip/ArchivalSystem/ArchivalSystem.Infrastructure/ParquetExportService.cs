﻿using Parquet;
using Parquet.Schema;
using System.Data;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure;

public class ParquetExportService(ITargetTableRepository targetTableRepository) : IParquetExportService
{
    private readonly ITargetTableRepository _targetTableRepository = targetTableRepository
                                                                 ?? throw new ArgumentNullException(
                                                                     nameof(targetTableRepository));
    
    private const int BatchSize = 10_000;

    public async Task<ParquetExportMetrics> ExportTableToStreamAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Stream output,
        CancellationToken ct = default)
    {
        if (output == null) throw new ArgumentNullException(nameof(output));
        if (!output.CanWrite) throw new ArgumentException("Output stream must be writable.", nameof(output));

        await using var query = await _targetTableRepository.ExecuteQueryAsync(
            databaseName,
            schemaName,
            tableName,
            asOfDateColumn,
            asOfDate,
            ct);

        var reader = query.Reader;

        var fields = BuildParquetColumns(reader);
        var schema = new ParquetSchema(fields.ToArray());
        var columnCount = fields.Count;

        long totalRows = 0;

        // Use ParquetWriter writing directly to provided output stream.
        await using (var parquetWriter = await ParquetWriter.CreateAsync(schema, output, cancellationToken: ct))
        {
            parquetWriter.CompressionMethod = CompressionMethod.Snappy;

            // if no rows, we still create an empty file with schema (ParquetWriter above does this)
            if (!reader.HasRows)
            {
                // nothing else to write
                return new ParquetExportMetrics
                {
                    RowCount = 0,
                    ColumnCount = columnCount,
                    SizeBytes = TryGetStreamLength(output)
                };
            }

            var columnBuffers = InitColumnDataArrays(fields);
            int rowsInBatch = 0;

            while (await reader.ReadAsync(ct))
            {
                ct.ThrowIfCancellationRequested();

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    object? value = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    columnBuffers[i].Add(value);
                }

                rowsInBatch++;
                totalRows++;

                if (rowsInBatch >= BatchSize)
                {
                    await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct);

                    // Reset batch
                    columnBuffers = InitColumnDataArrays(fields);
                    rowsInBatch = 0;
                }
            }

            // Flush remaining rows if any
            if (rowsInBatch > 0)
            {
                await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct);
            }

            // closing parquetWriter commits footer to the output stream
        }

        return new ParquetExportMetrics
        {
            RowCount = totalRows,
            ColumnCount = columnCount,
            SizeBytes = TryGetStreamLength(output)
        };
    }

    // helper returns length if stream supports it, otherwise -1
    private static long TryGetStreamLength(Stream s)
    {
        try
        {
            return s.CanSeek ? s.Length : -1;
        }
        catch
        {
            return -1;
        }
    }

    // Build Parquet schema (DataField list) from reader metadata
    private static List<DataField> BuildParquetColumns(IDataReader reader)
    {
        var fields = new List<DataField>();

        for (int i = 0; i < reader.FieldCount; i++)
        {
            var name = reader.GetName(i);
            var type = reader.GetFieldType(i);

            // Very simple type mapping; extend as needed when needed.
            if (type == typeof(int) || type == typeof(int?))
            {
                fields.Add(new DataField<int?>(name));
            }
            else if (type == typeof(long) || type == typeof(long?))
            {
                fields.Add(new DataField<long?>(name));
            }
            else if (type == typeof(decimal) || type == typeof(decimal?))
            {
                fields.Add(new DataField<decimal?>(name));
            }
            else if (type == typeof(double) || type == typeof(double?))
            {
                fields.Add(new DataField<double?>(name));
            }
            else if (type == typeof(float) || type == typeof(float?))
            {
                fields.Add(new DataField<float?>(name));
            }
            else if (type == typeof(DateTime) || type == typeof(DateTime?))
            {
                fields.Add(new DataField<DateTime?>(name));
            }
            else if (type == typeof(bool) || type == typeof(bool?))
            {
                fields.Add(new DataField<bool?>(name));
            }
            else if (type == typeof(Guid) || type == typeof(Guid?))
            {
                fields.Add(new DataField<string>(name)); // store GUIDs as strings
            }
            else
            {
                // default to string
                fields.Add(new DataField<string>(name));
            }
        }

        return fields;
    }

    // Initialize column buffers for a batch
    private static List<List<object?>> InitColumnDataArrays(List<DataField> fields)
    {
        var list = new List<List<object?>>(fields.Count);
        for (int i = 0; i < fields.Count; i++)
        {
            list.Add(new List<object?>());
        }

        return list;
    }

    // Write a single row group from current buffers
    private static async Task WriteRowGroupAsync(
        ParquetWriter parquetWriter,
        List<DataField> fields,
        List<List<object?>> columnBuffers,
        CancellationToken ct)
    {
        using ParquetRowGroupWriter rowGroupWriter = parquetWriter.CreateRowGroup();

        for (int i = 0; i < fields.Count; i++)
        {
            var field = fields[i];
            var buffer = columnBuffers[i];

            Array typedArray = ConvertToTypedArray(field, buffer);

            var dataColumn = new Parquet.Data.DataColumn(field, typedArray);
            await rowGroupWriter.WriteColumnAsync(dataColumn, ct);
        }
    }

    // Convert a List<object?> into the right typed array for the DataField
    private static Array ConvertToTypedArray(DataField field, List<object?> buffer)
    {
        var clrType = field.ClrType; // e.g. typeof(int?), typeof(string), etc.

        var array = Array.CreateInstance(clrType, buffer.Count);

        for (int i = 0; i < buffer.Count; i++)
        {
            array.SetValue(buffer[i], i);
        }

        return array;
    }
}
