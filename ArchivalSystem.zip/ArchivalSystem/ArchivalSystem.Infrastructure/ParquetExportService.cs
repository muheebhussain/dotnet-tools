﻿using Parquet;
using Parquet.Schema;
using System.Data;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure;

public class ParquetExportService(ITargetTableRepository targetTableRepository) : IParquetExportService
{
    private readonly ITargetTableRepository _targetTableRepository = targetTableRepository ?? throw new ArgumentNullException(nameof(targetTableRepository));

    // Tune based on available memory and desired row-group size
    private const int RowGroupBatchSize = 10_000;

    public async Task<ParquetExportMetrics> ExportTableToStreamAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Stream output,
        CancellationToken ct = default)
    {
        if (output == null) throw new ArgumentNullException(nameof(output));
        if (!output.CanWrite) throw new ArgumentException("Output stream must be writable.", nameof(output));

        await using var query = await _targetTableRepository.ExecuteQueryAsync(
            databaseName, schemaName, tableName, asOfDateColumn, asOfDate, ct);

        var reader = query.Reader;

        var fields = BuildParquetColumns(reader);
        var schema = new ParquetSchema(fields.ToArray());
        var columnCount = fields.Count;

        long totalRows = 0;

        await using (var parquetWriter = await ParquetWriter.CreateAsync(schema, output, cancellationToken: ct))
        {
            parquetWriter.CompressionMethod = CompressionMethod.Snappy;

            // If there are no rows, return metrics with zero and attempt to return stream length if possible
            if (!reader.HasRows)
            {
                return new ParquetExportMetrics
                {
                    RowCount = 0,
                    ColumnCount = columnCount,
                    SizeBytes = TryGetStreamLength(output)
                };
            }

            var columnBuffers = InitColumnDataArrays(fields);
            int rowsInBatch = 0;

            while (await reader.ReadAsync(ct))
            {
                ct.ThrowIfCancellationRequested();

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    object? value = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    columnBuffers[i].Add(value);
                }

                rowsInBatch++;
                totalRows++;

                if (rowsInBatch >= RowGroupBatchSize)
                {
                    await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct);
                    columnBuffers = InitColumnDataArrays(fields);
                    rowsInBatch = 0;
                }
            }

            if (rowsInBatch > 0)
            {
                await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, ct);
            }
        }

        return new ParquetExportMetrics
        {
            RowCount = totalRows,
            ColumnCount = columnCount,
            SizeBytes = TryGetStreamLength(output)
        };
    }

    public async Task<IReadOnlyList<ParquetExportPartResult>> ExportTableToPartsAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Func<int, Func<Stream, CancellationToken, Task>, CancellationToken, Task<ArchivalBlobInfo>> uploadPartAsync,
        int maxRowsPerPart = 250_000,
        CancellationToken ct = default)
    {
        if (uploadPartAsync == null) throw new ArgumentNullException(nameof(uploadPartAsync));
        if (maxRowsPerPart <= 0) throw new ArgumentOutOfRangeException(nameof(maxRowsPerPart));

        await using var query = await _targetTableRepository.ExecuteQueryAsync(
            databaseName, schemaName, tableName, asOfDateColumn, asOfDate, ct);

        var reader = query.Reader;

        var fields = BuildParquetColumns(reader);
        var schema = new ParquetSchema(fields.ToArray());
        var columnCount = fields.Count;

        var parts = new List<ParquetExportPartResult>();
        long totalRows = 0;
        int partIndex = 0;
        bool moreRows = true;

        // If no rows, create a single empty part
        if (!reader.HasRows)
        {
            ArchivalBlobInfo emptyBlob = await uploadPartAsync(0, async (s, token) =>
            {
                await using var pw = await ParquetWriter.CreateAsync(schema, s, cancellationToken: token);
                pw.CompressionMethod = CompressionMethod.Snappy;
                // no row groups written
            }, ct);

            parts.Add(new ParquetExportPartResult
            {
                PartIndex = 0,
                Metrics = new ParquetExportMetrics { RowCount = 0, ColumnCount = columnCount, SizeBytes = emptyBlob.ContentLength ?? -1 },
                BlobInfo = emptyBlob
            });

            return parts;
        }

        while (moreRows)
        {
            int rowsInPart = 0;

            // Writer function writes up to maxRowsPerPart rows by consuming the shared reader.
            async Task WriterFunc(Stream output, CancellationToken token)
            {
                await using var parquetWriter = await ParquetWriter.CreateAsync(schema, output, cancellationToken: token);
                parquetWriter.CompressionMethod = CompressionMethod.Snappy;

                var columnBuffers = InitColumnDataArrays(fields);
                int rowsInBatch = 0;

                while (rowsInPart < maxRowsPerPart)
                {
                    token.ThrowIfCancellationRequested();

                    var hasRow = await reader.ReadAsync(token);
                    if (!hasRow)
                    {
                        moreRows = false;
                        break;
                    }

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        object? value = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        columnBuffers[i].Add(value);
                    }

                    rowsInBatch++;
                    rowsInPart++;
                    totalRows++;

                    if (rowsInBatch >= RowGroupBatchSize)
                    {
                        await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, token);
                        columnBuffers = InitColumnDataArrays(fields);
                        rowsInBatch = 0;
                    }
                }

                if (rowsInBatch > 0)
                {
                    await WriteRowGroupAsync(parquetWriter, fields, columnBuffers, token);
                }
            }

            // Upload the part (caller will provide a stream and our WriterFunc writes into it)
            ArchivalBlobInfo partBlobInfo = await uploadPartAsync(partIndex, WriterFunc, ct);

            var metrics = new ParquetExportMetrics
            {
                RowCount = rowsInPart,
                ColumnCount = columnCount,
                SizeBytes = partBlobInfo.ContentLength ?? -1
            };

            parts.Add(new ParquetExportPartResult
            {
                PartIndex = partIndex,
                Metrics = metrics,
                BlobInfo = partBlobInfo
            });

            partIndex++;
        }

        return parts;
    }

    // helper returns length if stream supports it, otherwise -1
    private static long TryGetStreamLength(Stream s)
    {
        try
        {
            return s.CanSeek ? s.Length : -1;
        }
        catch
        {
            return -1;
        }
    }

    // Build Parquet schema (DataField list) from reader metadata
    private static List<DataField> BuildParquetColumns(IDataReader reader)
    {
        var fields = new List<DataField>();

        for (int i = 0; i < reader.FieldCount; i++)
        {
            var name = reader.GetName(i);
            var type = reader.GetFieldType(i);

            // Very simple type mapping; extend as needed when needed.
            if (type == typeof(int) || type == typeof(int?))
            {
                fields.Add(new DataField<int?>(name));
            }
            else if (type == typeof(long) || type == typeof(long?))
            {
                fields.Add(new DataField<long?>(name));
            }
            else if (type == typeof(decimal) || type == typeof(decimal?))
            {
                fields.Add(new DataField<decimal?>(name));
            }
            else if (type == typeof(double) || type == typeof(double?))
            {
                fields.Add(new DataField<double?>(name));
            }
            else if (type == typeof(float) || type == typeof(float?))
            {
                fields.Add(new DataField<float?>(name));
            }
            else if (type == typeof(DateTime) || type == typeof(DateTime?))
            {
                fields.Add(new DataField<DateTime?>(name));
            }
            else if (type == typeof(bool) || type == typeof(bool?))
            {
                fields.Add(new DataField<bool?>(name));
            }
            else if (type == typeof(Guid) || type == typeof(Guid?))
            {
                fields.Add(new DataField<string>(name)); // store GUIDs as strings
            }
            else
            {
                // default to string
                fields.Add(new DataField<string>(name));
            }
        }

        return fields;
    }

    // Initialize column buffers for a batch
    private static List<List<object?>> InitColumnDataArrays(List<DataField> fields)
    {
        var list = new List<List<object?>>(fields.Count);
        for (int i = 0; i < fields.Count; i++)
        {
            list.Add(new List<object?>());
        }

        return list;
    }

    // Write a single row group from current buffers
    private static async Task WriteRowGroupAsync(
        ParquetWriter parquetWriter,
        List<DataField> fields,
        List<List<object?>> columnBuffers,
        CancellationToken ct)
    {
        using ParquetRowGroupWriter rowGroupWriter = parquetWriter.CreateRowGroup();

        for (int i = 0; i < fields.Count; i++)
        {
            var field = fields[i];
            var buffer = columnBuffers[i];

            Array typedArray = ConvertToTypedArray(field, buffer);

            var dataColumn = new Parquet.Data.DataColumn(field, typedArray);
            await rowGroupWriter.WriteColumnAsync(dataColumn, ct);
        }
    }

    // Convert a List<object?> into the right typed array for the DataField
    private static Array ConvertToTypedArray(DataField field, List<object?> buffer)
    {
        var clrType = field.ClrType; // e.g. typeof(int?), typeof(string), etc.

        var array = Array.CreateInstance(clrType, buffer.Count);

        for (int i = 0; i < buffer.Count; i++)
        {
            array.SetValue(buffer[i], i);
        }

        return array;
    }
}