﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;

namespace ArchivalSystem.Infrastructure
{
    public class BlobStorageService(IOptions<BlobStorageOptions> options) : IBlobStorageService
    {
        private readonly BlobStorageOptions
            _options = options.Value ?? throw new ArgumentNullException(nameof(options));

        private BlobServiceClient GetServiceClient(string storageAccountName)
        {
            var account = _options.Accounts
                .FirstOrDefault(a =>
                    a.StorageAccountName.Equals(storageAccountName, StringComparison.OrdinalIgnoreCase));

            if (account == null)
                throw new InvalidOperationException(
                    $"No connection string configured for storage account '{storageAccountName}'.");

            return new BlobServiceClient(account.ConnectionString);
        }

        private BlobContainerClient GetContainerClient(string storageAccountName, string containerName)
        {
            var serviceClient = GetServiceClient(storageAccountName);
            return serviceClient.GetBlobContainerClient(containerName);
        }

        public async Task<IReadOnlyList<ArchivalBlobInfo>> ListBlobsAsync(
            string storageAccountName,
            string containerName,
            string? prefix,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);

            var result = new List<ArchivalBlobInfo>();

            await foreach (var blobItem in containerClient
                               .GetBlobsAsync(prefix: prefix, cancellationToken: ct))
            {
                result.Add(new ArchivalBlobInfo
                {
                    StorageAccountName = storageAccountName,
                    ContainerName = containerName,
                    BlobPath = blobItem.Name,
                    ETag = blobItem.Properties.ETag?.ToString(),
                    ContentType = blobItem.Properties.ContentType,
                    ContentLength = blobItem.Properties.ContentLength
                });
            }

            return result;
        }

        public async Task<ArchivalBlobInfo> UploadAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            string contentType,
            byte[] content,
            IDictionary<string, string> tags,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);
            await containerClient.CreateIfNotExistsAsync(cancellationToken: ct);

            var blobClient = containerClient.GetBlobClient(blobPath);

            using var stream = new System.IO.MemoryStream(content, writable: false);
            var uploadOptions = new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders
                {
                    ContentType = contentType
                }
            };

            await blobClient.UploadAsync(stream, uploadOptions, ct);

            if (tags != null && tags.Count > 0)
            {
                await blobClient.SetTagsAsync(tags, cancellationToken: ct);
            }

            var properties = await blobClient.GetPropertiesAsync(cancellationToken: ct);

            return new ArchivalBlobInfo
            {
                StorageAccountName = storageAccountName,
                ContainerName = containerName,
                BlobPath = blobPath,
                ETag = properties.Value.ETag.ToString(),
                ContentType = properties.Value.ContentType,
                ContentLength = properties.Value.ContentLength
            };
        }

        public async Task SetTagsAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            IDictionary<string, string> tags,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);
            var blobClient = containerClient.GetBlobClient(blobPath);

            await blobClient.SetTagsAsync(tags, cancellationToken: ct);
        }

        public async Task<IDictionary<string, string>> GetTagsAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);
            var blobClient = containerClient.GetBlobClient(blobPath);

            try
            {
                var response = await blobClient.GetTagsAsync(cancellationToken: ct);
                return response.Value.Tags;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return new Dictionary<string, string>();
            }
        }

        public async Task<string?> GetAccessTierAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);
            var blobClient = containerClient.GetBlobClient(blobPath);

            try
            {
                var properties = await blobClient.GetPropertiesAsync(cancellationToken: ct);
                return properties.Value.AccessTier?.ToString();
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        public async Task<Stream> OpenWriteStreamAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            bool overwrite = true,
            string? contentType = null,
            CancellationToken ct = default)
        {
            var containerClient = GetContainerClient(storageAccountName, containerName);
            await containerClient.CreateIfNotExistsAsync(cancellationToken: ct);

            var blobClient = containerClient.GetBlobClient(blobPath);

            var openOptions = new BlobOpenWriteOptions
            {
                HttpHeaders = new BlobHttpHeaders
                {
                    ContentType = string.IsNullOrWhiteSpace(contentType) ? "application/octet-stream" : contentType
                }
            };

            // OpenWriteAsync returns a stream that writes directly to the blob.
            // Caller is responsible for disposing/flushing the stream.
            var writeStream =
                await blobClient.OpenWriteAsync(overwrite: overwrite, options: openOptions, cancellationToken: ct);
            return writeStream;
        }

        public async Task<ArchivalBlobInfo> UploadFromStreamAsync(
            string storageAccountName,
            string containerName,
            string blobPath,
            string contentType,
            Func<Stream, CancellationToken, Task> writer,
            IDictionary<string, string>? tags = null,
            bool overwrite = true,
            CancellationToken ct = default)
        {
            if (writer == null) throw new ArgumentNullException(nameof(writer));
            if (string.IsNullOrWhiteSpace(storageAccountName))
                throw new ArgumentException("Storage account name required.", nameof(storageAccountName));
            if (string.IsNullOrWhiteSpace(containerName))
                throw new ArgumentException("Container name required.", nameof(containerName));
            if (string.IsNullOrWhiteSpace(blobPath))
                throw new ArgumentException("Blob path required.", nameof(blobPath));

            var containerClient = GetContainerClient(storageAccountName, containerName);
            await containerClient.CreateIfNotExistsAsync(cancellationToken: ct);

            var blobClient = containerClient.GetBlobClient(blobPath);

            var openOptions = new BlobOpenWriteOptions
            {
                HttpHeaders = new BlobHttpHeaders
                {
                    ContentType = string.IsNullOrWhiteSpace(contentType) ? "application/octet-stream" : contentType
                }
            };

            // Write to the blob stream (commits when disposed)
            await using (var writeStream =
                         await blobClient.OpenWriteAsync(overwrite: overwrite, options: openOptions,
                             cancellationToken: ct))
            {
                await writer(writeStream, ct);

                // flush to ensure any buffered data is persisted
                await writeStream.FlushAsync(ct);
            }

            // Apply tags if provided (separate call)
            if (tags != null && tags.Count > 0)
            {
                await blobClient.SetTagsAsync(tags, cancellationToken: ct);
            }

            // Get final properties
            var properties = await blobClient.GetPropertiesAsync(cancellationToken: ct);
            
            return new ArchivalBlobInfo
            {
                StorageAccountName = storageAccountName,
                ContainerName = containerName,
                BlobPath = blobPath,
                ETag = properties.Value.ETag.ToString(),
                ContentType = properties.Value.ContentType,
                ContentLength = properties.Value.ContentLength
            };
        }
    }
}
