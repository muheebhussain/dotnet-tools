﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure
{
    public class ArchivalFileLifecyclePolicyResolver(
        IArchivalFileLifecyclePolicyRepository filePolicyRepository,
        IArchivalTableConfigurationRepository tableConfigRepository) : ILifecyclePolicyResolver
    {
        private readonly IArchivalFileLifecyclePolicyRepository _filePolicyRepository = filePolicyRepository ?? throw new ArgumentNullException(nameof(filePolicyRepository));
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        
        public async Task<(ArchivalFileLifecyclePolicyDto policy, string? azurePolicyTag)>
            ResolvePolicyForFileAsync(ArchivalFileDto file, CancellationToken ct = default)
        {
            ArgumentNullException.ThrowIfNull(file);

            if (file.OverrideFileLifecyclePolicyId.HasValue)
            {
                var overridePolicy = await _filePolicyRepository.GetByIdAsync(file.OverrideFileLifecyclePolicyId.Value, ct);

                if (overridePolicy == null)
                    throw new InvalidOperationException(
                        $"Override lifecycle policy {file.OverrideFileLifecyclePolicyId} not found for file {file.Id}.");

                return (overridePolicy.ToDto(), overridePolicy.AzurePolicyTag);
            }

            var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(file.TableConfigurationId, ct);

            if (tableConfig == null)
                throw new InvalidOperationException(
                    $"Table configuration {file.TableConfigurationId} not found for file {file.Id}.");

            var policy = tableConfig.FileLifecyclePolicy
                ?? throw new InvalidOperationException(
                    $"File lifecycle policy {tableConfig.FileLifecyclePolicyId} not found for table configuration {tableConfig.Id}.");

            return (policy.ToDto(), policy.AzurePolicyTag);
        }

        public async Task<(ArchivalFileLifecyclePolicyDto policy, string? azurePolicyTag)>
            ResolvePolicyForTableAsync(int tableConfigurationId, CancellationToken ct = default)
        {
            var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(tableConfigurationId, ct);

            if (tableConfig == null)
                throw new InvalidOperationException(
                    $"Table configuration {tableConfigurationId} not found.");

            var policy = tableConfig.FileLifecyclePolicy
                ?? throw new InvalidOperationException(
                    $"File lifecycle policy {tableConfig.FileLifecyclePolicyId} not found for table configuration {tableConfig.Id}.");

            return (policy.ToDto(), policy.AzurePolicyTag);
        }

        public (int? coolDays, int? archiveDays, int? deleteDays)
            GetDurationsForDateType(ArchivalFileLifecyclePolicyDto policy, DateType? dateType)
        {
            if (policy == null) throw new ArgumentNullException(nameof(policy));

            int? cool = null, archive = null, delete = null;

            switch (dateType)
            {
                case DateType.EOD:
                    cool = policy.EodCoolDays;
                    archive = policy.EodArchiveDays;
                    delete = policy.EodDeleteDays;
                    break;

                case DateType.EOM:
                    cool = policy.EomCoolDays;
                    archive = policy.EomArchiveDays;
                    delete = policy.EomDeleteDays;
                    break;

                case DateType.EOQ:
                    cool = policy.EoqCoolDays;
                    archive = policy.EoqArchiveDays;
                    delete = policy.EoqDeleteDays;
                    break;

                case DateType.EOY:
                    cool = policy.EoyCoolDays;
                    archive = policy.EoyArchiveDays;
                    delete = policy.EoyDeleteDays;
                    break;

                case DateType.EXT:
                case null:
                    cool = policy.ExternalCoolDays;
                    archive = policy.ExternalArchiveDays;
                    delete = policy.ExternalDeleteDays;
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(dateType), dateType, "Unsupported date type.");
            }

            return (cool, archive, delete);
        }
    }
}
