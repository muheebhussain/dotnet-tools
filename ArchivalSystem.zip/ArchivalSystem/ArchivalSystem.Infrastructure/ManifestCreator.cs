﻿using System.Text;
using System.Text.Json;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;

namespace ArchivalSystem.Infrastructure;

public interface IManifestCreator
{
    byte[] BuildManifestBytes(IEnumerable<ArchivalBlobInfo> parts);
    Task<ArchivalBlobInfo> UploadManifestAsync(
        string storageAccountName,
        string containerName,
        string manifestPath,
        byte[] manifestBytes,
        IDictionary<string, string>? tags,
        CancellationToken ct = default);
}
public sealed class ManifestCreator : IManifestCreator
{
    private readonly IBlobStorageService _blobStorage;

    public ManifestCreator(IBlobStorageService blobStorage)
    {
        _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
    }

    public byte[] BuildManifestBytes(IEnumerable<ArchivalBlobInfo> parts)
    {
        var manifest = new
        {
            generatedAt = DateTime.UtcNow,
            parts = parts.Select(p => new
            {
                path = p.BlobPath,
                etag = p.ETag,
                contentType = p.ContentType,
                length = p.ContentLength
            }).ToArray()
        };

        return Encoding.UTF8.GetBytes(JsonSerializer.Serialize(manifest));
    }

    public Task<ArchivalBlobInfo> UploadManifestAsync(
        string storageAccountName,
        string containerName,
        string manifestPath,
        byte[] manifestBytes,
        IDictionary<string, string>? tags,
        CancellationToken ct = default)
    {
        if (manifestBytes == null) throw new ArgumentNullException(nameof(manifestBytes));

        return _blobStorage.UploadFromStreamAsync(
            storageAccountName,
            containerName,
            manifestPath,
            contentType: "application/json",
            writer: async (stream, token) =>
            {
                await stream.WriteAsync(manifestBytes, 0, manifestBytes.Length, token);
            },
            tags: tags,
            overwrite: true,
            ct: ct);
    }
}