﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure
{
    public class ExternalTableArchiver(
        IExternalFileRegistrar externalFileRegistrar,
        IArchivalRunRepository archivalRunRepository,
        ILogger<ExternalTableArchiver> logger)
        : IExternalTableArchiver
    {
        private readonly IExternalFileRegistrar _externalFileRegistrar = externalFileRegistrar ?? throw new ArgumentNullException(nameof(externalFileRegistrar));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILogger<ExternalTableArchiver> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task ArchiveAsync(
            ArchivalTableConfigurationDto tableConfig,
            long runId,
            CancellationToken ct = default)
        {
            _logger.LogInformation(
                "Processing External table {Id} (storage={Account}/{Container}, discovery_prefix={Prefix}).",
                tableConfig.Id,
                tableConfig.StorageAccountName,
                tableConfig.ContainerName,
                tableConfig.DiscoveryPathPrefix);

            try
            {
                var count = await _externalFileRegistrar.DiscoverAndRegisterAsync(
                    tableConfig.Id,
                    runId,
                    ct);

                _logger.LogInformation(
                    "External TableConfig {Id}: registered/updated {Count} blobs.",
                    tableConfig.Id,
                    count);

                // Optional: log a summarized run detail
                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate: null,
                    dateType: null,
                    phase: RunDetailPhase.Lifecycle,
                    status: RunDetailStatus.Success,
                    rowsAffected: count,
                    filePath: tableConfig.DiscoveryPathPrefix,
                    errorMessage: null,
                    ct: ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Error discovering/registering external blobs for TableConfig {Id}.",
                    tableConfig.Id);

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate: null,
                    dateType: null,
                    phase: RunDetailPhase.Lifecycle,
                    status: RunDetailStatus.Failed,
                    rowsAffected: null,
                    filePath: tableConfig.DiscoveryPathPrefix,
                    errorMessage: ex.ToString(),
                    ct: ct);

                throw;
            }
        }
    }
}
