﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure
{
    public interface IRetentionService
    {
        Task<RetentionResult> ComputeRetentionAsync(
            ArchivalTableConfigurationDto tableConfig,
            CancellationToken ct = default);

        Task<Dictionary<DateOnly, DateType>> GetDateTypesAsync(
            IEnumerable<DateOnly> dates,
            CancellationToken ct = default);

        Task<DateType?> GetDateTypeAsync(
            DateOnly date,
            CancellationToken ct = default);
    }

    public class RetentionService(
        IRetentionRepository retentionRepository,
        ITargetTableRepository targetTableRepository)
        : IRetentionService
    {
        private readonly IRetentionRepository _retentionRepository = retentionRepository ?? throw new ArgumentNullException(nameof(retentionRepository));
        private readonly ITargetTableRepository _targetTableRepository = targetTableRepository ?? throw new ArgumentNullException(nameof(targetTableRepository));

        public async Task<RetentionResult> ComputeRetentionAsync(
            ArchivalTableConfigurationDto tableConfig,
            CancellationToken ct = default)
        {
            if (tableConfig == null) throw new ArgumentNullException(nameof(tableConfig));
            if (string.IsNullOrWhiteSpace(tableConfig.AsOfDateColumn))
                throw new InvalidOperationException(
                    $"Table configuration {tableConfig.Id} has no as_of_date_column defined.");

            // 1) Compute KEEP SET from ArchivalDb (business calendar + retention + exemptions)
            var keepDates = await _retentionRepository.GetKeepSetAsync(tableConfig.Id, ct);

            // 2) Get PRESENT dates from actual data table in its own database
            var presentDates = await _targetTableRepository.GetDistinctAsOfDatesAsync(
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName,
                tableConfig.AsOfDateColumn,
                ct);
            

            // 3) Candidates = present - keep
            var keepSet = keepDates.ToHashSet();
            var candidates = presentDates
                .Where(d => !keepSet.Contains(d))
                .OrderBy(d => d)
                .ToArray();

            return new RetentionResult
            {
                KeepDates = keepDates.OrderBy(d => d).ToArray(),
                CandidateDates = candidates
            };
        }


      

        // --------------------------------------------------------------------
        // Helper methods to get DateType for DateOnly using v_business_date_classification
        // --------------------------------------------------------------------

        public Task<Dictionary<DateOnly, DateType>> GetDateTypesAsync(
            IEnumerable<DateOnly> dates,
            CancellationToken ct = default)
            => _retentionRepository.GetDateTypesAsync(dates, ct);

        public async Task<DateType?> GetDateTypeAsync(
            DateOnly date,
            CancellationToken ct = default)
        {
            var map = await GetDateTypesAsync(new[] { date }, ct);
            return map.TryGetValue(date, out var dt) ? dt : (DateType?)null;
        }
    }
}
