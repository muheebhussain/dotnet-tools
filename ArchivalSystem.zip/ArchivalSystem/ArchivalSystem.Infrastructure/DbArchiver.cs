﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure
{
    public class DbArchiver(
        IArchivalTableConfigurationRepository tableConfigRepository,
        IArchivalFileRepository archivalFileRepository,
        ISourceExporter sourceExporter,
        ISourceDataDeleter sourceDataDeleter,
        IArchivalRunRepository archivalRunRepository,
        ILogger<DbArchiver> logger) : IDbArchiver
    {
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly ISourceExporter _sourceExporter = sourceExporter ?? throw new ArgumentNullException(nameof(sourceExporter));
        private readonly ISourceDataDeleter _sourceDataDeleter = sourceDataDeleter ?? throw new ArgumentNullException(nameof(sourceDataDeleter));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILogger<DbArchiver> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task ArchiveTableForDateAsync(
            ArchivalTableConfigurationDto tableConfig,
            DateTime asOfDate,
            DateType dateType,
            long runId,
            CancellationToken ct = default)
        {
            if (tableConfig == null) throw new ArgumentNullException(nameof(tableConfig));

            if (tableConfig.ExportMode != ExportMode.SelfManaged)
                throw new InvalidOperationException(
                    $"Table configuration {tableConfig.Id} is not SelfManaged (ExportMode={tableConfig.ExportMode}).");

            _logger.LogInformation(
                "Archiving TableConfig {Id} ({Db}.{Schema}.{Table}) for {Date} ({DateType}).",
                tableConfig.Id,
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName,
                asOfDate.ToString("yyyy-MM-dd"),
                dateType);

            // 0) Skip if already archived for this table/date/dateType
            var exists = await _archivalFileRepository.ExistsForTableDateAsync(tableConfig.Id, asOfDate, dateType, ct);
            if (exists)
            {
                _logger.LogInformation("Archival file already exists for TableConfig {Id}, Date {Date}, skipping.",
                    tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Skipped,
                    rowsAffected: null,
                    filePath: null,
                    errorMessage: "Archival file already exists.",
                    ct: ct);

                return;
            }

            // 1) Table-level exemption
            var isTableExempt = await _archivalFileRepository.IsTableExemptAsync(tableConfig.Id, asOfDate, ct);
            if (isTableExempt)
            {
                _logger.LogInformation("Skipping archival for TableConfig {Id}, Date {Date} due to TABLE exemption.",
                    tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Skipped,
                    rowsAffected: null,
                    filePath: null,
                    errorMessage: "Table-level exemption",
                    ct: ct);

                return;
            }

            // 2) Export -> may produce single blob or multiple parts (per-part DB rows are created by SourceExporter)
            ParquetExportResult exportResult;
            try
            {
                exportResult = await _sourceExporter.ExportAsync(tableConfig, asOfDate, dateType, runId, ct);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Export cancelled for TableConfig {Id} date {Date}.", tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Export failed for TableConfig {Id} on {Date}.", tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));
                throw;
            }

            // 3) Create a canonical archival_file row for the export.
            //    If exportResult.BlobInfo is present (single-file), use it. For multi-part use first part as representative.
            var representativePath = exportResult.BlobInfo?.BlobPath
                                     ?? exportResult.Parts?.FirstOrDefault()?.BlobPath
                                     ?? BlobStorageHelper.BuildBlobPath(tableConfig, asOfDate, dateType);

            var archivalFile = new ArchivalFileEntity
            {
                TableConfigurationId = tableConfig.Id,
                AsOfDate = asOfDate.Date,
                DateType = dateType,
                StorageAccountName = tableConfig.StorageAccountName,
                ContainerName = tableConfig.ContainerName,
                BlobPath = representativePath,
                Etag = exportResult.BlobInfo?.ETag,
                ContentType = exportResult.BlobInfo?.ContentType,
                FileSizeBytes = exportResult.BlobInfo?.ContentLength,
                RowCount = exportResult.Metrics?.RowCount > 0 ? exportResult.Metrics?.RowCount : null,
                Status = ArchivalFileStatus.Created,
                CreatedAtEt = DateTime.UtcNow,
                ArchivalPolicyTag = exportResult.AzurePolicyTag,
                CurrentAccessTier = null,
                LastTierCheckAtEt = null,
                OverrideFileLifecyclePolicyId = null,
                LastTagsSyncAtEt = DateTime.UtcNow
            };

            var savedFile = await _archivalFileRepository.UpsertFileAsync(archivalFile, ct);

            // 4) If multi-part, ensure the per-part archival rows exist/are updated.
            if (exportResult.Parts != null && exportResult.Parts.Count > 0)
            {
                var partEntities = new List<ArchivalFileEntity>(exportResult.Parts.Count);

                foreach (var part in exportResult.Parts)
                {
                    ct.ThrowIfCancellationRequested();

                    // 'part' is ArchivalBlobInfo (returned by SourceExporter / ParquetExportService)
                    var blobPath = part.BlobPath;
                    var etag = part.ETag;
                    var contentType = part.ContentType;
                    var length = part.ContentLength;

                    var existing = await _archivalFileRepository.GetByBlobPathAsync(tableConfig.Id, blobPath, ct);
                    if (existing == null)
                    {
                        partEntities.Add(new ArchivalFileEntity
                        {
                            TableConfigurationId = tableConfig.Id,
                            AsOfDate = asOfDate.Date,
                            DateType = dateType,
                            StorageAccountName = tableConfig.StorageAccountName,
                            ContainerName = tableConfig.ContainerName,
                            BlobPath = blobPath,
                            Etag = etag,
                            ContentType = contentType,
                            FileSizeBytes = length,
                            RowCount = null,
                            Status = ArchivalFileStatus.Created,
                            CreatedAtEt = DateTime.UtcNow,
                            ArchivalPolicyTag = exportResult.AzurePolicyTag,
                            LastTagsSyncAtEt = DateTime.UtcNow
                        });
                    }
                    else
                    {
                        existing.Etag = etag;
                        existing.ContentType = contentType;
                        existing.FileSizeBytes = length;
                        existing.RowCount = existing.RowCount; // keep existing rowcount unless updated elsewhere
                        existing.ArchivalPolicyTag = exportResult.AzurePolicyTag;
                        existing.LastTagsSyncAtEt = DateTime.UtcNow;

                        partEntities.Add(existing);
                    }
                }

                if (partEntities.Count > 0)
                {
                    // Persist parts in bulk (insert/update)
                    await _archivalFileRepository.UpdateFilesAsync(partEntities, ct);
                }
            }

            // 5) Delete from source if configured and rows exported
            if (tableConfig.DeleteFromSource && (exportResult.Metrics?.RowCount > 0))
            {
                try
                {
                    await _sourceDataDeleter.DeleteAsync(
                        tableConfig,
                        asOfDate,
                        expectedRowCount: exportResult.Metrics!.RowCount,
                        runId: runId,
                        dateType: dateType,
                        ct: ct);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Delete-from-source failed for TableConfig {Id} on {Date}.", tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));

                    // Log failure but do not roll back export.
                    await _archivalRunRepository.LogDetailAsync(
                        runId,
                        tableConfig.Id,
                        asOfDate,
                        dateType,
                        RunDetailPhase.Delete,
                        RunDetailStatus.Failed,
                        rowsAffected: null,
                        filePath: representativePath,
                        errorMessage: ex.ToString(),
                        ct: ct);

                    throw;
                }
            }
            else if (!tableConfig.DeleteFromSource)
            {
                _logger.LogInformation("Delete-from-source disabled for TableConfig {Id}.", tableConfig.Id);
            }
            else
            {
                _logger.LogInformation("No rows exported for TableConfig {Id}, Date {Date}. Skipping delete-from-source.",
                    tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"));
            }

            // 6) Final run detail: success summary
            await _archivalRunRepository.LogDetailAsync(
                runId,
                tableConfig.Id,
                asOfDate,
                dateType,
                RunDetailPhase.Export,
                RunDetailStatus.Success,
                rowsAffected: exportResult.Metrics?.RowCount,
                filePath: representativePath,
                errorMessage: null,
                ct: ct);

            _logger.LogInformation("Archive completed for TableConfig {Id} date {Date}. Rows={Rows}.",
                tableConfig.Id, asOfDate.ToString("yyyy-MM-dd"), exportResult.Metrics?.RowCount ?? 0);
        }
    }
}