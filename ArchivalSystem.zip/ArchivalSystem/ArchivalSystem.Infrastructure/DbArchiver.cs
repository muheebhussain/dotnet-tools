﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure
{
    public class DbArchiver(
        IArchivalTableConfigurationRepository tableConfigRepository,
        IArchivalFileRepository archivalFileRepository,
        ISourceExporter sourceExporter,
        ISourceDataDeleter sourceDataDeleter,
        IArchivalRunRepository archivalRunRepository,
        ILogger<DbArchiver> logger)
        : IDbArchiver
    {
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly ISourceExporter _sourceExporter = sourceExporter ?? throw new ArgumentNullException(nameof(sourceExporter));
        private readonly ISourceDataDeleter _sourceDataDeleter = sourceDataDeleter ?? throw new ArgumentNullException(nameof(sourceDataDeleter));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILogger<DbArchiver> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task ArchiveTableForDateAsync(
            ArchivalTableConfigurationDto tableConfig,
            DateTime asOfDate,
            DateType dateType,
            long runId,
            CancellationToken ct = default)
        {

            if (tableConfig == null)
                throw new InvalidOperationException($"Table configuration not found.");

            if (tableConfig.ExportMode != ExportMode.SelfManaged)
                throw new InvalidOperationException(
                    $"Table configuration {tableConfig.Id} is not SelfManaged (ExportMode={tableConfig.ExportMode}).");

            _logger.LogInformation(
                "Archiving TableConfig {Id} ({Db}.{Schema}.{Table}) for {Date} ({DateType}).",
                tableConfig.Id,
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName,
                asOfDate.ToString("yyyy-MM-dd"),
                dateType);

            // If there is already an archival_file for this table/date, skip
            var exists = await _archivalFileRepository.ExistsForTableDateAsync(
                tableConfig.Id, asOfDate, dateType, ct);

            if (exists)
            {
                _logger.LogInformation(
                    "Archival file already exists for TableConfig {Id}, Date {Date}, skipping.",
                    tableConfig.Id,
                    asOfDate.ToString("yyyy-MM-dd"));

                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate,
                    dateType,
                    RunDetailPhase.Export,
                    RunDetailStatus.Skipped,
                    rowsAffected: null,
                    filePath: null,
                    errorMessage: "Archival file already exists.",
                    ct: ct);

                return;
            }


            // 1) Table-level exemption: skip everything
            var isTableExempt = await _archivalFileRepository.IsTableExemptAsync(
                tableConfig.Id, asOfDate, ct);

            if (isTableExempt)
            {
                _logger.LogInformation(
                    "Skipping archival for TableConfig {Id}, Date {Date} due to TABLE exemption.",
                    tableConfig.Id,
                    asOfDate.ToString("yyyy-MM-dd"));
                
                return;
            }

            // 2) Export source data → Parquet (streamed into blob).
            var exportResult = await _sourceExporter.ExportAsync(
                tableConfig,
                asOfDate,
                dateType,
                runId,
                ct);

            // 3) Register archival file row
            var archivalFile = new ArchivalFileEntity
            {
                TableConfigurationId = tableConfig.Id,
                AsOfDate = asOfDate.Date,
                DateType = dateType,
                StorageAccountName = tableConfig.StorageAccountName,
                ContainerName = tableConfig.ContainerName,
                BlobPath = exportResult.BlobInfo?.BlobPath ?? BlobStorageHelper.BuildBlobPath(tableConfig, asOfDate, dateType),
                Etag = exportResult.BlobInfo?.ETag,
                ContentType = exportResult.BlobInfo?.ContentType,
                FileSizeBytes = exportResult.BlobInfo?.ContentLength,
                RowCount = exportResult.Metrics?.RowCount > 0 ? exportResult.Metrics?.RowCount : null,
                Status = ArchivalFileStatus.Created,
                CreatedAtEt = DateTime.UtcNow,
                ArchivalPolicyTag = exportResult.AzurePolicyTag,
                CurrentAccessTier = null,
                LastTierCheckAtEt = null,
                OverrideFileLifecyclePolicyId = null,
                LastTagsSyncAtEt = DateTime.UtcNow
            };

            var savedFile = await _archivalFileRepository.UpsertFileAsync(archivalFile, ct);

            // 4) delete-from-source
            if (tableConfig.DeleteFromSource && (exportResult.Metrics?.RowCount > 0))
            {
                await _sourceDataDeleter.DeleteAsync(
                    tableConfig,
                    asOfDate,
                    expectedRowCount: exportResult.Metrics!.RowCount,
                    runId: runId,
                    dateType: dateType,
                    ct: ct);
            }
            else if (!tableConfig.DeleteFromSource)
            {
                _logger.LogInformation(
                    "Delete-from-source disabled for TableConfig {Id}.", tableConfig.Id);
            }
            else
            {
                _logger.LogInformation(
                    "No rows exported for TableConfig {Id}, Date {Date}. Skipping delete-from-source.",
                    tableConfig.Id,
                    asOfDate.ToString("yyyy-MM-dd"));
            }

            return;
        }
    }
}