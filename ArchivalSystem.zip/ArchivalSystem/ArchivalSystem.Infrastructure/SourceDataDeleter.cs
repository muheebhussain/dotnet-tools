﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure;

public class SourceDataDeleter(
    ITargetTableRepository targetTableRepository,
    IArchivalRunRepository archivalRunRepository,
    ILogger<SourceDataDeleter> logger)
    : ISourceDataDeleter
{
    private readonly ITargetTableRepository _targetTableRepository = targetTableRepository ?? throw new ArgumentNullException(nameof(targetTableRepository));
    private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
    private readonly ILogger<SourceDataDeleter> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    private const int DeleteBatchSize = 50_000;

    public async Task<long> DeleteAsync(
        ArchivalTableConfigurationDto tableConfig,
        DateTime asOfDate,
        long expectedRowCount,
        long runId,
        DateType dateType,
        CancellationToken ct = default)
    {

        ArgumentNullException.ThrowIfNull(tableConfig);
        if (string.IsNullOrWhiteSpace(tableConfig.AsOfDateColumn))
            throw new InvalidOperationException($"Table configuration {tableConfig.Id} has no as_of_date_column defined.");

        var totalDeleted = await _targetTableRepository.DeleteByAsOfDateAsync(
            tableConfig.DatabaseName,
            tableConfig.SchemaName,
            tableConfig.TableName,
            tableConfig.AsOfDateColumn!,
            asOfDate,
            DeleteBatchSize,
            ct);

        string? error = null;
        if (expectedRowCount > 0 && totalDeleted != expectedRowCount)
        {
            _logger.LogWarning(
                "Delete-from-source row count mismatch for TableConfig {Id}, Date {Date}: expected {Expected}, deleted {Deleted}.",
                tableConfig.Id,
                asOfDate.ToString("yyyy-MM-dd"),
                expectedRowCount,
                totalDeleted);

            error = $"Row count mismatch: expected={expectedRowCount}, deleted={totalDeleted}.";
        }

        await _archivalRunRepository.LogDetailAsync(
            runId,
            tableConfig.Id,
            asOfDate,
            dateType,
            RunDetailPhase.Delete,
            RunDetailStatus.Success,
            rowsAffected: totalDeleted,
            filePath: null,
            errorMessage: error,
            ct: ct);

        return totalDeleted;
    }
}