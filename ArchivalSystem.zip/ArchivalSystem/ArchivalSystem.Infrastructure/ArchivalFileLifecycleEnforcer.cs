﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArchivalSystem.Application.Models;

namespace ArchivalSystem.Infrastructure
{
    public sealed class ArchivalFileLifecycleEnforcer(
       IArchivalFileRepository fileRepository,
       IArchivalTableConfigurationRepository tableConfigRepository,
       IArchivalFileLifecyclePolicyRepository policyRepository,
       IBlobStorageService blobStorage,
       IArchivalRunRepository runRepository,
       ILogger<ArchivalFileLifecycleEnforcer> logger,
       IClock clock,
       int degreeOfParallelism = 8,
       TimeSpan? minAgeBetweenTierChecks = null)
    {
        private readonly IArchivalFileRepository _fileRepository = fileRepository ?? throw new ArgumentNullException(nameof(fileRepository));
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileLifecyclePolicyRepository _policyRepository = policyRepository ?? throw new ArgumentNullException(nameof(policyRepository));
        private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
        private readonly IArchivalRunRepository _runRepository = runRepository ?? throw new ArgumentNullException(nameof(runRepository));
        private readonly ILogger<ArchivalFileLifecycleEnforcer> _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        private readonly IClock _clock = clock ?? throw new ArgumentNullException(nameof(clock));

        // Tunables
        private readonly int _degreeOfParallelism = Math.Max(1, degreeOfParallelism);
        private readonly TimeSpan _minAgeBetweenTierChecks = minAgeBetweenTierChecks ?? TimeSpan.FromDays(1);

        /// <summary>
        /// Enforce lifecycle actions for all files in the given storage account.
        /// If containerName or prefix is provided, the scope is narrowed.
        /// dryRun = true will not apply blob changes, only log actions and return counts.
        /// </summary>
        public async Task<LifecycleEnforcerResult> EnforceAsync(
            string storageAccountName,
            string? containerName = null,
            string? prefix = null,
            bool dryRun = false,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(storageAccountName)) throw new ArgumentNullException(nameof(storageAccountName));

            _logger.LogInformation("Starting lifecycle enforcement for account='{Account}' container='{Container}' prefix='{Prefix}' (dryRun={DryRun})",
                storageAccountName, containerName ?? "*", prefix ?? "*", dryRun);

            var candidates = await _fileRepository.GetFilesForStorageAccountAsync(
                storageAccountName,
                containerName,
                prefix,
                asTracking: false,
                pageSize: 5000,
                minAgeBetweenTierChecks: _minAgeBetweenTierChecks,
                ct: ct);

            if (candidates == null || candidates.Count == 0)
            {
                _logger.LogInformation("No archival files found for enforcement (account={Account}, container={Container}, prefix={Prefix}).",
                    storageAccountName, containerName ?? "(any)", prefix ?? "(any)");
                return new LifecycleEnforcerResult(0, 0, 0);
            }

            // Preload table configurations referenced by files to avoid per-file DB hits
            var tableConfigIds = candidates.Select(f => f.TableConfigurationId).Distinct().ToList();
            var tableConfigs = new Dictionary<int, ArchivalTableConfigurationEntity>();
            foreach (var tid in tableConfigIds)
            {
                var cfg = await _tableConfigRepository.GetWithRelatedAsync(tid, ct);
                if (cfg != null) tableConfigs[tid] = cfg;
            }

            // Collect override policy ids to fetch in bulk
            var overridePolicyIds = candidates.Where(f => f.OverrideFileLifecyclePolicyId.HasValue)
                                              .Select(f => f.OverrideFileLifecyclePolicyId!.Value)
                                              .Distinct()
                                              .ToList();

            var overridePolicies = overridePolicyIds.Count > 0
                ? await _policyRepository.GetByIdsAsync(overridePolicyIds, ct)
                : new Dictionary<int, ArchivalFileLifecyclePolicyEntity>();

            // Use clock for "now" values (Eastern per IClock implementation)
            var nowOffset = _clock.Now;            // DateTimeOffset in Eastern
            var today = _clock.Today;              // DateOnly in Eastern

            var modifiedFiles = new List<ArchivalFileEntity>();
            var runDetails = new List<ArchivalRunDetailEntity>();

            var counters = new LifecycleCounters();

            // Process candidates in parallel with bounded concurrency.
            await Parallel.ForEachAsync(candidates, new ParallelOptions { MaxDegreeOfParallelism = _degreeOfParallelism, CancellationToken = ct }, async (file, token) =>
            {
                try
                {
                    token.ThrowIfCancellationRequested();

                    // Skip deleted/invalid status
                    if (file.Status == ArchivalFileStatus.Deleted)
                        return;

                    // Cheap skip: if we checked recently, skip
                    if (file.LastTierCheckAtEt.HasValue && (nowOffset.UtcDateTime - file.LastTierCheckAtEt.Value) < _minAgeBetweenTierChecks)
                    {
                        return;
                    }

                    // Resolve lifecycle policy (override first, else table config)
                    ArchivalFileLifecyclePolicyEntity? policy = null;
                    if (file.OverrideFileLifecyclePolicyId.HasValue)
                    {
                        overridePolicies.TryGetValue(file.OverrideFileLifecyclePolicyId.Value, out policy);
                    }

                    if (policy == null)
                    {
                        if (tableConfigs.TryGetValue(file.TableConfigurationId, out var cfg))
                        {
                            policy = cfg.FileLifecyclePolicy;
                        }
                    }

                    if (policy == null)
                    {
                        lock (runDetails)
                        {
                            runDetails.Add(CreateRunDetail(nowOffset.UtcDateTime, file, RunDetailPhase.Lifecycle, RunDetailStatus.Failed, "No lifecycle policy resolved"));
                        }
                        counters.Failed++;
                        return;
                    }

                    // Determine thresholds for this file's dateType
                    var (coolDays, archiveDays, deleteDays) = GetThresholdsForPolicy(policy, file.DateType);

                    // Determine the base date to compute age (use DateOnly for consistent date math in Eastern)
                    var baseDate = file.AsOfDate.HasValue
                        ? DateOnly.FromDateTime(file.AsOfDate.Value)
                        : DateOnly.FromDateTime(file.CreatedAtEt.ToUniversalTime());

                    // ageDays as integer days between Eastern today and baseDate
                    var ageDays = today.DayNumber - baseDate.DayNumber;

                    // Decide action
                    bool shouldDelete = deleteDays.HasValue && ageDays >= deleteDays.Value;
                    string? targetTier = null;
                    if (!shouldDelete)
                    {
                        if (archiveDays.HasValue && ageDays >= archiveDays.Value) targetTier = "Archive";
                        else if (coolDays.HasValue && ageDays >= coolDays.Value) targetTier = "Cool";
                    }

                    // Perform action (or dry-run)
                    if (shouldDelete)
                    {
                        if (!dryRun)
                        {
                            try
                            {
                                await _blobStorage.DeleteIfExistsAsync(file.StorageAccountName, file.ContainerName, file.BlobPath, token);
                                file.Status = ArchivalFileStatus.Deleted;
                            }
                            catch (Exception ex)
                            {
                                lock (runDetails)
                                {
                                    runDetails.Add(CreateRunDetail(nowOffset.UtcDateTime, file, RunDetailPhase.Lifecycle, RunDetailStatus.Failed, ex.ToString()));
                                }
                                counters.Failed++;
                                return;
                            }
                        }

                        file.LastTierCheckAtEt = nowOffset.UtcDateTime;
                        lock (modifiedFiles) modifiedFiles.Add(file);

                        lock (runDetails)
                        {
                            runDetails.Add(CreateRunDetail(nowOffset.UtcDateTime, file, RunDetailPhase.Lifecycle, RunDetailStatus.Success, shouldDelete ? "Deleted (or dry-run)" : "Dry-run delete"));
                        }

                        counters.Deleted++;
                        return;
                    }

                    if (targetTier != null)
                    {
                        // set access tier if different (or always if dry-run)
                        if (!dryRun)
                        {
                            try
                            {
                                // Use blob storage abstraction to set access tier
                                await _blobStorage.SetAccessTierAsync(file.StorageAccountName, file.ContainerName, file.BlobPath, targetTier, token);
                                file.CurrentAccessTier = targetTier;
                            }
                            catch (Exception ex)
                            {
                                lock (runDetails)
                                {
                                    runDetails.Add(CreateRunDetail(nowOffset.UtcDateTime, file, RunDetailPhase.Lifecycle, RunDetailStatus.Failed, ex.ToString()));
                                }
                                counters.Failed++;
                                return;
                            }
                        }

                        file.LastTierCheckAtEt = nowOffset.UtcDateTime;
                        lock (modifiedFiles) modifiedFiles.Add(file);

                        lock (runDetails)
                        {
                            runDetails.Add(CreateRunDetail(nowOffset.UtcDateTime, file, RunDetailPhase.Lifecycle, RunDetailStatus.Success, $"SetTier={targetTier} (or dry-run)"));
                        }

                        counters.Tiered++;
                        return;
                    }

                    // Nothing to do: update LastTierCheckAtEt to avoid re-evaluating immediately
                    file.LastTierCheckAtEt = nowOffset.UtcDateTime;
                    lock (modifiedFiles)
                        modifiedFiles.Add(file);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unhandled exception while enforcing lifecycle for file {Path}", file.BlobPath);
                    lock (runDetails)
                    {
                        runDetails.Add(CreateRunDetail(DateTime.UtcNow, file, RunDetailPhase.Lifecycle, RunDetailStatus.Failed, ex.ToString()));
                    }
                    counters.Failed++;
                }
            });

            // Persist changes in bulk
            if (modifiedFiles.Count > 0)
            {
                // Use repository bulk update for efficiency
                await _fileRepository.UpdateFilesAsync(modifiedFiles, ct);
            }

            if (runDetails.Count > 0)
            {
                await _runRepository.ArchivalRunDetailBulkInsertAsync(runDetails, ct);
            }

            _logger.LogInformation("Lifecycle enforcement completed for account={Account}. Tiered={Tiered}, Deleted={Deleted}, Failed={Failed}",
                storageAccountName, counters.Tiered, counters.Deleted, counters.Failed);

            return new LifecycleEnforcerResult(counters.Tiered, counters.Deleted, counters.Failed);
        }

        private static (int? cool, int? archive, int? delete) GetThresholdsForPolicy(ArchivalFileLifecyclePolicyEntity policy, DateType? dateType)
        {
            // Map dateType to corresponding fields
            switch (dateType)
            {
                case DateType.EOD:
                    return (policy.EodCoolDays, policy.EodArchiveDays, policy.EodDeleteDays);
                case DateType.EOM:
                    return (policy.EomCoolDays, policy.EomArchiveDays, policy.EomDeleteDays);
                case DateType.EOQ:
                    return (policy.EoqCoolDays, policy.EoqArchiveDays, policy.EoqDeleteDays);
                case DateType.EOY:
                    return (policy.EoyCoolDays, policy.EoyArchiveDays, policy.EoyDeleteDays);
                case DateType.EXT:
                default:
                    return (policy.ExternalCoolDays, policy.ExternalArchiveDays, policy.ExternalDeleteDays);
            }
        }

        private static ArchivalRunDetailEntity CreateRunDetail(DateTime now, ArchivalFileEntity file, RunDetailPhase phase, RunDetailStatus status, string? message)
            => new()
            {
                RunId = 0, // caller can supply run id context if desired
                TableConfigurationId = file.TableConfigurationId,
                AsOfDate = file.AsOfDate,
                DateType = file.DateType,
                Phase = phase,
                Status = status,
                ArchivalFileId = file.Id,
                FilePath = file.BlobPath,
                ErrorMessage = message,
                CreatedAtEt = now
            };

        private sealed class LifecycleCounters
        {
            public int Tiered;
            public int Deleted;
            public int Failed;
        }
    }
}
