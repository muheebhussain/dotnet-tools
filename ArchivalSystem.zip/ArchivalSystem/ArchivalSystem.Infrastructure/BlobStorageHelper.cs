﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure;

public static class BlobStorageHelper
{
    public static string BuildBlobPath(
        ArchivalTableConfigurationDto config,
        DateTime asOfDate,
        DateType dateType)
    {
        var path = config.ArchivePathTemplate;

        path = path.Replace("{db}", config.DatabaseName);
        path = path.Replace("{schema}", config.SchemaName);
        path = path.Replace("{table}", config.TableName);
        path = path.Replace("{date_type}", dateType.ToString());
        path = path.Replace("{yyyy}", asOfDate.ToString("yyyy"));
        path = path.Replace("{MM}", asOfDate.ToString("MM"));
        path = path.Replace("{dd}", asOfDate.ToString("dd"));

        return path.TrimStart('/');
    }
}