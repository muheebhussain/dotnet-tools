﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Infrastructure;

public interface IExternalFileGrouper
{
    IEnumerable<IGrouping<string, ArchivalBlobInfo>> GroupByLogicalKey(IEnumerable<ArchivalBlobInfo> blobs);
    (DateTime? asOfDate, DateType? dateType) ParseDateFromPath(string blobPath);
}
public sealed class ExternalFileGrouper : IExternalFileGrouper
{
    public IEnumerable<IGrouping<string, ArchivalBlobInfo>> GroupByLogicalKey(IEnumerable<ArchivalBlobInfo> blobs)
        => blobs.GroupBy(b => GetLogicalGroupKey(b.BlobPath), StringComparer.Ordinal);

    public (DateTime? asOfDate, DateType? dateType) ParseDateFromPath(string blobPath)
    {
        if (string.IsNullOrWhiteSpace(blobPath)) return (null, null);
        var parts = blobPath.Split(new[] { '/', '\\' }, StringSplitOptions.RemoveEmptyEntries);

        for (int i = 0; i < parts.Length; i++)
        {
            if (i + 2 < parts.Length &&
                parts[i].Length == 4 && parts[i + 1].Length == 2 && parts[i + 2].Length == 2 &&
                int.TryParse(parts[i], out var y) &&
                int.TryParse(parts[i + 1], out var m) &&
                int.TryParse(parts[i + 2], out var d))
            {
                try { return (new DateTime(y, m, d), DateType.EXT); } catch { }
            }

            var seg = parts[i];
            if (seg.Length == 10 && seg[4] == '-' && seg[7] == '-')
            {
                if (DateTime.TryParseExact(seg, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out var dt))
                    return (dt, DateType.EXT);
            }
        }

        return (null, null);
    }

    private static string GetLogicalGroupKey(string blobPath)
    {
        if (string.IsNullOrWhiteSpace(blobPath)) return string.Empty;
        var parts = blobPath.Split(new[] { '/', '\\' }, StringSplitOptions.RemoveEmptyEntries);

        for (int i = 0; i < parts.Length; i++)
        {
            var seg = parts[i];

            if (seg.Length == 10 && seg[4] == '-' && seg[7] == '-')
                return string.Join('/', parts.Take(i + 1));

            if (i + 2 < parts.Length &&
                parts[i].Length == 4 && parts[i + 1].Length == 2 && parts[i + 2].Length == 2 &&
                int.TryParse(parts[i], out _) &&
                int.TryParse(parts[i + 1], out _) &&
                int.TryParse(parts[i + 2], out _))
            {
                return string.Join('/', parts.Take(i + 3));
            }
        }

        var idx = blobPath.LastIndexOf('/');
        return idx > 0 ? blobPath.Substring(0, idx) : blobPath;
    }
}