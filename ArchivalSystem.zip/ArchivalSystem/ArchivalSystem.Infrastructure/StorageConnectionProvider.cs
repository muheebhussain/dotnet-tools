﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using Microsoft.Extensions.Options;

/// <summary>
/// Simple IStorageConnectionProvider backed by BlobStorageOptions (configuration).
/// </summary>
public class StorageConnectionProvider(IOptions<BlobStorageOptions> options) : IStorageConnectionProvider
{
    private readonly BlobStorageOptions _options = options?.Value ?? throw new ArgumentNullException(nameof(options));

    public string GetConnectionString(string storageAccountName)
    {
        if (string.IsNullOrWhiteSpace(storageAccountName))
            throw new ArgumentNullException(nameof(storageAccountName));

        var acct = _options.Accounts?
            .FirstOrDefault(a => a.StorageAccountName.Equals(storageAccountName, StringComparison.OrdinalIgnoreCase));

        if (acct == null || string.IsNullOrWhiteSpace(acct.ConnectionString))
            throw new InvalidOperationException($"No connection string configured for storage account '{storageAccountName}'.");

        return acct.ConnectionString;
    }
}