﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Infrastructure
{
    public interface IBlobTagSynchronizer
    {
        Task<int> SyncTagsForTableAsync(
            int tableConfigurationId,
            CancellationToken ct = default);

        Task<int> SyncTagsForFileAsync(
            long archivalFileId,
            CancellationToken ct = default);
    }

    public class BlobTagSynchronizer(
        IArchivalFileRepository archivalFileRepository,
        IArchivalTableConfigurationRepository tableConfigRepository,
        IArchivalFileLifecyclePolicyRepository filePolicyRepository,
        IBlobStorageService blobStorage,
        ILifecyclePolicyResolver lifecyclePolicyResolver)
        : IBlobTagSynchronizer
    {
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileLifecyclePolicyRepository _filePolicyRepository = filePolicyRepository ?? throw new ArgumentNullException(nameof(filePolicyRepository));
        private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
        private readonly ILifecyclePolicyResolver _lifecyclePolicyResolver = lifecyclePolicyResolver ?? throw new ArgumentNullException(nameof(lifecyclePolicyResolver));

        public async Task<int> SyncTagsForTableAsync(
            int tableConfigurationId,
            CancellationToken ct = default)
        {
            // 0) Load table config + default file lifecycle policy once
            var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(tableConfigurationId, ct);
            if (tableConfig == null) throw new InvalidOperationException($"Table configuration {tableConfigurationId} not found.");
            var tablePolicy = tableConfig.FileLifecyclePolicy;

            // 1) Load files (no tracking) for table
            var files = await _archivalFileRepository.GetByTableConfigurationIdAsync(tableConfigurationId, asTracking: false, ct);

            if (!files.Any()) return 0;

            // 2) Collect override policy ids and distinct AsOfDates for exemption lookup
            var overridePolicyIds = files
                .Where(f => f.OverrideFileLifecyclePolicyId.HasValue)
                .Select(f => f.OverrideFileLifecyclePolicyId!.Value)
                .Distinct()
                .ToList();

            var asOfDates = files
                .Where(f => f.AsOfDate.HasValue)
                .Select(f => DateOnly.FromDateTime(f.AsOfDate!.Value))
                .Distinct()
                .ToList();

            // 3) Fetch override policies in one shot
            var overridePolicies = await _filePolicyRepository.GetByIdsAsync(overridePolicyIds, ct);

            // 4) Fetch file-scoped exemptions for these dates in one shot
            var exemptDates = await _archivalFileRepository.GetFileExemptionDatesAsync(tableConfigurationId, asOfDates, ct);

            var now = DateTime.UtcNow;
            var modifiedFiles = new List<ArchivalFileEntity>();
            var count = 0;

            foreach (var file in files)
            {
                ct.ThrowIfCancellationRequested();

                // Determine policy: override if present, otherwise table policy
                ArchivalFileLifecyclePolicyEntity? policy = null;
                if (file.OverrideFileLifecyclePolicyId.HasValue)
                {
                    overridePolicies.TryGetValue(file.OverrideFileLifecyclePolicyId!.Value, out policy);
                    if (policy == null)
                    {
                        // fallback: if override not found, try table policy
                        policy = tablePolicy;
                    }
                }
                else
                {
                    policy = tablePolicy;
                }

                var azurePolicyTag = policy?.AzurePolicyTag;

                // Determine exemption from pre-fetched set
                var isFileExempt = file.AsOfDate.HasValue && exemptDates.Contains(DateOnly.FromDateTime(file.AsOfDate!.Value));

                // Build tags and set on blob
                var tags = new Dictionary<string, string>
                {
                    ["archival_table_configuration_id"] = file.TableConfigurationId.ToString(),
                    ["archival_policy"] = azurePolicyTag ?? string.Empty,
                    ["archival_exempt"] = isFileExempt ? "true" : "false"
                };

                if (file.AsOfDate.HasValue)
                    tags["archival_date"] = file.AsOfDate.Value.ToString("yyyy-MM-dd");

                if (file.DateType.HasValue)
                    tags["archival_date_type"] = file.DateType.Value.ToString();

                await _blobStorage.SetTagsAsync(
                    file.StorageAccountName,
                    file.ContainerName,
                    file.BlobPath,
                    tags,
                    ct);

                // update entity fields locally
                file.ArchivalPolicyTag = azurePolicyTag;
                file.LastTagsSyncAtEt = now;

                modifiedFiles.Add(file);
                count++;
            }

            // Persist updates in grouped bulk sets
            if (modifiedFiles.Count > 0)
            {
                var groups = modifiedFiles.GroupBy(f => f.ArchivalPolicyTag, StringComparer.Ordinal).ToList();
                foreach (var g in groups)
                {
                    var ids = g.Select(f => f.Id).ToList();
                    var tag = g.Key;
                    await _archivalFileRepository.BulkSetTagsAndSyncTimeAsync(ids, tag, now, ct);
                }
            }

            return count;
        }

        public async Task<int> SyncTagsForFileAsync(
            long archivalFileId,
            CancellationToken ct = default)
        {
            var entity = await _archivalFileRepository.GetByIdAsync(archivalFileId, ct);

            if (entity == null) return 0;

            var updated = await SyncTagsForFileInternalAsync(entity, ct);

            if (updated)
            {
                await _archivalFileRepository.UpsertFileAsync(entity, ct);
            }

            return updated ? 1 : 0;
        }

        private async Task<bool> SyncTagsForFileInternalAsync(
            ArchivalFileEntity file,
            CancellationToken ct)
        {
            ArgumentNullException.ThrowIfNull(file);

            // Determine lifecycle policy: try override, else table policy (reuse same approach as bulk path)
            ArchivalFileLifecyclePolicyEntity? policy = null;
            if (file.OverrideFileLifecyclePolicyId.HasValue)
            {
                policy = await _filePolicyRepository.GetByIdAsync(file.OverrideFileLifecyclePolicyId.Value, ct);
            }

            if (policy == null)
            {
                var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(file.TableConfigurationId, ct);
                if (tableConfig == null)
                    throw new InvalidOperationException($"Table configuration {file.TableConfigurationId} not found for file {file.Id}.");

                policy = tableConfig.FileLifecyclePolicy
                         ?? throw new InvalidOperationException(
                             $"File lifecycle policy {tableConfig.FileLifecyclePolicyId} not found for table configuration {tableConfig.Id}.");
            }

            var azurePolicyTag = policy?.AzurePolicyTag;

            // Check exemption
            bool isFileExempt = false;
            if (file.AsOfDate.HasValue)
            {
                isFileExempt = await _archivalFileRepository.IsFileExemptAsync(file.TableConfigurationId, file.AsOfDate.Value.Date, ct);
            }

            var tags = new Dictionary<string, string>
            {
                ["archival_table_configuration_id"] = file.TableConfigurationId.ToString(),
                ["archival_policy"] = azurePolicyTag ?? string.Empty,
                ["archival_exempt"] = isFileExempt ? "true" : "false"
            };

            if (file.AsOfDate.HasValue)
                tags["archival_date"] = file.AsOfDate.Value.ToString("yyyy-MM-dd");

            if (file.DateType.HasValue)
                tags["archival_date_type"] = file.DateType.Value.ToString();

            await _blobStorage.SetTagsAsync(
                file.StorageAccountName,
                file.ContainerName,
                file.BlobPath,
                tags,
                ct);

            // update tracked entity fields
            file.ArchivalPolicyTag = azurePolicyTag;
            file.LastTagsSyncAtEt = DateTime.UtcNow;

            return true;
        }
    }
}
