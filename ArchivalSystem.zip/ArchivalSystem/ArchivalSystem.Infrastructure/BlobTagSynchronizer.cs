﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Infrastructure
{
    public interface IBlobTagSynchronizer
    {
        Task<int> SyncTagsForTableAsync(
            int tableConfigurationId,
            CancellationToken ct = default);

        Task<int> SyncTagsForFileAsync(
            long archivalFileId,
            CancellationToken ct = default);
    }

    public class BlobTagSynchronizer(
        IArchivalFileRepository archivalFileRepository,
        IArchivalRunRepository archivalRunRepository,
        IArchivalTableConfigurationRepository tableConfigRepository,
        IArchivalFileLifecyclePolicyRepository filePolicyRepository,
        IBlobStorageService blobStorage,
        ILifecyclePolicyResolver lifecyclePolicyResolver)
        : IBlobTagSynchronizer
    {
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileLifecyclePolicyRepository _filePolicyRepository = filePolicyRepository ?? throw new ArgumentNullException(nameof(filePolicyRepository));
        private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
        private readonly ILifecyclePolicyResolver _lifecyclePolicyResolver = lifecyclePolicyResolver ?? throw new ArgumentNullException(nameof(lifecyclePolicyResolver));

        // Skip tagging files that were synced recently to reduce repeated work.
        // Tune as appropriate for your environment.
        private static readonly TimeSpan DefaultSkipIfSyncedWithin = TimeSpan.FromHours(1);

        // Default parallelism for tagging operations
        private const int DefaultDegreeOfParallelism = 16;

        public async Task<int> SyncTagsForTableAsync(
            int tableConfigurationId,
            CancellationToken ct = default)
        {
            var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(tableConfigurationId, ct);
            if (tableConfig == null) throw new InvalidOperationException($"Table configuration {tableConfigurationId} not found.");
            var tablePolicy = tableConfig.FileLifecyclePolicy;

            // load files for table (no tracking)
            var files = await _archivalFileRepository.GetByTableConfigurationIdAsync(tableConfigurationId, asTracking: false, ct);
            if (!files.Any()) return 0;

            // collect override ids and distinct as-of dates
            var overridePolicyIds = files
                .Where(f => f.OverrideFileLifecyclePolicyId.HasValue)
                .Select(f => f.OverrideFileLifecyclePolicyId!.Value)
                .Distinct()
                .ToList();

            var asOfDates = files
                .Where(f => f.AsOfDate.HasValue)
                .Select(f => DateOnly.FromDateTime(f.AsOfDate!.Value))
                .Distinct()
                .ToList();

            // fetch override policies
            var overridePolicies = await _filePolicyRepository.GetByIdsAsync(overridePolicyIds, ct);

            // fetch file-scoped exemptions
            var exemptDates = await _archivalFileRepository.GetFileExemptionDatesAsync(tableConfigurationId, asOfDates, ct);

            var now = DateTime.UtcNow;
            var modifiedFiles = new List<ArchivalFileEntity>();
            var runDetails = new List<ArchivalRunDetailEntity>();

            // Build list of work items (file + tags) to process in parallel
            var workItems = new List<(ArchivalFileEntity file, IDictionary<string, string> tags)>(files.Count);

            foreach (var file in files)
            {
                ct.ThrowIfCancellationRequested();

                // Skip if recently synced (cheap heuristic)
                if (file.LastTagsSyncAtEt.HasValue && (now - file.LastTagsSyncAtEt.Value) < DefaultSkipIfSyncedWithin)
                    continue;

                // Determine policy: override if present, otherwise table policy
                ArchivalFileLifecyclePolicyEntity? policy = null;
                if (file.OverrideFileLifecyclePolicyId.HasValue)
                {
                    overridePolicies.TryGetValue(file.OverrideFileLifecyclePolicyId!.Value, out policy);
                    policy ??= tablePolicy;
                }
                else
                {
                    policy = tablePolicy;
                }

                var azurePolicyTag = policy?.AzurePolicyTag;

                // Determine exemption
                var isFileExempt = file.AsOfDate.HasValue && exemptDates.Contains(DateOnly.FromDateTime(file.AsOfDate!.Value));

                // Build tags
                var tags = new Dictionary<string, string>
                {
                    ["archival_table_configuration_id"] = file.TableConfigurationId.ToString(),
                    ["archival_policy"] = azurePolicyTag ?? string.Empty,
                    ["archival_exempt"] = isFileExempt ? "true" : "false"
                };

                if (file.AsOfDate.HasValue)
                    tags["archival_date"] = file.AsOfDate.Value.ToString("yyyy-MM-dd");

                if (file.DateType.HasValue)
                    tags["archival_date_type"] = file.DateType.Value.ToString();

                workItems.Add((file, tags));
            }

            // Perform tagging in parallel with bounded concurrency and basic retries.
            var successCount = await SetTagsConcurrentlyAsync(workItems, DefaultDegreeOfParallelism, runDetails, modifiedFiles, now, tableConfigurationId, ct);

            // Persist LastTagsSyncAtEt / ArchivalPolicyTag for DB-known files in grouped bulk updates
            if (modifiedFiles.Count > 0)
            {
                var groups = modifiedFiles.GroupBy(f => f.ArchivalPolicyTag, StringComparer.Ordinal).ToList();
                foreach (var g in groups)
                {
                    var ids = g.Select(f => f.Id).ToList();
                    var tag = g.Key;
                    await _archivalFileRepository.BulkSetTagsAndSyncTimeAsync(ids, tag, now, ct);
                }
            }

            // Persist run details (successful and failed)
            if (runDetails.Count > 0)
            {
                await _archivalRunRepository.ArchivalRunDetailBulkInsertAsync(runDetails, ct);
            }

            return successCount;
        }

        public async Task<int> SyncTagsForFileAsync(
            long archivalFileId,
            CancellationToken ct = default)
        {
            var file = await _archivalFileRepository.GetByIdAsync(archivalFileId, ct);
            if (file == null) return 0;

            var updated = await SyncTagsForFileInternalAsync(file, ct);

            if (updated)
            {
                await _archivalFileRepository.UpsertFileAsync(file, ct);
            }

            return updated ? 1 : 0;
        }

        private async Task<bool> SyncTagsForFileInternalAsync(
            ArchivalFileEntity file,
            CancellationToken ct)
        {
            ArgumentNullException.ThrowIfNull(file);

            // determine policy
            ArchivalFileLifecyclePolicyEntity? policy = null;
            if (file.OverrideFileLifecyclePolicyId.HasValue)
            {
                policy = await _filePolicyRepository.GetByIdAsync(file.OverrideFileLifecyclePolicyId.Value, ct);
            }

            if (policy == null)
            {
                var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(file.TableConfigurationId, ct);
                if (tableConfig == null) throw new InvalidOperationException($"Table configuration {file.TableConfigurationId} not found for file {file.Id}.");
                policy = tableConfig.FileLifecyclePolicy ?? throw new InvalidOperationException($"File lifecycle policy {tableConfig.FileLifecyclePolicyId} not found for table configuration {tableConfig.Id}.");
            }

            var azurePolicyTag = policy?.AzurePolicyTag;

            // check exemption
            var isFileExempt = false;
            if (file.AsOfDate.HasValue)
            {
                isFileExempt = await _archivalFileRepository.IsFileExemptAsync(file.TableConfigurationId, file.AsOfDate.Value.Date, ct);
            }

            var tags = new Dictionary<string, string>
            {
                ["archival_table_configuration_id"] = file.TableConfigurationId.ToString(),
                ["archival_policy"] = azurePolicyTag ?? string.Empty,
                ["archival_exempt"] = isFileExempt ? "true" : "false"
            };

            if (file.AsOfDate.HasValue)
                tags["archival_date"] = file.AsOfDate.Value.ToString("yyyy-MM-dd");

            if (file.DateType.HasValue)
                tags["archival_date_type"] = file.DateType.Value.ToString();

            await _blobStorage.SetTagsAsync(file.StorageAccountName, file.ContainerName, file.BlobPath, tags, ct);

            file.ArchivalPolicyTag = azurePolicyTag;
            file.LastTagsSyncAtEt = DateTime.UtcNow;

            return true;
        }

        // Parallel tagging helper with simple retry and thread-safe collection updates.
        // This version uses local heuristics only (LastTagsSyncAtEt + ETag) to skip tags that likely don't need updating.
        private async Task<int> SetTagsConcurrentlyAsync(
            IEnumerable<(ArchivalFileEntity file, IDictionary<string, string> tags)> items,
            int degreeOfParallelism,
            List<ArchivalRunDetailEntity> runDetails,
            List<ArchivalFileEntity> modifiedFiles,
            DateTime now,
            int tableConfigurationId,
            CancellationToken ct)
        {
            if (items == null) return 0;
            degreeOfParallelism = Math.Max(1, degreeOfParallelism);

            var successCount = 0;
            var sync = new object();

            await Parallel.ForEachAsync(items, new ParallelOptions { MaxDegreeOfParallelism = degreeOfParallelism, CancellationToken = ct }, async (item, token) =>
            {
                var file = item.file;
                var tags = item.tags;

                // Cheap heuristic: if recently synced and ETag unchanged, skip setting tags.
                if (file.LastTagsSyncAtEt.HasValue && (now - file.LastTagsSyncAtEt.Value) < DefaultSkipIfSyncedWithin && !string.IsNullOrEmpty(file.Etag))
                {
                    // If we have a blob ETag in DB and haven't seen changes since last sync, assume tags are current.
                    lock (sync)
                    {
                        runDetails.Add(new ArchivalRunDetailEntity
                        {
                            RunId = 0,
                            TableConfigurationId = tableConfigurationId,
                            AsOfDate = file.AsOfDate,
                            DateType = file.DateType,
                            Phase = RunDetailPhase.Lifecycle,
                            Status = RunDetailStatus.Success,
                            ArchivalFileId = file.Id,
                            FilePath = file.BlobPath,
                            ErrorMessage = "Skipped (recently synced, ETag unchanged)",
                            CreatedAtEt = now
                        });
                    }

                    return;
                }

                var attempts = 0;
                var succeeded = false;
                Exception? lastEx = null;

                while (attempts < 3 && !succeeded)
                {
                    attempts++;
                    try
                    {
                        token.ThrowIfCancellationRequested();
                        await _blobStorage.SetTagsAsync(file.StorageAccountName, file.ContainerName, file.BlobPath, tags, token);
                        succeeded = true;
                    }
                    catch (Exception ex)
                    {
                        lastEx = ex;
                        if (attempts < 3)
                            await Task.Delay(TimeSpan.FromSeconds(2 * attempts), token);
                    }
                }

                lock (sync)
                {
                    if (succeeded)
                    {
                        // mark for DB update
                        file.ArchivalPolicyTag = tags.TryGetValue("archival_policy", out var t) ? t : file.ArchivalPolicyTag;
                        file.LastTagsSyncAtEt = now;
                        modifiedFiles.Add(file);

                        runDetails.Add(new ArchivalRunDetailEntity
                        {
                            RunId = 0,
                            TableConfigurationId = tableConfigurationId,
                            AsOfDate = file.AsOfDate,
                            DateType = file.DateType,
                            Phase = RunDetailPhase.Lifecycle,
                            Status = RunDetailStatus.Success,
                            ArchivalFileId = file.Id,
                            FilePath = file.BlobPath,
                            ErrorMessage = null,
                            CreatedAtEt = now
                        });

                        successCount++;
                    }
                    else
                    {
                        runDetails.Add(new ArchivalRunDetailEntity
                        {
                            RunId = 0,
                            TableConfigurationId = tableConfigurationId,
                            AsOfDate = file.AsOfDate,
                            DateType = file.DateType,
                            Phase = RunDetailPhase.Lifecycle,
                            Status = RunDetailStatus.Failed,
                            ArchivalFileId = file.Id,
                            FilePath = file.BlobPath,
                            ErrorMessage = lastEx?.ToString(),
                            CreatedAtEt = now
                        });
                    }
                }
            });

            return successCount;
        }
    }

}