﻿using ArchivalSystem.Abstraction;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ArchivalSystem.Infrastructure
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<ArchivalDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("ArchivalDb")));

            services.AddSingleton<IConnectionProvider, ConnectionProvider>();
            services.AddScoped<IBlobStorageService, BlobStorageService>();
            services.AddScoped<IParquetExportService, ParquetExportService>();

            return services;
        }

        public static IServiceCollection AddArchivalServices(this IServiceCollection services)
        {
            services.AddScoped<ISelfManagedTableArchiver, SelfManagedTableArchiver>();
            services.AddScoped<IExternalTableArchiver, ExternalTableArchiver>();
            services.AddScoped<IRetentionService, RetentionService>();
            services.AddScoped<ILifecyclePolicyResolver, ArchivalFileLifecyclePolicyResolver>();
            services.AddScoped<IDbArchiver, DbArchiver>();
            services.AddScoped<IExternalFileRegistrar, ExternalFileRegistrar>();
            services.AddScoped<IBlobTagSynchronizer, BlobTagSynchronizer>();
            services.AddScoped<IArchivalRunRepository, ArchivalRunRepository>();
            //services.AddScoped<IArchivalOrchestrator, ArchivalOrchestrator>();
            services.AddScoped<ISourceExporter, SourceExporter>();
            services.AddScoped<ISourceDataDeleter, SourceDataDeleter>();

            return services;
        }
    }
}
