﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Infrastructure
{
    public class ExternalFileRegistrar(
         IArchivalTableConfigurationRepository tableConfigRepository,
         IArchivalFileRepository archivalFileRepository,
         IBlobStorageService blobStorage,
         ILifecyclePolicyResolver lifecyclePolicyResolver,
         IArchivalRunRepository archivalRunRepository) 
         : IExternalFileRegistrar
    {
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly IArchivalFileRepository _archivalFileRepository = archivalFileRepository ?? throw new ArgumentNullException(nameof(archivalFileRepository));
        private readonly IBlobStorageService _blobStorage = blobStorage ?? throw new ArgumentNullException(nameof(blobStorage));
        private readonly ILifecyclePolicyResolver _lifecyclePolicyResolver = lifecyclePolicyResolver ?? throw new ArgumentNullException(nameof(lifecyclePolicyResolver));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));

        public async Task<int> DiscoverAndRegisterAsync(
            int tableConfigurationId,
            long runId,
            CancellationToken ct = default)
        {
            var tableConfig = await _tableConfigRepository.GetWithRelatedAsync(tableConfigurationId, ct);

            if (tableConfig == null)
                throw new InvalidOperationException($"Table configuration {tableConfigurationId} not found.");

            if (tableConfig.ExportMode != ExportMode.External)
                throw new InvalidOperationException(
                    $"Table configuration {tableConfigurationId} is not External.");

            var prefix = tableConfig.DiscoveryPathPrefix ?? string.Empty;

            var blobs = await _blobStorage.ListBlobsAsync(
                tableConfig.StorageAccountName,
                tableConfig.ContainerName,
                prefix,
                ct);

            if (!blobs.Any())
            {
                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfigurationId,
                    asOfDate: null,
                    dateType: null,
                    phase: RunDetailPhase.Discover,
                    status: RunDetailStatus.Skipped,
                    filePath: prefix,
                    errorMessage: "No blobs discovered for External configuration.",
                    ct: ct);

                return 0;
            }

            // resolve policy once for table
            var (policy, azurePolicyTag) =
                await _lifecyclePolicyResolver.ResolvePolicyForTableAsync(tableConfigurationId, ct);

            // Pre-fetch existing archival_file rows for discovered blob paths
            var blobPaths = blobs.Select(b => b.BlobPath).Distinct(StringComparer.Ordinal).ToList();
            var existingFiles = await _archivalFileRepository.GetByBlobPathsAsync(tableConfigurationId, blobPaths, ct);
            var existingByPath = existingFiles.ToDictionary(f => f.BlobPath, StringComparer.Ordinal);

            // Pre-parse dates to build exemption lookup
            var asOfDates = blobs
                .Select(b => ParseDateFromPath(b.BlobPath).asOfDate)
                .Where(d => d.HasValue)
                .Select(d => DateOnly.FromDateTime(d!.Value))
                .Distinct()
                .ToList();

            var exemptDates = await _archivalFileRepository.GetFileExemptionDatesAsync(tableConfigurationId, asOfDates, ct);

            var count = 0;
            var modifiedFiles = new List<ArchivalFileEntity>();

            // 1) Create or prepare file entities (do an initial bulk save to get IDs for new files)
            foreach (var blob in blobs)
            {
                ct.ThrowIfCancellationRequested();

                var (asOfDate, dateType) = ParseDateFromPath(blob.BlobPath);

                var isFileExempt = asOfDate.HasValue && exemptDates.Contains(DateOnly.FromDateTime(asOfDate.Value));

                existingByPath.TryGetValue(blob.BlobPath, out var existingFile);

                if (existingFile == null)
                {
                    existingFile = new ArchivalFileEntity
                    {
                        TableConfigurationId = tableConfigurationId,
                        AsOfDate = asOfDate?.Date,
                        DateType = dateType,
                        StorageAccountName = blob.StorageAccountName,
                        ContainerName = blob.ContainerName,
                        BlobPath = blob.BlobPath,
                        Etag = blob.ETag,
                        ContentType = blob.ContentType,
                        FileSizeBytes = blob.ContentLength,
                        Status = ArchivalFileStatus.Created,
                        CreatedAtEt = DateTime.UtcNow,
                        ArchivalPolicyTag = azurePolicyTag,
                        CurrentAccessTier = null,
                        LastTierCheckAtEt = null,
                        OverrideFileLifecyclePolicyId = null,
                        LastTagsSyncAtEt = null
                    };

                    modifiedFiles.Add(existingFile);
                }
                else
                {
                    // update fields that may have changed prior to tagging
                    existingFile.AsOfDate = asOfDate?.Date;
                    existingFile.DateType = dateType;
                    existingFile.Etag = blob.ETag;
                    existingFile.ContentType = blob.ContentType;
                    existingFile.FileSizeBytes = blob.ContentLength;
                    existingFile.ArchivalPolicyTag = azurePolicyTag;

                    modifiedFiles.Add(existingFile);
                }
            }

            // Persist initial state so new files get Ids for logging
            if (modifiedFiles.Count > 0)
            {
                await _archivalFileRepository.UpdateFilesAsync(modifiedFiles, ct);

                // refresh existingByPath with possibly new entries (ids assigned)
                var refreshed = await _archivalFileRepository.GetByBlobPathsAsync(tableConfigurationId, blobPaths, ct);
                existingByPath = refreshed.ToDictionary(f => f.BlobPath, StringComparer.Ordinal);
            }

            // 2) Apply tags per blob and collect run-detail rows for bulk insert
            var now = DateTime.UtcNow;
            var runDetails = new List<ArchivalRunDetailEntity>();

            foreach (var blob in blobs)
            {
                ct.ThrowIfCancellationRequested();

                var (asOfDate, dateType) = ParseDateFromPath(blob.BlobPath);
                existingByPath.TryGetValue(blob.BlobPath, out var fileEntity);
                if (fileEntity == null)
                {
                    // This shouldn't happen - safety check
                    continue;
                }

                var isFileExempt = asOfDate.HasValue && exemptDates.Contains(DateOnly.FromDateTime(asOfDate.Value));

                var tags = new Dictionary<string, string>
                {
                    ["archival_table_configuration_id"] = tableConfigurationId.ToString(),
                    ["archival_policy"] = azurePolicyTag ?? string.Empty,
                    ["archival_exempt"] = isFileExempt ? "true" : "false"
                };

                if (asOfDate.HasValue)
                    tags["archival_date"] = asOfDate.Value.ToString("yyyy-MM-dd");

                if (dateType.HasValue)
                    tags["archival_date_type"] = dateType.Value.ToString();

                try
                {
                    await _blobStorage.SetTagsAsync(
                        blob.StorageAccountName,
                        blob.ContainerName,
                        blob.BlobPath,
                        tags,
                        ct);

                    // update entity metadata
                    fileEntity.LastTagsSyncAtEt = now;
                    fileEntity.ArchivalPolicyTag = azurePolicyTag;
                    fileEntity.Etag = blob.ETag;
                    fileEntity.ContentType = blob.ContentType;
                    fileEntity.FileSizeBytes = blob.ContentLength;

                    // buffer a run-detail row instead of immediate per-blob insert
                    runDetails.Add(new ArchivalRunDetailEntity
                    {
                        RunId = runId,
                        TableConfigurationId = tableConfigurationId,
                        AsOfDate = asOfDate?.Date,
                        DateType = dateType,
                        Phase = RunDetailPhase.Discover,
                        Status = RunDetailStatus.Success,
                        ArchivalFileId = fileEntity.Id,
                        FilePath = fileEntity.BlobPath,
                        ErrorMessage = null,
                        CreatedAtEt = now
                    });

                    count++;
                }
                catch (Exception ex)
                {
                    // buffer failed detail as well
                    runDetails.Add(new ArchivalRunDetailEntity
                    {
                        RunId = runId,
                        TableConfigurationId = tableConfigurationId,
                        AsOfDate = asOfDate?.Date,
                        DateType = dateType,
                        Phase = RunDetailPhase.Discover,
                        Status = RunDetailStatus.Failed,
                        ArchivalFileId = fileEntity?.Id,
                        FilePath = blob.BlobPath,
                        ErrorMessage = ex.ToString(),
                        CreatedAtEt = now
                    });
                }
            }

            // 3) Persist final metadata (etag, last sync time etc.) and bulk insert run details
            var finalModified = existingByPath.Values.ToList();
            if (finalModified.Count > 0)
            {
                await _archivalFileRepository.UpdateFilesAsync(finalModified, ct);
            }

            if (runDetails.Count > 0)
            {
                await _archivalRunRepository.ArchivalRunDetailBulkInsertAsync(runDetails, ct);
            }

            return blobs.Count;
        }

        private static (DateTime? asOfDate, DateType? dateType) ParseDateFromPath(string blobPath)
        {
            // Example: external/systemA/pnl/2025/11/27/file.ext
            // We'll try to find yyyy/MM/dd anywhere in the path.
            var parts = blobPath.Split(new[] { '/', '\\' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < parts.Length - 2; i++)
            {
                if (parts[i].Length == 4 && parts[i + 1].Length == 2 && parts[i + 2].Length == 2 &&
                    int.TryParse(parts[i], out var year) &&
                    int.TryParse(parts[i + 1], out var month) &&
                    int.TryParse(parts[i + 2], out var day))
                {
                    try
                    {
                        var dt = new DateTime(year, month, day);
                        return (dt, DateType.EXT); // treat external reports as EXT by default
                    }
                    catch
                    {
                        // ignore and continue
                    }
                }
            }

            return (null, null);
        }
    }
}
