﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data.Common;
using ArchivalSystem.Abstraction;

namespace ArchivalSystem.Infrastructure;

public class ConnectionProvider(IConfiguration configuration) : IConnectionProvider
{
    private readonly IConfiguration _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

    public async Task<DbConnection> CreateOpenConnectionAsync(string databaseName, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(databaseName)) throw new ArgumentException("Database name must be provided.", nameof(databaseName));

        var cs = _configuration.GetConnectionString(databaseName);
        if (string.IsNullOrWhiteSpace(cs))
            throw new InvalidOperationException($"No connection string found for key '{databaseName}' in ConnectionStrings.");

        var conn = new SqlConnection(cs);
        await conn.OpenAsync(ct);
        return conn; // caller owns and must dispose
    }
}