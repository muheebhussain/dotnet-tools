﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure
{
    public class SelfManagedTableArchiver(
        IRetentionService retentionService,
        IDbArchiver dbArchiver,
        IArchivalRunRepository archivalRunRepository,
        ILogger<SelfManagedTableArchiver> logger)
        : ISelfManagedTableArchiver
    {
        private readonly IRetentionService _retentionService = retentionService ?? throw new ArgumentNullException(nameof(retentionService));
        private readonly IDbArchiver _dbArchiver = dbArchiver ?? throw new ArgumentNullException(nameof(dbArchiver));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILogger<SelfManagedTableArchiver> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task ArchiveAsync(
            ArchivalTableConfigurationDto tableConfig,
            long runId,
            CancellationToken ct = default)
        {
            if (tableConfig == null) throw new ArgumentNullException(nameof(tableConfig));
            if (string.IsNullOrWhiteSpace(tableConfig.AsOfDateColumn))
                throw new InvalidOperationException($"Table configuration {tableConfig.Id} has no AsOfDateColumn configured.");
            
            _logger.LogInformation(
                "Processing SelfManaged table {Id} ({Db}.{Schema}.{Table}).",
                tableConfig.Id,
                tableConfig.DatabaseName,
                tableConfig.SchemaName,
                tableConfig.TableName);

            // 1) Compute KEEP SET + candidates via business calendar + retention + exemptions
            var retention = await _retentionService.ComputeRetentionAsync(tableConfig, ct);

            var keepCount = retention.KeepDates.Count;
            var candidateCount = retention.CandidateDates.Count;

            _logger.LogInformation(
                "TableConfig {Id}: KEEP={KeepCount}, Candidates={CandidateCount}",
                tableConfig.Id,
                keepCount,
                candidateCount);

            if (candidateCount == 0)
            {
                await _archivalRunRepository.LogDetailAsync(
                    runId,
                    tableConfig.Id,
                    asOfDate: null,
                    dateType: null,
                    phase: RunDetailPhase.Export,
                    status: RunDetailStatus.Skipped,
                    rowsAffected: null,
                    filePath: null,
                    errorMessage: "No candidate dates for archival (nothing to export).",
                    ct: ct);

                return;
            }

            // 2) Get date types (EOD/EOM/EOQ/EOY) for candidate dates
            var dateTypeMap = await _retentionService.GetDateTypesAsync(retention.CandidateDates, ct);

            // 3) Iterate candidate dates in order (sequential - avoids DB / IO storms).
            foreach (var d in retention.CandidateDates.OrderBy(x => x))
            {
                ct.ThrowIfCancellationRequested();

                var dateStr = d.ToString("yyyy-MM-dd");
                if (!dateTypeMap.TryGetValue(d, out var dateType))
                {
                    _logger.LogWarning($"Date {dateStr} not found in business calendar for TableConfig {tableConfig.Id}; defaulting to DateType=EOD.");
                    dateType = DateType.EOD;
                }

                try
                {
                    var asOfDateTime = d.ToDateTime(TimeOnly.MinValue);
                    _logger.LogInformation($"Archiving TableConfig {tableConfig.Id} for date {dateStr} (DateType={dateType}).");

                    await _dbArchiver.ArchiveTableForDateAsync(tableConfig, asOfDateTime, dateType, runId, ct);
                }
                catch (OperationCanceledException)
                {
                    // propagate cancellation
                    _logger.LogInformation($"Archival cancelled for TableConfig {tableConfig.Id} at date {dateStr}.");

                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Error archiving TableConfig {tableConfig.Id} for date {dateStr}. Continuing with next date.");
                    // continue processing remaining candidate dates
                }
            }
        }
    }
}
