﻿using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Core
{
    public interface IArchivalOrchestrator
    {
        /// <summary>
        /// Executes a full archival run (all active table configurations).
        /// </summary>
        Task RunAsync(CancellationToken ct = default);
    }
    public class ArchivalOrchestrator(
        ArchivalDbContext db,
        ISelfManagedTableArchiver selfManagedTableArchiver,
        IExternalTableArchiver externalTableArchiver,
        IRunLogger runLogger,
        ILogger<ArchivalOrchestrator> logger)
        : IArchivalOrchestrator
    {
        private readonly ArchivalDbContext _db = db ?? throw new ArgumentNullException(nameof(db));
        private readonly ISelfManagedTableArchiver _selfManagedTableArchiver = selfManagedTableArchiver ?? throw new ArgumentNullException(nameof(selfManagedTableArchiver));
        private readonly IExternalTableArchiver _externalTableArchiver = externalTableArchiver ?? throw new ArgumentNullException(nameof(externalTableArchiver));
        private readonly IRunLogger _runLogger = runLogger ?? throw new ArgumentNullException(nameof(runLogger));
        private readonly ILogger<ArchivalOrchestrator> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task RunAsync(CancellationToken ct = default)
        {
            // Start top-level run
            var run = await _runLogger.StartRunAsync("Archival orchestrator run", ct);

            var anyFailures = false;

            try
            {
                var tableConfigs = await _db.ArchivalTableConfigurations
                    .Where(tc => tc.IsActive)
                    .AsNoTracking()
                    .ToListAsync(ct);

                if (!tableConfigs.Any())
                {
                    _logger.LogInformation("No active archival_table_configuration rows found. Nothing to do.");

                    await _runLogger.CompleteRunAsync(
                        run.Id,
                        RunStatus.Success,
                        "No active table configurations.",
                        ct);

                    return;
                }

                foreach (var tc in tableConfigs)
                {
                    ct.ThrowIfCancellationRequested();

                    try
                    {
                        switch (tc.ExportMode)
                        {
                            case ExportMode.SelfManaged:
                                await _selfManagedTableArchiver.ArchiveAsync(tc, run.Id, ct);
                                break;

                            case ExportMode.External:
                                await _externalTableArchiver.ArchiveAsync(tc, run.Id, ct);
                                break;

                            default:
                                _logger.LogWarning(
                                    "TableConfiguration {Id} has unsupported ExportMode {Mode}. Skipping.",
                                    tc.Id,
                                    tc.ExportMode);

                                await _runLogger.LogDetailAsync(
                                    run.Id,
                                    tc.Id,
                                    asOfDate: null,
                                    dateType: null,
                                    phase: RunDetailPhase.Export,
                                    status: RunDetailStatus.Skipped,
                                    rowsAffected: null,
                                    filePath: null,
                                    errorMessage: $"Unsupported export_mode '{tc.ExportMode}'.",
                                    ct: ct);
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        anyFailures = true;

                        _logger.LogError(ex,
                            "Error processing table configuration {Id} ({Db}.{Schema}.{Table}).",
                            tc.Id,
                            tc.DatabaseName,
                            tc.SchemaName,
                            tc.TableName);

                        await _runLogger.LogDetailAsync(
                            run.Id,
                            tc.Id,
                            asOfDate: null,
                            dateType: null,
                            phase: RunDetailPhase.Export,
                            status: RunDetailStatus.Failed,
                            rowsAffected: null,
                            filePath: null,
                            errorMessage: ex.ToString(),
                            ct: ct);
                    }
                }

                await _runLogger.CompleteRunAsync(
                    run.Id,
                    anyFailures ? RunStatus.Failed : RunStatus.Success,
                    anyFailures
                        ? "One or more table configurations failed."
                        : "All table configurations processed successfully.",
                    ct);
            }
            catch (Exception ex)
            {
                anyFailures = true;

                _logger.LogError(ex, "Fatal error in archival orchestrator run {RunId}.", run.Id);

                await _runLogger.CompleteRunAsync(
                    run.Id,
                    RunStatus.Failed,
                    "Fatal error: " + ex,
                    ct);

                throw;
            }
        }
    }
}
