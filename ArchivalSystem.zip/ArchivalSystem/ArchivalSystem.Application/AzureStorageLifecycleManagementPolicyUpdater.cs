﻿using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using Azure.Core;
using Azure.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Application
{
    /// <summary>
    /// Reads lifecycle policies from the Archival DB and pushes
    /// an Azure Storage ManagementPolicy to a given storage account.
    ///
    /// It assumes:
    /// - archival_table_configuration has StorageAccountName
    /// - archival_file_lifecycle_policy holds cool/archive/delete days
    /// - Blob tags: archival_policy, archival_date_type (EOD/EOM/EOQ/EOY)
    /// </summary>
    public class AzureStorageLifecycleManagementPolicyUpdater(
        IArchivalTableConfigurationRepository tableConfigReadRepo,
        IArchivalFileLifecyclePolicyRepository filePolicyRepo,
        IHttpClientFactory httpClientFactory,
        ILogger<AzureStorageLifecycleManagementPolicyUpdater> logger)
    {
        private readonly IArchivalTableConfigurationRepository _tableConfigReadRepo = tableConfigReadRepo ?? throw new ArgumentNullException(nameof(tableConfigReadRepo));
        private readonly IArchivalFileLifecyclePolicyRepository _filePolicyRepo = filePolicyRepo ?? throw new ArgumentNullException(nameof(filePolicyRepo));
        private readonly IHttpClientFactory _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        private readonly ILogger<AzureStorageLifecycleManagementPolicyUpdater> _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        private readonly TokenCredential _credential = new DefaultAzureCredential();

        // Will try Managed Identity, VS, Azure CLI, etc. depending on environment

        public async Task SyncForStorageAccountAsync(
            string subscriptionId,
            string resourceGroupName,
            string storageAccountName,
            CancellationToken ct = default)
        {
            _logger.LogInformation(
                "Syncing Storage ManagementPolicy for account {Account} (RG={RG}, Sub={Sub})",
                storageAccountName, resourceGroupName, subscriptionId);

            // 1) Find all active table configs using this storage account
            var usedPolicyIds = await _tableConfigReadRepo
                .GetDistinctActiveFileLifecyclePolicyIdsByStorageAccountAsync(storageAccountName, ct);

            if (!usedPolicyIds.Any())
            {
                _logger.LogWarning("No active table configurations reference storage account {Account}. Nothing to sync.", storageAccountName);
                return;
            }

            // 2) Load those lifecycle policies
            var policies = await _filePolicyRepo.GetActiveByIdsAsync(usedPolicyIds, ct);

            if (!policies.Any())
            {
                _logger.LogWarning("No active lifecycle policies found for storage account {Account}. Nothing to sync.", storageAccountName);
                return;
            }

            // 3) Build ManagementPolicy body
            var managementPolicyBody = BuildManagementPolicyJsonObject(policies);

            var json = JsonSerializer.Serialize(
                managementPolicyBody,
                new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    WriteIndented = true
                });

            _logger.LogInformation("Generated ManagementPolicy JSON:\n{Json}", json);

            // 4) Call Azure Management API (ARM)
            var token = await _credential.GetTokenAsync(
                new TokenRequestContext(new[] { "https://management.azure.com/.default" }),
                ct);

            var client = _httpClientFactory.CreateClient("AzureMgmt");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.Token);

            var uri =
                $"https://management.azure.com/subscriptions/{subscriptionId}" +
                $"/resourceGroups/{resourceGroupName}" +
                $"/providers/Microsoft.Storage/storageAccounts/{storageAccountName}" +
                "/managementPolicies/default?api-version=2023-01-01";

            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PutAsync(uri, content, ct);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogError(
                    "Failed to update ManagementPolicy. Status={Status}, Body={Body}",
                    response.StatusCode, body);

                throw new InvalidOperationException(
                    $"Failed to update ManagementPolicy: {response.StatusCode}");
            }

            _logger.LogInformation(
                "Successfully updated ManagementPolicy for storage account {Account}.",
                storageAccountName);
        }

        /// <summary>
        /// Builds an anonymous object representing the ManagementPolicy resource body.
        /// Each ArchivalFileLifecyclePolicy row becomes up to 4 rules (EOD/EOM/EOQ/EOY),
        /// filtered by blob index tags:
        ///   archival_policy == policy.Name
        ///   archival_date_type == 'EOD' / 'EOM' / 'EOQ' / 'EOY'
        /// </summary>
        private object BuildManagementPolicyJsonObject(IEnumerable<ArchivalFileLifecyclePolicyEntity> policies)
        {
            var rules = new List<object>();

            foreach (var p in policies)
            {
                AddRuleIfConfigured(rules, p, "EOD", p.EodCoolDays, p.EodArchiveDays, p.EodDeleteDays);
                AddRuleIfConfigured(rules, p, "EOM", p.EomCoolDays, p.EomArchiveDays, p.EomDeleteDays);
                AddRuleIfConfigured(rules, p, "EOQ", p.EoqCoolDays, p.EoqArchiveDays, p.EoqDeleteDays);
                AddRuleIfConfigured(rules, p, "EOY", p.EoyCoolDays, p.EoyArchiveDays, p.EoyDeleteDays);
            }

            return new
            {
                properties = new
                {
                    policy = new
                    {
                        rules
                    }
                }
            };
        }

        private void AddRuleIfConfigured(
            List<object> rules,
            ArchivalFileLifecyclePolicyEntity p,
            string dateType,
            int? coolDays,
            int? archiveDays,
            int? deleteDays)
        {
            if (coolDays is null && archiveDays is null && deleteDays is null)
            {
                return; // nothing configured for this date type
            }

            var baseBlobActions = new Dictionary<string, object>();

            if (coolDays is not null)
            {
                baseBlobActions["tierToCool"] = new
                {
                    daysAfterModificationGreaterThan = (double)coolDays.Value
                };
            }

            if (archiveDays is not null)
            {
                baseBlobActions["tierToArchive"] = new
                {
                    daysAfterModificationGreaterThan = (double)archiveDays.Value
                };
            }

            if (deleteDays is not null)
            {
                baseBlobActions["delete"] = new
                {
                    daysAfterModificationGreaterThan = (double)deleteDays.Value
                };
            }

            if (baseBlobActions.Count == 0)
            {
                return;
            }

            var rule = new
            {
                name = $"{p.Name}_{dateType}",
                enabled = true,
                type = "Lifecycle",
                definition = new
                {
                    filters = new
                    {
                        blobTypes = new[] { "blockBlob" },
                        tagFilters = new[]
                        {
                            new { name = "archival_policy", op = "==", value = p.Name },
                            new { name = "archival_date_type", op = "==", value = dateType }
                        }
                    },
                    actions = new
                    {
                        baseBlob = baseBlobActions
                    }
                }
            };

            rules.Add(rule);
        }
    }
}
