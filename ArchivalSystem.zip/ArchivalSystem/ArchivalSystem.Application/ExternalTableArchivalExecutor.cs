﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Application
{
    public class ExternalTableArchivalExecutor(
        ArchivalDbContext db,
        IExternalTableArchiver externalTableArchiver,
        IRunLogger runLogger,
        ILogger<ExternalTableArchivalExecutor> logger)
        : IExternalTableArchivalExecutor
    {
        private readonly ArchivalDbContext _db = db ?? throw new ArgumentNullException(nameof(db));
        private readonly IExternalTableArchiver _externalTableArchiver = externalTableArchiver ?? throw new ArgumentNullException(nameof(externalTableArchiver));
        private readonly IRunLogger _runLogger = runLogger ?? throw new ArgumentNullException(nameof(runLogger));
        private readonly ILogger<ExternalTableArchivalExecutor> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task RunForTableAsync(int tableConfigurationId, CancellationToken ct = default)
        {
            // Start run specific to this external table
            var description = $"Airflow per-table EXTERNAL archival run for table_config_id={tableConfigurationId}";
            var run = await _runLogger.StartRunAsync(description, ct);

            try
            {
                var tc = await _db.ArchivalTableConfigurations
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Id == tableConfigurationId, ct);

                if (tc == null)
                {
                    var msg = $"External table configuration {tableConfigurationId} not found.";
                    _logger.LogError(msg);

                    await _runLogger.CompleteRunAsync(
                        run.Id,
                        RunStatus.Failed,
                        msg,
                        ct);

                    return;
                }

                if (!tc.IsActive)
                {
                    var msg = $"External table configuration {tableConfigurationId} is not active. Skipping.";
                    _logger.LogInformation(msg);

                    await _runLogger.CompleteRunAsync(
                        run.Id,
                        RunStatus.Success,
                        msg,
                        ct);

                    return;
                }

                if (tc.ExportMode != ExportMode.External)
                {
                    var msg = $"Table configuration {tableConfigurationId} is not External (ExportMode={tc.ExportMode}).";
                    _logger.LogWarning(msg);

                    await _runLogger.CompleteRunAsync(
                        run.Id,
                        RunStatus.Failed,
                        msg,
                        ct);

                    return;
                }

                _logger.LogInformation(
                    "Starting per-table EXTERNAL archival for TableConfig {Id} (account={Account}, container={Container}, prefix={Prefix}).",
                    tc.Id,
                    tc.StorageAccountName,
                    tc.ContainerName,
                    tc.DiscoveryPathPrefix);

                // Delegate the actual external discovery/registration to IExternalTableArchiver
                await _externalTableArchiver.ArchiveAsync(tc, run.Id, ct);

                await _runLogger.CompleteRunAsync(
                    run.Id,
                    RunStatus.Success,
                    $"Per-table EXTERNAL archival completed for table_configuration_id={tableConfigurationId}.",
                    ct);

                _logger.LogInformation(
                    "Per-table EXTERNAL archival completed successfully for TableConfig {Id}.",
                    tableConfigurationId);
            }
            catch (OperationCanceledException)
            {
                var msg = $"Per-table EXTERNAL archival cancelled for table_configuration_id={tableConfigurationId}.";
                _logger.LogWarning(msg);

                await _runLogger.CompleteRunAsync(
                    run.Id,
                    RunStatus.Failed,
                    msg,
                    CancellationToken.None);

                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Per-table EXTERNAL archival failed for TableConfig {Id}.",
                    tableConfigurationId);

                await _runLogger.CompleteRunAsync(
                    run.Id,
                    RunStatus.Failed,
                    "Error: " + ex,
                    ct);

                throw;
            }
        }
    }
}
