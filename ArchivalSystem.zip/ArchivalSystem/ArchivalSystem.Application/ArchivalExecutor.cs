﻿using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Application
{
    public class ArchivalExecutor(
        IArchivalTableConfigurationRepository tableConfigRepository,
        ISelfManagedTableArchiver selfManagedTableArchiver,
        IExternalTableArchiver externalTableArchiver,
        IArchivalRunRepository archivalRunRepository,
        ILogger<ArchivalExecutor> logger)
        : IArchivalExecutor
    {
        private readonly IArchivalTableConfigurationRepository _tableConfigRepository = tableConfigRepository ?? throw new ArgumentNullException(nameof(tableConfigRepository));
        private readonly ISelfManagedTableArchiver _selfManagedTableArchiver = selfManagedTableArchiver ?? throw new ArgumentNullException(nameof(selfManagedTableArchiver));
        private readonly IExternalTableArchiver _externalTableArchiver = externalTableArchiver ?? throw new ArgumentNullException(nameof(externalTableArchiver));
        private readonly IArchivalRunRepository _archivalRunRepository = archivalRunRepository ?? throw new ArgumentNullException(nameof(archivalRunRepository));
        private readonly ILogger<ArchivalExecutor> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task ExecuteAsync(int tableConfigurationId, CancellationToken ct = default)
        {
            var description = $"Per-table archival run for table_config_id={tableConfigurationId}";
            var run = await _archivalRunRepository.StartRunAsync(description, ct);

            try
            {
                var tc = await _tableConfigRepository.GetByIdAsync(tableConfigurationId, ct);

                if (tc == null)
                {
                    var msg = $"Table configuration {tableConfigurationId} not found.";
                    _logger.LogError(msg);

                    await _archivalRunRepository.CompleteRunAsync(run.Id, RunStatus.Failed, msg, ct);

                    return;
                }

                if (!tc.IsActive)
                {
                    var msg = $"Table configuration {tableConfigurationId} is not active. Skipping.";
                    _logger.LogInformation(msg);

                    await _archivalRunRepository.CompleteRunAsync(run.Id, RunStatus.Success, msg, ct);

                    return;
                }

                var tcDto = tc.ToDto();

                _logger.LogInformation(
                    "Starting per-table archival for TableConfig {Id} ({Db}.{Schema}.{Table}), ExportMode={Mode}.",
                    tc.Id,
                    tc.DatabaseName,
                    tc.SchemaName,
                    tc.TableName,
                    tc.ExportMode);

                switch (tc.ExportMode)
                {
                    case ExportMode.SelfManaged:
                        await _selfManagedTableArchiver.ArchiveAsync(tcDto, run.Id, ct);
                        break;

                    case ExportMode.External:
                        await _externalTableArchiver.ArchiveAsync(tc.ToDto(), run.Id, ct);
                        break;

                    default:
                        var msg = $"Unsupported ExportMode '{tc.ExportMode}' for table_configuration_id={tableConfigurationId}.";
                        _logger.LogWarning(msg);

                        await _archivalRunRepository.CompleteRunAsync(run.Id, RunStatus.Failed, msg, ct);

                        return;
                }

                await _archivalRunRepository.CompleteRunAsync(
                    run.Id,
                    RunStatus.Success,
                    $"Per-table archival completed for table_configuration_id={tableConfigurationId}.",
                    ct);

                _logger.LogInformation("Per-table archival completed successfully for TableConfig {Id}.", tableConfigurationId);
            }
            catch (OperationCanceledException)
            {
                var msg = $"Per-table archival cancelled for table_configuration_id={tableConfigurationId}.";
                _logger.LogWarning(msg);

                await _archivalRunRepository.CompleteRunAsync(run.Id, RunStatus.Failed, msg, CancellationToken.None);

                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Per-table archival failed for TableConfig {Id}.", tableConfigurationId);

                await _archivalRunRepository.CompleteRunAsync(run.Id, RunStatus.Failed, "Error: " + ex, ct);

                throw;
            }
        }
    }
}
