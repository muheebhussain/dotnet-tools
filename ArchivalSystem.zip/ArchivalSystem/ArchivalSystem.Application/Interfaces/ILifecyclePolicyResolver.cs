﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Interfaces;

public interface ILifecyclePolicyResolver
{
    Task<(ArchivalFileLifecyclePolicyDto policy, string? azurePolicyTag)>
        ResolvePolicyForFileAsync(ArchivalFileDto file, CancellationToken ct = default);

    Task<(ArchivalFileLifecyclePolicyDto policy, string? azurePolicyTag)>
        ResolvePolicyForTableAsync(int tableConfigurationId, CancellationToken ct = default);

    (int? coolDays, int? archiveDays, int? deleteDays)
        GetDurationsForDateType(ArchivalFileLifecyclePolicyDto policy, DateType? dateType);
}