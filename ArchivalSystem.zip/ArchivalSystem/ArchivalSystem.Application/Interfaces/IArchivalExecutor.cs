﻿namespace ArchivalSystem.Application.Interfaces;

public interface IArchivalExecutor
{
    /// <summary>
    /// Executes archival for a single table configuration (SelfManaged or External),
    /// depending on export_mode.
    /// Intended to be called by a per-table job (e.g., Airflow task).
    /// </summary>
    Task ExecuteAsync(int tableConfigurationId, CancellationToken ct = default);
}