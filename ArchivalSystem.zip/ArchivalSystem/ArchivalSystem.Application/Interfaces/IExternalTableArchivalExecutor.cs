﻿namespace ArchivalSystem.Application.Interfaces;

public interface IExternalTableArchivalExecutor
{
    /// <summary>
    /// Executes archival (discovery/registration) for a single External table configuration.
    /// Intended to be called by a per-table job (e.g., Airflow task).
    /// </summary>
    Task RunForTableAsync(int tableConfigurationId, CancellationToken ct = default);
}