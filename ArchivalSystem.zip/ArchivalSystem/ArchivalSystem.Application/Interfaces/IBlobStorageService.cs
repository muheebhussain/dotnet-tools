﻿using ArchivalSystem.Application.Models;

namespace ArchivalSystem.Application.Interfaces;

public interface IBlobStorageService
{
    int GetDegreeOfParallelism();

    BlobStorageAccountOptions GetAccountOptions(string storageAccountName);

    Task<IReadOnlyList<ArchivalBlobInfo>> ListBlobsAsync(
        string storageAccountName,
        string containerName,
        string? prefix,
        CancellationToken ct = default);

    Task<ArchivalBlobInfo> UploadAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        string contentType,
        byte[] content,
        IDictionary<string, string> tags,
        CancellationToken ct = default);

    Task SetTagsAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        IDictionary<string, string> tags,
        CancellationToken ct = default);

    Task<IDictionary<string, string>> GetTagsAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        CancellationToken ct = default);

    Task<string?> GetAccessTierAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        CancellationToken ct = default);

    /// <summary>
    /// Open a writable stream to the target blob. Caller is responsible for writing to and disposing the stream.
    /// After the stream is closed the caller can set tags (via SetTagsAsync) and/or fetch properties.
    /// </summary>
    Task<Stream> OpenWriteStreamAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        bool overwrite = true,
        string? contentType = null,
        CancellationToken ct = default);

    /// <summary>
    /// High level helper: write content by invoking <paramref name="writer"/> into the target blob stream,
    /// then apply tags and return final blob properties (ETag, ContentLength, ContentType).
    /// This wraps write + finalize + tagging as a single service call.
    /// </summary>
    Task<ArchivalBlobInfo> UploadFromStreamAsync(
        string storageAccountName,
        string containerName,
        string blobPath,
        string contentType,
        Func<Stream, CancellationToken, Task> writer,
        IDictionary<string, string>? tags = null,
        bool overwrite = true,
        CancellationToken ct = default);


    Task DeleteIfExistsAsync(string storageAccountName, string containerName, string blobPath,
        CancellationToken ct = default);

    Task SetAccessTierAsync(string storageAccountName, string containerName, string blobPath, string tier,
        CancellationToken ct = default);
}