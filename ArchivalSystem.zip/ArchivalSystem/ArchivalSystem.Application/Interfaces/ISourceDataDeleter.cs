﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Interfaces;

public interface ISourceDataDeleter
{
    Task<long> DeleteAsync(
        ArchivalTableConfigurationDto tableConfig,
        DateTime asOfDate,
        long expectedRowCount,
        long runId,
        DateType dateType,
        CancellationToken ct = default);
}