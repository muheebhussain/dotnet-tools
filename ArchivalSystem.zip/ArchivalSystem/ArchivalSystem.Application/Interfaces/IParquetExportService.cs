﻿using ArchivalSystem.Application.Models;

namespace ArchivalSystem.Application.Interfaces;

public interface IParquetExportService
{
    /// <summary>
    /// Stream Parquet output directly to the provided output stream. Returns basic metrics.
    /// Caller owns the output stream lifecycle.
    /// </summary>
    Task<ParquetExportMetrics> ExportTableToStreamAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Stream output,
        CancellationToken ct = default);

    /// <summary>
    /// Export table into one or more parquet parts. For each part the service will invoke the
    /// provided <paramref name="uploadPartAsync"/> callback with a writer delegate that must write
    /// the part content into the provided <see cref="Stream"/>. Implementations should call the writer
    /// synchronously as part of <c>uploadPartAsync</c>.
    /// Returns per-part metrics + blob info returned by <paramref name="uploadPartAsync"/>.
    /// </summary>
    Task<IReadOnlyList<ParquetExportPartResult>> ExportTableToPartsAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Func<int, Func<Stream, CancellationToken, Task>, CancellationToken, Task<ArchivalBlobInfo>> uploadPartAsync,
        int maxRowsPerPart = 250_000,
        CancellationToken ct = default);
}