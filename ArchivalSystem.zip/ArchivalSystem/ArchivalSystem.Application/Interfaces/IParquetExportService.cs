﻿using ArchivalSystem.Application.Models;

namespace ArchivalSystem.Application.Interfaces;

public interface IParquetExportService
{
    /// <summary>
    /// Stream Parquet output directly to the provided output stream. Returns basic metrics.
    /// Caller owns the output stream lifecycle.
    /// </summary>
    Task<ParquetExportMetrics> ExportTableToStreamAsync(
        string databaseName,
        string schemaName,
        string tableName,
        string asOfDateColumn,
        DateTime asOfDate,
        Stream output,
        CancellationToken ct = default);
}