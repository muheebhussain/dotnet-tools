﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Interfaces;

public interface ISourceExporter
{
    Task<ParquetExportResult> ExportAsync(
        ArchivalTableConfigurationDto tableConfig,
        DateTime asOfDate,
        DateType dateType,
        long runId,
        CancellationToken ct = default);
}