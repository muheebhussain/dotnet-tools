﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Interfaces;

public interface IExternalTableArchiver
{
    Task ArchiveAsync(
        ArchivalTableConfigurationDto tableConfig,
        long runId,
        CancellationToken ct = default);
}