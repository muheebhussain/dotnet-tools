﻿namespace ArchivalSystem.Application.Interfaces;

public interface IDbConnectionStringFactory
{
    /// <summary>
    /// Returns a connection string for the given logical database name
    /// (e.g. "TransversalDb", "BDealerDb", "CrustDb").
    /// </summary>
    string GetConnectionString(string databaseName);
}