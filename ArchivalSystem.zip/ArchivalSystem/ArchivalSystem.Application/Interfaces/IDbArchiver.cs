﻿using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;

namespace ArchivalSystem.Application.Interfaces;

public interface IDbArchiver
{
    Task ArchiveTableForDateAsync(
        ArchivalTableConfigurationDto tableConfig,
        DateTime asOfDate,
        DateType dateType,
        long runId,
        CancellationToken ct = default);
}