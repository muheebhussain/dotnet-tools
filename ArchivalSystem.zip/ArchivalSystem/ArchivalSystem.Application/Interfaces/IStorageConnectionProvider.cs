﻿namespace ArchivalSystem.Application.Interfaces;

/// <summary>
/// Provides a storage account connection string for a given storage account name.
/// Implementations may read from configuration, Key Vault, or another store.
/// </summary>
public interface IStorageConnectionProvider
{
    /// <summary>
    /// Returns the connection string for the requested storage account name.
    /// Throws InvalidOperationException if the account is not known.
    /// </summary>
    string GetConnectionString(string storageAccountName);
}