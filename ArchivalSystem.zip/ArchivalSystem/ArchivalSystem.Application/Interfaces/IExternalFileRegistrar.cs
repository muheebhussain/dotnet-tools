﻿namespace ArchivalSystem.Application.Interfaces;

public interface IExternalFileRegistrar
{
    /// <summary>
    /// Discover blobs for the given table configuration (export_mode = External),
    /// register them into archival_file, and apply tags.
    /// Returns the number of files registered/updated.
    /// </summary>
    Task<int> DiscoverAndRegisterAsync(
        int tableConfigurationId,
        long runId,
        CancellationToken ct = default);
}