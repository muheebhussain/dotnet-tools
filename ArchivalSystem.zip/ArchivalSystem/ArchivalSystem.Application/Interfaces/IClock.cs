﻿namespace ArchivalSystem.Application.Interfaces;

/// <summary>
/// Provides current time values (Eastern time).
/// Implementations should be registered in DI (transient as requested).
/// </summary>
public interface IClock
{
    /// <summary>
    /// Current date/time in Eastern time zone as <see cref="DateTimeOffset"/>.
    /// </summary>
    DateTimeOffset Now { get; }

    /// <summary>
    /// Current date in Eastern time zone as <see cref="DateOnly"/>.
    /// </summary>
    DateOnly Today { get; }
}