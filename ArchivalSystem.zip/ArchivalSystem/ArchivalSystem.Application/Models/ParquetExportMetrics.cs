﻿namespace ArchivalSystem.Application.Models;

public sealed class ParquetExportMetrics
{
    public long RowCount { get; init; }
    public int ColumnCount { get; init; }
    /// <summary>
    /// Size in bytes written to the output stream, or -1 if unknown.
    /// </summary>
    public long SizeBytes { get; init; } = -1;
}

public sealed class ParquetExportPartResult
{
    public int PartIndex { get; init; }
    public ParquetExportMetrics Metrics { get; init; } = default!;
    public ArchivalBlobInfo BlobInfo { get; init; } = default!;
}