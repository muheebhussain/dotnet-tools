﻿namespace ArchivalSystem.Application.Models;

public sealed class ParquetExportMetrics
{
    public long RowCount { get; init; }
    public int ColumnCount { get; init; }
    /// <summary>
    /// Size in bytes written to the output stream, or -1 if unknown.
    /// </summary>
    public long SizeBytes { get; init; } = -1;
}