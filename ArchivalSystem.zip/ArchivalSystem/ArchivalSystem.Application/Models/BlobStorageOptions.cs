﻿namespace ArchivalSystem.Application.Models
{
    public class BlobStorageAccountOptions
    {
        public string StorageAccountName { get; set; } = default!;
        public string ConnectionString { get; set; } = default!;

        /// <summary>
        /// When true the registrar will call SetTagsAsync on blobs. Defaults to false.
        /// </summary>
        public bool SetTagsAllowed { get; set; } = false;

        /// <summary>
        /// When true the registrar will attempt to update storage account management policy (ARM).
        /// Defaults to false.
        /// </summary>
        public bool ManagementPolicyUpdateAllowed { get; set; } = false;
    }

    public class BlobStorageOptions
    {
        public IList<BlobStorageAccountOptions> Accounts { get; set; }
            = new List<BlobStorageAccountOptions>();

        /// <summary>
        /// Degree of parallelism used for concurrent operations.
        /// </summary>
        public int DegreeOfParallelism { get; set; } = 16;
    }
}
