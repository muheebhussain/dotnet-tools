﻿namespace ArchivalSystem.Application.Models
{
    public class BlobStorageAccountOptions
    {
        public string StorageAccountName { get; set; } = default!;
        public string ConnectionString { get; set; } = default!;
    }

    public class BlobStorageOptions
    {
        public IList<BlobStorageAccountOptions> Accounts { get; set; }
            = new List<BlobStorageAccountOptions>();
    }
}
