﻿namespace ArchivalSystem.Application.Models;

public sealed class ArchivalFileLifecyclePolicyDto
{
    public int Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public bool IsActive { get; init; }

    // Azure policy tag used for blob tagging / ARM policy name
    public string? AzurePolicyTag { get; init; }

    // EOD durations
    public int? EodCoolDays { get; init; }
    public int? EodArchiveDays { get; init; }
    public int? EodDeleteDays { get; init; }

    // EOM durations
    public int? EomCoolDays { get; init; }
    public int? EomArchiveDays { get; init; }
    public int? EomDeleteDays { get; init; }

    // EOQ durations
    public int? EoqCoolDays { get; init; }
    public int? EoqArchiveDays { get; init; }
    public int? EoqDeleteDays { get; init; }

    // EOY durations
    public int? EoyCoolDays { get; init; }
    public int? EoyArchiveDays { get; init; }
    public int? EoyDeleteDays { get; init; }

    // External / EXT durations
    public int? ExternalCoolDays { get; init; }
    public int? ExternalArchiveDays { get; init; }
    public int? ExternalDeleteDays { get; init; }

    // Audit / metadata
    public string? CreatedBy { get; init; }
    public string? UpdatedBy { get; init; }
}