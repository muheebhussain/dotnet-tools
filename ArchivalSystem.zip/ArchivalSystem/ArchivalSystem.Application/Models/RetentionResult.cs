﻿namespace ArchivalSystem.Application.Models;

public sealed class RetentionResult
{
    public IReadOnlyCollection<DateOnly> KeepDates { get; init; } = Array.Empty<DateOnly>();
    public IReadOnlyCollection<DateOnly> CandidateDates { get; init; } = Array.Empty<DateOnly>();
}