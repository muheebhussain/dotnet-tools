﻿namespace ArchivalSystem.Application.Models;

public sealed class RetentionResult
{
    public IReadOnlyCollection<DateOnly> KeepDates { get; init; } = Array.Empty<DateOnly>();
    public IReadOnlyCollection<DateOnly> CandidateDates { get; init; } = Array.Empty<DateOnly>();
}

/// <summary>
/// Simple result type for enforcement runs.
/// </summary>
public sealed record LifecycleEnforcerResult(int Tiered, int Deleted, int Failed);