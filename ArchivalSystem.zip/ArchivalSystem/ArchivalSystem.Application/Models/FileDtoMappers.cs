﻿using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Models;

public static  class FileDtoMappers
{
    public static ArchivalFileDto ToDto(this ArchivalFileEntity e)
    {
        if (e is null) throw new ArgumentNullException(nameof(e));

        return new ArchivalFileDto
        {
            Id = e.Id,
            TableConfigurationId = e.TableConfigurationId,
            AsOfDate = e.AsOfDate,
            DateType = e.DateType,
            StorageAccountName = e.StorageAccountName,
            ContainerName = e.ContainerName,
            BlobPath = e.BlobPath,
            Etag = e.Etag,
            ContentType = e.ContentType,
            FileSizeBytes = e.FileSizeBytes,
            ArchivalPolicyTag = e.ArchivalPolicyTag,
            OverrideFileLifecyclePolicyId = e.OverrideFileLifecyclePolicyId,
            LastTagsSyncAtEt = e.LastTagsSyncAtEt,
            CreatedAtEt = e.CreatedAtEt,
            CurrentAccessTier = e.CurrentAccessTier,
            LastTierCheckAtEt = e.LastTierCheckAtEt,
            RowCount = e.RowCount,
            Status = e.Status
        };
    }
    public static ArchivalFileEntity ToEntity(this ArchivalFileDto dto)
    {
        if (dto == null) throw new ArgumentNullException(nameof(dto));

        return new ArchivalFileEntity
        {
            Id = dto.Id,
            TableConfigurationId = dto.TableConfigurationId,
            AsOfDate = dto.AsOfDate,
            DateType = dto.DateType,
            StorageAccountName = dto.StorageAccountName,
            ContainerName = dto.ContainerName,
            BlobPath = dto.BlobPath,
            Etag = dto.Etag,
            ContentType = dto.ContentType,
            FileSizeBytes = dto.FileSizeBytes,
            RowCount = dto.RowCount,
            Status = dto.Status,
            ArchivalPolicyTag = dto.ArchivalPolicyTag,
            CurrentAccessTier = dto.CurrentAccessTier,
            OverrideFileLifecyclePolicyId = dto.OverrideFileLifecyclePolicyId,
            LastTagsSyncAtEt = dto.LastTagsSyncAtEt,
            CreatedAtEt = dto.CreatedAtEt,
            //CreatedBy = dto.CreatedBy,
            //UpdatedAtEt = dto.UpdatedAtEt,
            //UpdatedBy = dto.UpdatedBy
        };
    }

    // Apply DTO values onto an existing tracked entity (updates only fields we expect to change)
    public static void ApplyToEntity(this ArchivalFileDto dto, ArchivalFileEntity entity)
    {
        if (dto == null) throw new ArgumentNullException(nameof(dto));
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        // Do not change primary key
        // Update fields that are safe to overwrite from DTO
        entity.TableConfigurationId = dto.TableConfigurationId;
        entity.AsOfDate = dto.AsOfDate;
        entity.DateType = dto.DateType;
        entity.StorageAccountName = dto.StorageAccountName;
        entity.ContainerName = dto.ContainerName;
        entity.BlobPath = dto.BlobPath;

        // Metadata that may change after tag operations
        entity.Etag = dto.Etag;
        entity.ContentType = dto.ContentType;
        entity.FileSizeBytes = dto.FileSizeBytes;
        entity.RowCount = dto.RowCount;
        entity.Status = dto.Status;

        // Lifecycle / policy related fields
        entity.ArchivalPolicyTag = dto.ArchivalPolicyTag;
        entity.OverrideFileLifecyclePolicyId = dto.OverrideFileLifecyclePolicyId;
        entity.CurrentAccessTier = dto.CurrentAccessTier;

        // Sync / audit timestamps
        entity.LastTagsSyncAtEt = dto.LastTagsSyncAtEt;

        // Optional audit fields if provided
        if (dto.CreatedAtEt > DateTime.MinValue) entity.CreatedAtEt = dto.CreatedAtEt;
        //if (!string.IsNullOrWhiteSpace(dto.CreatedBy)) entity.CreatedBy = dto.CreatedBy;
        //if (dto.UpdatedAtEt > DateTime.MinValue) entity.UpdatedAtEt = dto.UpdatedAtEt;
        //if (!string.IsNullOrWhiteSpace(dto.UpdatedBy)) entity.UpdatedBy = dto.UpdatedBy;
    }
}