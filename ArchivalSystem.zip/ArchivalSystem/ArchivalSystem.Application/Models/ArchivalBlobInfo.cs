﻿namespace ArchivalSystem.Application.Models
{
    public class ArchivalBlobInfo
    {
        public string StorageAccountName { get; set; } = default!;
        public string ContainerName { get; set; } = default!;
        public string BlobPath { get; set; } = default!;
        public string? ETag { get; set; }
        public string? ContentType { get; set; }
        public long? ContentLength { get; set; }
    }
}
