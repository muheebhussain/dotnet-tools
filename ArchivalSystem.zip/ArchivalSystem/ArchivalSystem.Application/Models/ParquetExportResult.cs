﻿namespace ArchivalSystem.Application.Models;

public sealed class ParquetExportResult
{
    public ParquetExportMetrics? Metrics { get; init; }

    // Blob info for the uploaded object (ETag, length, content type)
    public ArchivalBlobInfo? BlobInfo { get; init; }
    
    public string? AzurePolicyTag { get; set; }
}