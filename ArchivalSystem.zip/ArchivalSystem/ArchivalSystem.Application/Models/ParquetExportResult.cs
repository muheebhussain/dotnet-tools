﻿namespace ArchivalSystem.Application.Models;

public sealed class ParquetExportResult
{
    public ParquetExportMetrics? Metrics { get; init; }

    // Blob info for the uploaded object (ETag, length, content type)
    public ArchivalBlobInfo? BlobInfo { get; init; }

    // If multipart, parts contains per-part blob info (empty for single-file exports).
    public IReadOnlyList<ArchivalBlobInfo>? Parts { get; init; }

    public string? AzurePolicyTag { get; set; }
}