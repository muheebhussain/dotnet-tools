﻿using ArchivalSystem.Data.Entities;

namespace ArchivalSystem.Application.Models;

public static class DtoMappers
{
    public static ArchivalTableConfigurationDto ToDto(this ArchivalTableConfigurationEntity e)
    {
        if (e == null) throw new ArgumentNullException(nameof(e));

        return new ArchivalTableConfigurationDto
        {
            Id = e.Id,
            DatabaseName = e.DatabaseName,
            SchemaName = e.SchemaName,
            TableName = e.TableName,
            AsOfDateColumn = e.AsOfDateColumn,
            ExportMode = e.ExportMode,
            StorageAccountName = e.StorageAccountName,
            ContainerName = e.ContainerName,
            ArchivePathTemplate = e.ArchivePathTemplate,
            DiscoveryPathPrefix = e.DiscoveryPathPrefix,
            TableRetentionPolicyId = e.TableRetentionPolicyId,
            FileLifecyclePolicyId = e.FileLifecyclePolicyId,
            IsActive = e.IsActive,
            DeleteFromSource = e.DeleteFromSource
        };
    }

    public static ArchivalFileLifecyclePolicyDto ToDto(this ArchivalFileLifecyclePolicyEntity e)
    {
        if (e == null) throw new ArgumentNullException(nameof(e));

        return new ArchivalFileLifecyclePolicyDto
        {
            Id = e.Id,
            Name = e.Name,
            IsActive = e.IsActive,
            AzurePolicyTag = e.AzurePolicyTag,
            EodCoolDays = e.EodCoolDays,
            EodArchiveDays = e.EodArchiveDays,
            EodDeleteDays = e.EodDeleteDays,
            EomCoolDays = e.EomCoolDays,
            EomArchiveDays = e.EomArchiveDays,
            EomDeleteDays = e.EomDeleteDays,
            EoqCoolDays = e.EoqCoolDays,
            EoqArchiveDays = e.EoqArchiveDays,
            EoqDeleteDays = e.EoqDeleteDays,
            EoyCoolDays = e.EoyCoolDays,
            EoyArchiveDays = e.EoyArchiveDays,
            EoyDeleteDays = e.EoyDeleteDays,
            ExternalCoolDays = e.ExternalCoolDays,
            ExternalArchiveDays = e.ExternalArchiveDays,
            ExternalDeleteDays = e.ExternalDeleteDays,
            CreatedBy = e.CreatedBy,
            UpdatedBy = e.UpdatedBy
        };
    }
}