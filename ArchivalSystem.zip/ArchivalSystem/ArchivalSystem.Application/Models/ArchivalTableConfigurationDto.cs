﻿using ArchivalSystem.Data;

namespace ArchivalSystem.Application.Models;

public sealed class ArchivalTableConfigurationDto
{
    public int Id { get; init; }
    public string DatabaseName { get; init; } = string.Empty;
    public string SchemaName { get; init; } = string.Empty;
    public string TableName { get; init; } = string.Empty;
    public string? AsOfDateColumn { get; set; }
    public ExportMode ExportMode { get; init; }
    public string StorageAccountName { get; init; } = string.Empty;
    public string ContainerName { get; init; } = string.Empty;
    public string ArchivePathTemplate { get; init; } = string.Empty;
    public string? DiscoveryPathPrefix { get; init; }
    public int? TableRetentionPolicyId { get; init; }
    public int FileLifecyclePolicyId { get; init; }
    public bool IsActive { get; init; }
    public bool DeleteFromSource { get; init; }
}