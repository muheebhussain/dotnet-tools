﻿using ArchivalSystem.Data;

namespace ArchivalSystem.Application.Models;

public sealed class ArchivalFileDto
{
    public long Id { get; set; }

    public int TableConfigurationId { get; set; }
    public DateTime? AsOfDate { get; set; }
    public DateType? DateType { get; set; }

    public string StorageAccountName { get; set; } = default!;
    public string ContainerName { get; set; } = default!;
    public string BlobPath { get; set; } = default!;

    public string? Etag { get; set; }
    public string? ContentType { get; set; }
    public long? FileSizeBytes { get; set; }
    public long? RowCount { get; set; }

    public ArchivalFileStatus Status { get; set; }

    public DateTime CreatedAtEt { get; set; }

    public string? ArchivalPolicyTag { get; set; }
    public string? CurrentAccessTier { get; set; }
    public DateTime? LastTierCheckAtEt { get; set; }

    public int? OverrideFileLifecyclePolicyId { get; set; }
    public DateTime? LastTagsSyncAtEt { get; set; }
}