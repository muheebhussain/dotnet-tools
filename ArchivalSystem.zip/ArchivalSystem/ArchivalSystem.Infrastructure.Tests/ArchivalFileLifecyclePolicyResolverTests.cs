
using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Infrastructure;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using ArchivalSystem.Application.Interfaces;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class ArchivalFileLifecyclePolicyResolverTests
    {
        [Fact]
        public async Task ResolvePolicyForFileAsync_ReturnsOverridePolicy_WhenOverridePresent()
        {
            // Arrange
            var policyEntity = new ArchivalFileLifecyclePolicyEntity
            {
                Id = 123,
                Name = "override",
                AzurePolicyTag = "tag-override",
                IsActive = true
            };

            var mockPolicyRepo = new Mock<IArchivalFileLifecyclePolicyRepository>();
            mockPolicyRepo.Setup(r => r.GetByIdAsync(123, It.IsAny<CancellationToken>()))
                          .ReturnsAsync(policyEntity);

            var mockTableConfigRepo = new Mock<IArchivalTableConfigurationRepository>();

            var resolver = new ArchivalFileLifecyclePolicyResolver(mockPolicyRepo.Object, mockTableConfigRepo.Object);

            var fileDto = new ArchivalFileDto
            {
                Id = 1,
                TableConfigurationId = 10,
                OverrideFileLifecyclePolicyId = 123
            };

            // Act
            var (policyDto, azureTag) = await resolver.ResolvePolicyForFileAsync(fileDto, CancellationToken.None);

            // Assert
            Assert.NotNull(policyDto);
            Assert.Equal(policyEntity.Id, policyDto.Id);
            Assert.Equal(policyEntity.AzurePolicyTag, azureTag);
        }

        [Fact]
        public async Task ResolvePolicyForFileAsync_FallsBackToTablePolicy_WhenOverrideNotProvided()
        {
            // Arrange
            var tablePolicy = new ArchivalFileLifecyclePolicyEntity
            {
                Id = 200,
                Name = "table-policy",
                AzurePolicyTag = "tag-table",
                IsActive = true
            };

            var tableConfig = new ArchivalTableConfigurationEntity
            {
                Id = 10,
                FileLifecyclePolicyId = tablePolicy.Id,
                FileLifecyclePolicy = tablePolicy
            };

            var mockPolicyRepo = new Mock<IArchivalFileLifecyclePolicyRepository>();
            var mockTableConfigRepo = new Mock<IArchivalTableConfigurationRepository>();
            mockTableConfigRepo.Setup(r => r.GetWithRelatedAsync(10, It.IsAny<CancellationToken>()))
                               .ReturnsAsync(tableConfig);

            var resolver = new ArchivalFileLifecyclePolicyResolver(mockPolicyRepo.Object, mockTableConfigRepo.Object);

            var fileDto = new ArchivalFileDto
            {
                Id = 2,
                TableConfigurationId = 10,
                OverrideFileLifecyclePolicyId = null
            };

            // Act
            var (policyDto, azureTag) = await resolver.ResolvePolicyForFileAsync(fileDto, CancellationToken.None);

            // Assert
            Assert.NotNull(policyDto);
            Assert.Equal(tablePolicy.Id, policyDto.Id);
            Assert.Equal(tablePolicy.AzurePolicyTag, azureTag);
        }

        [Fact]
        public async Task ResolvePolicyForFileAsync_Throws_WhenOverrideNotFound()
        {
            // Arrange
            var mockPolicyRepo = new Mock<IArchivalFileLifecyclePolicyRepository>();
            mockPolicyRepo.Setup(r => r.GetByIdAsync(777, It.IsAny<CancellationToken>()))
                          .ReturnsAsync((ArchivalFileLifecyclePolicyEntity?)null);

            var mockTableConfigRepo = new Mock<IArchivalTableConfigurationRepository>();

            var resolver = new ArchivalFileLifecyclePolicyResolver(mockPolicyRepo.Object, mockTableConfigRepo.Object);

            var fileDto = new ArchivalFileDto
            {
                Id = 3,
                TableConfigurationId = 11,
                OverrideFileLifecyclePolicyId = 777
            };

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => resolver.ResolvePolicyForFileAsync(fileDto, CancellationToken.None));
        }

        [Theory]
        [InlineData("EOD")]
        [InlineData("EOM")]
        [InlineData("EOQ")]
        [InlineData("EOY")]
        [InlineData("EXT")]
        public void GetDurationsForDateType_ReturnsExpectedDurations(string dateTypeStr)
        {
            // Arrange - construct a policy DTO with distinct values for each bucket
            var dto = new ArchivalFileLifecyclePolicyDto
            {
                Id = 1,
                Name = "p",
                EodCoolDays = 1,
                EodArchiveDays = 2,
                EodDeleteDays = 3,
                EomCoolDays = 4,
                EomArchiveDays = 5,
                EomDeleteDays = 6,
                EoqCoolDays = 7,
                EoqArchiveDays = 8,
                EoqDeleteDays = 9,
                EoyCoolDays = 10,
                EoyArchiveDays = 11,
                EoyDeleteDays = 12,
                ExternalCoolDays = 13,
                ExternalArchiveDays = 14,
                ExternalDeleteDays = 15
            };

            var mockPolicyRepo = new Mock<IArchivalFileLifecyclePolicyRepository>();
            var mockTableConfigRepo = new Mock<IArchivalTableConfigurationRepository>();
            var resolver = new ArchivalFileLifecyclePolicyResolver(mockPolicyRepo.Object, mockTableConfigRepo.Object);

            DateType? dt = dateTypeStr switch
            {
                "EOD" => DateType.EOD,
                "EOM" => DateType.EOM,
                "EOQ" => DateType.EOQ,
                "EOY" => DateType.EOY,
                "EXT" => DateType.EXT,
                _ => null
            };

            // Act
            var (cool, archive, delete) = resolver.GetDurationsForDateType(dto, dt);

            // Assert
            switch (dt)
            {
                case DateType.EOD:
                    Assert.Equal(1, cool);
                    Assert.Equal(2, archive);
                    Assert.Equal(3, delete);
                    break;

                case DateType.EOM:
                    Assert.Equal(4, cool);
                    Assert.Equal(5, archive);
                    Assert.Equal(6, delete);
                    break;

                case DateType.EOQ:
                    Assert.Equal(7, cool);
                    Assert.Equal(8, archive);
                    Assert.Equal(9, delete);
                    break;

                case DateType.EOY:
                    Assert.Equal(10, cool);
                    Assert.Equal(11, archive);
                    Assert.Equal(12, delete);
                    break;

                case DateType.EXT:
                    Assert.Equal(13, cool);
                    Assert.Equal(14, archive);
                    Assert.Equal(15, delete);
                    break;

                default:
                    throw new InvalidOperationException("Unexpected DateType");
            }
        }
    }
}