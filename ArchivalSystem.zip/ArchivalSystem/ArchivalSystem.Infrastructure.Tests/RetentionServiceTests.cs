using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Infrastructure;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class RetentionServiceTests
    {
        [Fact]
        public async Task ComputeRetentionAsync_Throws_OnNullTableConfig()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => svc.ComputeRetentionAsync(null!, CancellationToken.None));
        }

        [Fact]
        public async Task ComputeRetentionAsync_Throws_WhenAsOfDateColumnMissing()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var dto = new ArchivalTableConfigurationDto
            {
                Id = 1,
                DatabaseName = "db",
                SchemaName = "dbo",
                TableName = "t",
                AsOfDateColumn = null // missing
            };

            await Assert.ThrowsAsync<InvalidOperationException>(() => svc.ComputeRetentionAsync(dto, CancellationToken.None));
        }

        [Fact]
        public async Task ComputeRetentionAsync_ReturnsCandidates_ExcludingKeepDates_Sorted()
        {
            // Arrange
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            // keep set contains 2025-01-02 and 2025-01-04
            var keep = new List<DateOnly> { new DateOnly(2025, 1, 2), new DateOnly(2025, 1, 4) };
            mockRetentionRepo.Setup(r => r.GetKeepSetAsync(10, It.IsAny<CancellationToken>()))
                             .ReturnsAsync((IReadOnlyCollection<DateOnly>)keep);

            // present dates: 2025-01-01,02,03,04
            var present = new List<DateOnly>
            {
                new DateOnly(2025,1,1),
                new DateOnly(2025,1,2),
                new DateOnly(2025,1,3),
                new DateOnly(2025,1,4)
            };
            mockTargetRepo.Setup(t => t.GetDistinctAsOfDatesAsync("db", "sch", "tbl", "as_of", It.IsAny<CancellationToken>()))
                          .ReturnsAsync((IReadOnlyCollection<DateOnly>)present);

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var dto = new ArchivalTableConfigurationDto
            {
                Id = 10,
                DatabaseName = "db",
                SchemaName = "sch",
                TableName = "tbl",
                AsOfDateColumn = "as_of"
            };

            // Act
            var result = await svc.ComputeRetentionAsync(dto, CancellationToken.None);

            // Assert
            Assert.NotNull(result);
            // KeepDates returned sorted ascending
            Assert.Equal(new[] { new DateOnly(2025,1,2), new DateOnly(2025,1,4) }, result.KeepDates);
            // Candidates = present - keep => 2025-01-01, 2025-01-03 (sorted)
            Assert.Equal(new[] { new DateOnly(2025,1,1), new DateOnly(2025,1,3) }, result.CandidateDates);
        }

        [Fact]
        public async Task ComputeRetentionAsync_HandlesEmptyPresentDates()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            mockRetentionRepo.Setup(r => r.GetKeepSetAsync(5, It.IsAny<CancellationToken>()))
                             .ReturnsAsync(new List<DateOnly> { new DateOnly(2025,1,1) });

            mockTargetRepo.Setup(t => t.GetDistinctAsOfDatesAsync("db", "s", "t", "as_of", It.IsAny<CancellationToken>()))
                          .ReturnsAsync(Array.Empty<DateOnly>());

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var dto = new ArchivalTableConfigurationDto
            {
                Id = 5,
                DatabaseName = "db",
                SchemaName = "s",
                TableName = "t",
                AsOfDateColumn = "as_of"
            };

            var result = await svc.ComputeRetentionAsync(dto, CancellationToken.None);

            Assert.NotNull(result);
            Assert.Empty(result.CandidateDates);
            Assert.Equal(new[] { new DateOnly(2025,1,1) }, result.KeepDates);
        }

        [Fact]
        public async Task GetDateTypesAsync_DelegatesToRepository()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            var inputDates = new[] { new DateOnly(2025, 6, 30), new DateOnly(2025, 7, 1) };
            var map = new Dictionary<DateOnly, DateType>
            {
                { inputDates[0], DateType.EOM },
                { inputDates[1], DateType.EOD }
            };

            mockRetentionRepo.Setup(r => r.GetDateTypesAsync(It.Is<IEnumerable<DateOnly>>(d => d.SequenceEqual(inputDates)), It.IsAny<CancellationToken>()))
                             .ReturnsAsync(map);

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var result = await svc.GetDateTypesAsync(inputDates, CancellationToken.None);

            Assert.Equal(2, result.Count);
            Assert.Equal(DateType.EOM, result[inputDates[0]]);
            Assert.Equal(DateType.EOD, result[inputDates[1]]);
        }

        [Fact]
        public async Task GetDateTypeAsync_ReturnsValue_WhenPresent()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            var date = new DateOnly(2025, 12, 31);
            var map = new Dictionary<DateOnly, DateType> { { date, DateType.EOY } };

            mockRetentionRepo.Setup(r => r.GetDateTypesAsync(It.Is<IEnumerable<DateOnly>>(d => d.SequenceEqual(new[] { date })), It.IsAny<CancellationToken>()))
                             .ReturnsAsync(map);

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var result = await svc.GetDateTypeAsync(date, CancellationToken.None);

            Assert.Equal(DateType.EOY, result);
        }

        [Fact]
        public async Task GetDateTypeAsync_ReturnsNull_WhenNotPresent()
        {
            var mockRetentionRepo = new Mock<IRetentionRepository>();
            var mockTargetRepo = new Mock<ITargetTableRepository>();

            var date = new DateOnly(2026, 1, 1);
            mockRetentionRepo.Setup(r => r.GetDateTypesAsync(It.IsAny<IEnumerable<DateOnly>>(), It.IsAny<CancellationToken>()))
                             .ReturnsAsync(new Dictionary<DateOnly, DateType>());

            var svc = new RetentionService(mockRetentionRepo.Object, mockTargetRepo.Object);

            var result = await svc.GetDateTypeAsync(date, CancellationToken.None);

            Assert.Null(result);
        }
    }
}