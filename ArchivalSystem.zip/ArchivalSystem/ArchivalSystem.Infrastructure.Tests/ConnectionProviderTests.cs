using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Infrastructure;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class ConnectionProviderTests
    {
        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("   ")]
        public async Task CreateOpenConnectionAsync_ThrowsArgumentException_WhenDatabaseNameNullOrWhitespace(string dbName)
        {
            // Arrange
            var config = new ConfigurationBuilder().Build();
            var provider = new ConnectionProvider(config);

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentException>(async () =>
                await provider.CreateOpenConnectionAsync(dbName, CancellationToken.None));
        }

        [Fact]
        public async Task CreateOpenConnectionAsync_ThrowsInvalidOperationException_WhenConnectionStringMissing()
        {
            // Arrange: configuration WITHOUT a ConnectionStrings entry for "MissingDb"
            var inMem = new Dictionary<string, string>
            {
                // intentionally not adding "ConnectionStrings:MissingDb"
                { "SomeOtherKey", "value" }
            };
            var config = new ConfigurationBuilder().AddInMemoryCollection(inMem).Build();
            var provider = new ConnectionProvider(config);

            // Act & Assert
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
                await provider.CreateOpenConnectionAsync("MissingDb", CancellationToken.None));

            Assert.Contains("No connection string", ex.Message, StringComparison.OrdinalIgnoreCase);
        }
    }
}