using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Infrastructure;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class SelfManagedTableArchiverTests
    {
        private static ArchivalTableConfigurationDto MakeTableDto(int id, string? asOfDateColumn = "as_of")
            => new()
            {
                Id = id,
                DatabaseName = "db",
                SchemaName = "dbo",
                TableName = "t",
                AsOfDateColumn = asOfDateColumn,
                ExportMode = ExportMode.SelfManaged,
                StorageAccountName = "acct",
                ContainerName = "c",
                ArchivePathTemplate = "/{db}/{schema}/{table}/{yyyy}/{MM}/{dd}"
            };

        [Fact]
        public async Task ArchiveAsync_Throws_When_TableConfigIsNull()
        {
            var mockRetention = new Mock<IRetentionService>();
            var mockDbArchiver = new Mock<IDbArchiver>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            await Assert.ThrowsAsync<ArgumentNullException>(() => sut.ArchiveAsync(null!, 1, CancellationToken.None));
        }

        [Fact]
        public async Task ArchiveAsync_Throws_When_AsOfDateColumnMissing()
        {
            var mockRetention = new Mock<IRetentionService>();
            var mockDbArchiver = new Mock<IDbArchiver>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            var dto = MakeTableDto(1, asOfDateColumn: null);

            await Assert.ThrowsAsync<InvalidOperationException>(() => sut.ArchiveAsync(dto, 1, CancellationToken.None));
        }

        [Fact]
        public async Task ArchiveAsync_LogsSkippedAndReturns_When_NoCandidateDates()
        {
            var dto = MakeTableDto(2);
            var runId = 10L;

            var mockRetention = new Mock<IRetentionService>();
            mockRetention
                .Setup(r => r.ComputeRetentionAsync(dto, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new RetentionResult
                {
                    KeepDates = Array.Empty<DateOnly>(),
                    CandidateDates = Array.Empty<DateOnly>()
                });

            var mockDbArchiver = new Mock<IDbArchiver>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(runId, dto.Id, null, null, RunDetailPhase.Export, RunDetailStatus.Skipped, null, null, null, "No candidate dates for archival (nothing to export).", It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L);

            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            await sut.ArchiveAsync(dto, runId, CancellationToken.None);

            mockDbArchiver.Verify(d => d.ArchiveTableForDateAsync(It.IsAny<ArchivalTableConfigurationDto>(), It.IsAny<DateTime>(), It.IsAny<DateType>(), It.IsAny<long>(), It.IsAny<CancellationToken>()), Times.Never);
            mockRunRepo.Verify(r => r.LogDetailAsync(runId, dto.Id, null, null, RunDetailPhase.Export, RunDetailStatus.Skipped, null, null, null, "No candidate dates for archival (nothing to export).", It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task ArchiveAsync_Calls_DbArchiver_ForEachCandidate_WithResolvedDateTypes()
        {
            var dto = MakeTableDto(3);
            var runId = 20L;

            var candidates = new[] { new DateOnly(2025, 1, 1), new DateOnly(2025, 1, 2) };

            var mockRetention = new Mock<IRetentionService>();
            mockRetention.Setup(r => r.ComputeRetentionAsync(dto, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new RetentionResult
                {
                    KeepDates = Array.Empty<DateOnly>(),
                    CandidateDates = candidates
                });

            // date types mapping: first -> EOD, second -> EOM
            var dateTypeMap = new Dictionary<DateOnly, DateType>
            {
                [candidates[0]] = DateType.EOD,
                [candidates[1]] = DateType.EOM
            };

            mockRetention.Setup(r => r.GetDateTypesAsync(It.Is<IEnumerable<DateOnly>>(d => d.SequenceEqual(candidates)), It.IsAny<CancellationToken>()))
                .ReturnsAsync(dateTypeMap);

            var mockDbArchiver = new Mock<IDbArchiver>();
            mockDbArchiver.Setup(d => d.ArchiveTableForDateAsync(dto, candidates[0].ToDateTime(TimeOnly.MinValue), DateType.EOD, runId, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
            mockDbArchiver.Setup(d => d.ArchiveTableForDateAsync(dto, candidates[1].ToDateTime(TimeOnly.MinValue), DateType.EOM, runId, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask)
                .Verifiable();

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            await sut.ArchiveAsync(dto, runId, CancellationToken.None);

            mockDbArchiver.Verify(d => d.ArchiveTableForDateAsync(dto, candidates[0].ToDateTime(TimeOnly.MinValue), DateType.EOD, runId, It.IsAny<CancellationToken>()), Times.Once);
            mockDbArchiver.Verify(d => d.ArchiveTableForDateAsync(dto, candidates[1].ToDateTime(TimeOnly.MinValue), DateType.EOM, runId, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task ArchiveAsync_Continues_When_DbArchiverThrows_NonCancellation()
        {
            var dto = MakeTableDto(4);
            var runId = 30L;

            var candidates = new[] { new DateOnly(2025, 2, 1), new DateOnly(2025, 2, 2) };

            var mockRetention = new Mock<IRetentionService>();
            mockRetention.Setup(r => r.ComputeRetentionAsync(dto, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new RetentionResult { KeepDates = Array.Empty<DateOnly>(), CandidateDates = candidates });

            mockRetention.Setup(r => r.GetDateTypesAsync(It.IsAny<IEnumerable<DateOnly>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(candidates.ToDictionary(d => d, d => DateType.EOD));

            var mockDbArchiver = new Mock<IDbArchiver>();
            // first call throws generic exception
            mockDbArchiver.SetupSequence(d => d.ArchiveTableForDateAsync(dto, It.IsAny<DateTime>(), It.IsAny<DateType>(), runId, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("boom"))
                .Returns(Task.CompletedTask);

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Should not throw: first error is caught and processing continues to second date
            await sut.ArchiveAsync(dto, runId, CancellationToken.None);

            // Verify db archiver called twice (once threw, once succeeded)
            mockDbArchiver.Verify(d => d.ArchiveTableForDateAsync(dto, It.IsAny<DateTime>(), It.IsAny<DateType>(), runId, It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task ArchiveAsync_Propagates_OperationCanceledException()
        {
            var dto = MakeTableDto(5);
            var runId = 40L;

            var candidates = new[] { new DateOnly(2025, 3, 1) };

            var mockRetention = new Mock<IRetentionService>();
            mockRetention.Setup(r => r.ComputeRetentionAsync(dto, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new RetentionResult { KeepDates = Array.Empty<DateOnly>(), CandidateDates = candidates });

            mockRetention.Setup(r => r.GetDateTypesAsync(It.IsAny<IEnumerable<DateOnly>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new Dictionary<DateOnly, DateType>());

            var mockDbArchiver = new Mock<IDbArchiver>();
            mockDbArchiver.Setup(d => d.ArchiveTableForDateAsync(dto, It.IsAny<DateTime>(), It.IsAny<DateType>(), runId, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new OperationCanceledException());

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SelfManagedTableArchiver>>();

            var sut = new SelfManagedTableArchiver(
                mockRetention.Object,
                mockDbArchiver.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            await Assert.ThrowsAsync<OperationCanceledException>(() => sut.ArchiveAsync(dto, runId, CancellationToken.None));
        }
    }
}