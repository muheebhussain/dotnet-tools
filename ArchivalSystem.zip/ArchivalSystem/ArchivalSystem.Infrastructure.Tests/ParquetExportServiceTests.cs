using System;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Abstraction;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Infrastructure;
using ArchivalSystem.Data;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class ParquetExportServiceTests
    {
        [Fact]
        public async Task ExportTableToStreamAsync_WritesParquet_ForRows()
        {
            // Arrange
            var dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("When", typeof(DateTime));

            dt.Rows.Add(1, "alice", new DateTime(2025,1,1));
            dt.Rows.Add(2, "bob", new DateTime(2025,1,2));
            dt.Rows.Add(3, "carol", new DateTime(2025,1,3));

            // DataTableReader implements DbDataReader
            var reader = dt.CreateDataReader();

            var mockConn = new Mock<DbConnection>(); // used only for disposal by TableQueryResult
            var tableQueryResult = new TableQueryResult(mockConn.Object, reader);

            var mockRepo = new Mock<ITargetTableRepository>();
            mockRepo
                .Setup(r => r.ExecuteQueryAsync("db", "dbo", "t", "as_of", It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(tableQueryResult);

            var svc = new ParquetExportService(mockRepo.Object);

            await using var ms = new MemoryStream();

            // Act
            var metrics = await svc.ExportTableToStreamAsync(
                "db",
                "dbo",
                "t",
                "as_of",
                new DateTime(2025, 1, 1),
                ms,
                CancellationToken.None);

            // Assert
            Assert.NotNull(metrics);
            Assert.Equal(3, metrics.RowCount);
            Assert.Equal(3, metrics.ColumnCount); // Id, Name, When
            Assert.True(metrics.SizeBytes > 0, "Parquet output should have positive size.");
            Assert.True(ms.Length > 0, "Output stream should have data.");
        }

        [Fact]
        public async Task ExportTableToStreamAsync_ReturnsZeroMetrics_WhenNoRows()
        {
            // Arrange: empty table (schema only)
            var dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));

            // no rows
            var reader = dt.CreateDataReader();

            var mockConn = new Mock<DbConnection>();
            var tableQueryResult = new TableQueryResult(mockConn.Object, reader);

            var mockRepo = new Mock<ITargetTableRepository>();
            mockRepo
                .Setup(r => r.ExecuteQueryAsync("db", "dbo", "t", "as_of", It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(tableQueryResult);

            var svc = new ParquetExportService(mockRepo.Object);

            await using var ms = new MemoryStream();

            // Act
            var metrics = await svc.ExportTableToStreamAsync(
                "db",
                "dbo",
                "t",
                "as_of",
                DateTime.UtcNow,
                ms,
                CancellationToken.None);

            // Assert
            Assert.NotNull(metrics);
            Assert.Equal(0, metrics.RowCount);
            Assert.Equal(2, metrics.ColumnCount); // two columns in schema
            Assert.True(metrics.SizeBytes >= 0, "SizeBytes should be returned (>=0) for seekable stream.");
            Assert.True(ms.Length > 0, "Even empty parquet with schema should write footer/header and be non-empty.");
        }

        [Fact]
        public async Task ExportTableToStreamAsync_Throws_ForNonWritableStream()
        {
            // Arrange
            var mockRepo = new Mock<ITargetTableRepository>();
            var svc = new ParquetExportService(mockRepo.Object);

            // create non-writable MemoryStream
            var buffer = new byte[0];
            using var nonWritable = new MemoryStream(buffer, writable: false);

            // Act / Assert
            await Assert.ThrowsAsync<ArgumentException>(async () =>
                await svc.ExportTableToStreamAsync(
                    "db",
                    "dbo",
                    "t",
                    "as_of",
                    DateTime.UtcNow,
                    nonWritable,
                    CancellationToken.None));
        }
    }
}