using ArchivalSystem.Data;
using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class ExternalTableArchiverTests
    {
        private static ArchivalTableConfigurationDto MakeExternalDto(int id) =>
            new ArchivalTableConfigurationDto
            {
                Id = id,
                ExportMode = ExportMode.External,
                StorageAccountName = "acct",
                ContainerName = "container",
                DiscoveryPathPrefix = "prefix/"
            };

        [Fact]
        public async Task ArchiveAsync_OnSuccess_CallsRegistrar_And_LogsLifecycleSuccess()
        {
            // Arrange
            var dto = MakeExternalDto(42);
            var runId = 123L;
            var registeredCount = 5;

            var mockRegistrar = new Mock<IExternalFileRegistrar>();
            mockRegistrar
                .Setup(m => m.DiscoverAndRegisterAsync(dto.Id, runId, It.IsAny<CancellationToken>()))
                .ReturnsAsync(registeredCount);

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(
                    runId,
                    dto.Id,
                    It.IsAny<DateTime?>(),
                    It.IsAny<DateType?>(),
                    RunDetailPhase.Lifecycle,
                    RunDetailStatus.Success,
                    It.IsAny<long?>(),
                    It.IsAny<long?>(),
                    It.IsAny<string?>(),
                    It.IsAny<string?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L);

            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<ExternalTableArchiver>>();

            var sut = new ExternalTableArchiver(
                mockRegistrar.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            await sut.ArchiveAsync(dto, runId, CancellationToken.None);

            // Assert
            mockRegistrar.Verify(m => m.DiscoverAndRegisterAsync(dto.Id, runId, It.IsAny<CancellationToken>()), Times.Once);

            // verify lifecycle run detail is logged with expected rowsAffected and filePath
            mockRunRepo.Verify(r => r.LogDetailAsync(
                runId,
                dto.Id,
                It.Is<DateTime?>(d => d == null),
                It.Is<DateType?>(dt => dt == null),
                RunDetailPhase.Lifecycle,
                RunDetailStatus.Success,
                It.IsAny<long?>(),
                It.Is<long?>(rows => rows == registeredCount),
                It.Is<string>(p => p == dto.DiscoveryPathPrefix),
                It.Is<string?>(s => s == null),
                It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task ArchiveAsync_WhenRegistrarThrows_LogsFailure_And_Rethrows()
        {
            // Arrange
            var dto = MakeExternalDto(77);
            var runId = 999L;

            var ex = new InvalidOperationException("boom");

            var mockRegistrar = new Mock<IExternalFileRegistrar>();
            mockRegistrar
                .Setup(m => m.DiscoverAndRegisterAsync(dto.Id, runId, It.IsAny<CancellationToken>()))
                .ThrowsAsync(ex);

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(
                    runId,
                    dto.Id,
                    It.IsAny<DateTime?>(),
                    It.IsAny<DateType?>(),
                    RunDetailPhase.Lifecycle,
                    RunDetailStatus.Failed,
                    It.IsAny<long?>(),
                    It.IsAny<long?>(),
                    It.IsAny<string?>(),
                    It.IsAny<string?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L);

            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<ExternalTableArchiver>>();

            var sut = new ExternalTableArchiver(
                mockRegistrar.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act & Assert
            var thrown = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                sut.ArchiveAsync(dto, runId, CancellationToken.None));

            Assert.Same(ex, thrown);

            // verify failure was logged with filePath and error message contains exception text
            mockRunRepo.Verify(r => r.LogDetailAsync(
                runId,
                dto.Id,
                It.Is<DateTime?>(d => d == null),
                It.Is<DateType?>(dt => dt == null),
                RunDetailPhase.Lifecycle,
                RunDetailStatus.Failed,
                It.IsAny<long?>(),
                It.IsAny<long?>(),
                It.Is<string>(p => p == dto.DiscoveryPathPrefix),
                It.Is<string>(msg => msg != null && msg.Contains("boom")),
                It.IsAny<CancellationToken>()),
                Times.Once);
        }
    }
}