using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Infrastructure;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class SourceExporterTests
    {
        private static ArchivalTableConfigurationDto MakeTableDto(int id) =>
            new ArchivalTableConfigurationDto
            {
                Id = id,
                DatabaseName = "db",
                SchemaName = "dbo",
                TableName = "t",
                AsOfDateColumn = "as_of",
                ExportMode = ExportMode.SelfManaged,
                StorageAccountName = "acct",
                ContainerName = "container",
                ArchivePathTemplate = "/{db}/{schema}/{table}/{yyyy}/{MM}/{dd}"
            };

        [Fact]
        public async Task ExportAsync_Throws_When_AsOfDateColumnMissing()
        {
            // Arrange
            var dto = MakeTableDto(1);
            dto.AsOfDateColumn = null; 
            var mockParquet = new Mock<IParquetExportService>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLifecycle = new Mock<ILifecyclePolicyResolver>();
            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockBlob = new Mock<IBlobStorageService>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SourceExporter>>();

            var sut = new SourceExporter(
                mockParquet.Object,
                mockRunRepo.Object,
                mockLifecycle.Object,
                mockFileRepo.Object,
                mockBlob.Object,
                mockLogger.Object);

            // Act / Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                sut.ExportAsync(dto, DateTime.UtcNow, DateType.EOD, runId: 1, CancellationToken.None));
        }

        [Fact]
        public async Task ExportAsync_Success_WritesBlob_CallsExporter_And_LogsSuccess()
        {
            // Arrange
            var dto = MakeTableDto(2);
            var asOf = new DateTime(2025, 11, 27);
            var runId = 55L;

            var expectedAzureTag = "policy-tag";
            var policyDto = new ArchivalFileLifecyclePolicyDto { Id = 11, AzurePolicyTag = expectedAzureTag };

            var metrics = new ParquetExportMetrics { RowCount = 42, ColumnCount = 3, SizeBytes = 12345 };

            var returnedBlob = new ArchivalBlobInfo
            {
                StorageAccountName = dto.StorageAccountName,
                ContainerName = dto.ContainerName,
                BlobPath = BlobStorageHelper.BuildBlobPath(dto, asOf, DateType.EOD),
                ETag = "etag-1",
                ContentType = "application/octet-stream",
                ContentLength = 12345
            };

            var mockParquet = new Mock<IParquetExportService>();
            mockParquet
                .Setup(p => p.ExportTableToStreamAsync(dto.DatabaseName, dto.SchemaName, dto.TableName, dto.AsOfDateColumn!, asOf, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(metrics);

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(runId, dto.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Success,0,metrics.RowCount, It.IsAny<string?>(), null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L);

            var mockLifecycle = new Mock<ILifecyclePolicyResolver>();
            mockLifecycle
                .Setup(l => l.ResolvePolicyForTableAsync(dto.Id, It.IsAny<CancellationToken>()))
                .ReturnsAsync((policyDto, expectedAzureTag));

            var mockFileRepo = new Mock<IArchivalFileRepository>();
            mockFileRepo
                .Setup(f => f.IsFileExemptAsync(dto.Id, asOf.Date, It.IsAny<CancellationToken>()))
                .ReturnsAsync(true);

            ArchivalBlobInfo capturedBlobInfo = null;
            IDictionary<string, string> capturedTags = null;

            var mockBlob = new Mock<IBlobStorageService>();
            mockBlob
                .Setup(b => b.UploadFromStreamAsync(
                    dto.StorageAccountName,
                    dto.ContainerName,
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Func<Stream, CancellationToken, Task>>(),
                    It.IsAny<IDictionary<string, string>>(),
                    It.IsAny<bool>(),
                    It.IsAny<CancellationToken>()))
                .Returns(async (string account, string container, string path, string contentType, Func<Stream, CancellationToken, Task> writer, IDictionary<string, string> tags, bool overwrite, CancellationToken ct) =>
                {
                    // capture tags and simulate writer invocation
                    capturedTags = new Dictionary<string, string>(tags);
                    using var ms = new MemoryStream();
                    await writer(ms, ct);
                    // return blob info (path must match expected)
                    capturedBlobInfo = new ArchivalBlobInfo
                    {
                        StorageAccountName = account,
                        ContainerName = container,
                        BlobPath = path,
                        ETag = "etag-1",
                        ContentType = contentType,
                        ContentLength = ms.Length
                    };
                    return capturedBlobInfo;
                });

            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SourceExporter>>();

            var sut = new SourceExporter(
                mockParquet.Object,
                mockRunRepo.Object,
                mockLifecycle.Object,
                mockFileRepo.Object,
                mockBlob.Object,
                mockLogger.Object);

            // Act
            var result = await sut.ExportAsync(dto, asOf, DateType.EOD, runId, CancellationToken.None);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.BlobInfo);
            Assert.Equal(returnedBlob.StorageAccountName, result.BlobInfo.StorageAccountName);
            Assert.Equal(metrics.RowCount, result.Metrics?.RowCount);
            Assert.Equal(expectedAzureTag, result.AzurePolicyTag);

            // Verify exporter was invoked
            mockParquet.Verify(p => p.ExportTableToStreamAsync(dto.DatabaseName, dto.SchemaName, dto.TableName, dto.AsOfDateColumn!, asOf, It.IsAny<Stream>(), It.IsAny<CancellationToken>()), Times.Once);

            // Verify blob upload invoked and tags contained expected entries
            mockBlob.Verify(b => b.UploadFromStreamAsync(dto.StorageAccountName, dto.ContainerName, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Func<Stream, CancellationToken, Task>>(), It.IsAny<IDictionary<string,string>>(), true, It.IsAny<CancellationToken>()), Times.Once);
            Assert.NotNull(capturedTags);
            Assert.Equal(dto.Id.ToString(), capturedTags["archival_table_configuration_id"]);
            Assert.Equal(asOf.ToString("yyyy-MM-dd"), capturedTags["archival_date"]);
            Assert.Equal("true", capturedTags["archival_exempt"]);
            Assert.Equal(expectedAzureTag, capturedTags["archival_policy"]);

            // Verify run detail logged as success
            mockRunRepo.Verify(r => r.LogDetailAsync(runId, dto.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Success,0, metrics.RowCount, It.IsAny<string?>(), null, It.IsAny<CancellationToken>()), Times.Once);
            Assert.Equal(expectedAzureTag, result.AzurePolicyTag);
        }

        [Fact]
        public async Task ExportAsync_WhenUploadFails_LogsFailedAndRethrows()
        {
            // Arrange
            var dto = MakeTableDto(3);
            var asOf = new DateTime(2025, 12, 1);
            var runId = 77L;

            var policyDto = new ArchivalFileLifecyclePolicyDto { Id = 11, AzurePolicyTag = "p" };
            var mockLifecycle = new Mock<ILifecyclePolicyResolver>();
            mockLifecycle.Setup(l => l.ResolvePolicyForTableAsync(dto.Id, It.IsAny<CancellationToken>()))
                         .ReturnsAsync((policyDto, "p"));

            var mockFileRepo = new Mock<IArchivalFileRepository>();
            mockFileRepo.Setup(f => f.IsFileExemptAsync(dto.Id, asOf.Date, It.IsAny<CancellationToken>())).ReturnsAsync(false);

            var mockParquet = new Mock<IParquetExportService>();

            var mockBlob = new Mock<IBlobStorageService>();
            mockBlob
                .Setup(b => b.UploadFromStreamAsync(
                    dto.StorageAccountName,
                    dto.ContainerName,
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Func<Stream, CancellationToken, Task>>(),
                    It.IsAny<IDictionary<string, string>>(),
                    It.IsAny<bool>(),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("upload failed"));

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(runId, dto.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Failed, 0,null, null, It.IsAny<string>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L);

            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<SourceExporter>>();

            var sut = new SourceExporter(
                mockParquet.Object,
                mockRunRepo.Object,
                mockLifecycle.Object,
                mockFileRepo.Object,
                mockBlob.Object,
                mockLogger.Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => sut.ExportAsync(dto, asOf, DateType.EOD, runId, CancellationToken.None));

            // Verify failure logged
            mockRunRepo.Verify(r => r.LogDetailAsync(runId, dto.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Failed, null, null,It.IsAny<string>(), It.Is<string>(s => s.Contains("upload failed")), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}