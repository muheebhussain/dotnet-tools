using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using Moq;
using Xunit;
using Microsoft.Extensions.Logging;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class SourceDataDeleterTests
    {
        private static ArchivalTableConfigurationDto MakeTableConfigDto()
            => new()
            {
                Id = 99,
                DatabaseName = "MyDb",
                SchemaName = "dbo",
                TableName = "MyTable",
                AsOfDateColumn = "as_of_date"
            };

        [Fact]
        public async Task DeleteAsync_Throws_OnNullTableConfig()
        {
            // Arrange
            var mockTargetRepo = new Mock<ITargetTableRepository>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<ILogger<SourceDataDeleter>>();

            var sut = new SourceDataDeleter(
                mockTargetRepo.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act / Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                sut.DeleteAsync(null!, DateTime.UtcNow, expectedRowCount: 0, runId: 1, DateType.EOD, CancellationToken.None));
        }

        [Fact]
        public async Task DeleteAsync_Throws_WhenAsOfDateColumnMissing()
        {
            // Arrange
            var cfg = MakeTableConfigDto();
            cfg.AsOfDateColumn = null; // missing

            var mockTargetRepo = new Mock<ITargetTableRepository>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<ILogger<SourceDataDeleter>>();

            var sut = new SourceDataDeleter(
                mockTargetRepo.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act / Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                sut.DeleteAsync(cfg, DateTime.UtcNow, expectedRowCount: 0, runId: 1, DateType.EOD, CancellationToken.None));
        }

        [Fact]
        public async Task DeleteAsync_CallsRepository_LogsSuccess_WhenRowCountsMatch()
        {
            // Arrange
            var cfg = MakeTableConfigDto();
            var asOf = new DateTime(2025, 11, 27);
            const long expected = 123L;
            const long runId = 7L;

            var mockTargetRepo = new Mock<ITargetTableRepository>();
            mockTargetRepo
                .Setup(r => r.DeleteByAsOfDateAsync(
                    cfg.DatabaseName,
                    cfg.SchemaName,
                    cfg.TableName,
                    cfg.AsOfDateColumn!,
                    asOf,
                    It.IsAny<int>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected)
                .Verifiable();

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(
                    runId,
                    cfg.Id,
                    asOf,
                    DateType.EOD,
                    RunDetailPhase.Delete,
                    RunDetailStatus.Success,
                    It.Is<long?>(v => v == expected),
                    It.IsAny<long?>(),
                    It.Is<string?>(s => s == null),
                    "",
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(1L)
                .Verifiable();

            var mockLogger = new Mock<ILogger<SourceDataDeleter>>();

            var sut = new SourceDataDeleter(
                mockTargetRepo.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            var deleted = await sut.DeleteAsync(cfg, asOf, expectedRowCount: expected, runId: runId, dateType: DateType.EOD, ct: CancellationToken.None);

            // Assert
            Assert.Equal(expected, deleted);

            mockTargetRepo.Verify(r => r.DeleteByAsOfDateAsync(
                cfg.DatabaseName, cfg.SchemaName, cfg.TableName, cfg.AsOfDateColumn!, asOf, It.Is<int>(i => i == 50_000), It.IsAny<CancellationToken>()), Times.Once);

            mockRunRepo.Verify();
        }

        [Fact]
        public async Task DeleteAsync_LogsErrorMessage_WhenRowCountMismatch()
        {
            // Arrange
            var cfg = MakeTableConfigDto();
            var asOf = new DateTime(2025, 12, 01);
            const long expected = 200L;
            const long actualDeleted = 150L;
            const long runId = 8L;

            var mockTargetRepo = new Mock<ITargetTableRepository>();
            mockTargetRepo
                .Setup(r => r.DeleteByAsOfDateAsync(
                    cfg.DatabaseName,
                    cfg.SchemaName,
                    cfg.TableName,
                    cfg.AsOfDateColumn!,
                    asOf,
                    It.IsAny<int>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(actualDeleted);

            var capturedError = string.Empty;
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo
                .Setup(r => r.LogDetailAsync(
                    runId,
                    cfg.Id,
                    asOf,
                    DateType.EOD,
                    RunDetailPhase.Delete,
                    RunDetailStatus.Success,
                    It.Is<long?>(v => v == actualDeleted),
                    It.IsAny<long?>(),
                    It.IsAny<string?>(),
                    It.IsAny<string?>(),
                    It.IsAny<CancellationToken>()))
                .Callback<long, int, DateTime?, DateType?, RunDetailPhase, RunDetailStatus, long?, string?, string?, CancellationToken>(
                    (run, tableId, a, dt, phase, status, rows, path, err, ct) =>
                    {
                        capturedError = err ?? string.Empty;
                    })
                .ReturnsAsync(1L)
                .Verifiable();

            var mockLogger = new Mock<ILogger<SourceDataDeleter>>();
            mockLogger.Setup(l => l.Log(
                    It.IsAny<Microsoft.Extensions.Logging.LogLevel>(),
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception?>(),
                    (Func<It.IsAnyType, Exception?, string>)It.IsAny<object>()))
                .Verifiable(); // just allow

            var sut = new SourceDataDeleter(
                mockTargetRepo.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            var deleted = await sut.DeleteAsync(cfg, asOf, expectedRowCount: expected, runId: runId, dateType: DateType.EOD, ct: CancellationToken.None);

            // Assert
            Assert.Equal(actualDeleted, deleted);

            mockRunRepo.Verify();
            Assert.Contains("Row count mismatch", capturedError);
        }
    }
}