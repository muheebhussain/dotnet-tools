using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using ArchivalSystem.Infrastructure;
using ArchivalSystem.Application.Models;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class BlobStorageServiceTests
    {
        [Fact]
        public async Task ListBlobsAsync_UnknownAccount_ThrowsInvalidOperationException()
        {
            // Arrange - options contain no account with name "missing-account"
            var options = Options.Create(new BlobStorageOptions
            {
                Accounts = new[]
                {
                    new BlobStorageAccountOptions { StorageAccountName = "other-account", ConnectionString = "UseDevelopmentStorage=true" }
                }
            });

            var svc = new BlobStorageService(options);

            // Act / Assert
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
                await svc.ListBlobsAsync("missing-account", "container", prefix: null, ct: CancellationToken.None));

            Assert.Contains("No connection string configured for storage account", ex.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task OpenWriteStreamAsync_UnknownAccount_ThrowsInvalidOperationException()
        {
            // Arrange - options do not include the requested account
            var options = Options.Create(new BlobStorageOptions
            {
                Accounts = Array.Empty<BlobStorageAccountOptions>()
            });

            var svc = new BlobStorageService(options);

            // Act / Assert
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
                await svc.OpenWriteStreamAsync("not-configured", "container", "path", overwrite: true, contentType: null, ct: CancellationToken.None));

            Assert.Contains("No connection string configured for storage account", ex.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task UploadFromStreamAsync_NullWriter_ThrowsArgumentNullException()
        {
            // Arrange - provide at least one account so GetServiceClient would succeed if reached.
            var options = Options.Create(new BlobStorageOptions
            {
                Accounts = new[]
                {
                    new BlobStorageAccountOptions { StorageAccountName = "acct", ConnectionString = "UseDevelopmentStorage=true" }
                }
            });

            var svc = new BlobStorageService(options);

            // Act / Assert - writer is null -> immediate ArgumentNullException
            await Assert.ThrowsAsync<ArgumentNullException>(async () =>
                await svc.UploadFromStreamAsync(
                    storageAccountName: "acct",
                    containerName: "c",
                    blobPath: "p",
                    contentType: "application/octet-stream",
                    writer: null!, // explicit null
                    tags: null,
                    overwrite: true,
                    ct: CancellationToken.None));
        }
    }
}