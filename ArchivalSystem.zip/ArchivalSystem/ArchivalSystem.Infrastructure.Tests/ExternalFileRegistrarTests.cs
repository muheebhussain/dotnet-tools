using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using ArchivalSystem.Infrastructure;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class ExternalFileRegistrarTests
    {
        private static ArchivalTableConfigurationEntity MakeExternalTableConfig(int id)
            => new()
            {
                Id = id,
                ExportMode = ExportMode.External,
                StorageAccountName = "acct",
                ContainerName = "container",
                DiscoveryPathPrefix = "prefix/",
                FileLifecyclePolicyId = 11,
                FileLifecyclePolicy = new ArchivalFileLifecyclePolicyEntity { Id = 11, AzurePolicyTag = "policy-tag" }
            };

        private static ArchivalBlobInfo MakeBlob(string path, long length = 123)
            => new()
            {
                StorageAccountName = "acct",
                ContainerName = "container",
                BlobPath = path,
                ETag = "etag-" + path,
                ContentType = "application/octet-stream",
                ContentLength = length
            };

        [Fact]
        public async Task DiscoverAndRegisterAsync_NoBlobs_LogsSkippedAndReturnsZero()
        {
            // Arrange
            var tableId = 5;
            var runId = 101L;

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            mockTableRepo.Setup(r => r.GetWithRelatedAsync(tableId, It.IsAny<CancellationToken>()))
                         .ReturnsAsync(MakeExternalTableConfig(tableId));

            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockBlobStorage = new Mock<IBlobStorageService>();
            mockBlobStorage.Setup(s => s.ListBlobsAsync("acct", "container", "prefix/", It.IsAny<CancellationToken>()))
                           .ReturnsAsync(Array.Empty<ArchivalBlobInfo>());

            var mockPolicyResolver = new Mock<ILifecyclePolicyResolver>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();

            var sut = new ExternalFileRegistrar(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockBlobStorage.Object,
                mockPolicyResolver.Object,
                mockRunRepo.Object);

            // Act
            var result = await sut.DiscoverAndRegisterAsync(tableId, runId, CancellationToken.None);

            // Assert
            Assert.Equal(0, result);
            //mockRunRepo.Verify(r => r.LogDetailAsync(
            //    runId,
            //    tableId,
            //    asOfDate: null,
            //    dateType: null,
            //    phase: RunDetailPhase.Discover,
            //    status: RunDetailStatus.Skipped,
            //    filePath: "prefix/",
            //    errorMessage: "No blobs discovered for External configuration.",
            //    It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task DiscoverAndRegisterAsync_CreatesNewFiles_SetsTags_AndInsertsRunDetails()
        {
            // Arrange
            var tableId = 7;
            var runId = 202L;

            var tableConfig = MakeExternalTableConfig(tableId);

            var blobs = new[]
            {
                MakeBlob("external/systemA/2025/11/27/file1.ext"),
                MakeBlob("external/systemA/2025/11/28/file2.ext")
            };

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            mockTableRepo.Setup(r => r.GetWithRelatedAsync(tableId, It.IsAny<CancellationToken>()))
                         .ReturnsAsync(tableConfig);

            var mockBlobStorage = new Mock<IBlobStorageService>();
            mockBlobStorage.Setup(s => s.ListBlobsAsync(tableConfig.StorageAccountName, tableConfig.ContainerName, It.IsAny<string>(), It.IsAny<CancellationToken>()))
                           .ReturnsAsync(blobs);

            var mockFileRepo = new Mock<IArchivalFileRepository>();
            // Initially no existing files
            mockFileRepo.SetupSequence(r => r.GetByBlobPathsAsync(tableId, It.IsAny<IEnumerable<string>>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new List<ArchivalFileEntity>()) // before insert
                        .ReturnsAsync(() =>
                        {
                            // after UpdateFilesAsync, return entities with Ids
                            return blobs.Select((b, i) => new ArchivalFileEntity
                            {
                                Id = i + 100,
                                TableConfigurationId = tableId,
                                BlobPath = b.BlobPath,
                                StorageAccountName = b.StorageAccountName,
                                ContainerName = b.ContainerName,
                                Etag = b.ETag,
                                ContentType = b.ContentType,
                                FileSizeBytes = b.ContentLength
                            }).ToList();
                        });

            mockFileRepo.Setup(r => r.GetFileExemptionDatesAsync(tableId, It.IsAny<IEnumerable<DateOnly>>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new HashSet<DateOnly>());

            mockFileRepo.Setup(r => r.UpdateFilesAsync(It.IsAny<IEnumerable<ArchivalFileEntity>>(), It.IsAny<CancellationToken>()))
                        .Returns(Task.CompletedTask);

            mockFileRepo.Setup(r => r.GetByTableConfigurationIdAsync(tableId, It.IsAny<bool>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new List<ArchivalFileEntity>()); // not used here

            mockFileRepo.Setup(r => r.BulkSetTagsAndSyncTimeAsync(It.IsAny<IEnumerable<long>>(), It.IsAny<string?>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(0);

            var mockPolicyResolver = new Mock<ILifecyclePolicyResolver>();
            mockPolicyResolver.Setup(p => p.ResolvePolicyForTableAsync(tableId, It.IsAny<CancellationToken>()))
                              .ReturnsAsync((tableConfig.FileLifecyclePolicy.ToDto(), tableConfig.FileLifecyclePolicy.AzurePolicyTag));

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo.Setup(r => r.ArchivalRunDetailBulkInsertAsync(It.IsAny<IEnumerable<ArchivalRunDetailEntity>>(), It.IsAny<CancellationToken>()))
                       .Returns(Task.CompletedTask);

            var mockBlobStorageApply = mockBlobStorage;
            mockBlobStorageApply.Setup(s => s.SetTagsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IDictionary<string, string>>(), It.IsAny<CancellationToken>()))
                                .Returns(Task.CompletedTask)
                                .Verifiable();

            var sut = new ExternalFileRegistrar(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockBlobStorage.Object,
                mockPolicyResolver.Object,
                mockRunRepo.Object);

            // Act
            var count = await sut.DiscoverAndRegisterAsync(tableId, runId, CancellationToken.None);

            // Assert
            Assert.Equal(blobs.Length, count);

            // Verify UpdateFilesAsync was called to insert initial rows
            mockFileRepo.Verify(r => r.UpdateFilesAsync(It.Is<IEnumerable<ArchivalFileEntity>>(l => l.Count() == blobs.Length), It.IsAny<CancellationToken>()), Times.Once);

            // Verify tags applied for each blob
            foreach (var b in blobs)
            {
                mockBlobStorage.Verify(s => s.SetTagsAsync(b.StorageAccountName, b.ContainerName, b.BlobPath, It.IsAny<IDictionary<string, string>>(), It.IsAny<CancellationToken>()), Times.Once);
            }

            // Verify run-details bulk insert called with same number of entries
            mockRunRepo.Verify(r => r.ArchivalRunDetailBulkInsertAsync(It.Is<IEnumerable<ArchivalRunDetailEntity>>(d => d.Count() == blobs.Length), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task DiscoverAndRegisterAsync_WhenSetTagsFails_BuffersFailedRunDetail_StillInsertsAllRunDetails()
        {
            // Arrange
            var tableId = 9;
            var runId = 303L;

            var tableConfig = MakeExternalTableConfig(tableId);

            var blobs = new[]
            {
                MakeBlob("external/systemB/2025/10/01/f1.ext"),
                MakeBlob("external/systemB/2025/10/02/f2.ext")
            };

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            mockTableRepo.Setup(r => r.GetWithRelatedAsync(tableId, It.IsAny<CancellationToken>()))
                         .ReturnsAsync(tableConfig);

            var mockBlobStorage = new Mock<IBlobStorageService>();
            mockBlobStorage.Setup(s => s.ListBlobsAsync(tableConfig.StorageAccountName, tableConfig.ContainerName, It.IsAny<string>(), It.IsAny<CancellationToken>()))
                           .ReturnsAsync(blobs);

            var mockFileRepo = new Mock<IArchivalFileRepository>();
            mockFileRepo.SetupSequence(r => r.GetByBlobPathsAsync(tableId, It.IsAny<IEnumerable<string>>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new List<ArchivalFileEntity>())
                        .ReturnsAsync(() =>
                            blobs.Select((b, i) => new ArchivalFileEntity
                            {
                                Id = i + 200,
                                TableConfigurationId = tableId,
                                BlobPath = b.BlobPath,
                                StorageAccountName = b.StorageAccountName,
                                ContainerName = b.ContainerName
                            }).ToList());

            mockFileRepo.Setup(r => r.GetFileExemptionDatesAsync(tableId, It.IsAny<IEnumerable<DateOnly>>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new HashSet<DateOnly>());

            mockFileRepo.Setup(r => r.UpdateFilesAsync(It.IsAny<IEnumerable<ArchivalFileEntity>>(), It.IsAny<CancellationToken>()))
                        .Returns(Task.CompletedTask);

            var mockPolicyResolver = new Mock<ILifecyclePolicyResolver>();
            mockPolicyResolver.Setup(p => p.ResolvePolicyForTableAsync(tableId, It.IsAny<CancellationToken>()))
                              .ReturnsAsync((tableConfig.FileLifecyclePolicy.ToDto(), tableConfig.FileLifecyclePolicy.AzurePolicyTag));

            // simulate SetTagsAsync failing for first blob, succeeding for second
            mockBlobStorage.Setup(s => s.SetTagsAsync("acct", "container", blobs[0].BlobPath, It.IsAny<IDictionary<string, string>>(), It.IsAny<CancellationToken>()))
                           .ThrowsAsync(new Exception("tagging failed"));
            mockBlobStorage.Setup(s => s.SetTagsAsync("acct", "container", blobs[1].BlobPath, It.IsAny<IDictionary<string, string>>(), It.IsAny<CancellationToken>()))
                           .Returns(Task.CompletedTask);

            var mockRunRepo = new Mock<IArchivalRunRepository>();
            mockRunRepo.Setup(r => r.ArchivalRunDetailBulkInsertAsync(It.IsAny<IEnumerable<ArchivalRunDetailEntity>>(), It.IsAny<CancellationToken>()))
                       .Returns(Task.CompletedTask)
                       .Verifiable();

            var sut = new ExternalFileRegistrar(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockBlobStorage.Object,
                mockPolicyResolver.Object,
                mockRunRepo.Object);

            // Act
            var count = await sut.DiscoverAndRegisterAsync(tableId, runId, CancellationToken.None);

            // Assert
            Assert.Equal(blobs.Length, count);

            // Ensure SetTags attempted for both blobs
            mockBlobStorage.Verify(s => s.SetTagsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IDictionary<string, string>>(), It.IsAny<CancellationToken>()), Times.Exactly(2));

            // Verify bulk insert of run details still called
            mockRunRepo.Verify(r => r.ArchivalRunDetailBulkInsertAsync(It.Is<IEnumerable<ArchivalRunDetailEntity>>(d => d.Count() == blobs.Length), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}