using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Application.Models;
using ArchivalSystem.Data;
using ArchivalSystem.Data.Entities;
using ArchivalSystem.Infrastructure;
using Moq;
using Xunit;

namespace ArchivalSystem.Infrastructure.Tests
{
    public class DbArchiverTests
    {
        private static ArchivalTableConfigurationDto MakeTableDto(int id, bool deleteFromSource = false)
            => new()
            {
                Id = id,
                DatabaseName = "db",
                SchemaName = "dbo",
                TableName = "t",
                AsOfDateColumn = "as_of",
                ExportMode = ExportMode.SelfManaged,
                StorageAccountName = "acct",
                ContainerName = "c",
                ArchivePathTemplate = "/{db}/{schema}/{table}/{yyyy}/{MM}/{dd}",
                DeleteFromSource = deleteFromSource
            };

        [Fact]
        public async Task ArchiveTableForDateAsync_Skips_WhenArchivalFileExists()
        {
            // Arrange
            var tc = MakeTableDto(1);
            var asOf = new DateTime(2025, 01, 01);
            var runId = 99L;

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockExporter = new Mock<ISourceExporter>();
            var mockDeleter = new Mock<ISourceDataDeleter>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<DbArchiver>>();

            mockFileRepo
                .Setup(r => r.ExistsForTableDateAsync(tc.Id, asOf, DateType.EOD, It.IsAny<CancellationToken>()))
                .ReturnsAsync(true);

            var sut = new DbArchiver(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockExporter.Object,
                mockDeleter.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            await sut.ArchiveTableForDateAsync(tc, asOf, DateType.EOD, runId, CancellationToken.None);

            // Assert
            mockExporter.Verify(x => x.ExportAsync(It.IsAny<ArchivalTableConfigurationDto>(), It.IsAny<DateTime>(), It.IsAny<DateType>(), It.IsAny<long>(), It.IsAny<CancellationToken>()), Times.Never);
            mockRunRepo.Verify(r => r.LogDetailAsync(runId, tc.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Skipped, It.IsAny<long?>(), It.IsAny<long?>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task ArchiveTableForDateAsync_Skips_WhenTableExempt()
        {
            // Arrange
            var tc = MakeTableDto(2);
            var asOf = new DateTime(2025, 02, 02);
            var runId = 100L;

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockExporter = new Mock<ISourceExporter>();
            var mockDeleter = new Mock<ISourceDataDeleter>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<DbArchiver>>();

            mockFileRepo
                .Setup(r => r.ExistsForTableDateAsync(tc.Id, asOf, DateType.EOD, It.IsAny<CancellationToken>()))
                .ReturnsAsync(false);
            mockFileRepo
                .Setup(r => r.IsTableExemptAsync(tc.Id, asOf, It.IsAny<CancellationToken>()))
                .ReturnsAsync(true);

            var sut = new DbArchiver(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockExporter.Object,
                mockDeleter.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            await sut.ArchiveTableForDateAsync(tc, asOf, DateType.EOD, runId, CancellationToken.None);

            // Assert
            mockExporter.Verify(x => x.ExportAsync(It.IsAny<ArchivalTableConfigurationDto>(), It.IsAny<DateTime>(), It.IsAny<DateType>(), It.IsAny<long>(), It.IsAny<CancellationToken>()), Times.Never);
            // No run detail for skip in this path (implementation returns early), ensure DeleteAsync not called
            mockDeleter.Verify(d => d.DeleteAsync(It.IsAny<ArchivalTableConfigurationDto>(), It.IsAny<DateTime>(), It.IsAny<long>(), It.IsAny<long>(), It.IsAny<DateType>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task ArchiveTableForDateAsync_ExportsAndRegistersAndDeletes_WhenRowsExportedAndDeleteEnabled()
        {
            // Arrange
            var tc = MakeTableDto(3, deleteFromSource: true);
            var asOf = new DateTime(2025, 03, 03);
            var runId = 200L;

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockExporter = new Mock<ISourceExporter>();
            var mockDeleter = new Mock<ISourceDataDeleter>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<DbArchiver>>();

            mockFileRepo.Setup(r => r.ExistsForTableDateAsync(tc.Id, asOf, DateType.EOD, It.IsAny<CancellationToken>())).ReturnsAsync(false);
            mockFileRepo.Setup(r => r.IsTableExemptAsync(tc.Id, asOf, It.IsAny<CancellationToken>())).ReturnsAsync(false);

            var blobInfo = new ArchivalBlobInfo
            {
                StorageAccountName = tc.StorageAccountName,
                ContainerName = tc.ContainerName,
                BlobPath = "p",
                ETag = "etag",
                ContentType = "application/octet-stream",
                ContentLength = 12345
            };

            var metrics = new ParquetExportMetrics { RowCount = 42, ColumnCount = 5, SizeBytes = 12345 };

            var exportResult = new ParquetExportResult
            {
                BlobInfo = blobInfo,
                Metrics = metrics
            };

            mockExporter
                .Setup(e => e.ExportAsync(tc, asOf, DateType.EOD, runId, It.IsAny<CancellationToken>()))
                .ReturnsAsync(exportResult);

            mockFileRepo
                .Setup(r => r.UpsertFileAsync(It.IsAny<ArchivalFileEntity>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((ArchivalFileEntity f, CancellationToken ct) => { f.Id = 77; return f; });

            mockDeleter
                .Setup(d => d.DeleteAsync(tc, asOf, metrics.RowCount, runId, DateType.EOD, It.IsAny<CancellationToken>()))
                .ReturnsAsync(metrics.RowCount);

            var sut = new DbArchiver(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockExporter.Object,
                mockDeleter.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            await sut.ArchiveTableForDateAsync(tc, asOf, DateType.EOD, runId, CancellationToken.None);

            // Assert
            mockExporter.Verify(e => e.ExportAsync(tc, asOf, DateType.EOD, runId, It.IsAny<CancellationToken>()), Times.Once);
            mockFileRepo.Verify(r => r.UpsertFileAsync(It.Is<ArchivalFileEntity>(f =>
                f.TableConfigurationId == tc.Id &&
                f.BlobPath == blobInfo.BlobPath &&
                f.Etag == blobInfo.ETag &&
                f.RowCount == metrics.RowCount), It.IsAny<CancellationToken>()), Times.Once);

            mockDeleter.Verify(d => d.DeleteAsync(tc, asOf, metrics.RowCount, runId, DateType.EOD, It.IsAny<CancellationToken>()), Times.Once);
            mockRunRepo.Verify(r => r.LogDetailAsync(runId, tc.Id, asOf, DateType.EOD, RunDetailPhase.Export, RunDetailStatus.Success, It.IsAny<long?>(), It.IsAny<long?>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task ArchiveTableForDateAsync_DoesNotDelete_WhenNoRowsExported()
        {
            // Arrange
            var tc = MakeTableDto(4, deleteFromSource: true);
            var asOf = new DateTime(2025, 04, 04);
            var runId = 300L;

            var mockTableRepo = new Mock<IArchivalTableConfigurationRepository>();
            var mockFileRepo = new Mock<IArchivalFileRepository>();
            var mockExporter = new Mock<ISourceExporter>();
            var mockDeleter = new Mock<ISourceDataDeleter>();
            var mockRunRepo = new Mock<IArchivalRunRepository>();
            var mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<DbArchiver>>();

            mockFileRepo.Setup(r => r.ExistsForTableDateAsync(tc.Id, asOf, DateType.EOD, It.IsAny<CancellationToken>())).ReturnsAsync(false);
            mockFileRepo.Setup(r => r.IsTableExemptAsync(tc.Id, asOf, It.IsAny<CancellationToken>())).ReturnsAsync(false);

            var exportResult = new ParquetExportResult
            {
                BlobInfo = new ArchivalBlobInfo { BlobPath = "p2", ETag = "e", ContentLength = 0 },
                Metrics = new ParquetExportMetrics { RowCount = 0, ColumnCount = 0, SizeBytes = 0 }
            };

            mockExporter
                .Setup(e => e.ExportAsync(tc, asOf, DateType.EOD, runId, It.IsAny<CancellationToken>()))
                .ReturnsAsync(exportResult);

            var sut = new DbArchiver(
                mockTableRepo.Object,
                mockFileRepo.Object,
                mockExporter.Object,
                mockDeleter.Object,
                mockRunRepo.Object,
                mockLogger.Object);

            // Act
            await sut.ArchiveTableForDateAsync(tc, asOf, DateType.EOD, runId, CancellationToken.None);

            // Assert
            mockDeleter.Verify(d => d.DeleteAsync(It.IsAny<ArchivalTableConfigurationDto>(), It.IsAny<DateTime>(), It.IsAny<long>(), It.IsAny<long>(), It.IsAny<DateType>(), It.IsAny<CancellationToken>()), Times.Never);
            mockFileRepo.Verify(r => r.UpsertFileAsync(It.IsAny<ArchivalFileEntity>(), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}