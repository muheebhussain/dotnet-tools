﻿using System;
using System.Threading;
using System.Threading.Tasks;
using ArchivalSystem.Abstraction;
using ArchivalSystem.Application;
using ArchivalSystem.Application.Interfaces;
using ArchivalSystem.Data;
using ArchivalSystem.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

internal class Program
{
    public static async Task<int> Main(string[] args)
    {
        try
        {
            // Usage: ArchivalJob --tableConfigId 42
            if (args.Length < 2 || !string.Equals(args[0], "--tableConfigId", StringComparison.OrdinalIgnoreCase))
            {
                Console.Error.WriteLine("Usage: ArchivalJob --tableConfigId <id>");
                return 1;
            }

            if (!int.TryParse(args[1], out var tableConfigId))
            {
                Console.Error.WriteLine("Invalid tableConfigId argument.");
                return 1;
            }

            using var cts = new CancellationTokenSource();

            var host = Host.CreateDefaultBuilder()
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: false);
                    // Add environment variables, KeyVault, etc. as needed
                })
                .ConfigureServices((ctx, services) =>
                {
                    var configuration = ctx.Configuration;

                    // Archival metadata DB
                    services.AddDbContext<ArchivalDbContext>(options =>
                        options.UseSqlServer(configuration.GetConnectionString("ArchivalDb")));

                    // Infrastructure
                    //services.AddSingleton<IConnectionProvider, Connec>();
                    //services.AddScoped<ITableDataProvider, SqlTableDataProvider>();
                    services.AddScoped<IBlobStorageService, BlobStorageService>();
                    services.AddScoped<IParquetExportService, ParquetExportService>();

                    // Core services
                    services.AddScoped<IRetentionService, RetentionService>();
                    services.AddScoped<ISourceExporter, SourceExporter>();
                    //services.AddScoped<IBlobArchivalService, BlobArchivalService>();
                    services.AddScoped<ISourceDataDeleter, SourceDataDeleter>();
                    services.AddScoped<IDbArchiver, DbArchiver>();
                    services.AddScoped<IExternalFileRegistrar, ExternalFileRegistrar>();
                    services.AddScoped<IArchivalRunRepository, ArchivalRunRepository>();
                    services.AddScoped<ISelfManagedTableArchiver, SelfManagedTableArchiver>();
                    services.AddScoped<IExternalTableArchiver, ExternalTableArchiver>();

                    // Combined per-table executor
                    services.AddScoped<IArchivalExecutor, ArchivalExecutor>();
                })
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.AddConsole();
                })
                .Build();

            using (host)
            {
                await host.StartAsync(cts.Token);

                var executor = host.Services.GetRequiredService<IArchivalExecutor>();
                await executor.ExecuteAsync(tableConfigId, cts.Token);

                await host.StopAsync(cts.Token);
            }

            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("Fatal error in per-table archival job: " + ex);
            return 1;
        }
    }
}
