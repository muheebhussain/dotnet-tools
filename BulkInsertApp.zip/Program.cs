using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace BulkInsertApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
            var logger = loggerFactory.CreateLogger<DataProcessor>();

            var dataProcessor = new DataProcessor(logger);
            await dataProcessor.ProcessProductJobAsync();
        }
    }
}
