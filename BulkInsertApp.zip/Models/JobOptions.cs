using System;

namespace BulkInsertApp
{
    public class JobOptions
    {
        public int Id { get; set; }
        public DateTime BusinessDate { get; set; }
        public bool Rerun { get; set; }
    }

    public class ProductJobOptions : JobOptions
    {
        public string FilePath { get; set; }
    }
}
