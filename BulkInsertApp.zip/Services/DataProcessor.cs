using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace BulkInsertApp
{
    public class DataProcessor
    {
        private readonly ILogger<DataProcessor> _logger;

        public DataProcessor(ILogger<DataProcessor> logger)
        {
            _logger = logger;
        }

        public async Task ProcessProductJobAsync()
        {
            var productJobOptions = new ProductJobOptions
            {
                Id = 1,
                BusinessDate = DateTime.Now,
                Rerun = true,
                FilePath = "path_to_product_file.txt"
            };

            var extractor = new ProductFileExtractor(_logger);
            await extractor.ExtractDataAsync(productJobOptions);
        }
    }
}
