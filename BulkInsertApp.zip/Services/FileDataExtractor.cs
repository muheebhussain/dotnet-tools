using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace BulkInsertApp
{
    public abstract class FileDataExtractor<T> where T : class
    {
        private readonly ILogger<FileDataExtractor<T>> _logger;

        protected FileDataExtractor(ILogger<FileDataExtractor<T>> logger)
        {
            _logger = logger;
        }

        public async Task ExtractDataAsync(JobOptions jobOptions)
        {
            if (jobOptions.Rerun)
            {
                _logger.LogInformation($"Re-run requested for job {jobOptions.Id} on {jobOptions.BusinessDate}.");
                await DeleteExistingRecordsAsync(jobOptions.Id, jobOptions.BusinessDate);
            }

            var entities = new List<T>();

            if (jobOptions is ProductJobOptions productJobOptions)
            {
                using (var streamReader = new StreamReader(productJobOptions.FilePath))
                {
                    string line;
                    while ((line = await streamReader.ReadLineAsync()) != null)
                    {
                        var columns = line.Split('\t');
                        var entity = MapToEntity(columns);

                        entities.Add(entity);

                        if (entities.Count >= 1000)
                        {
                            await BulkInsertEntitiesAsync(entities);
                            _logger.LogInformation($"Bulk inserted 1000 records for job {jobOptions.Id}.");
                            entities.Clear();
                        }
                    }

                    if (entities.Count > 0)
                    {
                        await BulkInsertEntitiesAsync(entities);
                        _logger.LogInformation($"Bulk inserted remaining {entities.Count} records for job {jobOptions.Id}.");
                    }
                }
            }
        }

        protected abstract T MapToEntity(string[] columns);

        protected async Task BulkInsertEntitiesAsync(List<T> entities)
        {
            using (var context = new MyDbContext())
            {
                await context.BulkInsertAsync(entities);
            }
        }

        protected async Task DeleteExistingRecordsAsync(int id, DateTime businessDate)
        {
            using (var context = new MyDbContext())
            {
                var recordsToDelete = context.Set<T>().Where(e => EF.Property<int>(e, "Id") == id && EF.Property<DateTime>(e, "BusinessDate") == businessDate);
                context.Set<T>().RemoveRange(recordsToDelete);
                await context.SaveChangesAsync();

                _logger.LogInformation($"Deleted existing records for Id {id} and BusinessDate {businessDate}.");
            }
        }
    }
}
