using BulkInsertApp.Models;
using Microsoft.Extensions.Logging;

namespace BulkInsertApp
{
    public class ProductFileExtractor : FileDataExtractor<Product>
    {
        public ProductFileExtractor(ILogger<ProductFileExtractor> logger) : base(logger)
        {
        }

        protected override Product MapToEntity(string[] columns)
        {
            return new Product
            {
                Date = columns[0].ParseDate(),
                Name = columns[1],
                Price = columns[2].ParseDouble()
            };
        }
    }
}
